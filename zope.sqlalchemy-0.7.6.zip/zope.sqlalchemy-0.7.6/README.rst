|Build status|_

.. |Build status| image:: https://travis-ci.org/zopefoundation/zope.sqlalchemy.png?branch=master
.. _Build status: https://travis-ci.org/zopefoundation/zope.sqlalchemy

See src/zope/sqlalchemy/README.txt
