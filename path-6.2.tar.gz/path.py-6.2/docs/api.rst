===
API
===

.. automodule:: path
   :members:
   :undoc-members:
