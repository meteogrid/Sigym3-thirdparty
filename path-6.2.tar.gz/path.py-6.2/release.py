# path.py uses jaraco.packaging.release for releases
files_with_versions = 'path.py',
