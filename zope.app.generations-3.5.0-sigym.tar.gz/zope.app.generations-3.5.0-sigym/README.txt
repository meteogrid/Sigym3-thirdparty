Generations are a way of updating objects in the database when the application
schema changes.  An application schema is essentially the structure of data,
the structure of classes in the case of ZODB or the table descriptions in the
case of a relational database.
