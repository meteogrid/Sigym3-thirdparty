def my_view(context, request):
    return {'project':'tutorial'}
