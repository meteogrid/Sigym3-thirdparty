.. _renderers_module:

:mod:`repoze.bfg.renderers`
---------------------------

.. module:: repoze.bfg.renderers

.. autofunction:: get_renderer

.. autofunction:: render

.. autofunction:: render_to_response

