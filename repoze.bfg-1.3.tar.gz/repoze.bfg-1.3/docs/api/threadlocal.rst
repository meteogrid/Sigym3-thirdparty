.. _threadlocal_module:

:mod:`repoze.bfg.threadlocal`
-------------------------------

.. automodule:: repoze.bfg.threadlocal

   .. autofunction:: get_current_request()

   .. autofunction:: get_current_registry()

