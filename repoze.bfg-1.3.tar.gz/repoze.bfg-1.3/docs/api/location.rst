.. _location_module:

:mod:`repoze.bfg.location`
--------------------------

.. automodule:: repoze.bfg.location

  .. autofunction:: lineage

  .. autofunction:: inside


