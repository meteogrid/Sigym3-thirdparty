.. _exceptions_module:

:mod:`repoze.bfg.exceptions`
----------------------------

.. automodule:: repoze.bfg.exceptions

  .. autoclass:: Forbidden

  .. autoclass:: NotFound

  .. autoclass:: ConfigurationError

  .. autoclass:: URLDecodeError
