class MyModel(object):
    pass

root = MyModel()

def get_root(request):
    return root
