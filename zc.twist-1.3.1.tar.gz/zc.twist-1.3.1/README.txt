Mixing Twisted and ZODB
