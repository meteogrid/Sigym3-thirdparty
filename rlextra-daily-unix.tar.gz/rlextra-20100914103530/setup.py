#Copyright ReportLab Europe Ltd. 2000-2008
#see license.txt for license details
__version__=''' $Id: setup.py 37219 2010-09-07 10:25:47Z rgbecker $ '''
import os, sys, glob, ConfigParser, shutil
platform = sys.platform
pjoin = os.path.join
abspath = os.path.abspath
isfile = os.path.isfile
isdir = os.path.isdir
dirname = os.path.dirname
basename = os.path.basename
if __name__=='__main__':
    pkgDir=dirname(sys.argv[0])
else:
    pkgDir=dirname(__file__)
if not pkgDir:
    pkgDir=os.getcwd()
elif not os.path.isabs(pkgDir):
    pkgDir=os.path.abspath(pkgDir)

import distutils
from distutils.core import setup, Extension
from distutils import sysconfig
#from distutils.dist import Distribution
#import py_compile
#class ImpureDist(Distribution):
#   def __init__(self,attrs):
#       Distribution.__init__(self,attrs)
#       print '############################ ImpureDist initialized'
#   def has_ext_modules(self):
#       return True

# from Zope - App.Common.package_home
def package_home(globals_dict):
    __name__=globals_dict['__name__']
    m=sys.modules[__name__]
    r=os.path.split(m.__path__[0])[0]
    return r

def get_version():
    #determine Version

    #first try source
    FN = pjoin(pkgDir,'rlextra','__init__')
    try:
        for l in open(pjoin(FN+'.py'),'r').readlines():
            if l.startswith('Version'):
                exec l.strip()
                return Version
    except:
        pass

    #don't have source, try import
    import imp
    for desc in ('.pyc', 'rb', 2), ('.pyo', 'rb', 2):
        try:
            fn = FN+desc[0]
            f = open(fn,desc[1])
            m = imp.load_module('rlextra',f,fn,desc)
            return m.Version
        except:
            pass
    raise ValueError('Cannot determine RLExtra Version')

class config:
    def __init__(self):
        try:
            self.parser = ConfigParser.RawConfigParser()
            self.parser.read(pjoin(pkgDir,'setup.cfg'))
        except:
            self.parser = None

    def __call__(self,sect,name,default=None):
        try:
            return self.parser.get(sect,name)
        except:
            return default
config = config()

#this code from /FBot's PIL setup.py
def aDir(P, d, x=None):
    if d and os.path.isdir(d) and d not in P:
        if x is None:
            P.append(d)
        else:
            P.insert(x, d)

def pfxJoin(pfx,*N):
    R=[]
    for n in N:
        R.append(os.path.join(pfx,n))
    return R

INFOLINES=[]
def infoline(t):
    print t
    INFOLINES.append(t)

try:
    set
except:
    class set(list):
        def add(self,e):
            if e not in self:
                self.append(e)

def expandFiles(baseDir,F):
    R = set([])
    for f in F:
        f = f.replace('/',os.sep)
        if '*' in f or '?' in f:
            pat = pjoin(baseDir,f)
            x = len(pat)-len(f)
            for fm in glob.glob(pat):
                R.add(fm[x:])
        else:
            R.add(f)
    return list(R)

RLXDIR=pjoin(pkgDir,'rlextra')
rlextra_files= expandFiles(RLXDIR,
        ([]
        +[pjoin('rml2pdf',x) for x in '''00README.txt dynamic_rml.dtd rml.dtd'''.split()]
        +[pjoin('rml2pdf','test',x) for x in '''*.afm *.pfb *.pdf *.png *.xls *.gif *.xml *.rml'''.split()]
        +[pjoin('rml2pdf','demos',x) for x in '''*.jpg *.py *.rml *.gif'''.split()]
        +[pjoin('rml2pdf','doc',x) for x in '''*.rml *.py logo.pdf readme.txt *.prep'''.split()]
        +[pjoin('rml2pdf','doc','images',x) for x in '''*.gif *.jpg'''.split()]
        +'''examples/currency/currency.dtd examples/currency/*.py examples/currency/*.xml examples/currency/readme.txt'''.split()
        +'''examples/ers_portfolio/*.txt examples/ers_portfolio/*.py examples/ers_portfolio/aebl____.* examples/ers_portfolio/aew_____.* examples/ers_portfolio/ers_portfolio.* examples/ers_portfolio/eurosbe2.* examples/ers_portfolio/*.prep examples/ers_portfolio/*.xml examples/graphics/gpie.cgi'''.split()
        +'''examples/graphics/*.txt examples/graphics/*.xml examples/graphics/*.sql examples/graphics/*.zip examples/graphics/*.csv'''.split()
        +'''examples/invoice/*.txt examples/invoice/*.py examples/invoice/invoice.* examples/invoice/*.py examples/invoice/*.prep examples/invoice/*.xml'''.split()
        +'''examples/shakespeare/*.dtd examples/shakespeare/*.py examples/shakespeare/shakespeare.1.10.xml/j_caesar.xml'''.split()
        +'''examples/taxform/00readme.txt examples/taxform/f1040.pdf examples/taxform/f1040ez* examples/taxform/f1040sab.pdf examples/taxform/*.py examples/taxform/rml_1_0.dtd'''.split()
        +'''examples/travelplan/*.xml examples/travelplan/res/*.ttf examples/travelplan/res/*.gif'''.split()
        +'''examples/travelplan/res/*.gif examples/travelplan/res/*.pfb examples/travelplan/res/*.ttf examples/travelplan/res/*.afm examples/travelplan/res/*.jpg examples/travelplan/rsrc/*.gif examples/travelplan/rsrc/*.jpg examples/travelplan/rsrc/*.js examples/travelplan/rsrc/*.css examples/travelplan/*.xml examples/travelplan/*.prep examples/travelplan/*.txt examples/travelplan/views/*.prep examples/travelplan/views/*.html'''.split()
        +'''examples/web_frameworks/django/reportlab_rml_sample/*.py examples/web_frameworks/django/reportlab_rml_sample/*.rml examples/web_frameworks/django/reportlab_rml_sample/templates/*.html examples/web_frameworks/django/README.TXT examples/web_frameworks/dotnet/ReportLabRMLSample/*.config examples/web_frameworks/dotnet/ReportLabRMLSample/*.vb examples/web_frameworks/dotnet/ReportLabRMLSample/*.vbproj.* examples/web_frameworks/dotnet/ReportLabRMLSample/project/*.vb examples/web_frameworks/dotnet/ReportLabRMLSample/project/*.settings examples/web_frameworks/dotnet/ReportLabRMLSample/project/*.myapp examples/web_frameworks/dotnet/ReportLabRMLSample/project/*.resx examples/web_frameworks/dotnet/ReportLabRMLSample/*.rml examples/web_frameworks/dotnet/ReportLabRMLSample/*.aspx examples/web_frameworks/dotnet/*.TXT'''.split()
        +[pjoin('pageCatcher','test',x) for x in '''*.pdf'''.split()]
        +[pjoin('pageCatcher','demos',x) for x in '''*.py *.bat *.pdf'''.split()]
        +[pjoin('pageCatcher',x) for x in '''00README.txt PageCatchIntro.html PageCatchIntro.rml replogo.bmp testfile.pdf'''.split()]
        +[pjoin('preppy','test',x) for x in '''*.txt *.prep'''.split()]
        +[pjoin('preppy','test',x) for x in '''*.prep *.html *.rml'''.split()]
        +[pjoin('radxml','doc',x) for x in '''*.txt *.html'''.split()]
        +[pjoin('radxml','samples',x) for x in '''*.txt *.py *.zip *.xml *.svg *.dtd *.rml'''.split()]
        +[pjoin('radxml','test',x) for x in ['00readme.txt']
            +[pjoin('xhtml2rml',y) for y in
                [pjoin('fonts',z) for z in '''LT_50331.*'''.split()]
                +'''*.html *.py *.html'''.split()]]
        +[pjoin('security',x) for x in ['*.txt'] +
            [pjoin('doc',y) for y in '''*.gif *.rml'''.split()]]
        +[pjoin('graphics','guiedit','sample.csv')]
        +[pjoin('graphics','doc',x) for x in (
                ('''*.data *.txt *.doc *.rml *.py'''.split())
                +[pjoin('images',y) for y in '''*.gif *.PNG'''.split()]
                +[pjoin('samples',y) for y in '''*.py'''.split()]
            )
            ]
        ))
PYC=[pjoin('rlextra',x) for x in (
    pjoin('rml2pdf','rml2pdf.py'),
    pjoin('pageCatcher','pageCatcher.py'),
    pjoin('utils','zipapp.py'),
    pjoin('utils','ubold.py'),
    pjoin('graphics','guiedit','datacharts.py'),
    )]

scriptsPath=pjoin(pkgDir,'scripts')
def makeScript(pkgName,modName):
    try:
        bat=sys.platform in ('win32','amd64')
        scriptPath=os.path.join(scriptsPath+(bat and '.bat' or ''),modName)
        exePath=sys.executable
        f = open(scriptPath,'w')
        try:
            if bat:
                text = '@echo off\n"%s" -m "%s.%s" %%*\n' % (exePath,pkgName,modName)
            else:
                text = '#!/bin/sh\nexec "%s" -m "%s.%s" $*\n' % (exePath,pkgName,modName)
            f.write(text)
        finally:
            f.close()
    except:
        print 'script for %s.%s not created or erroneous' % (pkgName, modName)
        import traceback
        traceback.print_exc(file=sys.stdout)
        return None
    print 'Created "%s"' % scriptPath
    return scriptPath

def main():
    #test to see if we've a special command
    if 'tests' in sys.argv or 'tests-preinstall' in sys.argv:
        if len(sys.argv)!=2:
            raise ValueError('tests commands may only be used alone')
        cmd = sys.argv[-1]
        PYTHONPATH=[pkgDir]
        if cmd=='tests-preinstall':
            PYTHONPATH.insert(0,pjoin(pkgDir,'src'))
        os.environ['PYTHONPATH']=os.pathsep.join(PYTHONPATH)
        os.chdir(RLXDIR)
        os.system("%s testall.py" % sys.executable)
        return
    cwd = os.getcwd()

    scripts = []
    if sys.version_info[:2]>=(2,5):
        if not isdir(scriptsPath): os.makedirs(scriptsPath)
        scripts.extend(filter(None,[
                makeScript('rlextra.rml2pdf','rml2pdf'),
                makeScript('rlextra.preppy','preppy'),
                makeScript('rlextra.pageCatcher','pageCatcher'),
                makeScript('rlextra.pageCatcher','pdfexplorer'),
                makeScript('rlextra.utils','zipapp'),
                ]))

    SPECIAL_PACKAGE_DATA = {}
    LIBS = []
    LIBRARIES=[]
    EXT_MODULES = []
    srcDir = dirname(RLXDIR)

    #building pyRXP
    if sys.platform=="win32":
        LIBS=['wsock32']
    elif sys.platform=="sunos5":
        LIBS=['nsl', 'socket', 'dl']
    elif sys.platform=="aix4":
        LIBS=['nsl_r', 'dl']
    else:
        LIBS=[]

    rxpFiles = ('xmlparser.c', 'url.c', 'charset.c', 'string16.c', 'ctype16.c', 
                'dtd.c', 'input.c', 'stdio16.c', 'system.c', 'hash.c', 
                'version.c', 'namespaces.c', 'http.c', 'nf16check.c', 'nf16data.c')
    pyRXPDir=pjoin(pkgDir,'pyRXP')
    RXPLIBSOURCES=[]
    pyRXP_c = os.path.join(pyRXPDir,'pyRXP.c')
    RXPDIR=pjoin(pyRXPDir,'rxp')
    RXPLIBSOURCES= [os.path.join(RXPDIR,f) for f in rxpFiles]
    EXT_MODULES =   [Extension( 'pyRXP',
                                [pyRXP_c]+RXPLIBSOURCES,
                                include_dirs=[RXPDIR],
                                define_macros=[('CHAR_SIZE', 8),],
                                library_dirs=[],
                                # libraries to link against
                                libraries=LIBS,
                                ),
                            ]
    # We copy the rxp source - we need to build it a second time for uRXP
    # with different compile time flags
    RXPUDIR=os.path.join('build','_pyRXPU')
    if os.path.exists(RXPUDIR):
        shutil.rmtree(RXPUDIR)
    os.makedirs(RXPUDIR)
    uRXPLIBSOURCES=[]
    for f in rxpFiles:
        uRXP_file = os.path.join(RXPUDIR,f.replace('.','U.'))
        try:
            shutil.copy2(os.path.join(RXPDIR,f),uRXP_file)
        except:
            print RXPDIR, f, uRXP_file
            raise
        uRXPLIBSOURCES.append(uRXP_file)
    pyRXPU_c = os.path.join(RXPUDIR,'pyRXPU.c')
    shutil.copy2(pyRXP_c,pyRXPU_c)
    uRXPLIBSOURCES.append(pyRXPU_c)
    EXT_MODULES.append(Extension('pyRXPU',
                    uRXPLIBSOURCES,
                    include_dirs=[RXPDIR],
                    define_macros=[('CHAR_SIZE', 16),],
                    library_dirs=[],
                    # libraries to link against
                    libraries=LIBS,
                    ))

    #copy some special case files into place so package_data will treat them properly
    PACKAGE_DIR = {'rlextra': RLXDIR}
    for fn,dst in SPECIAL_PACKAGE_DATA.iteritems():
        shutil.copyfile(fn,pjoin(PACKAGE_DIR['rlextra'],dst))
        rlextra_files.append(dst)

    for pyc in PYC:
        n = len(os.path.split(pyc)) #we'll drop the rlextra
        pat = os.path.splitext(pjoin(pkgDir,pyc))[0]+('_%d%d.py[co]'%sys.version_info[:2])
        F = glob.glob(pat)
        if not F:
            print '!!!!! no compiled files match pattern %r' % pat
        rlextra_files.extend([pjoin(*(os.path.split(f)[-n:])) for f in F])

    try:
        setup(
            name="rlextra",
            version=get_version(),
            license="BSD license (see license.txt for details), Copyright (c) 2000-2010, ReportLab Inc.",
            description="The Reportlab Extra Toolkit",
            long_description="""The ReportLab Extra Toolkit. Python library for generating PDFs and graphics.""",

            author="Robinson, Watters, Lee, Precedo, Becker and many more...",
            author_email="info@reportlab.com",
            url="http://www.reportlab.com/",
            packages=[
                    'rlextra',
                    'rlextra.pageCatcher',
                    'rlextra.pageCatcher.test',
                    'rlextra.rml2pdf',
                    'rlextra.rml2pdf.test',
                    'rlextra.security',
                    'rlextra.radxml',
                    'rlextra.utils',
                    'rlextra.graphics',
                    'rlextra.graphics.guiedit',
                    'rlextra.preppy',
                    'rlextra.preppy.test',
                    'rlextra.thirdparty',
                    'rlextra.thirdparty.xlrd',
                    'rlextra.thirdparty.pyPdf',
                    'rlextra.test',
                    'rlextra.examples',
                    'rlextra.examples.graphics',
                    'rlextra.examples.travelplan',
                    ],
            package_dir = PACKAGE_DIR,
            package_data = {'rlextra': rlextra_files},
            libraries = LIBRARIES,
            ext_modules =   EXT_MODULES,
            scripts=scripts,
            )
        print
        print '########## SUMMARY INFO #########'
        print '\n'.join(INFOLINES)
    finally:
        for dst in SPECIAL_PACKAGE_DATA.itervalues():
            os.remove(pjoin(PACKAGE_DIR['reportlab'],dst))
            reportlab_files.remove(dst)

if __name__=='__main__':
    main()
