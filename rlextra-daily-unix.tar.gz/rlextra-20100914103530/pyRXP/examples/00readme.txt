This file accompanies the initial release of pyRXP.
See PyRXP_Documentation.pdf for details.

pyRXP and RXP are under the GNU General Public Licence.
RXP was written by Richard Tobin at the Language Technology Group, 
Human Communication Research Centre, University of Edinburgh and
is copyright 

PyRXP was written by Robin Becker at ReportLab.