extern char *rxp_version_string;
