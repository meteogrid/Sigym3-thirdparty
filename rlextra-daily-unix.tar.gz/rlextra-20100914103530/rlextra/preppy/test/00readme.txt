Execute check_basics.py.  This requires
PyUnit's unittest.py which is in reportlab.test.
