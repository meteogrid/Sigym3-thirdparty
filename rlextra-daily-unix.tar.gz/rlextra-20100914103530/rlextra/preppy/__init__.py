#copyright ReportLab Inc. 2001-2006
#see license.txt for license details
#history www.reportlab.co.uk/rl-cgi/viewcvs.cgi/rlextra/rml2pdf/__init__.py
