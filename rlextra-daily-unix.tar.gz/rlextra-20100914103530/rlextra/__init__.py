#copyright ReportLab Inc. 2000-2006
#see license.txt for license details
#history www.reportlab.co.uk/rl-cgi/viewcvs.cgi/rlextra/__init__.py
Version="2.4.20100914103530"
__version__=''' $Id: __init__.py 35883 2010-01-20 14:46:46Z damian $ '''

import sys

if sys.version_info[0:2] < (2, 3):
    warning = """The trunk of rlextra requires Python 2.3 or higher.
    2.4 is preferred and we will be using 2.4 features henceforth,
    especially in the higher-level frameworks.
    Any older applications should either use released versions beginning
    with 1.x (e.g. 1.20.x), or check out this branch (17 May 2005) which
    is mostly 2.1-compatible.  
     https://www.reportlab.co.uk/svn/private/branches/python21-stable
    """
    raise ImportError("rlextra needs Python 2.3 or higher", warning)
