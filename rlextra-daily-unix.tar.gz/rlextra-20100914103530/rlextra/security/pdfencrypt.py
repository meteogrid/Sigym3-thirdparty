#copyright ReportLab Europe Limited. 2000-2006
#see license.txt for license details
__version__=''' $Id: pdfencrypt.py 32605 2009-01-02 17:11:46Z jonas $ '''
__doc__="""Script stub for pdfencryption.

This can be shipped in plain mode outside of any encrypted archives.
"""
from reportlab.lib.pdfencrypt import *

if __name__ == '__main__':
    main()
