import logging
from django.core.management.base import NoArgsCommand
from rlextra.thirdparty.mailer.models import Message

class Command(NoArgsCommand):
    help = 'Attempt to resend any deferred mail.'
    
    def handle_noargs(self, **options):
        logging.basicConfig(level=logging.ERROR, format="%(message)s")
        count = Message.objects.retry_deferred() # @@@ new_priority not yet supported
        logging.info("%s message(s) retried" % count)
