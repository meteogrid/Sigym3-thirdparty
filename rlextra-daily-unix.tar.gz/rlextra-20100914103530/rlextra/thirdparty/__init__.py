#Copyright ReportLab Europe Ltd. 2000-2004
#see license.txt for license details
#history www.reportlab.co.uk/rl-cgi/viewcvs.cgi/rlextra/thirdparty/__init__.py
__version__=''' $Id: __init__.py 34437 2009-07-01 12:18:09Z damian $ '''
# The thirdparty package exists to allow us to have other packages in a standard location
# eg we can do
#from rlextra.thirdparty.rlextra.thirdparty import xlrd
