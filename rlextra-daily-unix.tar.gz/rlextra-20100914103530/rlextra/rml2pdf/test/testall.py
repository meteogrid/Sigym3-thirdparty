"""Tests for Report Markup Language
"""
import os, sys, glob
import unittest
from reportlab.lib.testutils import setOutDir,SecureTestCase
from rlextra.rml2pdf import rml2pdf

class RMLFunctionalTestCase(unittest.TestCase):
    """Tests for the behaviour of the go() API"""
    def setUp(self):
        #SecureTestCase.__init__(self)
        self.startDir = os.getcwd()
        self.rmlDir = os.path.dirname(rml2pdf.__file__)
        os.chdir(self.rmlDir)

    def tearDown(self):
        os.chdir(self.startDir)

    def testSimpleDocReturnsCanvasParameters(self):
        os.chdir('doc')
        rmlText = open('example_1.rml').read()
        returned = rml2pdf.go(rmlText)
        assert isinstance(returned, rml2pdf.CanvasParameters)

    def testStoryDocReturnsDocTemplate(self):
        os.chdir('doc')
        rmlText = open('example_2.rml').read()
        returned = rml2pdf.go(rmlText)
        assert isinstance(returned, rml2pdf.RMLDocTemplate)

    def testProgressCallBack(self):
        os.chdir('test')

        collector = []
        def progress(str, num, collector=collector):
            collector.append((str, num))

        # first do a story-document
        rmlText = open('test_008_tables.rml').read();
        returned = rml2pdf.go(rmlText, progressCallBack=progress)
        assert collector[0] == ('STARTED',0)
        assert len(collector) > 50    # this doc has 65 flowables
        assert collector[-1] == ('FINISHED',0)
        #import pprint
        #pprint.pprint(collector)
        # now do a pageDrawing document; should do one progress call
        # per page
        collector2 = []
        def progress2(str, num, collector=collector2):
            collector.append((str, num))
        os.chdir('../doc')
        rmlText = open('example_1.rml').read();
        returned = rml2pdf.go(rmlText, progressCallBack=progress2)
        assert collector2[0] == ('STARTED',0)
        assert collector2[-1] == ('FINISHED',0)

    def testObjectProperties(self):
        from rlextra.rml2pdf.rml2pdf import styles, TTParagraph, TTXPreformatted, LazyParagraph, LazyXPreformatted
        for v,x in  ((0,TTParagraph), (0,TTXPreformatted), (1,LazyParagraph), (0,LazyXPreformatted),
                ):
            obj = x(('para',{},'hello',None),styles['Normal'])
            assert obj._CLEAN_SPACE==v

class RMLDocumentTestCase(unittest.TestCase):
    """Some very crude tests on RML2PDF.

    This class runs one RML 'job' per test
    instance; that way, we get a list of each failure
    independently of the others.  It does not check
    for output, but instead calls rml2pdf.go programmatically
    and counts on it raising an exception if anything
    is wrong.  Assumes all file paths are relative to
    where RML lives, and CDs into directory of data
    file prior to running.
    """

    def setUp(self):
        #SecureTestCase.__init__(self)
        self.startDir = os.getcwd()
        self.rmlDir = os.path.dirname(rml2pdf.__file__)
        os.chdir(self.rmlDir)

    def tearDown(self):
        os.chdir(self.startDir)

    def processRMLFile(self, pathName):
        dirName, fileName = os.path.split(pathName)
        os.chdir(dirName)
        rmlText = open(fileName,'r').read()
        rml2pdf.go(rmlText, dtdDir = self.rmlDir)

    def testExample1(self):
        self.processRMLFile('doc/example_1.rml')
    def testExample2(self):
        self.processRMLFile('doc/example_2.rml')
    def testExample3(self):
        self.processRMLFile('doc/example_3.rml')
    def testExample4(self):
        self.processRMLFile('doc/example_4.rml')
    def testExample5(self):
        self.processRMLFile('doc/example_5.rml')
    def testExample6(self):
        self.processRMLFile('doc/example_6.rml')
    def testExample7a(self):
        self.processRMLFile('doc/example_7a.rml')
    def testExample7b(self):
        self.processRMLFile('doc/example_7b.rml')
    def testExample8(self):
        self.processRMLFile('doc/example_8.rml')
    def testExample9(self):
        self.processRMLFile('doc/example_9.rml')
    def testExample10(self):
        self.processRMLFile('doc/example_10.rml')
    def testExample11(self):
        self.processRMLFile('doc/example_11.rml')
    def testExample12(self):
        self.processRMLFile('doc/example_12.rml')
    #def testUserGuide(self):
    #    self.processRMLFile('doc/rml_user_guide.rml')

    #ones in test directory
    def test_000_simple(self):
        self.processRMLFile('test/test_000_simple.rml')
        self.processRMLFile('./test_000_complex.rml')
        self.processRMLFile('./test_000_catchforms.rml')
    def test_001_hello(self):
        self.processRMLFile('test/test_001_hello.rml')
    def test_001_hellocm(self):
        self.processRMLFile('test/test_001_hellocm.rml')
    def test_001_imagereflect(self):
        self.processRMLFile('test/test_001_imagereflect.rml')
    def test_002_paras(self):
        self.processRMLFile('test/test_002_paras.rml')
    def test_002_paras_index(self):
        self.processRMLFile('test/test_002_paras_index.rml')
    def test_003_frames(self):
        self.processRMLFile('test/test_003_frames.rml')
    def test_004_templates(self):
        self.processRMLFile('test/test_004_templates.rml')
    def test_004_fpt_templates(self):
        self.processRMLFile('test/test_004_fpt_templates.rml')
    def test_005_fonts(self):
        self.processRMLFile('test/test_005_fonts.rml')
    def test_006_barcodes(self):
        self.processRMLFile('test/test_006_barcodes.rml')
    def test_007_forms(self):
        self.processRMLFile('test/test_007_forms.rml')
    def test_008_tables(self):
        self.processRMLFile('test/test_008_tables.rml')
    def test_009_splitting(self):
        self.processRMLFile('test/test_009_splitting.rml')
    def test_010_linkURL(self):
        self.processRMLFile('test/test_010_linkURL.rml')
    def test_011_keepwithnext(self):
        self.processRMLFile('test/test_011_keepwithnext.rml')
    def test_012_simpletoc(self):
        self.processRMLFile('test/test_012_simpletoc.rml')
    def test_014_graphics(self):
        self.processRMLFile('test/test_014_graphics.rml')
    def test_016_pagecatcher(self):
        self.processRMLFile('test/test_016_pagecatcher.rml')
    def test_017_outlines(self):
        self.processRMLFile('test/test_017_outlines.rml')
    def test_018_toc_outline(self):
        self.processRMLFile('test/test_018_toc_outline.rml')
    def test_019_relativeframes(self):
        self.processRMLFile('test/test_019_relativeframes.rml')
    def test_020_dynamic(self):
        self.processRMLFile('test/test_020_dynamic.rml')
    def test_021_figures(self):
        self.processRMLFile('test/test_021_figures.rml')
    def test_022_paras_oas(self):
        self.processRMLFile('test/test_022_paras_oas.rml')
    def test_023_ttfonts(self):
        #do it twice to check we can register fonts twice
        self.processRMLFile('test/test_023_ttfonts.rml')
        os.chdir(self.rmlDir)
        self.processRMLFile('test/test_023_ttfonts.rml')
    def test_024_indents(self):
        self.processRMLFile('test/test_024_indents.rml')
    def test_025_pto(self):
        self.processRMLFile('test/test_025_pto.rml')
    def test_026_leftright(self):
        self.processRMLFile('test/test_026_leftright.rml')
    def test_027_hardtoc(self):
        self.processRMLFile('test/test_027_hardtoc.rml')
    def test_028_fields(self):
        self.processRMLFile('test/test_028_fields.rml')
    def test_029_keepInFrame(self):
        self.processRMLFile('test/test_029_keepinframe.rml')
    def test_030_codepages(self):
        self.processRMLFile('test/test_030_codepages.rml')
    def test_031_japanese(self):
        self.processRMLFile('test/test_031_japanese.rml')
    def test_032_images(self):
        self.processRMLFile('test/test_032_images.rml')
    def test_032_default_images(self):
        self.processRMLFile('test/test_032_default_images.rml')
    def test_033_useb4def(self):
        self.processRMLFile('test/test_033_useb4def.rml')
    def test_034_cmyk(self):
        self.processRMLFile('test/test_034_cmyk.rml')
    def test_035_numbering(self):
        self.processRMLFile('test/test_035_numbering.rml')
    def test_036_numbering_contd(self):
        self.processRMLFile('test/test_036_numbering_contd.rml')
    def test_037_numbering_contd(self):
        self.processRMLFile('test/test_037_plugingraphic.rml')
    def test_038(self):
        self.processRMLFile('test/test_038_rect_href.rml')
    def test_039_doc_programming(self):
        self.processRMLFile('test/test_039_doc_programming.rml')
    def test_040_colors(self):
        self.processRMLFile('test/test_040_colors.rml')
    def test_041_masking(self):
        self.processRMLFile('test/test_041_masking.rml')
    def test_042_longdoc(self):
        self.processRMLFile('test/test_042_longdoc.rml')
    def test_043_headings(self):
        self.processRMLFile('test/test_043_headings.rml')
    def test_044_codesnippets(self):
        self.processRMLFile('test/test_044_codesnippets.rml')

    # three demos
    def test_demos_snow(self):
        self.processRMLFile('demos/snow.rml')
    def test_demos_heart(self):
        self.processRMLFile('demos/heart.rml')
    def test_demos_sample(self):
        self.processRMLFile('demos/sample.rml')

def makeSuite():
    allTests = unittest.TestSuite()
    allTests.addTest(unittest.makeSuite(RMLFunctionalTestCase))
    allTests.addTest(unittest.makeSuite(RMLDocumentTestCase))
    return allTests

def main():
    unittest.TextTestRunner().run(makeSuite())

#noruntests
if __name__ == "__main__":
    main()
