use db_report;

DROP TABLE IF EXISTS `lineup`;

DROP TABLE IF EXISTS `event`;
CREATE TABLE  `event` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `eventDatetime` datetime NOT NULL,
  `sex` varchar(1) NOT NULL,
  `eventName` varchar(20) NOT NULL,
  `round` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOAD DATA LOCAL INFILE 'database/event.csv' INTO TABLE event CHARACTER SET 'utf8' fields terminated by ',' enclosed by '''' lines terminated by '\n' (@eventDatetime,sex,eventName,round) set eventDatetime = str_to_date(@eventDatetime,'%d/%m/%y %H:%i:%s');

DROP TABLE IF EXISTS `athlete`;
CREATE TABLE  `athlete` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `athleteName` varchar(20) NOT NULL,
  `team` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOAD DATA LOCAL INFILE 'database/athlete.csv' INTO TABLE athlete CHARACTER SET 'utf8' fields terminated by ',' enclosed by '''' lines terminated by '\n' (athletename,team,country);

CREATE TABLE  `lineup` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `eventID` int(9) NOT NULL,
  `athleteID` int(9) NOT NULL,
  `laneorder` int(9) NOT NULL,
  `position` int(9) NOT NULL,
  `resulttime` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `event_fk_constraint` (`eventID`),
  KEY `athlete_fk_constraint` (`athleteID`),
  CONSTRAINT `athlete_fk_constraint` FOREIGN KEY (`athleteID`) REFERENCES `athlete` (`id`),
  CONSTRAINT `event_fk_constraint` FOREIGN KEY (`eventID`) REFERENCES `event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

LOAD DATA LOCAL INFILE 'database/lineup.csv' INTO TABLE lineup CHARACTER SET 'utf8' fields terminated by ',' enclosed by '"' lines terminated by '\n' (eventID,athleteID,laneorder,position,resulttime);