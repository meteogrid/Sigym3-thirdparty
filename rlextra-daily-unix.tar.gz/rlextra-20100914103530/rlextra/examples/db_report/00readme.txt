This sample shows you how to use content from a database to create 
dynamic documents using Report Markup Language, mySQL and ReportLab's
templating engine, 'preppy'.

To run it:

1. Create a mysql database using the file 'create_database.sql'.  Log into 
   mySQL and execute 'create database db_report'.  Then from a command line,
   run:
        mysql -u <username> -p <password> db_report <create_database.sql
2. Edit the database connection parameters inside db_report.py
3. Run it from the command line:
    python db_report.py
    
You should see a pdf file named 'events.pdf' created in the same directory.

The basic architecture is:

1. Connect to the database and retrieve the data.  We have used an existing
module (ers.fetchobj) from the ReportLab PLUS package to map the database query
results into a set of python objects. For more extensive database object
mapping with read/write etc., use a library like SQLObject or SQLAlchemy.
2. Pass the resulting objects into ReportLab's 'preppy' module.  This merges
the data into a Report Markup Language 'template', to create an RML file.
This step could be done with any other templating engine such as genshi or mako.
3. The RML is compiled into a PDF file using RML2PDF.

The code is extensively commented.  For further information, consult the
documentation included with the distribution, or see the documentation page
on our website at http://www.reportlab.com