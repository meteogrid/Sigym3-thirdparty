# This ReportLab sample demonstrates how to create dynamic documents
# using RML and a mySQL database with the 'preppy' templating engine.
# Create the required database with the script 'create_database.sql', and look
# inside 'db_report_event.prep' to see how the basic PDF document is described
#in Report Markup Language.

import MySQLdb
from rlextra.preppy import preppy
from rlextra.rml2pdf import rml2pdf
from rlextra.ers import fetchobj

def main():
    #connect to the database
    db = MySQLdb.connect(user="root", passwd="", db="db_report")
    
    #sql query which fetches all the events
    sql='SELECT * FROM event'
    #map the query result to a list of python objects, using a 
    #function from ReportLab's Enterprise Reporting Suite
    events=fetchobj.queryToObjects(db,sql)

    #sql query which returns all the competitors and results for each event
    sql=('select a.athleteName, a.team, a.country, l.laneorder, l.position, l.resulttime , e.id as eventid from (athlete a join lineup l on a.id = l.athleteID)join event e on e.id = l.eventID order by eventid, l.position')
    races=fetchobj.queryToObjects(db,sql)

    #load the base RML template into preppy
    template = preppy.getModule('db_report_event.prep')
    #create an RML file from the template by passing in the database query result objects
    rmlText = template.get(events,races)
    
    #Uncomment this line to see the resulting RML file
    #open('events.rml', 'w').write(rmlText)
    
    #Now create the PDF by passing the RML file into RML2PDF
    rml2pdf.go(rmlText, outputFileName='events.pdf')
    print 'saved events.pdf' 
    
if __name__=='__main__':
    main()
