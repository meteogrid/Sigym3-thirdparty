This folder contains a sample Ruby on Rails project.

It's a simple demonstration of how to harness ReportLab's Report Markup Language (RML) from within Ruby on Rails.

To run the demonstration, you need a working installation of Python, the open source ReportLab toolkit, pyRXP, and the ReportLab PLUS bundle, which you can download by registering at http://www.reportlab.com

You will need to edit the configuration inside rml-sample/app/controllers/rml_sample_controller.rb to suit your system.

RML is an XML-style language for describing the layout of a document.  The RML is converted to PDF using a python module named rml2pdf.pyc.

Because the RML is a just a text file, it can be manipulated dynamically very easily from inside any language or framework.  

This example simply processes an rml template using the ruby on rails template engine to substitute a string dynamically.  It then writes the text to a temporary file and uses the ruby system function to call the rml2pdf python module with the relevant command line string.  This converts the RML to a PDF, and the file is returned to the browser.

RML2PDF and RML are part of the ReportLab PLUS software package.  For further information and extensive documentation, please see our website at http://www.reportlab.com/software
