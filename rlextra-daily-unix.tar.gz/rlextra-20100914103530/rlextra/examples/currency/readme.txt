
SIMPLE XML 2 RML TRANSLATION EXAMPLE WITH OUTLINE ENTRIES

TO RUN THE EXAMPLE EXECUTE

    ...python currency.py

IN THIS DIRECTORY.  THIS CREATES currency.rml FROM currency.xml
INCLUDING OUTLINE ENTRIES.

This directory contains programs and data to demonstrate how
to translate a very simple XML format into RML which in turn
can be translated into PDF using RML2PDF.

Contents of this directory:

The currency.* files are the key files.  The source files are

   currency.py
      -- XML to RML translation script.  Please see the documentation
         at the top of this script for more explanation.
   currency.xml
      -- XML data describing the fluctuation of the Canadian dollar versus
         several other currencies over a period of time.
   currency.dtd
      -- the "document type description" for currency.xml.
   currencies.txt
      -- this is a comma delimited file with the same data as currency.xml.

Derived Files:

   currency.rml
      -- created when "currency.py" runs -- a translation of currency.xml to RML
   currency.pdf
      -- created when RML2PDF translates "currency.rml" to PDF -- the PDF document.
   test.rml
      -- a test file which tests the document format for currency.rml without the data

The text2xml.py script was used to derive the DTD file and the xml file.


