"translate currency.txt comma separated lists into XML"

dtd = """
<!ELEMENT history (CanadianDollarConversion*)>

<!ELEMENT CanadianDollarConversion EMPTY>
<!ATTLIST CanadianDollarConversion
   YYYYMMDD CDATA #REQUIRED
   DayOfWeek CDATA #REQUIRED
   USDollar CDATA #REQUIRED
   Euro CDATA #REQUIRED
   DeutcheMark CDATA #REQUIRED
   FrenchFranc CDATA #REQUIRED
   JapaneseYen CDATA #REQUIRED
   BritishPound CDATA #REQUIRED
   SwissFranc CDATA #REQUIRED
   AustralianDollar CDATA #REQUIRED
   HongKongDollar CDATA #REQUIRED
   NewZealandDollar CDATA #REQUIRED
>
"""

dtdfile = open("currency.dtd", "w")
dtdfile.write(dtd)
dtdfile.close()
print "wrote currency.dtd"

fields = [None, "YYYYMMDD", "DayOfWeek",
 "USDollar", "Euro", "DeutcheMark", "FrenchFranc", "JapaneseYen",
 "BritishPound", "SwissFranc", "AustralianDollar", "HongKongDollar",
 "NewZealandDollar"]

flen = len(fields)
frange = range(flen)
import string

lines = open("currencies.txt", "r").readlines()
# ignore the first 2 and the last
lines=lines[2:-1]

outfile = open("currency.xml", "w")
outfile.write("""<?xml version="1.0" encoding="iso-8859-1" standalone="no" ?>
<!DOCTYPE history SYSTEM "currency.dtd">

<history>
""")
for L in lines:
    sL = string.split(L, ",")
    if len(sL)<flen:
        print "ignoring", repr(L)
    else:
        outfile.write("\n <CanadianDollarConversion\n")
        for i in frange:
            fieldname = fields[i]
            fieldvalue = sL[i]
            fieldvalue = string.strip(fieldvalue)
            if fieldvalue[:1]==fieldvalue[-1:]=='"':
                fieldvalue = fieldvalue[1:-1]
            if fieldname:
                outfile.write('    %s="%s"\n' % (fieldname, fieldvalue))
        outfile.write("/>\n")
                
outfile.write("</history>\n\n")
outfile.close()
print "wrote currency.xml"
