To run the demo:
Open a command prompt, cd to the directory containing this file,
and type the following:
    python run.py

the pdf (longExample.pdf) and rml source (longExample.rml) is created in the same directory.

Further explanation can be found in the comments in run.py and
rmltemplate.prep.  
