from reportlab.lib.colors import setColors

def getColorSeries(color1, color2):
    """They start with deep blue and go through 4 gradually lighter
    graduations; then light red, getting darker in 4 stages."""


# as on sample sheet - blues fading out, reds fading out
setColors(fidblue=0x3366cc,fidred=0xCC0033,
	fid_aa_palette=(0xb3b3b3, 0x1f60a9, 0x5481bb, 0x8ba7cf, 0xc4d1e6, 0xff000c, 0xff4233, 0xff8068, 0xffc0ac, 0xc3b263, 0xdcd099, 0xede6c9, 0xffffff,
					0x44567F, 0x6f7eaa, 0x97a4ce, 0xcacee8, 0xca5653, 0xdf816f, 0xf3a991, 0xf5bfad, 0xc3ad4b, 0xcfbd6f, 0xdbce93, 0xe7deb7, 0xf3eedb,
					))
import phrases
IMA_NAMES=phrases.IMA_NAMES[phrases._langDefault]

def ima_sort(classes,what=None,ima=0):
	R = []
	for i in classes:
		if i not in IMA_NAMES: R.append(i)
	if R:
		raise ValueError("Classes %s not in IMA_NAMES\n%s" % (R,IMA_NAMES))
	if what is None: what = classes[:]
	V = list(ima and IMA_NAMES or classes)
	if type(classes) is not type([]): classes = list(classes)
	for i in IMA_NAMES:
		if i in classes: R.append(what[V.index(i)])
	return R


