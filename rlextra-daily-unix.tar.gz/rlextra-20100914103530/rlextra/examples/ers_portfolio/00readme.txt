These are examples to demonstrate ers producing rich financial documents:

To run the examples, type:

    python rpcdrawing.py
    python spcdrawing.py
    python tbardrawing.py
    python tbcdrawing.py
    python ypcdrawing.py

This should generare the following 5 pdfs in the current directory.

    RPCDrawing000.pdf
    SPCDrawing000.pdf
    TBarDrawing000.pdf
    TBCDrawing000.pdf
    YPCDrawing000.pdf
