#support for different languages
# -*- coding: iso-8859-1 -*-
_langDefault='uk'
def setDefaultLang(lang):
    global _langDefault
    _langDefault = lang
    import palette
    palette.IMA_NAMES = IMA_NAMES[_langDefault]

riskNames = {
            'uk': ['SHORT TERM','CONSERVATIVE','BALANCED','GROWTH','AGGRESSIVE GROWTH'],
            'de': ['KURZFRISTIG','KONSERVATIV','GEMISCHT','WACHSTUM','DYNAM. WACHSTUM'],
            }

decimalSep={
            'uk': '.',
            'de': ',',
            }

thousandSep={
            'uk': ',',
            'de': '.',
            }

from reportlab.platypus.flowables import Flowable
class setLang(Flowable):
    def __init__(self, data):
        setDefaultLang(data)
    def wrap(self, w, h):
        return (0,0)
    def draw(self):
        pass

class _WL:
    '''something to hang words on'''
    def __init__(self,**kw):
        self.__dict__ = kw

tbclabels = {
            'uk': _WL(gr='Growth',rp='Regular payments', ininv='Initial investment', now='Now', by='By ', target='Target '),
            'de': _WL(gr='Wachstum',rp='Regelm�ssich\nBeitr�ge', ininv='Ersteinlage', now='Heute', by='', target='Ziel '),
            }

ypclabels = {
            'uk': _WL(ci='Consider investing...',yp='Your plan',more='more',less='less'),
            'de': _WL(ci='Meinen Sie anlegen',yp='Ihr Plan',more='mehr',less='weniger'),
            }

tbdlabels = {
            'uk': _WL(amount='Amount'),
            'de': _WL(amount='Betrag'),
            }

spclabels = {
            'uk': _WL(inv='Investment', os='Our suggestion', total='Total'),
            'de': _WL(inv='Anlagekategorie',os='Unser Vorschlag', total='Gesamtbetrag'),
            }
cc = {
    'uk': '\xc2\xa3',
    'de': '\xe2\x82\xac',
    }

IMA_NAMES={'uk':(
                'Cash',
                'UK Gilts',
                'UK Corporate Bond',
                'UK Other Bond',
                'UK Equity Income',
                'UK All Companies',
                'UK Smaller Companies',
                'Europe excluding UK',
                'North America',
                'Global Growth',
                'Japan',
                'Far East excluding Japan',
                'Global Emerging Markets',
                ),
            'de':(
                'Geld Markt',
                'Renten Europa',
                'Aktien Europa',
                'Renten International',
                'Renten Hoch Gewinn',
                'Aktien International',
                'Aktien Europa Spezialist',
                'Aktien Nordamerika',
                'Aktien Japan',
                'Aktien Pazifik',
                'Aktien Nordamerika Spezialist',
                'Aktien Japan Spezialist',
                'Aktien Pazifik Spezialist',
                'Gemischt',
                ),
        }
