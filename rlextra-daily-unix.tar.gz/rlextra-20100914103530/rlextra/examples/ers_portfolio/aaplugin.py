#copyright ReportLab Europe Limited. 2000-2006
#see license.txt for license details
__version__=''' $Id: aaplugin.py 20834 2006-04-05 17:15:32Z rgbecker $ '''

def tbc(target,growth,regular,icontrib,ivalue,enddate):
	from tbcdrawing import TBCDrawing
	return TBCDrawing(_targetValue=target,_data=[(icontrib,ivalue),(0,regular),(0,growth)],_enddate=enddate)

def spc(*args):
	'''name1, value1, name2, value2, ...., namen, value'''
	from spcdrawing import SPCDrawing
	n = len(args)
	if not n or (n&1): raise ValueError("spc needs an even non-zero number of arguments")
	data = []
	labels = []
	for i in xrange(0,n,2):
		labels.append(args[i])
		data.append(args[i+1])
	return SPCDrawing(_data=data,_labels=labels)

def ypc(*args):
	''''class1',value1, cvalue1, 'class2',value2, ...., 'classn',valuen, cvaluen'''
	from ypcdrawing import YPCDrawing
	n = len(args)
	if not n or (n%3): raise ValueError("ypc needs an 3 multiple non-zero number of arguments")
	data = []
	cdata = []
	labels = []
	for i in xrange(0,n,3):
		labels.append(args[i])
		data.append(args[i+1])
		cdata.append(args[i+2])
	return YPCDrawing(_labels=labels,_data=data,_cdata=cdata)

def rpc(risk):
	'''risk value 0 to 4'''
	from rpcdrawing import RPCDrawing
	return RPCDrawing(_risk=risk)

def tbar(paletteIndex,text):
	from tbardrawing import TBarDrawing
	from reportlab.lib.colors import fid_aa_palette
	return TBarDrawing(_swatchColor=fid_aa_palette[paletteIndex],_title=text)
