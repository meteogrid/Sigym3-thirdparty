#copyright ReportLab Europe Limited. 2000-2006
#see license.txt for license details
Version='0.0'
__version__=''' $Id: __init__.py 20834 2006-04-05 17:15:32Z rgbecker $ '''
