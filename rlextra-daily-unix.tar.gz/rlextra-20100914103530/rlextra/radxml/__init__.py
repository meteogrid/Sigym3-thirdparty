#copyright ReportLab Inc. 2001-2006
#see license.txt for license details
