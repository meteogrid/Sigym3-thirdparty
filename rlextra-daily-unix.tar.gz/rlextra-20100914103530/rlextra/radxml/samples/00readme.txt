This directory should hold a selection of XML files
and DTDs where appropriate.