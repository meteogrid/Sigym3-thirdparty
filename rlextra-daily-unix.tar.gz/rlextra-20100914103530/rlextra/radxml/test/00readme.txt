This directory includes test programs and sample XML files
for the radxml package.