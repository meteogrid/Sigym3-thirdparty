# -*- coding: utf-8 -*-
"""
Defines utilities for working with a small subset of XHTML.

We often need to work with chunks of 'rich text' which define a
short story, or sequence of paragraphs.  These can come from data feeds,
scraping web sites, or input into web forms (MCE, fck, stuff pasted from
other web pages or MS Word).  Such content should ALWAYS be normalised
and checked (possibly rejected) and saves in a standard, known subset
of XHTML.  rltext.py will provide utilities to 'clean up' and check
such input.

Once normalised, we want to be able to convert this content to
RML in a standard way.  So, this provides a converter.  This will
presume some standard styles.

Finally, sometimes we need utilities to truncate or measure the length
of chunks of text - e.g pull out the first sentence or two.  This is
also the home for that.

The main components are:


1. a DTD called 'rltext.dtd', actually a subset of XHTML, defining a small set
of tags.  This is stored as a string variable within the module, so it
is always available without needing separate files and so the parser
doesn't need to assume anything about file systems or current directories.

2. a validate function

3. a "toRML(..)" functions

4. (not done yet)  functions to clean and truncate and measure length of text.


"""
from xml.sax.saxutils import quoteattr
import sys, os

import pyRXPU
from rlextra.radxml.xmlutils import applyDocType, TupleTreeWalker
from rlextra.django.common.transform import XhtmlTransformer
from rlextra.django.common.htmlformatter import HtmlFormatter
from rlextra.thirdparty.BeautifulSoup import BeautifulSoup, Comment
from types import UnicodeType

from html_cleaner import Cleaner

import string, random

dtd = 'rltext.dtd'

dtdstring = """
<!--

   Simplified version XHTML 1.0
   Fully XHTML compatible

   This DTD module is identified by the SYSTEM identifiers:

   SYSTEM "rltext.dtd"


-->

<!--================== Imported Names ====================================-->

  <!-- This are just a dummy elements inserted in empty declarations which allows
  us to keep the general structure of the original XHTML DTD. The _nothingX elements
  should not be used in documents -->

<!ENTITY % Nothing1 "_nothing1">
<!ENTITY % Nothing2 "_nothing2">
<!ENTITY % Nothing3 "_nothing3">
<!ENTITY % Nothing4 "_nothing4">

<!ELEMENT _nothing1 (#PCDATA)>
<!ELEMENT _nothing2 (#PCDATA)>
<!ELEMENT _nothing3 (#PCDATA)>
<!ELEMENT _nothing4 (#PCDATA)>

<!--================ Character mnemonic entities =========================-->

<!--

<!ENTITY % HTMLlat1 PUBLIC
   "-//W3C//ENTITIES Latin1//EN//HTML"
   "HTMLlat1.ent">
%HTMLlat1;

<!ENTITY % HTMLsymbol PUBLIC
   "-//W3C//ENTITIES Symbols//EN//HTML"
   "HTMLsymbol.ent">
%HTMLsymbol;

<!ENTITY % HTMLspecial PUBLIC
   "-//W3C//ENTITIES Special//EN//HTML"
   "HTMLspecial.ent">
%HTMLspecial;

-->

<!--================== Imported Names ====================================-->

<!ENTITY % Character "CDATA">
    <!-- a single character, as per section 2.2 of [XML] -->

<!ENTITY % Number "CDATA">
    <!-- one or more digits -->

<!ENTITY % URI "CDATA">
    <!-- a Uniform Resource Identifier, see [RFC2396] -->

<!ENTITY % Text "CDATA">
    <!-- used for titles etc. -->

<!ENTITY % Length "CDATA">
    <!-- nn for pixels or nn% for percentage length -->

<!ENTITY % StyleSheet "CDATA">
    <!-- style sheet data -->

<!--=================== Generic Attributes ===============================-->

<!-- core attributes common to most elements
-->
<!ENTITY % coreattrs "">

<!-- internationalization attributes
-->
<!ENTITY % i18n "">

<!-- attributes for common UI events
-->
<!ENTITY % events "">

<!-- attributes for elements that can get the focus
-->
<!ENTITY % focus "">

<!ENTITY % attrs "%coreattrs; %i18n; %events;">

<!--=================== Text Elements ====================================-->

<!ENTITY % special.extra "img">

<!ENTITY % special.pre "br">

<!ENTITY % special "%special.pre; | %special.extra;">

<!ENTITY % fontstyle "%Nothing2;">

<!ENTITY % phrase "i | em | b | strong | u | dfn | code | q |
                   samp | kbd | var | cite | abbr | acronym ">

<!ENTITY % inline.forms "%Nothing3;">

<!-- these can occur at block or inline level -->
<!ENTITY % misc.inline "%Nothing4;">

<!-- these can only occur at block level -->
<!ENTITY % misc "%misc.inline;">

<!ENTITY % inline "a | %special; | %fontstyle; | %phrase; | %inline.forms;">

<!-- %Inline; covers inline or "text-level" elements -->
<!ENTITY % Inline "(#PCDATA | %inline; | %misc.inline;)*">

<!--================== Block level elements ==============================-->

<!ENTITY % heading "h1|h2|h3|h4|h5|h6">
<!ENTITY % lists "ul|ol"> <!-- "ul | ol | dl" -->
<!ENTITY % blocktext "pre">

<!ENTITY % block
     "p | %heading; | %lists; | %blocktext; | table">

<!ENTITY % Block "(%block; | %misc;)*">
<!ENTITY % BlockPCDATA "(#PCDATA | %block; | %misc; | %special; )*">

<!-- %Flow; mixes block and inline and is used for list items etc. -->
<!ENTITY % Flow "(#PCDATA | %block; | %inline; | %misc;)*">

<!--================== Content models for exclusions =====================-->

<!-- a elements use %Inline; excluding a -->

<!ENTITY % a.content
   "(#PCDATA | %special; | %fontstyle; | %phrase; | %inline.forms; | %misc.inline;)*">

<!-- pre uses %Inline excluding big, small, sup or sup -->

<!ENTITY % pre.content
   "(#PCDATA | %fontstyle; | %phrase; | %special.pre; | %misc.inline;
      | %inline.forms;)*">

<!-- form uses %Block; excluding form -->

<!ENTITY % form.content "(%block; | %misc;)*">

<!-- button uses %Flow; but excludes a, form and form controls -->

<!ENTITY % button.content
   "(#PCDATA | p | %heading; | %lists; | %blocktext; |
    %special; | %fontstyle; | %phrase; | %misc;)*">

<!--================ Document Structure ==================================-->

<!-- the namespace URI designates the document profile -->

<!--================ Document Head =======================================-->

<!--=================== Document Body ====================================-->

<!ELEMENT body %BlockPCDATA;>
<!ATTLIST body
  %attrs;
  >

<!--=================== Paragraphs =======================================-->

<!ELEMENT p %Inline;>
<!ATTLIST p
  %attrs;
  style       %StyleSheet;             #IMPLIED
  align       (left | right | center)  #IMPLIED
  >

<!--=================== Headings =========================================-->

<!--
  There are six levels of headings from h1 (the most important)
  to h6 (the least important).
-->

<!ELEMENT h1  %Inline;>
<!ATTLIST h1
   %attrs;
   >

<!ELEMENT h2 %Inline;>
<!ATTLIST h2
   %attrs;
   >

<!ELEMENT h3 %Inline;>
<!ATTLIST h3
   %attrs;
   >

<!ELEMENT h4 %Inline;>
<!ATTLIST h4
   %attrs;
   >

<!ELEMENT h5 %Inline;>
<!ATTLIST h5
   %attrs;
   >

<!ELEMENT h6 %Inline;>
<!ATTLIST h6
   %attrs;
   >

<!--=================== Lists ============================================-->

<!-- Unordered list -->

<!ELEMENT ul (li)+>
<!ATTLIST ul
  %attrs;
  >

<!-- Ordered (numbered) list -->

<!ELEMENT ol (li)+>
<!ATTLIST ol
  %attrs;
  >

<!-- list item -->

<!-- ELEMENT li %Flow; Changed to Inline, only text level items allowed within li -->
<!ELEMENT li %Inline;>
<!ATTLIST li
  %attrs;
  >

<!-- definition lists - dt for term, dd for its definition -->

<!ELEMENT dl (dt|dd)+>
<!ATTLIST dl
  %attrs;
  >

<!ELEMENT dt %Inline;>
<!ATTLIST dt
  %attrs;
  >

<!ELEMENT dd %Flow;>
<!ATTLIST dd
  %attrs;
  >

<!--=================== Address ==========================================-->

<!--=================== Horizontal Rule ==================================-->

<!--=================== Preformatted Text ================================-->

<!-- content is %Inline; excluding "object|big|small|sub|sup" -->

<!ELEMENT pre %pre.content;>
<!ATTLIST pre
  %attrs;
  xml:space (preserve) #FIXED 'preserve'
  >

<!--=================== Block-like Quotes ================================-->

<!--=================== Inserted/Deleted Text ============================-->

<!--================== The Anchor Element ================================-->

<!-- content is %Inline; except that anchors shouldn't be nested -->

<!ELEMENT a %a.content;>
<!ATTLIST a
  %attrs;
  %focus;
  href        %URI;          #IMPLIED
  >

<!--===================== Inline Elements ================================-->

<!ELEMENT em %Inline;>   <!-- emphasis -->
<!ATTLIST em %attrs;>
<!ELEMENT i %Inline;>    <!-- emphasis -->
<!ATTLIST i %attrs;>

<!ELEMENT strong %Inline;>   <!-- strong emphasis -->
<!ATTLIST strong %attrs;>
<!ELEMENT b %Inline;>    <!-- strong emphasis -->
<!ATTLIST b %attrs;>

<!ELEMENT u %Inline;>    <!-- underline -->
<!ATTLIST u %attrs;>

<!ELEMENT br %Inline;>    <!-- Line break -->
<!ATTLIST br %attrs;>

<!ELEMENT dfn %Inline;>   <!-- definitional -->
<!ATTLIST dfn %attrs;>

<!ELEMENT code %Inline;>   <!-- program code -->
<!ATTLIST code %attrs;>

<!ELEMENT samp %Inline;>   <!-- sample -->
<!ATTLIST samp %attrs;>

<!ELEMENT kbd %Inline;>  <!-- something user would type -->
<!ATTLIST kbd %attrs;>

<!ELEMENT var %Inline;>   <!-- variable -->
<!ATTLIST var %attrs;>

<!ELEMENT cite %Inline;>   <!-- citation -->
<!ATTLIST cite %attrs;>

<!ELEMENT abbr %Inline;>   <!-- abbreviation -->
<!ATTLIST abbr %attrs;>

<!ELEMENT acronym %Inline;>   <!-- acronym -->
<!ATTLIST acronym %attrs;>

<!ELEMENT q %Inline;>   <!-- inlined quote -->
<!ATTLIST q
  %attrs;
  >

<!--==================== Object ======================================-->

<!--=================== Images ===========================================-->
<!ELEMENT img EMPTY>
<!ATTLIST img
  %attrs;
  src         %URI;          #REQUIRED
  height      %Length;       #IMPLIED
  width       %Length;       #IMPLIED
  alt         %Text;         #IMPLIED
  >

<!--================== Client-side image maps ============================-->

<!--================ Forms ===============================================-->

<!--======================= Tables =======================================-->
<!ELEMENT table
     (tr+)>
<!ELEMENT tr       (th|td)+>
<!ELEMENT th       %Flow;>
<!ELEMENT td       %Flow;>

<!--======================= Entities======================================-->

<!-- RML should always be used with UTF-8 encoding - the following entities
are the only ones that should be neccesary. A copy of the rml entities-->

<!--

<!ENTITY Aacute "&#xc1;">
<!ENTITY aacute "&#xe1;">
<!ENTITY Acirc "&#xc2;">
<!ENTITY acirc "&#xe2;">
<!ENTITY acute "&#xb4;">
<!ENTITY AElig "&#xc6;">
<!ENTITY aelig "&#xe6;">
<!ENTITY Agrave "&#xc0;">
<!ENTITY agrave "&#xe0;">
<!ENTITY alefsym "&#x2135;">
<!ENTITY Alpha "&#x391;">
<!ENTITY alpha "&#x3b1;">
<!ENTITY and "&#x2227;">
<!ENTITY ang "&#x2220;">
<!ENTITY Aring "&#xc5;">
<!ENTITY aring "&#xe5;">
<!ENTITY asymp "&#x2248;">
<!ENTITY Atilde "&#xc3;">
<!ENTITY atilde "&#xe3;">
<!ENTITY Auml "&#xc4;">
<!ENTITY auml "&#xe4;">
<!ENTITY bdquo "&#x201e;">
<!ENTITY Beta "&#x392;">
<!ENTITY beta "&#x3b2;">
<!ENTITY brvbar "&#xa6;">
<!ENTITY bull "&#x2022;">
<!ENTITY cap "&#x2229;">
<!ENTITY Ccedil "&#xc7;">
<!ENTITY ccedil "&#xe7;">
<!ENTITY cedil "&#xb8;">
<!ENTITY cent "&#xa2;">
<!ENTITY Chi "&#x3a7;">
<!ENTITY chi "&#x3c7;">
<!ENTITY circ "&#x2c6;">
<!ENTITY clubs "&#x2663;">
<!ENTITY cong "&#x2245;">
<!ENTITY copy "&#xa9;">
<!ENTITY crarr "&#x21b5;">
<!ENTITY cup "&#x222a;">
<!ENTITY curren "&#xa4;">
<!ENTITY dagger "&#x2020;">
<!ENTITY Dagger "&#x2021;">
<!ENTITY darr "&#x2193;">
<!ENTITY dArr "&#x21d3;">
<!ENTITY deg "&#xb0;">
<!ENTITY Delta "&#x2206;">
<!ENTITY delta "&#x3b4;">
<!ENTITY diams "&#x2666;">
<!ENTITY divide "&#xf7;">
<!ENTITY Eacute "&#xc9;">
<!ENTITY eacute "&#xe9;">
<!ENTITY Ecirc "&#xca;">
<!ENTITY ecirc "&#xea;">
<!ENTITY Egrave "&#xc8;">
<!ENTITY egrave "&#xe8;">
<!ENTITY empty "&#x2205;">
<!ENTITY emsp "&#x2003;">
<!ENTITY ensp "&#x2002;">
<!ENTITY Epsilon "&#x395;">
<!ENTITY epsilon "&#x3b5;">
<!ENTITY epsiv "&#x3b5;">
<!ENTITY equiv "&#x2261;">
<!ENTITY Eta "&#x397;">
<!ENTITY eta "&#x3b7;">
<!ENTITY ETH "&#xd0;">
<!ENTITY eth "&#xf0;">
<!ENTITY Euml "&#xcb;">
<!ENTITY euml "&#xeb;">
<!ENTITY euro "&#x20ac;">
<!ENTITY exist "&#x2203;">
<!ENTITY fnof "&#x192;">
<!ENTITY forall "&#x2200;">
<!ENTITY frac12 "&#xbd;">
<!ENTITY frac14 "&#xbc;">
<!ENTITY frac34 "&#xbe;">
<!ENTITY frasl "&#x2044;">
<!ENTITY Gamma "&#x393;">
<!ENTITY gamma "&#x3b3;">
<!ENTITY ge "&#x2265;">
<!ENTITY harr "&#x2194;">
<!ENTITY hArr "&#x21d4;">
<!ENTITY hearts "&#x2665;">
<!ENTITY hellip "&#x2026;">
<!ENTITY Iacute "&#xcd;">
<!ENTITY iacute "&#xed;">
<!ENTITY Icirc "&#xce;">
<!ENTITY icirc "&#xee;">
<!ENTITY iexcl "&#xa1;">
<!ENTITY Igrave "&#xcc;">
<!ENTITY igrave "&#xec;">
<!ENTITY image "&#x2111;">
<!ENTITY infin "&#x221e;">
<!ENTITY int "&#x222b;">
<!ENTITY Iota "&#x399;">
<!ENTITY iota "&#x3b9;">
<!ENTITY iquest "&#xbf;">
<!ENTITY isin "&#x2208;">
<!ENTITY Iuml "&#xcf;">
<!ENTITY iuml "&#xef;">
<!ENTITY Kappa "&#x39a;">
<!ENTITY kappa "&#x3ba;">
<!ENTITY Lambda "&#x39b;">
<!ENTITY lambda "&#x3bb;">
<!ENTITY lang "&#x2329;">
<!ENTITY laquo "&#xab;">
<!ENTITY larr "&#x2190;">
<!ENTITY lArr "&#x21d0;">
<!ENTITY lceil "&#xf8ee;">
<!ENTITY ldquo "&#x201c;">
<!ENTITY le "&#x2264;">
<!ENTITY lfloor "&#xf8f0;">
<!ENTITY lowast "&#x2217;">
<!ENTITY loz "&#x25ca;">
<!ENTITY lrm "&#x200e;">
<!ENTITY lsaquo "&#x2039;">
<!ENTITY lsquo "&#x2018;">
<!ENTITY macr "&#xaf;">
<!ENTITY mdash "&#x2014;">
<!ENTITY micro "&#xb5;">
<!ENTITY middot "&#xb7;">
<!ENTITY minus "&#x2212;">
<!ENTITY Mu "&#x39c;">
<!ENTITY mu "&#xb5;">
<!ENTITY nabla "&#x2207;">
<!ENTITY nbsp "&#xa0;">
<!ENTITY ndash "&#x2013;">
<!ENTITY ne "&#x2260;">
<!ENTITY ni "&#x220b;">
<!ENTITY not "&#xac;">
<!ENTITY notin "&#x2209;">
<!ENTITY nsub "&#x2284;">
<!ENTITY Ntilde "&#xd1;">
<!ENTITY ntilde "&#xf1;">
<!ENTITY Nu "&#x39d;">
<!ENTITY nu "&#x3bd;">
<!ENTITY Oacute "&#xd3;">
<!ENTITY oacute "&#xf3;">
<!ENTITY Ocirc "&#xd4;">
<!ENTITY ocirc "&#xf4;">
<!ENTITY OElig "&#x152;">
<!ENTITY oelig "&#x153;">
<!ENTITY Ograve "&#xd2;">
<!ENTITY ograve "&#xf2;">
<!ENTITY oline "&#xf8e5;">
<!ENTITY Omega "&#x2126;">
<!ENTITY omega "&#x3c9;">
<!ENTITY Omicron "&#x39f;">
<!ENTITY omicron "&#x3bf;">
<!ENTITY oplus "&#x2295;">
<!ENTITY or "&#x2228;">
<!ENTITY ordf "&#xaa;">
<!ENTITY ordm "&#xba;">
<!ENTITY Oslash "&#xd8;">
<!ENTITY oslash "&#xf8;">
<!ENTITY Otilde "&#xd5;">
<!ENTITY otilde "&#xf5;">
<!ENTITY otimes "&#x2297;">
<!ENTITY Ouml "&#xd6;">
<!ENTITY ouml "&#xf6;">
<!ENTITY para "&#xb6;">
<!ENTITY part "&#x2202;">
<!ENTITY permil "&#x2030;">
<!ENTITY perp "&#x22a5;">
<!ENTITY Phi "&#x3a6;">
<!ENTITY phi "&#x3d5;">
<!ENTITY phis "&#x3c6;">
<!ENTITY Pi "&#x3a0;">
<!ENTITY pi "&#x3c0;">
<!ENTITY piv "&#x3d6;">
<!ENTITY plusmn "&#xb1;">
<!ENTITY pound "&#xa3;">
<!ENTITY prime "&#x2032;">
<!ENTITY Prime "&#x2033;">
<!ENTITY prod "&#x220f;">
<!ENTITY prop "&#x221d;">
<!ENTITY Psi "&#x3a8;">
<!ENTITY psi "&#x3c8;">
<!ENTITY radic "&#x221a;">
<!ENTITY rang "&#x232a;">
<!ENTITY raquo "&#xbb;">
<!ENTITY rarr "&#x2192;">
<!ENTITY rArr "&#x21d2;">
<!ENTITY rceil "&#xf8f9;">
<!ENTITY rdquo "&#x201d;">
<!ENTITY real "&#x211c;">
<!ENTITY reg "&#xae;">
<!ENTITY rfloor "&#xf8fb;">
<!ENTITY Rho "&#x3a1;">
<!ENTITY rho "&#x3c1;">
<!ENTITY rlm "&#x200f;">
<!ENTITY rsaquo "&#x203a;">
<!ENTITY rsquo "&#x2019;">
<!ENTITY sbquo "&#x201a;">
<!ENTITY Scaron "&#x160;">
<!ENTITY scaron "&#x161;">
<!ENTITY sdot "&#x22c5;">
<!ENTITY sect "&#xa7;">
<!ENTITY shy "&#xad;">
<!ENTITY Sigma "&#x3a3;">
<!ENTITY sigma "&#x3c3;">
<!ENTITY sigmaf "&#x3c2;">
<!ENTITY sigmav "&#x3c2;">
<!ENTITY sim "&#x223c;">
<!ENTITY spades "&#x2660;">
<!ENTITY sub "&#x2282;">
<!ENTITY sube "&#x2286;">
<!ENTITY sum "&#x2211;">
<!ENTITY sup "&#x2283;">
<!ENTITY sup1 "&#xb9;">
<!ENTITY sup2 "&#xb2;">
<!ENTITY sup3 "&#xb3;">
<!ENTITY supe "&#x2287;">
<!ENTITY szlig "&#xdf;">
<!ENTITY Tau "&#x3a4;">
<!ENTITY tau "&#x3c4;">
<!ENTITY there4 "&#x2234;">
<!ENTITY Theta "&#x398;">
<!ENTITY theta "&#x3b8;">
<!ENTITY thetasym "&#x3d1;">
<!ENTITY thetav "&#x3d1;">
<!ENTITY thinsp "&#x2009;">
<!ENTITY THORN "&#xde;">
<!ENTITY thorn "&#xfe;">
<!ENTITY tilde "&#x2dc;">
<!ENTITY times "&#xd7;">
<!ENTITY trade "&#xf8ea;">
<!ENTITY Uacute "&#xda;">
<!ENTITY uacute "&#xfa;">
<!ENTITY uarr "&#x2191;">
<!ENTITY uArr "&#x21d1;">
<!ENTITY Ucirc "&#xdb;">
<!ENTITY ucirc "&#xfb;">
<!ENTITY Ugrave "&#xd9;">
<!ENTITY ugrave "&#xf9;">
<!ENTITY uml "&#xa8;">
<!ENTITY upsih "&#x3d2;">
<!ENTITY Upsilon "&#x3a5;">
<!ENTITY upsilon "&#x3c5;">
<!ENTITY Uuml "&#xdc;">
<!ENTITY uuml "&#xfc;">
<!ENTITY weierp "&#x2118;">
<!ENTITY Xi "&#x39e;">
<!ENTITY xi "&#x3be;">
<!ENTITY Yacute "&#xdd;">
<!ENTITY yacute "&#xfd;">
<!ENTITY yen "&#xa5;">
<!ENTITY Yuml "&#x178;">
<!ENTITY yuml "&#xff;">
<!ENTITY Zeta "&#x396;">
<!ENTITY zeta "&#x3b6;">
<!ENTITY zwj "&#x200d;">
<!ENTITY zwnj "&#x200c;">

-->

<!ENTITY pound "&#xa3;">
<!ENTITY nbsp "&#xa0;">
"""

# List of tags which are the same in both XHTML and RML
xhtml_friendly_tags = ['b', 'i', 'u', 'pre', 'tr', 'td', 'font', 'h1', 'h2', 'h3', 'sub', 'super', 'a', 'img']

# The below tags support only fewer attributes
# FIXME: Need to find out if this information could be extracted from the dtd
subset_tags = {
    'a' : ['href'],
    'img' : ['src', 'width', 'height', 'alt'],
    'p' : ['align', 'style'],
    'table' : [],
    }

# Dictionary for tags that are easy to substitute
subs_start_tag = {
    'strong' : 'b',
    'br' : '',
    'table' : 'blockTable'
    }

subs_end_tag = {
    'li' : '</para>',
    'strong' : '</b>',
    'br' : '',
    'table' : '</blockTable>',
    }

# These tags are overridden using custom start and end methods. This list needs to be updated whenever you are overriding a tag.
# Otherwise "filterTags" will not work properly.
override_tags = ['ul', 'ol', 'li', 'img', 'p']

tidy_options = {
    'break_before_br': 0,
    'clean': 1,
    'output_xhtml': 1,
    'word_2000': 1,
    'indent': 'no',
    'wrap': 0,
    'enclose_block_text' : 0,
    'quote_ampersand' : 1,
    'add_xml_decl' : 0,
}

_debug = 0

full_html_mode_tags = ['html', 'head', 'body', 'title', 'meta', 'style', 'script']

# rltext Tidy related options
TAG_MODE = "tagMode" # Returns tidied tags with no special processing.
BLOCK_MODE = "blockMode" # Wraps a <p> tag around the content
PAGE_MODE = "pageMode" # Returns a full valid html page

def _entityOpeningCallBack(dtdReference):
    """PyRXPU supports callbacks to supply a DTD if one is requested

    We may still need to ensure that a DTD is requested in the XML,
    by prefixing a doctype declaration.

    These callbacks may return either
    a. a single element, which should be the resolved name (e.g. turn foo.dtd
    into a URL pointing to it), or
    b. a two-element with the resolved name and the string content to use
    """
    return (dtdReference, dtdstring)

def wrapForParsing(source):
    """Turn brief input into a full XHTML document for validation

    Given a bunch of <p> tags, we need to wrap them in  <body> tag
    and add the doctype header, so pyRXPU can do its work.  However,
    if it's already a full document, do not change it.
    """
    original = source
    rootElement = 'body'
    source = source.strip()
    if source.startswith('<!DOCTYPE') or source.startswith('<?'):
        pass
    else:
        if source.startswith("<html"):
            rootElement = 'html'
        else: #most common case - they gave us paragraphs, we add body.
            #we can validate against body or against html
            if not source.startswith("<body"):
                source = "<%s>%s" % (rootElement, source)
            if not source.endswith("body>"):
                source = "%s</%s>" % (source, rootElement)
    source = applyDocType(source.strip(), rootElement, dtd)
    return source

def createTupleTree(input, ref='<string>', expandRef=0):
    """Validate and return tuple tree, with 'body' tag usually added

    'ref' aids in tracebacks, so you can pass in where the data came from.
    This might be used to pass in a fieldname, or a database record id and fieldname
    if coming from a database.  This way, validation tracebacks can tell the end user
    which record or file was broken e.g.
        ("Unknown tag <foo in line 238 of (Hotel'ABAOP', field 'diningInfo')


    >>> createTupleTree('<p>hello</p>')
    (u'body', None, [(u'p', None, [u'hello'], None)], None)
    >>>
    """
    p = pyRXPU.Parser(
                ErrorOnValidityErrors=1,
                ExpandCharacterEntities=expandRef,
                ExpandGeneralEntities=expandRef,
                srcName=ref,
                #warnCB=self._warnCB,
                eoCB=_entityOpeningCallBack,
                )
    wrapped = wrapForParsing(escu(input))
    tree = p.parse(wrapped)
    return tree


def validate(input, ref='<string>'):
    """Checks the input is valid 'rltext'

    Returns nothing, or a helpful exception.
    Behaves like createTupleTree but used when your intent
    is simply to validate, so returns True.

    It is not necessary to supply the <html> and '<body>' tags;
    you can supply a sequence of <p> tags and that's fine.


    It will catch badly nested tags....
    >>> validate('<p><b>hello</i></p>')
    Traceback (most recent call last):
       ...
    error: Error: Mismatched end tag: expected </b>, got </i>
     in unnamed entity at line 2 char 21 of <string>
    Mismatched end tag: expected </b>, got </i>
    Parse Failed!
    <BLANKLINE>

    ...poorly quoted text...
    >>> createTupleTree('<h2>Pig & Whistle</h2>')
    Traceback (most recent call last):
      File "C:\Python25\lib\doctest.py", line 1212, in __run
        compileflags, 1) in test.globs
      File "<doctest rltext.validate[1]>", line 1, in <module>
        createTupleTree('<h2>Pig & Whistle</h2>')
      File "C:\code\rlextra\radxml\rltext.py", line 421, in createTupleTree
        tree = p.parse(wrapped)
    error: Error: Expected name, but got <space> for entity
     in unnamed entity at line 2 char 16 of <string>
    Expected name, but got <space> for entity
    Parse Failed!
    <BLANKLINE>
    """
    tree = createTupleTree(input, ref)
    return True

# Class which extends XhtmlTransformer and does validation with our own dtd.
class myXhtmlTransformer(XhtmlTransformer):

    def __init__(self, xmlSource, formatter):
        self._formatter = formatter
        self._inBody = False  # stuff in the header is always our own boilerplate junk
        self._flowingElementStack = []  # LIFO [(elementName, autoClose), ...]
        #tree = validate(xmlSource)
        tree = createTupleTree(xmlSource, ref='<string>')
        TupleTreeWalker.__init__(self, tree)

class RmlMaker(TupleTreeWalker):
    def __init__(self, tree, context):
        TupleTreeWalker.__init__(self, tree)
        self.output = []  #build a list of strings
        self.context = context  #might want extra info (class / style names?)
        self.l_list = []

    def startElement(self, tagName, attrs):
        #print 'startTag(%s)' % tagName
        if hasattr(self, 'start_%s' % tagName):
            method = getattr(self, 'start_%s' % tagName)
            return method(tagName, attrs)
        elif tagName in xhtml_friendly_tags:
            return self.start_default_tag(tagName, attrs)
        elif tagName in subs_start_tag:
            return self.start_subs_tag(tagName, attrs)

    def endElement(self, tagName):
        if hasattr(self, 'end_%s' % tagName):
            method = getattr(self, 'end_%s' % tagName)
            return method(tagName)
        elif tagName in xhtml_friendly_tags:
            return self.end_default_tag(tagName)
        elif tagName in subs_end_tag:
            return self.end_subs_tag(tagName)

    def end(self):
        self.rml = ''.join(self.output)

    def characters(self, text):
        self.output.append(text)

    #now we write a tag handler for each tag we care about.
    #Others will be ignored.

    # Handler for tags which are the same in XHTML and RML
    def start_default_tag(self, tagName, attrs):
        tagName = tagName.lower()
        newtag = '<' + tagName + self.get_supported_attrs(tagName, attrs) + '>'
        if tagName in subs_start_tag:
            if len(subs_start_tag[tagName.lower()].strip()) < 1:
                return
            newtag = '<' + subs_start_tag[tagName] + self.get_supported_attrs(tagName, attrs) + '>'
        self.output.append(newtag)

    def end_default_tag(self, tagName):
        newtag = '</' + tagName.lower() + '>'
        if tagName in subs_end_tag:
            newtag = subs_end_tag[tagName.lower()]
        self.output.append(newtag)

    # Handler for tags which are easy to substitute like <para> for <p>
    def start_subs_tag(self, tagName, attrs):
        if len(subs_start_tag[tagName.lower()].strip()) < 1:
            return
        else:
            newtag = '<' + subs_start_tag[tagName.lower()] + '>'
            self.output.append(newtag)

    def end_subs_tag(self, tagName):
        if len(subs_end_tag[tagName.lower()].strip()) < 1:
            return
        else:
            self.output.append(subs_end_tag[tagName.lower()])

    # Handler for ul tag
    def start_ul(self, tagName, attrs):
        self.output.append('<indent left="%dcm">'%(len(self.l_list)*1 + 1))
        self.l_list.append('ul')

    def end_ul(self, tagName):
        self.output.append('</indent>')
        self.l_list.pop()

    # Handler for ol tag
    def start_ol(self, tagName, attrs):
        self.output.append('<fixedSize><para>')
        id_str = getRandString(length=3)
        self.output.append('<seqFormat id="%s" value="1"/>'%id_str)
        self.output.append('</para></fixedSize>')
        self.output.append('<indent left="%dcm">'%(len(self.l_list)*1 + 1))
        self.l_list.append('ol|%s'%id_str)

    def end_ol(self, tagName):
        self.output.append('</indent>')
        elem = self.l_list.pop()
        if elem.startswith('ol'):
            arr = elem.split('|')
            if len(arr) > 1:
                id = arr[1]
                self.output.append('<fixedSize><para>')
                self.output.append('<seqReset id="%s"/>'%id)
                self.output.append('</para></fixedSize>')

    # Handler for li tag
    def start_li(self, tagName, attrs):
        self.output.append('<para>')
        if self.l_list[-1].startswith('ul'):
            self.output.append('<bullet bulletIndent="3mm">&bull;')
        elif self.l_list[-1].startswith('ol'):
            self.output.append('<bullet bulletIndent="3mm">')
            elem = self.l_list[-1]
            arr = elem.split('|')
            if len(arr) > 1:
                id = arr[1]
            self.output.append('<seq id="%s"/>.'%id)
        self.output.append('</bullet>')

    def end_li(self, tagName):
        self.output.append('</para>')

    # Handler for tags like a, which supports only a subset
    def get_supported_attrs(self, tagName, attrs):
        if tagName in subset_tags:
            supported_attrs = subset_tags[tagName.lower()]
            attr_list = [ key.lower() + '=' + quote_str(attrs[key.lower()]) for key in attrs if key in supported_attrs]
            return (' ' + ' '.join(attr_list) + ' ')
        else:
            return ''

    # Handler for image tags
    def start_img(self, tagName, attrs):
        replace_attrs = {'src' : 'imageName', 'width' : 'imageWidth', 'height' : 'imageHeight', 'alt': 'alternativeText'}
        supported_attrs = subset_tags[tagName.lower()]
        attr_list = [ replace_attrs[key.lower()] + '=' + quote_str(attrs[key]) for key in attrs if key in supported_attrs]
        self.output.append('<imageFigure')
        self.output.append(' ' + ' '.join(attr_list) + '>')

    def end_img(self, tagName):
        self.output.append('</imageFigure>')

    # Handler for p tag. Simillar to img tag. Can generalize even this. But dont want because of readability issues
    def start_p(self, tagName, attrs):
        replace_attrs = {'align' : 'alignment', 'style' : 'style'}
        supported_attrs = subset_tags[tagName.lower()]
        attr_list = [ replace_attrs[key.lower()] + '=' + quote_str(attrs[key]) for key in attrs if key in supported_attrs]
        self.output.append('<para')
        attrs = ' '.join(attr_list)
        if attrs and len(attrs.strip()) > 1:
            self.output.append(' ' + attrs + '>')
        else:
            self.output.append('>')

    def end_p(self, tagName):
        self.output.append('</para>')

def quote_str(str):
    return quoteattr(str) # saxutils' quoteattr method.

def escu(txt):
    if txt == None:
        return ""
    """Use this for quoting text fields (which might contain non-ascii
    such as pound symbols, and '&' signs.  If they are unicode, it
    converts to UTF8 first."""
    if type(txt) is UnicodeType:
        bytes = txt.encode('utf8')
    else:
        bytes = txt
    return bytes

"""
Method to convert xhtml2rml. Validate should have been called before calling this method.
"""
def toRML(source, reference='<string>', context=None):
    """
    Converts the given XHTML text to rml
    >>> toRML('<p>Hello World</p>')
    u'<para>Hello World</para>'

    An example for a tag that requires no substition
    >>> toRML('<p><b>Hello World</b></p>')
    u'<para><b>Hello World</b></para>'

    This should appear without pound symbol
    >>> toRML('<p>&pound;&nbsp;&pound;</p>')
    u'<para>&pound;&nbsp;&pound;</para>'

    """
    tree = createTupleTree(escu(source), reference, expandRef=0)
    rm = RmlMaker(tree, context)
    rm.go()
    return rm.rml

# Utility method to get a random string. Used to get a dummy filename
def getRandString(length=10):
    twoletters = [c+d for c in string.letters for d in string.letters]
    r = random.random
    n = len(twoletters)
    l2 = length//2
    lst = [None] * l2
    for i in xrange(l2):
        lst[i] = twoletters[int(r() * n)]
    if length & 1:
        lst.append(random.choice(string.letters))
    return "".join(lst)

# Method to filter unwanted tags from the input and return only valid Xhtml
"""
def normalize(xhtml):
    formatter = HtmlFormatter(False) # Don't apply styles
    import rlextra.django.common.transform
    tr = myXhtmlTransformer(xhtml, formatter)
    output = tr.getOutput()
    output = output.encode('utf-8')
    return output
"""

def escapeOnce(data):
    """Ensure output is escaped just once, irrespective of input

    >>> escapeOnce('A & B')
    'A &amp; B'
    >>> escapeOnce('C &amp; D')
    'C &amp; D'
    >>> escapeOnce('E &amp;amp; F')
    'E &amp; F'

    """
    data = data.replace("&", "&amp;")

    #...but if it was already escaped, make sure it
    # is not done twice....this will turn any tags
    # back to how they were at the start.
    data = data.replace("&amp;amp;", "&amp;")
    data = data.replace("&amp;gt;", "&gt;")
    data = data.replace("&amp;lt;", "&lt;")
    data = data.replace("&amp;#", "&#")

    #..and just in case someone had double-escaped it, do it again
    data = data.replace("&amp;amp;", "&amp;")
    data = data.replace("&amp;gt;", "&gt;")
    data = data.replace("&amp;lt;", "&lt;")
    return data


#def normalize(xhtml, tidy_needed=False):
#    """ Normalize test cases
#    >>> normalize('<p><b>A & B</i></p>')
#    '<p><b>A &amp; B</b></p>'
#
#    >>> normalize('<p>Dick & Jane</p>')
#    '<p>Dick &amp; Jane</p>'
#
#    >>> normalize('<p>&amp;</p>')
#    '<p>&amp;</p>'
#
#    >>> normalize('<p>&amp;amp;</p>')
#    '<p>&amp;</p>'
#
#    >>> normalize('<p>&</p>')
#    '<p>&amp;</p>'
#
#    >>> normalize('<p><b>blah</i></p>')
#    '<p><b>blah</b></p>'
#    """
#    xhtml = filterTags(xhtml)
#    if tidy_needed:
#        clean_xhtml = tidy(xhtml)
#    else:
#        clean_xhtml = escapeOnce(xhtml)
#    return clean_xhtml

def normalize(xhtml, mode='block', options={}):
    c = Cleaner(target=mode, **options)
    if not xhtml:
        return xhtml
    elif isinstance(xhtml, int) or isinstance(xhtml, long):
        xhtml = str(xhtml)
    return c.process(xhtml)

def filterTags(xhtml, full_html_mode=False):
    """
    Reliably filters unwanted tags and attributes
    >>> filterTags('<p><apple>Hello world</apple></p>')
    '<p>Hello world</p>'

    >>> filterTags('<p><apple>Hello world</p>')
    '<p>Hello world</p>'

    >>> filterTags('<p id="myid">Hello world</p>')
    '<p>Hello world</p>'

    >>> filterTags('<p id="myid" style="a">Hello world</p>')
    '<p style="a">Hello world</p>'
    """
    # List of valid_tags
    valid_tags = xhtml_friendly_tags
    valid_tags += [key for key in subset_tags]
    valid_tags += [key for key in subs_start_tag]
    valid_tags += override_tags
    # If the submitted content is a full html generated by tidy, then add extra tags
    if full_html_mode:
        xhtml = getBody(xhtml)

    # Wrap table inside <p>
    xhtml = xhtml.replace('<table', '</p><table')

    # Fix screw ups!
    xhtml = xhtml.replace('</p></p><table', '</p><table')

    soup = BeautifulSoup(xhtml)
    for tag in soup.findAll(True):
        if tag.name not in valid_tags:
            tag.hidden = True
        # fix the attributes also magically
        tag.attrs = [(attr, val) for attr, val in tag.attrs
                     if tag.name in subset_tags
                     if attr in subset_tags[str(tag.name)]]
    contents = soup.renderContents().decode('utf8')

    # Read here http://ha.ckers.org/xss.html about xss attacks. Making sure we are not vulnerable to this
    import re
    regex = re.compile('j[\s]*(&#x.{1,7})?a[\s]*(&#x.{1,7})?v[\s]*(&#x.{1,7})?a[\s]*(&#x.{1,7})?s[\s]*(&#x.{1,7})?c[\s]*(&#x.{1,7})?r[\s]*(&#x.{1,7})?i[\s]*(&#x.{1,7})?p[\s]*(&#x.{1,7})?t', re.IGNORECASE)
    contents = regex.sub('', contents)

    #if not contents.lstrip().startswith('<p') and not contents.lstrip().startswith('<P'):
    #    contents = '<p>' + contents
    #if not contents.rstrip().endswith('</p>') and not contents.rstrip().endswith('</P>'):
    #    contents = contents + '</p>'

    return escu(contents)

def run_tidy(input, output=None, errors=None, tidy_options=tidy_options):
    (nerrors, nwarnings, outputdata, errordata) = Tidy.tidy(input, output, errors, **tidy_options)
    if _debug and errordata:
        print 'Tidy messages:'
        print
        print errordata
        print
    return outputdata

def tidy(input_str, mode=None):
    outputdata = run_tidy(input_str)
    # Can't figure out how to make Tidy return just the tag alone without returning the full HTML.
    # Hence using beautiful soup to extract what I want alone.
    if mode == TAG_MODE:
        getBody(outputdata)
    elif mode == BLOCK_MODE:
        contents = getBody('<p>' + outputdata + '</p>')
        return contents
    else:
        return outputdata


def getBody(xhtml, pretty_output=False):
    """
    Extracts and returns body tag alone from a xhtml. If it is not found, then the same xhtml is returned back.
    >>> getBody('<p>Hello World</p>')
    '<p>Hello World</p>'

    >>> getBody('<html><body><p>Hello World</p></body></html>')
    '<p>Hello World</p>'
    """
    delimiter = ''
    if pretty_output:
        delimiter = '\n'
    if xhtml.find('<body>') == -1:
        return xhtml
    else:
        soup = BeautifulSoup(xhtml)
        contents_list = soup.html.body.contents
        return delimiter.join([ str(content) for content in contents_list if str(content) != '\n'])

if __name__ == "__main__":
    import doctest, rltext
    doctest.testmod(rltext)
    input = "<p id='myid' style='a'><a href='blah' style='asgd'>Hello world</a></p>"
    input = """
    <p>Refuge luxueux et original située à 50 km à l’est de Mahé, Frégate Island Private se compose de 16 villas privées.  La règle qui prévaut dans l’île est la préservation et la protection d’un environnement naturel unique.  Dans ce lieu harmonieusement préservé, l’hôtel propose un somptueux décor et des installations luxueuses qui vous permettront de vivre à l’écart du monde et de jouir d’un repos complet dans une totale intimité.  La beauté naturelle de l’île, une cuisine gastronomique délicieuse, un large éventail d’activités sportives et de loisirs, deux piscines (dont une de 25 mètres pour ceux qui souhaitent faire des longueurs!): tout est organisé pour répondre à vos attentes les plus exigeantes.  Sont également accessibles le “Castaway Kids Club” et “The Rock Spa”.</p>
    """
    input = """
    <body>Below is a good table<table class="btxt" cellspacing="2" cellpadding="3" border="0"><tbody><tr><td>&#160;</td><td align="center" bgcolor="#01aef0"><span class="whitetxt">jan</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">fev</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">mar</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">avril</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">mai</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">juin</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">jul</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">o&#251;t</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">sep</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">oct</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">nov</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">dec</span></td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Les pr&#233;cipitations (millim&#232;tres)</div></span></td><td align="right" bgcolor="#eeeeee">402.6</td><td align="right" bgcolor="#eeeeee">283.2</td><td align="right" bgcolor="#eeeeee">194.9</td><td align="right" bgcolor="#eeeeee">186.7</td><td align="right" bgcolor="#eeeeee">151.6</td><td align="right" bgcolor="#eeeeee">105.1</td><td align="right" bgcolor="#eeeeee">76.6</td><td align="right" bgcolor="#eeeeee">119.3</td><td align="right" bgcolor="#eeeeee">154.0</td><td align="right" bgcolor="#eeeeee">189.7</td><td align="right" bgcolor="#eeeeee">206.3</td><td align="right" bgcolor="#eeeeee">302.8</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>La temp&#233;rature (&#186;C)</div></span></td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">27.4</td><td align="right" bgcolor="#eeeeee">27.8</td><td align="right" bgcolor="#eeeeee">28.1</td><td align="right" bgcolor="#eeeeee">27.8</td><td align="right" bgcolor="#eeeeee">26.7</td><td align="right" bgcolor="#eeeeee">26.0</td><td align="right" bgcolor="#eeeeee">26.0</td><td align="right" bgcolor="#eeeeee">26.5</td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">26.9</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Humidit&#233; relative (%)</div></span></td><td align="right" bgcolor="#eeeeee">82</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">82</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Direction du vent (kts)</div></span></td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">SW-NW</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SW-NW</td><td align="right" bgcolor="#eeeeee">NW</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div><div>Vitesse du vent</div></div></span></td><td align="right" bgcolor="#eeeeee">6.3</td><td align="right" bgcolor="#eeeeee">6.3</td><td align="right" bgcolor="#eeeeee">5.2</td><td align="right" bgcolor="#eeeeee">4.9</td><td align="right" bgcolor="#eeeeee">7.8</td><td align="right" bgcolor="#eeeeee">10.4</td><td align="right" bgcolor="#eeeeee">11.4</td><td align="right" bgcolor="#eeeeee">12.1</td><td align="right" bgcolor="#eeeeee">11.3</td><td align="right" bgcolor="#eeeeee">7.9</td><td align="right" bgcolor="#eeeeee">5.4</td><td align="right" bgcolor="#eeeeee">5.4</td></tr></tbody></table></body>
    """
    input = """
    <p>Les Seychelles jouissent d&#8217;un agr&#233;able climat chaud toute l&#8217;ann&#233;e. &#160;Dans cet asile tropical, la temp&#233;rature chute rarement au-dessous de 24&#176;C ni ne d&#233;passe les 32&#176;C. &#160;Except&#233; les &#206;les m&#233;ridionales les plus distantes, la majorit&#233; des &#206;les de l&#8217;archipel se situent hors de la zone des cyclones, faisant des Seychelles une destination id&#233;ale pour les amoureux de plage et du soleil, quelque soit la saison.</p><p>Lorsque les aliz&#233;s soufflent du nord-ouest d&#8217;octobre &#224; mars, la mer est g&#233;n&#233;ralement calme et le temps chaud et humide, avec les vents moyens de 8-12 noeuds.</p><p>En janvier et f&#233;vrier les &#206;les sont arros&#233;es par des pluies abondantes, approvisionnant les fleuves et faisant vibrer les feuillages sur fond d&#8217;arcs-en-ciel color&#233;s.</p><p>Lorsque les aliz&#233;s soufflent du sud-est de mai &#224; septembre, le temps est plus sec, moins humide et plus frais, avec une mer un peu agit&#233;e, en particulier sur les c&#244;tes du sud-est, et des vents de 10-20 noeuds.</p><p>Vous trouverez ci-dessous un tableau r&#233;capitulatif des moyennes statistiques pour l'a&#233;roport international des Seychelles de 1972 &#224; 2005 (fourni par les Services M&#233;t&#233;orologique des Seychelles). &#160;Pour plus d&#8217;information, veuillez consulter le site m&#233;t&#233;orologique des Seychelles: <u><a href="http://www.pps.gov.sc/meteo/">Seychelles Meteorological Services</a></u>.</p><table class="btxt" cellspacing="2" cellpadding="3" border="0"><tbody><tr><td>&#160;</td><td align="center" bgcolor="#01aef0"><span class="whitetxt">jan</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">fev</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">mar</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">avril</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">mai</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">juin</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">jul</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">o&#251;t</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">sep</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">oct</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">nov</span></td><td align="center" bgcolor="#01aef0"><span class="whitetxt">dec</span></td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Les pr&#233;cipitations (millim&#232;tres)</div></span></td><td align="right" bgcolor="#eeeeee">402.6</td><td align="right" bgcolor="#eeeeee">283.2</td><td align="right" bgcolor="#eeeeee">194.9</td><td align="right" bgcolor="#eeeeee">186.7</td><td align="right" bgcolor="#eeeeee">151.6</td><td align="right" bgcolor="#eeeeee">105.1</td><td align="right" bgcolor="#eeeeee">76.6</td><td align="right" bgcolor="#eeeeee">119.3</td><td align="right" bgcolor="#eeeeee">154.0</td><td align="right" bgcolor="#eeeeee">189.7</td><td align="right" bgcolor="#eeeeee">206.3</td><td align="right" bgcolor="#eeeeee">302.8</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>La temp&#233;rature (&#186;C)</div></span></td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">27.4</td><td align="right" bgcolor="#eeeeee">27.8</td><td align="right" bgcolor="#eeeeee">28.1</td><td align="right" bgcolor="#eeeeee">27.8</td><td align="right" bgcolor="#eeeeee">26.7</td><td align="right" bgcolor="#eeeeee">26.0</td><td align="right" bgcolor="#eeeeee">26.0</td><td align="right" bgcolor="#eeeeee">26.5</td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">26.9</td><td align="right" bgcolor="#eeeeee">26.9</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Humidit&#233; relative (%)</div></span></td><td align="right" bgcolor="#eeeeee">82</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">79</td><td align="right" bgcolor="#eeeeee">80</td><td align="right" bgcolor="#eeeeee">82</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div>Direction du vent (kts)</div></span></td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">NW</td><td align="right" bgcolor="#eeeeee">SW-NW</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SE</td><td align="right" bgcolor="#eeeeee">SW-NW</td><td align="right" bgcolor="#eeeeee">NW</td></tr><tr><td bgcolor="#01aef0"><span class="whitetxt"><div><div>Vitesse du vent</div></div></span></td><td align="right" bgcolor="#eeeeee">6.3</td><td align="right" bgcolor="#eeeeee">6.3</td><td align="right" bgcolor="#eeeeee">5.2</td><td align="right" bgcolor="#eeeeee">4.9</td><td align="right" bgcolor="#eeeeee">7.8</td><td align="right" bgcolor="#eeeeee">10.4</td><td align="right" bgcolor="#eeeeee">11.4</td><td align="right" bgcolor="#eeeeee">12.1</td><td align="right" bgcolor="#eeeeee">11.3</td><td align="right" bgcolor="#eeeeee">7.9</td><td align="right" bgcolor="#eeeeee">5.4</td><td align="right" bgcolor="#eeeeee">5.4</td></tr></tbody></table>
    """
    input == """
    <p>Les Seychelles jouissent d'un agr&eacute;able climat chaud toute l'ann&eacute;e. &nbsp;Dans cet asile tropical, la temp&eacute;rature chute rarement au-dessous de 24&deg;C ni ne d&eacute;passe les 32&deg;C. &nbsp;Except&eacute; les &Icirc;les m&eacute;ridionales les plus distantes, la majorit&eacute; des &Icirc;les de l'archipel se situent hors de la zone des cyclones, faisant des Seychelles une destination id&eacute;ale pour les amoureux de plage et du soleil, quelque soit la saison.</p>
<p>Lorsque les aliz&eacute;s soufflent du nord-ouest d'octobre &agrave; mars, la mer est g&eacute;n&eacute;ralement calme et le temps chaud et humide, avec les vents moyens de 8-12 noeuds.</p>
<p>En janvier et f&eacute;vrier les &Icirc;les sont arros&eacute;es par des pluies abondantes, approvisionnant les fleuves et faisant vibrer les feuillages sur fond d'arcs-en-ciel color&eacute;s.</p>
<p>Lorsque les aliz&eacute;s soufflent du sud-est de mai &agrave; septembre, le temps est plus sec, moins humide et plus frais, avec une mer un peu agit&eacute;e, en particulier sur les c&ocirc;tes du sud-est, et des vents de 10-20 noeuds.</p>
<p>Vous trouverez ci-dessous un tableau r&eacute;capitulatif des moyennes statistiques pour l'a&eacute;roport international des Seychelles de 1972 &agrave; 2005 (fourni par les Services M&eacute;t&eacute;orologique des Seychelles). &nbsp;Pour plus d'information, veuillez consulter le site m&eacute;t&eacute;orologique des Seychelles: <u><a href="http://www.pps.gov.sc/meteo/">Seychelles Meteorological Services</a></u>.</p>
<table>

<tr>
<td>&nbsp;</td>
<td>jan</td>
<td>fev</td>
<td>mar</td>
<td>avril</td>
<td>mai</td>
<td>juin</td>
<td>jul</td>
<td>o&ucirc;t</td>
<td>sep</td>
<td>oct</td>
<td>nov</td>
<td>dec</td>
</tr>
<tr>
<td>
Les pr&eacute;cipitations (millim&egrave;tres)
</td>
<td>402.6</td>
<td>283.2</td>
<td>194.9</td>
<td>186.7</td>
<td>151.6</td>
<td>105.1</td>
<td>76.6</td>
<td>119.3</td>
<td>154.0</td>
<td>189.7</td>
<td>206.3</td>
<td>302.8</td>
</tr>
<tr>
<td>
La temp&eacute;rature (&ordm;C)
</td>
<td>26.9</td>
<td>27.4</td>
<td>27.8</td>
<td>28.1</td>
<td>27.8</td>
<td>26.7</td>
<td>26.0</td>
<td>26.0</td>
<td>26.5</td>
<td>26.9</td>
<td>26.9</td>
<td>26.9</td>
</tr>
<tr>
<td>
Humidit&eacute; relative (%)
</td>
<td>82</td>
<td>80</td>
<td>80</td>
<td>80</td>
<td>79</td>
<td>79</td>
<td>80</td>
<td>80</td>
<td>79</td>
<td>79</td>
<td>80</td>
<td>82</td>
</tr>
<tr>
<td>
Direction du vent (kts)
</td>
<td>NW</td>
<td>NW</td>
<td>NW</td>
<td>SW-NW</td>
<td>SE</td>
<td>SE</td>
<td>SE</td>
<td>SE</td>
<td>SE</td>
<td>SE</td>
<td>SW-NW</td>
<td>NW</td>
</tr>
<tr>
<td>
Vitesse du vent
</td>
<td>6.3</td>
<td>6.3</td>
<td>5.2</td>
<td>4.9</td>
<td>7.8</td>
<td>10.4</td>
<td>11.4</td>
<td>12.1</td>
<td>11.3</td>
<td>7.9</td>
<td>5.4</td>
<td>5.4</td>
</tr>

</table>
<p>Il y a trois langues officielles aux Seychelles: le Cr&#233;ole (patois bas&#233; sur le Fran&#231;ais), l&#8217;Anglais et le Fran&#231;ais. &#160;Beaucoup de seychellois parlent &#233;galement couramment l&#8217;Italien et l&#8217;Allemand.<br /><br />Voici quelques expressions cr&#233;oles bien utiles:</p><table class="btxt" cellspacing="2" cellpadding="2" align="left" border="0"><tbody><tr class="tablerow"><td class="tableheader" width="160">Fran&#231;ais</td><td class="tableheader" width="160">Creole</td></tr><tr bgcolor="#eeeeee"><td width="160">Bonjour</td><td width="160">Bonzour</td></tr><tr bgcolor="#eeeeee"><td width="160">Au revoir</td><td width="160">Orevwar</td></tr><tr bgcolor="#eeeeee"><td width="160">Comment allez vous?</td><td width="160">Ki dir?</td></tr><tr bgcolor="#eeeeee"><td width="160">Merci</td><td width="160">Mersi</td></tr><tr bgcolor="#eeeeee"><td width="160">O&#249;?</td><td width="160">Kote?</td></tr><tr bgcolor="#eeeeee"><td width="160">S&#8217;il vous pla&#206;t</td><td width="160">Silvouple</td></tr><tr bgcolor="#eeeeee"><td width="160">Non</td><td width="160">Non</td></tr><tr bgcolor="#eeeeee"><td width="160">Oui</td><td width="160">Wi</td></tr><tr bgcolor="#eeeeee"><td width="160">Je ne comprends pas</td><td width="160">Mon pa konpran</td></tr><tr bgcolor="#eeeeee"><td width="160">&#231;a me pla&#206;t</td><td width="160">Mon kontan</td></tr><tr bgcolor="#eeeeee"><td width="160">Comment &#231;a va?</td><td width="160">Konman sava?</td></tr><tr bgcolor="#eeeeee"><td width="160">Qu&#8217;est ce que c&#8217;est?</td><td width="160">Kisisa?</td></tr></tbody></table>
"""
    nxhtml = normalize(input)
    #print nxhtml
    #print toRML(nxhtml)
    #print tidy(input, mode=TAG_MODE)

    input = """
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <title></title>
    </head>
    <body>
    <p>Les Seychelles jouissent d'un agr&eacute;able climat chaud toute l'ann&eacute;e. &nbsp;Dans cet asile tropical, la temp&eacute;rature chute rarement au-dessous de 24&deg;C ni ne d&eacute;passe les 32&deg;C. &nbsp;Except&eacute; les &Icirc;les m&eacute;ridionales les plus distantes, la majorit&eacute; des &Icirc;les de l'archipel se situent hors de la zone des cyclones, faisant des Seychelles une destination id&eacute;ale pour les amoureux de plage et du soleil, quelque soit la saison.</p>

    <p>Lorsque les aliz&eacute;s soufflent du nord-ouest d'octobre &agrave; mars, la mer est g&eacute;n&eacute;ralement calme et le temps chaud et humide, avec les vents moyens de 8-12 noeuds.</p>

    <p>En janvier et f&eacute;vrier les &Icirc;les sont arros&eacute;es par des pluies abondantes, approvisionnant les fleuves et faisant vibrer les feuillages sur fond d'arcs-en-ciel color&eacute;s.</p>

    <p>Lorsque les aliz&eacute;s soufflent du sud-est de mai &agrave; septembre, le temps est plus sec, moins humide et plus frais, avec une mer un peu agit&eacute;e, en particulier sur les c&ocirc;tes du sud-est, et des vents de 10-20 noeuds.</p>

    <p>Vous trouverez ci-dessous un tableau r&eacute;capitulatif des moyennes statistiques pour l'a&eacute;roport international des Seychelles de 1972 &agrave; 2005 (fourni par les Services M&eacute;t&eacute;orologique des Seychelles). &nbsp;Pour plus d'information, veuillez consulter le site m&eacute;t&eacute;orologique des Seychelles: <a href="http://www.pps.gov.sc/meteo/">Seychelles Meteorological Services</a>.</p>

    <br />
    <br />


    <p><br />
    </p>

    <table>
    <tr>
    <td>&nbsp;</td>
    <td>jan</td>
    <td>fev</td>
    <td>mar</td>
    <td>avril</td>
    <td>mai</td>
    <td>juin</td>
    <td>jul</td>
    <td>o&ucirc;t</td>
    <td>sep</td>
    <td>oct</td>
    <td>nov</td>
    <td>dec</td>
    </tr>

    <tr>
    <td>Les pr&eacute;cipitations (millim&egrave;tres)</td>
    <td>402.6</td>
    <td>283.2</td>
    <td>194.9</td>
    <td>186.7</td>
    <td>151.6</td>
    <td>105.1</td>
    <td>76.6</td>
    <td>119.3</td>
    <td>154.0</td>
    <td>189.7</td>
    <td>206.3</td>
    <td>302.8</td>
    </tr>

    <tr>
    <td>La temp&eacute;rature (&ordm;C)</td>
    <td>26.9</td>
    <td>27.4</td>
    <td>27.8</td>
    <td>28.1</td>
    <td>27.8</td>
    <td>26.7</td>
    <td>26.0</td>
    <td>26.0</td>
    <td>26.5</td>
    <td>26.9</td>
    <td>26.9</td>
    <td>26.9</td>
    </tr>

    <tr>
    <td>Humidit&eacute; relative (%)</td>
    <td>82</td>
    <td>80</td>
    <td>80</td>
    <td>80</td>
    <td>79</td>
    <td>79</td>
    <td>80</td>
    <td>80</td>
    <td>79</td>
    <td>79</td>
    <td>80</td>
    <td>82</td>
    </tr>

    <tr>
    <td>Direction du vent (kts)</td>
    <td>NW</td>
    <td>NW</td>
    <td>NW</td>
    <td>SW-NW</td>
    <td>SE</td>
    <td>SE</td>
    <td>SE</td>
    <td>SE</td>
    <td>SE</td>
    <td>SE</td>
    <td>SW-NW</td>
    <td>NW</td>
    </tr>

    <tr>
    <td>Vitesse du vent</td>
    <td>6.3</td>
    <td>6.3</td>
    <td>5.2</td>
    <td>4.9</td>
    <td>7.8</td>
    <td>10.4</td>
    <td>11.4</td>
    <td>12.1</td>
    <td>11.3</td>
    <td>7.9</td>
    <td>5.4</td>
    <td>5.4</td>
    </tr>
    </table>

    <p></p>

    <p>Il y a trois langues officielles aux Seychelles: le Cr&eacute;ole (patois bas&eacute; sur le Fran&ccedil;ais), l'Anglais et le Fran&ccedil;ais. &nbsp;Beaucoup de seychellois parlent &eacute;galement couramment l'Italien et l'Allemand.<br />
    <br />
    Voici quelques expressions cr&eacute;oles bien utiles:</p>

    <table class="btxt" cellspacing="2" cellpadding="2" align="left" border="0">
    <tbody>
    <tr class="tablerow">
    <td class="tableheader" width="160">Fran&ccedil;ais</td>
    <td class="tableheader" width="160">Creole</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Bonjour</td>
    <td width="160">Bonzour</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Au revoir</td>
    <td width="160">Orevwar</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Comment allez vous?</td>
    <td width="160">Ki dir?</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Merci</td>
    <td width="160">Mersi</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">O&ugrave;?</td>
    <td width="160">Kote?</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">S'il vous pla&Icirc;t</td>
    <td width="160">Silvouple</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Non</td>
    <td width="160">Non</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Oui</td>
    <td width="160">Wi</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Je ne comprends pas</td>
    <td width="160">Mon pa konpran</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">&ccedil;a me pla&Icirc;t</td>
    <td width="160">Mon kontan</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Comment &ccedil;a va?</td>
    <td width="160">Konman sava?</td>
    </tr>

    <tr bgcolor="#eeeeee">
    <td width="160">Qu'est ce que c'est?</td>
    <td width="160">Kisisa?</td>
    </tr>
    </tbody>
    </table>

    <br />
    <br />
    </body>
    </html>
    """
    input = """
    <?xml version="1.0"?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <title></title>
    </head>
    <body>
    Italian born sculptor Antonio started his career as a sculptor-philosopher in Germany, settling in Seychelles with his family in 1992. His complex carvings are works of art made from coral and wood, which express his philosophy of the harmony of life. You will be amazed at what he can make out of those natural materials found in Seychelles which are all unique in their own ways!
    </body>
    </html>
    """
    input= """
    <p>
    Water and refuelling facilities are available on the islands of Mah&eacute;, Praslin and La Digue at the areas listed below.<br />
    <br />
    On Mah&eacute;, local charter yachts may use the facilities available at the Marine Charter Association, Port Victoria. However, foreign yachts must contact the Harbour Master at Port Victoria at least 24-hrs in advance.<br />
    <br />
    Marine Chater Association<br />
    PO Box 469<br />
    Victoria, Mah&eacute;<br />
    Tel: +248 32 21 26<br />
    Fax: +248 22 46 79<br />
    Email: <a href="mailto:mca@seychelles.net">mca@seychelles.net</a> <br />
    Website: <a href="http://www.seychelles.net/mca">www.seychelles.net/mca</a> <br />
    <br />
    Harbour Master<br />
    Seychelles Port Authority<br />
    New Port, PO Box 47<br />
    Port Victoria, Mah&eacute;<br />
    Tel: +248 22 47 01<br />
    Fax: +248 22 40 04<br />
    Emails: <a href="mailto:enquiries@seychellesports.sc">enquiries@seychellesports.sc</a> or <a href="mailto:hm@seychellesports.sc">hm@seychellesports.sc</a> or <a href="mailto:portcontrol@seychellesports.sc">portcontrol@seychellesports.sc</a> <br />
    <br />
    Sailing vessels visiting Praslin or La Digue and wishing to make use of the facilities available at the jetty at Baie Ste. Anne or La Passe should contact the island's Pier Master -- preferably 24 hours in advance. Or, contact either jetty on VHF channel 16 upon arrival. For overnight mooring please also contact the relevant Pier Master.<br />
    <br />
    Pier Master - Baie Ste Anne Jetty<br />
    Baie Ste Anne, Praslin<br />
    Tel/Fax: +248 23 24 34<br />
    <br />
    Pier Master - La Passe Jetty<br />
    La Passe, La Digue<br />
    Tel/Fax: +248 22 43 00
    </p>

    """
    input = """
    <p>Refuge luxueux et original située à 50 km à l’est de Mahé, Frégate Island Private se compose de 16 villas privées.  La règle qui prévaut dans l’île est la préservation et la protection d’un environnement naturel unique.  Dans ce lieu harmonieusement préservé, l’hôtel propose un somptueux décor et des installations luxueuses qui vous permettront de vivre à l’écart du monde et de jouir d’un repos complet dans une totale intimité.  La beauté naturelle de l’île, une cuisine gastronomique délicieuse, un large éventail d’activités sportives et de loisirs, deux piscines (dont une de 25 mètres pour ceux qui souhaitent faire des longueurs!): tout est organisé pour répondre à vos attentes les plus exigeantes.  Sont également accessibles le “Castaway Kids Club” et “The Rock Spa”.</p>
    """
    #validate(input, apply_filter=True, full_html_mode=True)
    nxml = normalize(input)
    print nxml
    rml = toRML(nxml)
    print rml
# no more python code after this line
