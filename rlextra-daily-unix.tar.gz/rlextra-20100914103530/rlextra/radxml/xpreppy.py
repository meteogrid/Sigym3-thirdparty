#dynamic rml experiments

import sys
from types import StringType, UnicodeType, TupleType, ListType



from rlextra.radxml import xmlutils
from pprint import pprint as pp
from reportlab.lib.utils import recursiveImport
import xacquire
from xmlutils import xmlEscape

ENTITY_SUBSTITUTIONS_DRAWSTRING_DICT = {    #these must be in utf8
    "&pound;":'\xc2\xa3',
    "&amp;":"&",
    "&lt;":"<",
    "&gt;":">",
    "&quot;":"\"",
    "&apos;":"'",
    "&#039;":"'",
    }

#we allow multiple names for each tag.
# Sometimes DTD's/schemas are cleaner if you can define
# separate block-level or line-level tags, whose content can
# then be defined as something more helpful than 'anything goes'.

#These could all be redefined for a new app.
TAG_LOOP = ['loop', 'loop_b','loop_i', 'loop_t','loop_g', 'loop_s']
TAG_LOOP_INNER = 'var'
TAG_LOOP_OUTER = 'in'

TAG_EXPR = ['expr','expr_i','expr_b']
TAG_IF = ['if', 'if_i','if_b','if_g','if_t', 'if_s']

# this is the general 'if' statement.  The switch contains 1 or
# more cases, and an optional default.
# You may use one of two patterns:
#..a named variable and allowed values....
#<switch expr="colour">
#  <case cond="green">Go</case>
#  <case cond="amber">Slow</case>
#  <case cond="red">Stop</case>
#</switch>
#...or a full python expression in each condition...
#<switch>
#  <case cond="colour==green">Go</case>
#  <case cond="colour==amber">Slow</case>
#  <case cond="colour==red">Stop</case>
#</switch>
#It knows which to do based on the presence/absence of 'expr' in the switch.
#

TAG_SWITCH = ['switch','switch_b','switch_i','switch_g','switch_t', 'switch_s']
TAG_CASE = ['case','case_b','case_i','case_g','case_t', 'switch_s']
TAG_DEFAULT = ['default','default_b','default_i','default_g','default_t', 'default_s']

TAG_ASSIGN = ['assign','assign_b','assign_i','assign_g','assign_t']
TAG_ASSIGN_NAME = 'name'
TAG_ASSIGN_VALUE = 'value'

TAG_SCRIPT = ['script','script_b','script_i','script_g','script_t']

TAG_ACQUIRE = ['acquire','acquire_b','acquire_i','acquire_g','acquire_t']

TAG_DOCLET = ['doclet', 'doclet_b']

sample1 = """<?xml version="1.0" encoding="UTF-8"?>
<document>
<script>import string</script>
<assign name="author" value="Andy Robinson"/>
<author><expr>author + ' ' + string.digits</expr></author>
<para>Here comes a table with <expr>2+2</expr> rows</para>
<table><tr><td>Product</td><td>Units</td><td>Taste</td></tr>
<loop var="(product, units)" in="dataSet">  <tr>
    <td><expr>product</expr></td>
    <td><expr>units</expr></td>
    <td>
        <switch expr="product">
            <case condition="ham">nice</case>
            <case condition="spam">nasty</case>
            <case condition="eggs">OK</case>
            <default>never tried that...</default>
        </switch>
    </td>
  </tr></loop>
</table>
</document>
"""

def preProcess(tree, nameSpace, caller=None):
    """Expands the parsed tree in the namespace and return new one.
    Returns a single tag-tuple in most cases, but a list of them
    if processing a loop node.

    """
    from rlextra.radxml import xmlutils
    #expand this into a class with methods for each tag it handles.
    #then I can put logic tags in one and data access in another.
    tagName, attrs, children, extraStuff = tree

    if attrs is None:
        newAttrs = None
    else:
        #any attribute as $name becomes th value of name
        #tags might be nested in a loop, and if so then
        #each dictionary must be a fresh copy rather than
        # a pointer to the same dict
        
        newAttrs = attrs.copy()
        for key, value in newAttrs.items():
            if type(value) is StringType and value[0:1] == '$':
                newValue = eval(value[1:], nameSpace)
                newAttrs[key] = newValue
    attrs = newAttrs

    if tagName in TAG_LOOP:
        innerTxt = attrs[TAG_LOOP_INNER]
        outer = eval(attrs[TAG_LOOP_OUTER], nameSpace)
        dataSet = []
        for row in outer:
            nameSpace['__loop_inner__'] = row
            exec (innerTxt + " = __loop_inner__\n") in nameSpace
            #at this point we're making lots of child nodes.
            # the attribute dictionary of each shold be a copy, not
            # a reference
            newChildren = processChildren(children, nameSpace)
            if newChildren is not None:
                dataSet.extend(newChildren)
        return dataSet

    elif tagName in TAG_ASSIGN:
        name = attrs[TAG_ASSIGN_NAME]
        valueStr = attrs[TAG_ASSIGN_VALUE]
        try:
            value = eval(valueStr)
        except SyntaxError:  #must be a string
            value = valueStr
        nameSpace[name] = value
        return None

    elif tagName in TAG_SCRIPT:
        code = children[0]
        if not code.endswith('\n'): code += '\n'
        try:
            exec code in nameSpace
        except SyntaxError:
            raise SyntaxError("Error with following script in xpreppy:\n\n%s" % code)
        return None

    elif tagName in TAG_EXPR:
        exprText = children[0]
        assert type(exprText) in (StringType, UnicodeType), "expr can only contain strings"

        #attributes may affect escaping
        if attrs is not None:
            escape = attrs.get('escape', None)
            encoding = attrs.get('encoding','utf8')
        else:
            escape = None
            encoding = 'utf8'

        exprValue = eval(exprText, nameSpace)
        if isinstance(exprValue,str):
            if encoding!='utf8':
                exprValue = unicode(exprValue,encoding).encode('utf8')
        elif isinstance(exprValue,unicode):
            exprValue = exprValue.encode('utf8')
        else:
            exprValue = unicode(exprValue).encode('utf8')

        if escape in ('CDATA','CDATAESCAPE'):
            exprValue = '<![CDATA[%s]]>' % exprValue
            if escape=='CDATA': return [exprValue]
        elif escape == 'off':
            return [str(exprValue)]
        elif escape == 'unescape':
            return [xmlutils.unescape(exprValue, ENTITY_SUBSTITUTIONS_DRAWSTRING_DICT)]
        return [xmlEscape(exprValue)]

    elif tagName in TAG_IF:
        condText = attrs['cond']
        yesOrNo = eval(condText, nameSpace)
        if yesOrNo:
            return processChildren(children, nameSpace)
    
    elif tagName in TAG_SWITCH:
        #two modes, with and without top level variable
        if attrs is None:
            exprText = None
        elif attrs.has_key('expr'):
            exprText = attrs.get('expr','')
        else:
            exprText = None
            
        if exprText:
            expr = eval(exprText, nameSpace)

        selected = None
        for child in children:
            if type(child) is TupleType:
                (childTagName, childAttrs, grandChildren, stuff) = child
                if childTagName in TAG_CASE:
                    condition = childAttrs['condition']
                    if exprText:
                        #check if it equals the value
                        try:
                            value = eval(condition, nameSpace)
                        except NameError:
                            value = condition # assume a string
                        if (expr == value):
                            selected = processChildren(grandChildren, nameSpace)
                            break
                    else:
                        #they gave us a full condition, evaluate it
                        yes = eval(condition, nameSpace)
                        if yes:
                            selected = processChildren(grandChildren, nameSpace)
                            break
                elif childTagName in TAG_DEFAULT:
                    selected = processChildren(grandChildren, nameSpace)
                    break
                else:
                    raise ValueError('%s tag may only contain these tags: ' % (TAG_SWITCH, ', '.join(TAG_CASE+TAG_DEFAULT)))

                    
        return selected

    elif tagName in TAG_ACQUIRE:
        #all children will be data fetchers
        xacquire.acquireData(children, nameSpace)
        return None

    elif tagName in TAG_DOCLET:



        #pull out args needed to initialize
        dirName = attrs.get("baseDir", None)
        moduleName = attrs["module"]
        className = attrs["class"]
        dataStr = attrs.get("data", None)

        #load module, import and create it
        if caller == 'rml':
            from rlextra.rml2pdf.rml2pdf import _rml2pdf_locations
            locations = _rml2pdf_locations(dirName)
        else:
            locations = dirName
        m = recursiveImport(moduleName, locations)
        klass = getattr(m, className)
        docletObj = klass()

        #give it the data model
        if dataStr:
            dataObj = eval(dataStr, nameSpace)
        else:
            dataObj = nameSpace

        docletObj.setData(dataObj)
            

        #hide it in the tree so RML can see the object
        attrs['__doclet__'] = docletObj

        #return the tag otherwise unmodified        
        return (tagName, attrs, children, extraStuff)
    
    else:
        newChildren = processChildren(children, nameSpace)
        return (tagName, attrs, newChildren, extraStuff)

def processChildren(children, nameSpace):
    """Handles iteration over child tags, one of which may be a loop

    Also substitutes into attributes.
    """

    if children is None:
        newChildren = None
    else:
        newChildren = []
        for child in children:
            if type(child) in (StringType, UnicodeType):
                newChildren.append(child)
            else:
                newStuff = preProcess(child, nameSpace)
                if type(newStuff) is TupleType:
                    #returned a single tag-tuple
                    newChildren.append(newStuff)
                elif type(newStuff) is ListType:
                    #must have been a loop tag, returned a list
                    newChildren.extend(newStuff)
                #if None, omit it...
    return newChildren

def processDataAcquitision(children, nameSpace):
    """The data acquisition tags give easy access to data sources.
    They do not return values but put them in the namespace"""
    if children is None:
        newChildren = None
    else:
        for child in children:
            if type(child) in (StringType, UnicodeType):
                newChildren.append(child)
            else:
                newStuff = preProcess(child, nameSpace)
                if type(newStuff) is TupleType:
                    #returned a single tag-tuple
                    newChildren.append(newStuff)
                elif type(newStuff) is ListType:
                    #must have been a loop tag, returned a list
                    newChildren.extend(newStuff)
                #if None, omit it...
    return newChildren

def run(sample):
    from reportlab.lib.rparsexml import parsexml
    tree = parsexml(sample)
    xmlutils.stripWhitespace(tree)


    nameSpace = {'dataSet':[('ham',3),('spam',15),('eggs',12)]}
    processed = preProcess(tree, nameSpace)
    print
    print 'raw results:'
    pp(processed)
    print
    print 'formatted as XML again:'
    tw = xmlutils.TagWrapper(processed)
    xml = xmlutils.reconstructXML(tw)
    print xml

if __name__=='__main__':
    run(sample1)
