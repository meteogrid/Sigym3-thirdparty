#entry point for rlextra/reportlab test suites
"""This should invoke all other test suites within
the rlextra framework (maybe ReportLab too?).
"""
import os, sys
import unittest

class RlTestCase(unittest.TestCase):
    def __init__(self, methodName='runTest'):
        RlTestCase.__init__(self, methodName)

        #these attributes are descriptive and may be used
        #as hints when running in a zipfile or other unusual location

        #does it make files?  Might need a temp dir
        self.createsOutput = False

        #does the files it creates merit inspection, or can they be deleted?
        self.eyeballOutput = False

        #does it need resources out of the package hierarchy?  If so,
        #when running we'll need to know where it comes from.
        self.readsFromPackage = False

        #leave as 0 for quick (fraction-of-second) calculations.
        # if you know it's big, take a wild guess in seconds.
        # this will let developers choose to skip big ones.
        self.duration = 0

    def isApplicable(self):
        """Override this if you want to not run tests in some cases.
        e.g. if testing ability to parse a TrueType font, and the font
        is not available, you might skip the test...
        """
        return True

    def run(self, result=None):
        if not isApplicable():
            return
        unittest.TestCase.run(self, result=result)

try:
    _baseTestSuite=unittest.BaseTestSuite
except AttributeError:
    _baseTestSuite=unittest.TestSuite

class DirectoryTestSuite(_baseTestSuite):
    """Suite intended to be run in a specific package directory.

    It knows where its home is, and will CD to here before executing.
    """
    def __init__(self, tests=()):
        _baseTestSuite.__init__(self, tests)
        self.homeDir = None

    def __call__(self, result):
        if self.homeDir:
            startDir = os.getcwd()
            os.chdir(self.homeDir)
        try:
            return _baseTestSuite.__call__(self,result)
        finally:
            if self.homeDir:
                os.chdir(startDir)

def makeSuite():

    suites = []
    import rlextra.test.test_layout
    suites.append(rlextra.test.test_layout.makeSuite())

    #this setup ensures it runs in its own directory

    import rlextra.preppy.test
    preppyTestDir = os.path.dirname(rlextra.preppy.test.__file__)
    import rlextra.preppy.test.check_algorithms
    import rlextra.preppy.test.check_basics

    preppySuite = DirectoryTestSuite()
    preppySuite.addTest(rlextra.preppy.test.check_algorithms.makeSuite())
    preppySuite.addTest(rlextra.preppy.test.check_basics.suite)
    preppySuite.homeDir = preppyTestDir

    suites.append(preppySuite)
    return unittest.TestSuite(suites)

    #RML is smart - already knows where it's running....
    import rlextra.rml2pdf.test.testall
    suites.append(rlextra.rml2pdf.test.testall.makeSuite())

    import rlextra.examples.graphics.testall
    suites.append(rlextra.examples.graphics.testall.makeSuite())

    #PageCatcher
    from rlextra.pageCatcher.test import test_pagecatcher, test_pdfexplorer
    pcSuite = DirectoryTestSuite()
    pcSuite.homeDir = os.path.abspath(os.path.dirname(rlextra.pageCatcher.test.__file__))
    pcSuite.addTest(test_pagecatcher.makeSuite())
    pcSuite.addTest(test_pdfexplorer.makeSuite())
    suites.append(pcSuite)

    #modules known to have doctest blocks - I think John's
    #got a better way to do this by walking the package??
    # anyway, they all fail in bizarre ways so I need to work on
    # this...

##    if sys.version_info[0:2] >= (2,4):
##        #doctest gives lots of false positives in 2.3 unless you
##        #write them very, very carefully, so we write them 2.4-style
##        from doctest import DocTestSuite
##        #got this from a manual grep
##        import rlextra.rml2pdf.readxls
##        suites.append(DocTestSuite(rlextra.rml2pdf.readxls))
##
##        import rlextra.graphics.chartconfig
##        suites.append(DocTestSuite(rlextra.graphics.chartconfig))
##
##        from rlextra.ers import htmltext
##        suites.append(DocTestSuite(htmltext))
##
##        from rlextra.ers import metadata
##        suites.append(DocTestSuite(metadata))
##
##        from rlextra.ers import metabulk
##        suites.append(DocTestSuite(metabulk))
##
##    no useful code was written here....
##        from rlextra.ers import metaxml
##        suites.append(DocTestSuite(metaxml))
##
##        from rlextra.radxml import xmlutils
##        suites.append(DocTestSuite(xmlutils))

    return unittest.TestSuite(suites)

#noruntests
if __name__ == "__main__":
    unittest.TextTestRunner().run(makeSuite())

    # Run standalone examples

    cmds = [
        # folder, command
        ('examples/currency', 'currency.py'),
        ('examples/invoice', 'invoice.py sample_invoice0.xml'),
        ('examples/ers_portfolio', 'rpcdrawing.py'),
        ('examples/ers_portfolio', 'spcdrawing.py'),
        ('examples/ers_portfolio', 'tbardrawing.py'),
        ('examples/ers_portfolio', 'tbcdrawing.py'),
        ('examples/ers_portfolio', 'ypcdrawing.py'),
        ('examples/taxform', 'makef1040ez.py'),
        ('pageCatcher/test', 'test_pdf_image.py',),
        ]

    pythonbin = sys.executable
    owndir = os.path.abspath(os.path.dirname(__file__))

    oldpath = os.path.abspath(os.getcwd())
    try:
        for folder, cmd in cmds:
            os.chdir(os.path.join(owndir, folder))
            fullcmd = '%s %s' % (pythonbin, cmd)
            out = os.popen(fullcmd)
            output = out.read()
            if out.close():
                sys.stderr.write('Error running %s in %s\n    %s\n' % (fullcmd, os.getcwd(),output))
    finally:
        os.chdir(oldpath)
