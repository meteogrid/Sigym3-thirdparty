#copyright ReportLab Europe Limited. 2000-2006
#see license.txt for license details
__version__=''' $Id: chartcontroller.py 20834 2006-04-05 17:15:32Z rgbecker $ '''
from rlextra.ers.webapp import WebApp
from reportlab.lib.colors import toColor
from rlextra.graphics.quickchart import quickChart, getTestDrawing, parseDataBlock

class WebChartApp(WebApp):
    "Web test harness / demonstrator for our charts"
    def __init__(self,**kw):
        WebApp.__init__(self,**kw)
        self.viewDir = '.'
        self.defaultAction = 'main'
        
    def action_testImage(self, request, response):
        myChart = getTestDrawing()
        bitmapBytes = myChart.asString('png')
        response.setContentType('image/png')
        response.write(bitmapBytes)

    def action_getLogo(self, request, response):
        "Return reportlab logo"
        bitmapBytes = open('corplogo.gif','rb').read()
        response.setContentType('image/png')
        response.write(bitmapBytes)
        
    def action_image(self, request, response):
        "Generate PNG chart according to input parameters"


        # extract any chart-related parameters, converting
        # from strings to correct data types.  Keep this
        # explicit instead of being clever and dynamic
        params = request.params
        kw = {}
        def getColor(name,kw=kw,params=params):
            color = params.get(name,'None')
            kw[name] = color.upper()!='NONE' and toColor(color) or None

        def getParam(name,kw=kw,params=params):
            if params.has_key(name): kw[name] = params[name]

        kw['showBoundaries'] = params.has_key('showBoundaries')
        kw['chartType'] = params.get('chartType','bar')
        kw['seriesRelation'] = params.get('seriesRelation', 'sidebyside')
        kw['width'] = params.get('width','400')
        kw['height'] = params.get('height','300')

        getParam('data')
        kw['textData'] = params.get('textData',None)
        getParam('categoryNames')
        getParam('seriesNames')

        #chart colours
        if params.has_key('chartColors'):
            kw['chartColors'] = params['chartColors']
            chartColorText = params['chartColors']
            if chartColorText == 'None':
                chartColors = None
            else:
                chartColors = chartColorText
        else:
            chartColors = None
        kw['chartColors'] = chartColors

        #main title
        getParam('titleText')
        getParam('titleFontName')
        getParam('titleFontSize')
        getParam('titleFontColor')

        #x axis title
        getParam('xTitleText')
        getParam('xTitleFontName')
        getParam('xTitleFontSize')
        getParam('xTitleFontColor')

        #y axis title
        getParam('yTitleText')
        getParam('yTitleFontName')
        getParam('yTitleFontSize')
        getParam('yTitleFontColor')

        #x axis 
        kw['xAxisVisible'] = params.has_key('xAxisVisible')
        getParam('xAxisFontName')
        getParam('xAxisFontSize')
        getParam('xAxisFontColor')
        getParam('xAxisLabelAngle')

        #y axis 
        kw['yAxisVisible'] = params.has_key('yAxisVisible')
        getParam('yAxisFontName')
        getParam('yAxisFontSize')
        getParam('yAxisFontColor')
        getParam('yAxisLabelAngle')

        #data labels
        getParam('dataLabelsType')
        getParam('dataLabelsFontName')
        getParam('dataLabelsFontSize')
        getParam('dataLabelsFontColor')
        getParam('dataLabelsAlignment')

        # plot area
        kw['xAxisGridLines'] = params.has_key('xAxisGridLines')
        kw['yAxisGridLines'] = params.has_key('yAxisGridLines')
        
        if request.params.has_key('plotColor'):
            kw['plotColor'] =  request.params['plotColor']
        else:
            kw['plotColor'] =  None

        #if they give us a background colour, use it.
        getColor('bgColor')

        #if they give us a background stroke colour, use it.
        getColor('bgStrokeColor')

        #markers for lines eg, in scatter_lines_markers
        if params.has_key('markerType'):
            mk = params['markerType']
            if mk == 'None':
                mk = None
            kw['markerType'] = mk

        if params.has_key('markerSize'):
            ms = params['markerSize']
            if ms == 'None':
                ms = None
            else:
                ms = int(ms)
            kw['markerSize'] = ms

        #legend properties
        if params.has_key('legendPos'):
            lpos = params['legendPos']
            if lpos == 'None':
                lpos = None
            kw['legendPos'] = lpos

        if params.has_key('legendFontName'):
            lfont = params['legendFontName']
            if lfont == 'None':
                lfont = None
            kw['legendFontName'] = lfont

        if params.has_key('legendFontSize'):
            lsize = params['legendFontSize']
            if lsize == 'None':
                lsize = None
            kw['legendFontSize'] = lsize

        if params.has_key('legendFontColor'):
            lcol = params['legendFontColor']
            if lcol == 'None':
                lcol = None
            kw['legendFontColor'] = lcol

        myChart = quickChart(**kw)
        bitmapBytes = myChart.asString('gif')
        response.setContentType('image/gif')
        response.setHeader('Cache-Control', 'no-cache')
        response.write(bitmapBytes)

if __name__=='__main__':
    WebChartApp().handleCommandLine()
