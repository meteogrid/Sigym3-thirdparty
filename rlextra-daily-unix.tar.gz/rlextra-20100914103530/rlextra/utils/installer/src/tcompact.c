#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#ifdef macintosh
#	include <console.h>
#	define MAIN_T int
#endif
#if defined(WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#	define IMPORT(typ,fnc,arg) __declspec(dllimport) typ fnc arg
#	define MAIN_T void
#endif
#ifndef IMPORT
#	define IMPORT(typ,fnc,arg) typ fnc arg
#endif
/*this string is intended to be embedded in C or run through rl_embed_string
it is only guranteed to work cleanly if run in the same folder
as Diagra.slb and the fonts folder*/
static char* test_string="import sys, os, traceback, time\n\
tstart = time.time()\n\
from reportlab.lib.utils import getStringIO\n\
sys.stdout = sys.stderr = getStringIO()\n\
try:\n\
	from reportlab.graphics.renderPM import test\n\
	test()\n\
	print 'renderPM.test succeeded'\n\
except:\n\
	print '!!!!!renderPM.test failed'\n\
	traceback.print_exc()\n\
print\n\
from rlextra.graphics.guiedit.diagnostic import DiagnosticDrawing\n\
from rlextra.graphics.quickchart import getTestDrawing\n\
for obj,name in ((DiagnosticDrawing,'DiagnosticDrawing'),(getTestDrawing,'TestDrawing')):\n\
	try:\n\
		d = obj()\n\
		d.save(formats=['pdf','pict'],fnRoot=name,outDir='pmout')\n\
		print '%s succeeded wrote pmout%s%s.pdf & pmout%s%s.pict' % (name,os.sep,name,os.sep,name)\n\
	except:\n\
		print '!!!!!%s failed' % name\n\
		traceback.print_exc()\n\
print\n\
try:\n\
	t0 = time.time()\n\
	for i in xrange(10000):\n\
		d = getTestDrawing()\n\
		s = d.asString('pict')\n\
	t1 = time.time()\n\
	print 'Timing test: time for 100 test drawings rendered to string: %.2f seconds.' % (t1-t0)\n\
except:\n\
	print '!!!!!Timing test failed!'\n\
	traceback.print_exc()\n\
print\n\
print 'Finished total time taken: %.2f seconds.' % (time.time()-tstart)\n\
print 'Check the folder pmout for the result drawings and index.html.'\n\
\n\
import __main__\n\
__main__._rl_embed_result = sys.stdout.getvalue()\n\
sys.stdout = sys.__stdout__\n\
sys.stderr = sys.__stderr__\n\
";

typedef struct {
		char*	errorString;
		int		resultStringLength;
		char*	resultString;
		int		uncaughtError;
		} rl_embed_rt;
IMPORT(rl_embed_rt, rl_run_file,(char*));
IMPORT(rl_embed_rt,rl_run_string,(char*));
void main(int argc, char** argv)
{
	rl_embed_rt r;
	FILE	*outfd = fopen("tcompact.out","w");
	r = rl_run_string(test_string);
	if(r.errorString){
		fprintf(stderr,"Uncaught=%d\nERROR: %s\n",r.uncaughtError,r.errorString);
		exit(1);
		}
	fwrite(r.resultString, 1, r.resultStringLength, outfd);
}
