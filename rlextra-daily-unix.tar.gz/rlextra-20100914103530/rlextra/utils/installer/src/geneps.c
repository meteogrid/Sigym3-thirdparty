#include <stdio.h>
#if defined(macintosh)||defined(WIN32)
#	include <io.h>
#endif
#include <fcntl.h>
#include <stdlib.h>
#ifdef macintosh
#	include <console.h>
#	define MAIN_T int
#endif
#if defined(WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#	define IMPORT(typ,fnc,arg) __declspec(dllimport) typ fnc arg
#	define MAIN_T void
#endif
#ifndef IMPORT
#	define IMPORT(typ,fnc,arg) typ fnc arg
#endif
#ifndef MAIN_T
#	define MAIN_T int
#endif
#ifdef	RLREFRET
#	define RSTAR *
#	define R(a) r->a
#else
#	define RSTAR
#	define R(a) r.a
#endif
#ifndef	NO_MEMORY_TTFONTS
static	void	*_read_file(char* fn, char *mode, int *plen)
{
	char	*buf=NULL;
	size_t	len;
	int		n;
	FILE	*f = fopen(fn,mode);
	if(!f || fseek(f,0,SEEK_END)){
fail:	fprintf(stderr,"failed to readfile %s\n", fn);
		if(f) fclose(f);
		if(buf) free(buf);
		exit(1);
		}
	len = ftell(f);
	fseek(f,0,SEEK_SET);
	if(!(buf=malloc(len))) goto fail;

	n = fread(buf,(int)len,1,f);
	if(n!=1) goto fail;
	fclose(f);
	*plen = (int)len;
	return (void*)buf;
}
#endif

typedef struct {
		char*	errorString;
		int		resultStringLength;
		char*	resultString;
		int		uncaughtError;
		} rl_embed_rt;
IMPORT(rl_embed_rt RSTAR, rl_run_file,(char*));
IMPORT(rl_embed_rt RSTAR,rl_run_string,(char*));
#ifndef	NO_MEMORY_TTFONTS
IMPORT(rl_embed_rt RSTAR,rl_register_ttfont,(char*,char*,int));
IMPORT(rl_embed_rt RSTAR,rl_register_ttfont_ex,(char*,char*,int,int));
#endif
void usage(char** ARGV,int x){
	fprintf(stderr,"%s: usage\n\
%s [options] paths....\n"
#ifndef	NO_MEMORY_TTFONTS
"-ttf=ttfpath     preload ttf\n"
#endif
"-write=1/0       turn output write on/off\n\
-help            give this help\n\
-run-string=1/0  use _rl_run_string/_rl_fun_file interface\n\
-verbose=0/1/2   more or less verbose\n\
-repeat=1000     number of times to run\n",ARGV[0],ARGV[0]);
	exit(x);
	}

MAIN_T main(int argc, char** argv)
{
	rl_embed_rt  RSTAR r;
#ifndef	NO_MEMORY_TTFONTS
	char	**ARGV = (char**)malloc(argc*sizeof(char*));
	int		ARGC, i, j, buflen;
	char	*ttfname, *ttfpath, **fStrings;
	void	*buf;
	int		repCount=1, run_string=0, verbose=0, writeOutput=1;
#else
#	define ARGV argv
#	define ARGC	argc
#endif
#ifdef macintosh
	argc = ccommand(&argv);
#endif
#ifndef	NO_MEMORY_TTFONTS
	ARGV[0] = argv[0];
	for(ARGC=i=1;i<argc;i++){
		if(!strncmp(argv[i],"-ttf=",5)){
			ttfname = argv[i]+5;
			ttfpath = strchr(ttfname,',');
			if(!ttfname || !ttfpath){
				fprintf(stderr,"Bad ttf specification \"%s\"\n", argv[i]);
				goto fail;
				}
			*ttfpath++ = 0;
			buf = _read_file(ttfpath,"rb",&buflen);
			r = rl_register_ttfont_ex(ttfname, (char*)buf, buflen, 0);
			/*r = rl_register_ttfont(ttfname, (char*)buf, buflen);*/
			free(buf);
			if(R(errorString)){
				fprintf(stderr,"Uncaught=%d\nERROR: %s\n",R(uncaughtError),R(errorString));
				exit(1);
				}
			fprintf(stderr,"rl_register_ttfont_ex(\"%s\",FILE(\"%s\"), %d, 0)\n", ttfname, ttfpath, buflen);
			if(writeOutput) fwrite( R(resultString), 1, R(resultStringLength), stdout);
			}
		else if(!strncmp(argv[i],"-repeat=",8)){
			sscanf(argv[i]+8,"%d",&repCount);
			}
		else if(!strncmp(argv[i],"-run-string=",12)){
			sscanf(argv[i]+12,"%d",&run_string);
			}
		else if(!strncmp(argv[i],"-verbose=",9)){
			sscanf(argv[i]+9,"%d",&verbose);
			}
		else if(!strncmp(argv[i],"-write=",7)){
			sscanf(argv[i]+7,"%d",&writeOutput);
			}
		else if(!strncmp(argv[i],"-help",5)){
			usage(ARGV,0);
			}
		else{
			ARGV[ARGC++] = argv[i];
			}
		}
#endif

#ifdef macintosh
	if(ARGC < 3) {
fail:	usage(ARGV,1);
		}
	freopen(argv[2], "wb", stdout);
#else
#	ifdef WIN32
	_setmode(_fileno(stdout),_O_BINARY);
#	endif
	if(ARGC<2){
fail:	usage(ARGV,1);
		}
#endif
	if(verbose){
		fprintf(stderr,"-write=%d\n",writeOutput);
		fprintf(stderr,"-verbose=%d\n",verbose);
		fprintf(stderr,"-repeat=%d\n",repCount);
		fprintf(stderr,"-run-string=%d\n",run_string);
		}
	if(run_string){
		fStrings = (char**)malloc((ARGC+1)*sizeof(char*));
		if(verbose>1) fprintf(stderr,"fStrings=%p\n",fStrings);
		for(i=1;i<ARGC;i++){
			fStrings[i] = _read_file(ARGV[i],"r",&buflen);
			}
		}
	for(j=0;j<repCount;j++){
		for(i=1;i<ARGC;i++){
			if(run_string){
				r = rl_run_string(fStrings[i]);
				}
			else{
				r = rl_run_file(ARGV[i]);
				}
			if(R(errorString)){
				fprintf(stderr,"ERROR: file=%s iteration=%d\n%s\n",ARGV[i],j,R(errorString));
				exit(1);
				}
			if(!j){
				if(writeOutput) fwrite( R(resultString), 1, R(resultStringLength), stdout);
				}
			}
		}
}
