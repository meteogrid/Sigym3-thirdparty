#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#ifdef macintosh
#       include <console.h>
#       define MAIN_T int
#else
#		define MAIN_T void
#endif
#if defined(WIN32)
#       define WIN32_LEAN_AND_MEAN
#       include <windows.h>
#       define IMPORT(typ,fnc,arg) __declspec(dllimport) typ fnc arg
#       define MAIN_T void
#endif
#ifndef IMPORT
#       define IMPORT(typ,fnc,arg) typ fnc arg
#endif
/*this string is intended to be embedded in C or run through rl_embed_string
it is only guranteed to work cleanly if run in the same folder
as Diagra.slb and the fonts folder*/
#ifdef TEST_DRAWING
static char* test_string0="\n\
from rlextra.graphics.guiedit.diagnostic import DiagnosticDrawing\n\
import __main__\n\
";
static char* test_string1="d = DiagnosticDrawing()\n\
__main__._rl_embed_result = d.asString('pict')\n\
";
#else
static char* test_string0="import __main__\n\
";
static char* test_string1="__main__._rl_embed_result = 1000000*' '\n\
";
#endif
typedef struct {
                char*   errorString;
                int     resultStringLength;
                char*   resultString;
				int		uncaughtError;
                } rl_embed_rt;
IMPORT(rl_embed_rt, rl_run_file,(char*));
IMPORT(rl_embed_rt,rl_run_string,(char*));
MAIN_T main(void)
{
        rl_embed_rt r;
        int     i;
        r = rl_run_string(test_string0);
        if(r.errorString){
                fprintf(stderr,"%s\n",r.errorString);
                exit(1);
                }
        for(i=0;i<1000;i++){
                r = rl_run_string(test_string1);
                if(r.errorString){
                        fprintf(stderr,"%s\n",r.errorString);
                        exit(1);
                        }
				fprintf(stderr,"Uncaught=%d\nERROR: %s\ni=%4d: resultStringLength=%d\n",r.uncaughtError,r.errorString,i,r.resultStringLength);
                }
	return 0;
}
