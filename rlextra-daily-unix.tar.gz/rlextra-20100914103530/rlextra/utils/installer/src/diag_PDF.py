import sys
sys.stdout = sys.stderr #ensure any prints go to stderr

if __name__=="__main__": #NORUNTESTS
	from rlextra.graphics.guiedit.diagnostic import DiagnosticDrawing 
	d = DiagnosticDrawing()
	from reportlab.graphics import renderPDF
	from reportlab.lib.utils import getStringIO
	f = getStringIO()
	renderPDF.drawToFile(d, f)
	import __main__
	#this will be returned to the caller as resultString
	__main__._rl_embed_result = f.getvalue()
