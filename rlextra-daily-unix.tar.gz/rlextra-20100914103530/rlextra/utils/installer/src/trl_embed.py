print 'Hello from embedded Python'

import __main__
#this will be returned to the caller as resultString
__main__._rl_embed_result = 'Hello World from the embedded thing'
