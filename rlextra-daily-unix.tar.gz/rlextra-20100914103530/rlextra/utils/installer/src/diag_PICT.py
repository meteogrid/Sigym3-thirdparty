import sys
sys.stdout = sys.stderr #ensure any prints go to stderr

if __name__=="__main__": #NORUNTESTS
    from rlextra.graphics.guiedit.diagnostic import DiagnosticDrawing 
    d = DiagnosticDrawing()
    from reportlab.graphics import renderPM
    from reportlab.lib.utils import getStringIO
    f = getStringIO()
    renderPM.drawToFile(d, f, fmt='pict')
    import __main__
    #this will be returned to the caller as resultString
    __main__._rl_embed_result = f.getvalue()
