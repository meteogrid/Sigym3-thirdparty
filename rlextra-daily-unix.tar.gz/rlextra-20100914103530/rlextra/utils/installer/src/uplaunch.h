#ifndef _UPLAUNCH_H
#include <stdio.h>

#define MAGIC "MEI\014\013\012\013\016"	
#ifdef _CONSOLE
# define FATALERROR(x) printf(x)
# define OTHERERROR(x) printf(x)
#else
# define FATALERROR(x) MessageBox(NULL, x, "Fatal Error!", MB_OK | MB_ICONEXCLAMATION)
# define OTHERERROR(x) MessageBox(NULL, x, "Error!", MB_OK | MB_ICONWARNING)
#endif

#if defined(_DEBUG) || defined(_RL_DEBUG)
#	include <stdarg.h>
	void RL_DEBUG(const char *fmt,...){
		va_list a;
#		ifndef _CONSOLE
			static FILE *f=NULL;
			if(!f) f = fopen("/tmp/rgb_dbg.txt","w");
#		endif
		va_start(a,fmt);
#		ifndef _CONSOLE
			vfprintf(f,fmt,a);
#		else
			vfprintf(stderr,fmt,a);
#		endif
		va_end(a);
		}
# define VS(arg) RL_DEBUG(arg)
# define VS1(fmt,arg) RL_DEBUG(fmt,arg)
# define VS2(fmt,arg1,arg2) RL_DEBUG(fmt,arg1,arg2)
# define VS3(fmt,arg1,arg2,arg3) RL_DEBUG(fmt,arg1,arg2,arg3)
#else
# define VS(arg)
# define VS1(fmt,arg)
# define VS2(fmt,arg1,arg2)
# define VS3(fmt,arg1,arg2,arg3)
#endif

struct TOC {
	int structlen;	/*len of this one - including full len of name */
	int pos;	/* pos rel to start of concatenation */
	int len;	/* len of the data (compressed) */
	int ulen;	/* len of data (uncompressed) */
	char cflag;	/* is it compressed (really a byte) */
	char typcd; /* 'b' binary, 'z' zlib, 'm' module, 's' script - added v3 */
	char name[1];	/* the name to save it as */
};
struct COOKIE {
	char magic[8]; 	/* 'MEI\014\013\012\013\016' */
	int  len;	/* len of entire package */
	int  TOC;	/* pos (rel to start) of TableOfContents */
	int  TOClen;	/* length of TableOfContents */
	int  pyvers;	/* new in v4 */
};
typedef _typeobject;
typedef struct _object {
	int ob_refcnt; 
	struct _typeobject *ob_type;
} PyObject;
#define _Py_Dealloc(op) (*(op)->ob_type->tp_dealloc)((PyObject *)(op))
#define Py_INCREF(op) ((op)->ob_refcnt++)
#define Py_DECREF(op) \
	if (--(op)->ob_refcnt != 0) \
		; \
	else \
		_Py_Dealloc((PyObject *)(op))
#define Py_XDECREF(op) if ((op) == NULL) ; else Py_DECREF(op)
typedef void (*destructor)(PyObject *);
typedef struct _typeobject {
	int ob_refcnt; 
	struct _typeobject *ob_type;
	int ob_size; 
	char *tp_name; /* For printing */
	int tp_basicsize, tp_itemsize; /* For allocation */
	destructor tp_dealloc;
	/* ignore the rest.... */
} PyTypeObject;

#define Py_file_input 257

#define DECLPROC(result, name, args)\
    typedef result (__cdecl *__PROC__##name) args;\
    __PROC__##name name = NULL;

#define GETPROC(dll, result, name, args)\
    name = (__PROC__##name)GetProcAddress (dll, #name);\
    if (!name)\
        FATALERROR ("Cannot GetProcAddress for " #name)

#define DECLVAR(vartyp, name)\
	vartyp *name = NULL;
#define GETVAR(dll, vartyp, name)\
	name = (vartyp *)GetProcAddress (dll, #name);\
    if (!name)\
        FATALERROR ("Cannot GetProcAddress for " #name)
#endif
