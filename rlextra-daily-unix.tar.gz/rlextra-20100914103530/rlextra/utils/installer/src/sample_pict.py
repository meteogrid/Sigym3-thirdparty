import sys
sys.stdout = sys.stderr #ensure any prints go to stderr
from reportlab.graphics.shapes import Drawing,_DrawingEditorMixin
from reportlab.graphics.widgets.flags import Flag

class Drawing_000(_DrawingEditorMixin,Drawing):
    def __init__(self,width=400,height=200,*args,**kw):
        apply(Drawing.__init__,(self,width,height)+args,kw)
        self._add(self,Flag(),name='F',validate=None,desc=None)
        self._add(self,0,name='preview',validate=None,desc=None)
        self.F.size = 200
        self.F.kind='Afghanistan'
        self.preview = 0

if __name__=="__main__": #NORUNTESTS
    d = Drawing_000()
    from reportlab.graphics import renderPM
    from reportlab.lib.utils import getStringIO
    f = getStringIO()
    renderPM.drawToFile(d, f, fmt='pict')
    import __main__
    #this will be returned to the caller as resultString
    __main__._rl_embed_result = f.getvalue()
