#include <stdio.h>
#include <io.h>
#include <stdlib.h>
#ifdef macintosh
#	include <console.h>
#	define MAIN_T int
#endif
#if defined(WIN32)
#	define WIN32_LEAN_AND_MEAN
#	include <windows.h>
#	define IMPORT(typ,fnc,arg) __declspec(dllimport) typ fnc arg
#	define MAIN_T void
#endif
#ifndef IMPORT
#	define IMPORT(typ,fnc,arg) typ fnc arg
#endif
static char* sample_eps="import sys\n\
sys.stdout = sys.stderr #ensure any prints go to stderr\n\
from reportlab.graphics.shapes import Drawing,_DrawingEditorMixin\n\
from reportlab.graphics.widgets.flags import Flag\n\
\n\
class Drawing_000(_DrawingEditorMixin,Drawing):\n\
    def __init__(self,width=400,height=200,*args,**kw):\n\
        apply(Drawing.__init__,(self,width,height)+args,kw)\n\
        self._add(self,Flag(),name='F',validate=None,desc=None)\n\
        self._add(self,0,name='preview',validate=None,desc=None)\n\
        self.F.size = 200\n\
        self.F.kind='Afghanistan'\n\
        self.preview = 0\n\
\n\
if __name__=='__main__': #NORUNTESTS\n\
    d = Drawing_000()\n\
    from rlextra.graphics import renderPS_SEP\n\
    from reportlab.lib.utils import getStringIO\n\
    from reportlab import rl_config\n\
    f = getStringIO()\n\
    renderPS_SEP.drawToFile(d,\n\
                            f,\n\
                            title = 'Flag title',\n\
                            dept = getattr(d,'EPS_info',['Testing'])[0],\n\
                            company = getattr(d,'EPS_info',['','ReportLab'])[1],\n\
                            preview = d.preview,\n\
                            showBoundary=getattr(d,'showBorder',rl_config.showBoundary))\n\
    import __main__\n\
    #this will be returned to the caller as resultString\n\
    __main__._rl_embed_result = f.getvalue()";
typedef struct {
		char*	errorString;
		int		resultStringLength;
		char*	resultString;
		int		uncaughtError;
		} rl_embed_rt;
IMPORT(rl_embed_rt, rl_run_file,(char*));
IMPORT(rl_embed_rt,rl_run_string,(char*));
MAIN_T main(int argc, char** argv)
{
	rl_embed_rt r;
	int i;
#ifdef macintosh
	argc = ccommand(&argv);
#endif
	if(argc<2){
		fprintf(stderr,"Use %s script script.....\n", argv[0]);
		exit(1);
		}
	else{
		int		i;
		for(i=1;i<argc;i++){
			printf("=============================\nStart rl_run_file(%s)\n", argv[i]);
			r = rl_run_file(argv[i]);
			printf("    finish r.errorString = %s\n", r.errorString==NULL ? "(NULL)" : r.errorString);
			printf("           r.resultString %d bytes = %s\n", r.resultStringLength, r.resultString==NULL ? "(NULL)" : r.resultString);
			}
		}
	printf("=============================\n");
	printf("Doing string run Hello World\n");
	r = rl_run_string("print 'Hello World from trl_embed.c'\n");
	printf("    finish r.errorString = %s\n", r.errorString==NULL ? "(NULL)" : r.errorString);
	printf("           r.resultString = %s\n", r.resultString==NULL ? "(NULL)" : r.resultString);
	printf("           r.uncaughtError= %d\n", r.uncaughtError);

	printf("=============================\n");
	printf("Doing longer string run ie embedded sample_eps.py (missing last line ending)\n");
	for(i=0;i<=10;i++){
		r = rl_run_string(sample_eps);
		printf("    finish r.errorString = %s\n", r.errorString==NULL ? "(NULL)" : r.errorString);
		printf("           r.resultString is %s length=%d\n", r.resultString==NULL ? "NULL" : "Not NULL", r.resultStringLength);
		printf("           r.uncaughtError= %d\n", r.uncaughtError);
		}
}
