#ifndef _RL_STARTUP_H
#define _RL_STARTUP_H
#ifndef NO_RL_PYZ_STARTUP
static char* _rl_startup="def _rl_readPYZ(fn):\n\
	import zlib, imp, marshal, sys, struct\n\
	MAGIC='PYZ\\0'\n\
	TOCPOS=8\n\
	pymagic=imp.get_magic()\n\
	lib=open(fn,'rb')\n\
	if lib.read(len(MAGIC)) != MAGIC:\n\
		raise RuntimeError, fn+' is not a valid ZArchive file'\n\
	if lib.read(len(pymagic)) != pymagic:\n\
		raise RuntimeError, fn+' has version mismatch to dll'\n\
	lib.seek(TOCPOS)\n\
	(offset,)=struct.unpack('=i', lib.read(4))\n\
	lib.seek(offset)\n\
	toc=marshal.load(lib)\n\
	for name in ('_rl_iu','_rl_archive'):\n\
		(ispkg, pos, lngth)=toc.get(name, (0, None, 0))\n\
		if pos is None: raise ValueError, 'Module '+name+' not found'\n\
		lib.seek(pos)\n\
		code=marshal.loads(zlib.decompress(lib.read(lngth)))\n\
		if ispkg: values['__path__']=[fqname]\n\
		is_module=isinstance(code, type(sys))\n\
		module=is_module and code or imp.new_module(name)\n\
		module.__dict__.update({'__file__':code.co_filename,'__iname__':name})\n\
		sys.modules[name]=module\n\
		if not is_module: exec code in module.__dict__\n\
		module=sys.modules[name]\n\
		module.__name__=name\n\
	import _rl_archive, _rl_iu\n\
	_rl_iu._globalownertypes.insert(0, _rl_archive.PYZOwner)\n\
	im=sys.importManager=_rl_iu.ImportManager()\n\
	im.install()\n\
	im._bootPYZ=fn\n\
	sys.path.insert(0,fn)\n\
_rl_readPYZ(r'%sLib\\reportlab.pyz')\n\
del _rl_readPYZ";
#define _RL_RESTORE_PYZ "import sys;sys.path.insert(0,sys.importManager._bootPYZ)"
#else
#define _RL_RESTORE_PYZ ""
#endif
#endif
