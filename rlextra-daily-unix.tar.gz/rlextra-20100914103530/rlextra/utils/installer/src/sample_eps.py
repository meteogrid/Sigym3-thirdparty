import sys
sys.stdout = sys.stderr #ensure any prints go to stderr
from reportlab.graphics.shapes import Drawing,_DrawingEditorMixin
from reportlab.graphics.widgets.flags import Flag

class Drawing_000(_DrawingEditorMixin,Drawing):
    def __init__(self,width=400,height=200,*args,**kw):
        apply(Drawing.__init__,(self,width,height)+args,kw)
        self._add(self,Flag(),name='F',validate=None,desc=None)
        self._add(self,0,name='preview',validate=None,desc=None)
        self.F.size = 200
        self.F.kind='Afghanistan'
        self.preview = 1

if __name__=="__main__": #NORUNTESTS
    d = Drawing_000()
    from rlextra.graphics import renderPS_SEP
    from reportlab.lib.utils import getStringIO
    from reportlab import rl_config
    f = getStringIO()
    renderPS_SEP.drawToFile(d,
                            f,
                            title = 'Flag title',
                            dept = getattr(d,'EPS_info',['Testing'])[0],
                            company = getattr(d,'EPS_info',['','ReportLab'])[1],
                            preview = d.preview,
                            showBoundary=getattr(d,'showBorder',rl_config.showBoundary))
    import __main__
    #this will be returned to the caller as resultString
    __main__._rl_embed_result = f.getvalue()
