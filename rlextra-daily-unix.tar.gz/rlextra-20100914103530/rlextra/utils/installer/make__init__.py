def make__init__(modName='reportlab',dirName='reportlab',pyzName='reportlab.pyz'):
    return '''def _rl__INIT__PYZ(modName='%(modName)s'):
    import zlib, imp, marshal, sys, struct, os
    if hasattr(sys,'_rl_booted'): raise ImportError
    for fn in sys.path:
        fn = os.path.join(fn,'%(dirName)s','%(pyzName)s')
        if os.path.isfile(fn): break
    MAGIC='PYZ\\0'
    TOCPOS=8
    pymagic=imp.get_magic()
    lib=open(fn,'rb')
    if lib.read(len(MAGIC))!=MAGIC:
        raise RuntimeError, fn+' is not a valid ZArchive file'
    if lib.read(len(pymagic)) != pymagic:
        raise RuntimeError, fn+' has version mismatch to dll'
    lib.seek(TOCPOS)
    (offset,)=struct.unpack('<i', lib.read(4))
    lib.seek(offset)
    toc=marshal.load(lib)
    for name in ('_rl_iu','_rl_archive','_rl_boot'):
        if name in sys.modules.keys(): continue
        (ispkg, pos, lngth)=toc.get(name, (0, None, 0))
        if pos is None: raise ValueError, 'Module '+name+' not found'
        lib.seek(pos)
        code=marshal.loads(zlib.decompress(lib.read(lngth)))
        if ispkg: values['__path__']=[fqname]
        is_module=isinstance(code, type(sys))
        module=is_module and code or imp.new_module(name)
        module.__dict__.update({'__file__':code.co_filename,'__iname__':name})
        sys.modules[name]=module
        if not is_module: exec code in module.__dict__
        module=sys.modules[name]
        module.__name__=name
    import _rl_boot
    _rl_boot._fix_import(fn,modName)

_rl__INIT__PYZ()''' % locals()
