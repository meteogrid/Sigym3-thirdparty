import sys
exec 'import rlextra.utils.zipapp_%d%d as __m' % sys.version_info[:2]
__c=sys.modules[__name__]
__N=dict([(__a,getattr(__c,__a)) for __a in '__file__ __name__ __path__ __package__'.split() if hasattr(__c,__a)])
__c.__dict__.update(__m.__dict__)
__c.__dict__.update(__N)
del __m,__c,__N
