#copyright ReportLab Europe Ltd. 2000-2006
#see license.txt for license details
__version__=''' $Id: _rl_remove.py 20834 2006-04-05 17:15:32Z rgbecker $ '''
"""Removes all files matching a given pattern (e.g. .pyc) under directory"""

import sys, os
from fnmatch import fnmatch
from os.path import join, isfile, walk

def run(D,P):
	"Remove all files matching P (e.g. '*.pyc') under directory D"
	def match(L,D,N,P=P):
		force = os.path.basename(D)=='test'
		for n in N:
			fn = join(D,n)
			if isfile(fn):
				for p in P:
					if force or fnmatch(n, p):
						L.append(fn)
						break
	L = []
	walk(D,match,L)
	map(os.remove,L)

if __name__=='__main__':
	D = '.'
	P = ('*.pyc',)
	n = len(sys.argv)
	if n>1:
		D = sys.argv[1]
		if n>2: P = sys.argv[2:]
	run(D,P)
