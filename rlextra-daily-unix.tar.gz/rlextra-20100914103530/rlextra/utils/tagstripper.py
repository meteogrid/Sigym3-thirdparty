#!/usr/bin/env python
"""Removes all markup from a string

>>> 2+2
4
>>> stripTags('hello')
'hello'
>>> stripTags('hello<a href="crap"> world</a>')
'hello world'
>>> stripTags('goodbye<!--stuff--> comments')
'goodbye comments'
>>> stripTags('Entities &#amp; stuff')
'Entities &#amp; stuff'
>>> stripTags('Fr&#233;gate Island')   #accents etc preserved
'Fr&#233;gate Island'
>>> stripTags('Space&#nbsp;here')   #entities preserved
'Space&#nbsp;here'
>>> resolveEntities('Fr&#233;gate Island')   #accents etc preserved
'Fr\\xc3\\xa9gate Island'
>>> stripTags('Ch\xc2\xa3teau & <tag>Summerhouse</tag>')=='Ch\xc2\xa3teau & Summerhouse'
True
>>> stripTags('Ch\xc2\xa3teau & <tag>Summerhouse</tag>'.decode('utf8'))=='Ch\xc2\xa3teau & Summerhouse'.decode('utf8')
True
"""
import sgmllib
from htmlentitydefs import name2codepoint
from rlextra.radxml.xmlutils import nakedAmpFix

def stripTags(text,enc='utf8'):
    return TagStripper().strip(text,enc=enc)

def resolveEntities(text):
    "Turn them to UTF8 text"
    return EntityResolver().resolve(text)

class TagStripper(sgmllib.SGMLParser):
    def strip(self, text, enc='utf8'):
        self._output = []
        self.reset()
        if isinstance(text,unicode):
            enc = None
            br = u'<br/>'
            br1 = u'<br />'
        else:
            br = '<br/>'
            br1 = '<br />'
        self._enc = enc
        self.feed(nakedAmpFix(text).replace(br,br1))
        return ''.join(self._output)

    def handle_data(self, data):
        self._output.append(data)

    def convert_entityref(self, ref):
        u = unichr(name2codepoint.get(ref, 0))
        if self._enc:
            return u.encode(self._enc)
        else:
            return u

    def convert_charref(self, ref):
        "We want char refs to be preserved"
        #print 'ref=',ref, type(ref)
        return '&#%s;' % ref

class EntityResolver(sgmllib.SGMLParser):
    def resolve(self, text):
        self._output = []
        self.reset()
        self.feed(text)
        return ''.join(self._output)

    def handle_data(self, data):
        self._output.append(data)

    def convert_charref(self, ref):
        ch = sgmllib.SGMLParser.convert_charref(self, ref)
        if ch:
            return ch.decode('latin-1').encode('utf8')

if __name__=='__main__':
    import doctest, tagstripper
    doctest.testmod(tagstripper)

