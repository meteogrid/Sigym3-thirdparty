"""
Class to geocode an address and extract the latitude and longitude.
This uses geopy and Google Geocoder and can perform with/without an API key.
But it is recommended to use an API key, since google may ban IPs if they see too many automated requests.
"""

from rlextra.thirdparty.geopy import geocoders, util, distance
import sys

class geocode:

    def __init__(self, API_KEY = None):
        """
        Theoritically, it is possible to geocode even without an api key.
        """
        if API_KEY:
            self.geocoder = geocoders.Google(API_KEY)
        else:
            print >> sys.stderr, "Warning, working in scraping mode!"
            self.geocoder = geocoders.Google(resource='maps', output_format='js')
    
    def do_geocode(self, address=None, **args):
        return self.geocoder.geocode(address, **args)
    
    def parse(self, location):
        return util.parse_geo(location)
    
    def distance(self, location1, location2, geocode_required=True, return_miles=True):
        gc1 = location1
        gc2 = location2
        if geocode_required:
            _, gc1 = self.do_geocode(location1)
            _, gc2 = self.do_geocode(location2)
        if return_miles:    
            return distance.distance(gc1, gc2).miles
        else:
            return distance.distance(gc1, gc2).kilometers
        
def main():
    key = 'ABQIAAAATu_ZYE31JXunZRg0RDrkPhTGW-xOGj2CrpeXCzVTmkab0MGuMhR2i_SMouViajsIRJLus9oOPSr_iQ'
    g = geocode(key)
    #print g.do_geocode('165 the broadway wimbledon london sw19 1ne')
    print g.distance('165 the broadway wimbledon london sw19 1ne', '200 high street east ham london e6 2ja')
    
if __name__ == "__main__":    
    main()