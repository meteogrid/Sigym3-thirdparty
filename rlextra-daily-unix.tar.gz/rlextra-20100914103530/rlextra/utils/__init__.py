#copyright ReportLab Europe Limited. 2000-2006
#see license.txt for license details
