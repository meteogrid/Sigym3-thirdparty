This directory contains code that's not part of the DejaGNU test suite,
but is generally useful as various test harnesses.

vecoperations.c: Various vector operation sanity checks, e.g., shuffles,
  8-bit vector add and multiply.
