This directory contains scripts which are used by the TestRunner style
tests, which allows them to be simpler and more direct.
