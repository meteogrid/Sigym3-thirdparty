This directory contains test cases for the instcombine transformation.  The
dated tests are actual bug tests, whereas the named tests are used to test
for features that the this pass should be capable of performing.

