from fanstatic import Resource
from js.extjs.library import library

ext = Resource(library, 'adapter/ext/ext-base.js',
                debug='adapter/ext/ext-base-debug.js')
