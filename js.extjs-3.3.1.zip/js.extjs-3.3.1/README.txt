js.extjs
********

Introduction
============

This library packages `ExtJS`_ for `fanstatic`_.

.. _`fanstatic`: http://fanstatic.org
.. _`ExtJS`: http://www.sencha.com/products/js/

This requires integration between your web framework and ``fanstatic``,
and making sure that the original resources (shipped in the ``resources``
directory in ``js.extjs``) are published to some URL.

