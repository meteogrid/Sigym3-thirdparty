.. highlight:: cython

.. _limitations:

***********
Limitations
***********

