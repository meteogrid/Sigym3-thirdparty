# I'm bad. I want to be bad. Don't try to change me.

import bad_to_the_bone
