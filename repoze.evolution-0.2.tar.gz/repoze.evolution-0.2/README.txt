repoze.evolution README
=======================

This package exposes an extra named ``transaction``: include this
extra in order to use the ZODBTransactionManager.

Please see docs/index.rst for further documentation.
