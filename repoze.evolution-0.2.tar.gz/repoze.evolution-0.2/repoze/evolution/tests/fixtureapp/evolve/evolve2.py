def evolve(context):
    context.evolved = 2
