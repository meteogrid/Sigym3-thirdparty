=================
 repoze.zodbconn
=================

Library which allows ZODB databases to be constructed from URI
specifications.

See the docs directory for more information.


