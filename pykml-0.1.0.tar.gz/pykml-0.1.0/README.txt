====
PyKML
=====

PyKML is a Python package for authoring, parsing, and manipulating KML
documents.  It is based on the lxml library (http://codespeak.net/lxml/)
which provides a Python API for working with XML documents.

------------
Dependencies
------------

* lxml (>=2.2.8, older versions not tested)

