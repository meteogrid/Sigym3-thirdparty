# package
from test_doctests import test_suite
