Documentation for repoze.folder
===============================

:mod:`repoze.folder` provides a barebones ZODB ``folder`` (container)
implementation with object event support.

.. toctree::
   :maxdepth: 2

   narr.rst
   api.rst
   changes.rst

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
