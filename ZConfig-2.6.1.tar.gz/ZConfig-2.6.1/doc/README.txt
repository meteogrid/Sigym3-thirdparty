The zconfig.tex document in this directory contains the reference
documentation for the ZConfig package.  This documentation is written
using the Python LaTeX styles.

To format the documentation, get a copy of the Python documentation
tools (the Doc/ directory from the Python sources), and create a
symlink to the tools/mkhowto script from some convenient bin/
directory.  You will need to have a fairly complete set of
documentation tools installed on your platform; see

    http://www.python.org/doc/current/doc/doc.html

for more information on the tools.

This documentation requires the latest version of the Python
documentation tools from CVS.
