//------------------------------------------------------------------------------
/*! \file CrownFireSpreadTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::CrownFireSpread.
 */

#include "Handler.h"
#include "CrownFireSpread.h"
#include "CrownFireSpreadTest.h"
#include <QString>
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( CrownFireSpreadTest );

// Non-integral static data members must be initialized outside the class
const double CrownFireSpreadTest::Delta1 = 0.1;    
const double CrownFireSpreadTest::Delta2 = 0.01;    
const double CrownFireSpreadTest::Delta3 = 0.001;    
const double CrownFireSpreadTest::Delta4 = 0.0001;    
const double CrownFireSpreadTest::Delta5 = 0.00001;    
const double CrownFireSpreadTest::Delta6 = 0.000001;    
const double CrownFireSpreadTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void CrownFireSpreadTest::testConstructors()
{
std::cerr << "CrownFireSpreadTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::CrownFireSpread c1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.0, c1.canopyBaseHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.000625, c1.canopyBulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.60, c1.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.60, c1.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.60, c1.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.flameLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.0, c1.foliarMoisture(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.0, c1.liveWood(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.windSpeedAt20Ft(), Delta7 );
    
    CPPUNIT_ASSERT( ! c1.activeCrownFire() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.activeRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 983.115273, c1.criticalCrownFireSpreadRate(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 188.112092, c1.criticalSurfaceFirelineIntensity(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.005462, c1.criticalSurfaceFlameLength(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.crownFireSpreadRate(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::CrownFireAlgorithm::FireStatusSurface, (int) c1.fireStatus() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.surfaceFirelineIntensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, c1.transitionRatio(), Delta7 );
    CPPUNIT_ASSERT( ! c1.transitionToCrown() );

    // Custom constructor
    Sem::CrownFireSpread c2(
        10.0,   //!< canopyBaseHeight,
        0.05,   //!< canopyBulkDensity,
        0.05,   //!< dead1h,
        0.06,   //!< dead10h,
        0.10,   //!< dead100h,
        1.00,   //!< liveWood,
        0.50,   //!< foliarMoisture,
        20.0,   //!< windSpeedAt20Ft,
        20.0    //!< flameLength
    );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, c2.canopyBaseHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, c2.canopyBulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, c2.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, c2.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, c2.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.0, c2.flameLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.50, c2.foliarMoisture(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, c2.liveWood(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.0, c2.windSpeedAt20Ft(), Delta7 );

    CPPUNIT_ASSERT( c2.activeCrownFire() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3821.306888, c2.surfaceFirelineIntensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  111.974789, c2.criticalSurfaceFirelineIntensity(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(    3.942828, c2.criticalSurfaceFlameLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   34.126493, c2.transitionRatio(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   61.096694, c2.crownFireSpreadRate(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   12.288941, c2.criticalCrownFireSpreadRate(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(    4.971681, c2.activeRatio(), Delta6 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::CrownFireAlgorithm::FireStatusCrowning, (int) c2.fireStatus() );
    CPPUNIT_ASSERT( c2.transitionToCrown() );

    c2.setDead1h( 0.25 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.25, c2.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3821.306888, c2.surfaceFirelineIntensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  111.974789, c2.criticalSurfaceFirelineIntensity(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(    3.942828, c2.criticalSurfaceFlameLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   34.126493, c2.transitionRatio(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(    3.499835, c2.crownFireSpreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   12.288941, c2.criticalCrownFireSpreadRate(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(    0.284795, c2.activeRatio(), Delta6 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::CrownFireAlgorithm::FireStatusTorching, (int) c2.fireStatus() );
    CPPUNIT_ASSERT( c2.transitionToCrown() );
    return;
}

//------------------------------------------------------------------------------
void CrownFireSpreadTest::testEquality()
{
std::cerr << "CrownFireSpreadTest::testEquality()" << std::endl;
    Sem::CrownFireSpread p1;
    Sem::CrownFireSpread p2(
        10.0,   //!< canopyBaseHeight,
        0.05,   //!< canopyBulkDensity,
        0.05,   //!< dead1h,
        0.06,   //!< dead10h,
        0.10,   //!< dead100h,
        1.00,   //!< liveWood,
        0.50,   //!< foliarMoisture,
        20.0,   //!< windSpeedAt20Ft,
        20.0    //!< flameLength
    );
    Sem::CrownFireSpread p3( p1 );
    Sem::CrownFireSpread p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void CrownFireSpreadTest::testUpdates()
{
std::cerr << "CrownFireSpreadTest::testUpdates()" << std::endl;
    Sem::CrownFireSpread c1;

    c1.setCanopyBaseHeight( 10.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, c1.canopyBaseHeight(), Delta7 );

    c1.setCanopyBulkDensity( 0.05 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, c1.canopyBulkDensity(), Delta7 );

    c1.setDead1h( 0.05 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, c1.dead1h(), Delta7 );

    c1.setDead10h( 0.06 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, c1.dead10h(), Delta7 );

    c1.setDead100h( 0.10 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, c1.dead100h(), Delta7 );

    c1.setFlameLength( 20.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.0, c1.flameLength(), Delta7 );

    c1.setFoliarMoisture(0.50 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.50, c1.foliarMoisture(), Delta7 );

    c1.setLiveWood( 1.00 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, c1.liveWood(), Delta7 );

    c1.setWindSpeedAt20Ft( 20.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.0, c1.windSpeedAt20Ft(), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void CrownFireSpreadTest::setUp( void )
{
    m_asciiFile = "./data/CrownFireSpreadAscii.dat";
    m_binaryFile = "./data/CrownFireSpreadBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void CrownFireSpreadTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of CrownFireSpreadTest.cpp
//------------------------------------------------------------------------------

