//------------------------------------------------------------------------------
/*! \file LoggerHandlerTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::LoggerHandler.
 */

#include "Handler.h"
#include "Logger.h"
#include "LoggerHandlerTest.h"
#include <iostream>
#include <fstream>

// Registers the fixture into the 'registry'
//CPPUNIT_TEST_SUITE_REGISTRATION( LoggerHandlerTest );

//------------------------------------------------------------------------------
void LoggerHandlerTest::testUsage()
{
std::cerr << "LoggerHandlerTest::testUsage()" << std::endl;
    // Have to create a handler
    //Sem::Handler handler;

    // DON'T CHANGE ANY LINES HERE, OR THE LINE NUMBERS WILL BE OFF!
    Sem::Logger::Instance().send( 0, "send() with code 0 and __FILE__, __LINE args.", __FILE__, __LINE__ );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "INFO message from LoggerHandlerTest.cpp:(25) - send() with code 0 and __FILE__, __LINE args." )
        == 0 );

    Sem::Logger::Instance().send( 1, "send() with code 1 and __FILE__, __LINE args.", __FILE__, __LINE__ );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "WARNING message from LoggerHandlerTest.cpp:(30) - send() with code 1 and __FILE__, __LINE args." )
        == 0 );

    Sem::Logger::Instance().send( 2, "send() with code 2 and __FILE__, __LINE args.", __FILE__, __LINE__ );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "USER message from LoggerHandlerTest.cpp:(35) - send() with code 2 and __FILE__, __LINE args." )
        == 0 );

    Sem::Logger::Instance().send( 3, "send() with code 3 and __FILE__, __LINE args.", __FILE__, __LINE__ );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "PROGRAM message from LoggerHandlerTest.cpp:(40) - send() with code 3 and __FILE__, __LINE args." )
        == 0 );

    Sem::Logger::Instance().send( 4, "send() with code 4 and __FILE__, __LINE args.", __FILE__, __LINE__ );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "SYSTEM message from LoggerHandlerTest.cpp:(45) - send() with code 4 and __FILE__, __LINE args." )
        == 0 );

    // Its ok to change line numbers below here
    Sem::Logger::Instance().send( 0, "send() with code 0." );
    CPPUNIT_ASSERT( strcmp( Sem::Handler::Instance().message().toLatin1().constData(),
        "INFO message - send() with code 0." )
        == 0 );

    return;
}

//------------------------------------------------------------------------------
void LoggerHandlerTest::setUp( void )
{
    m_asciiFile = "./data/LoggerHandlerAscii.dat";
    return;
}

//------------------------------------------------------------------------------
void LoggerHandlerTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of LoggerHandlerTest.cpp
//------------------------------------------------------------------------------

