//------------------------------------------------------------------------------
/*! \file SurfaceFireTerrainTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireTerrain.
 */

#include "Handler.h"
#include "SurfaceFireTerrain.h"
#include "SurfaceFireTerrainTest.h"
#include <QString>
#include <iostream>
#include <iomanip>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireTerrainTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireTerrainTest::Delta1 = 0.1;    
const double SurfaceFireTerrainTest::Delta2 = 0.01;    
const double SurfaceFireTerrainTest::Delta3 = 0.001;    
const double SurfaceFireTerrainTest::Delta4 = 0.0001;    
const double SurfaceFireTerrainTest::Delta5 = 0.00001;    
const double SurfaceFireTerrainTest::Delta6 = 0.000001;    
const double SurfaceFireTerrainTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireTerrainTest::testConstructors()
{
std::cerr << "SurfaceFireTerrainTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SurfaceFireTerrain w1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.slopePercent(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.slopeDegrees(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, w1.upslopeCompass(), Delta7 );

    // Custom constructor
    Sem::SurfaceFireTerrain w2( 100.0, 270. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, w2.slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100.0, w2.slopePercent(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45.0, w2.slopeDegrees(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270.0, w2.aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270.0, w2.downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 90.0, w2.upslopeCompass(), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireTerrainTest::testEquality()
{
std::cerr << "SurfaceFireTerrainTest::testEquality()" << std::endl;
    Sem::SurfaceFireTerrain p1;
    Sem::SurfaceFireTerrain p2( 5.0, 90. );
    Sem::SurfaceFireTerrain p3( p1 );
    Sem::SurfaceFireTerrain p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireTerrainTest::testUpdates()
{
std::cerr << "SurfaceFireTerrainTest::testUpdates()" << std::endl;
    Sem::SurfaceFireTerrain b1;

    b1.setSlopeDegrees( 45. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45.0, b1.slopeDegrees(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, b1.slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100., b1.slopePercent(), Delta5 );

    b1.setSlopeDegrees( 89. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 89.0, b1.slopeDegrees(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 57.28996163, b1.slopeFraction(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5728.996613, b1.slopePercent(), Delta1 );

    b1.setSlopePercent( 100. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45.0, b1.slopeDegrees(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, b1.slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100., b1.slopePercent(), Delta7 );

    b1.setSlopeFraction( 0.5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 26.56505118, b1.slopeDegrees(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.50, b1.slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 50.0, b1.slopePercent(), Delta7 );

    b1.setUpslopeCompass( 123. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 303., b1.aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 303., b1.downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123., b1.upslopeCompass(), Delta7 );

    b1.setAspectCompass( 450. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270., b1.upslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  90., b1.downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  90., b1.aspectCompass(), Delta7 );

    b1.setDownslopeCompass( -450. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270., b1.aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270., b1.downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  90., b1.upslopeCompass(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireTerrainTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireTerrainAscii.dat";
    m_binaryFile = "./data/SurfaceFireTerrainBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireTerrainTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireTerrainTest.cpp
//------------------------------------------------------------------------------

