//------------------------------------------------------------------------------
/*! \file ContainTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::Contain.
 */

#include "Handler.h"
#include "ContainSim.h"
#include "ContainTest.h"
#include <QString>
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( ContainTest );

// Non-integral static data members must be initialized outside the class
const double ContainTest::Delta1 = 0.1;    
const double ContainTest::Delta2 = 0.01;    
const double ContainTest::Delta3 = 0.001;    
const double ContainTest::Delta4 = 0.0001;    
const double ContainTest::Delta5 = 0.00001;    
const double ContainTest::Delta6 = 0.000001;    
const double ContainTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void ContainTest::testConstructors()
{
std::cerr << "ContainTest::testConstructors()" << std::endl;
    // ContainResource
    Sem::ContainResource *crew1 = new Sem::ContainResource();
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, crew1->arrival(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, crew1->baseCost(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( crew1->description().toLatin1().constData(), "" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, crew1->duration(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)crew1->flank() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, crew1->hourCost(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, crew1->production(), Delta7 );

    Sem::ContainResource *crew2 = new Sem::ContainResource(
        60.,                //!< arrival (min after ignition)
        25.0,               //!< production (ch/hr)
        600.,               //!< duration (min)
        Sem::LeftFlank,     //!< flank
        "crew 2",           //!< description
        500.,               //!< baseCost,
        500. );             //!< hourly cost
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 60.0, crew2->arrival(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, crew2->baseCost(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( crew2->description().toLatin1().constData(), "crew 2" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, crew2->duration(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)crew2->flank() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, crew2->hourCost(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.0, crew2->production(), Delta7 );

    // ContainForce
    Sem::ContainForce *force = new Sem::ContainForce();
    CPPUNIT_ASSERT_EQUAL( 0, force->resources() );

    force->addResource( crew2 );
    CPPUNIT_ASSERT_EQUAL( 1, force->resources() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 60.0, force->resourceArrival(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, force->resourceBaseCost(0), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( force->resourceDescription(0).toLatin1().constData(), "crew 2" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, force->resourceDuration(0), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)force->resourceFlank(0) );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, force->resourceHourCost(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.0, force->resourceProduction(0), Delta7 );

    force->addResource(
        120.,               //!< arrival (min after ignition)
        100.,               //!< production (ch/hr)
        10.,                //!< duration (min)
        Sem::LeftFlank,     //!< flank
        "airtanker 1",      //!< description
        5000.,              //!< baseCost,
        5000. );            //!< hourly cost
    CPPUNIT_ASSERT_EQUAL( 2, force->resources() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 120.0, force->resourceArrival(1), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5000.0, force->resourceBaseCost(1), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( force->resourceDescription(1).toLatin1().constData(), "airtanker 1" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, force->resourceDuration(1), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)force->resourceFlank(1) );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5000.0, force->resourceHourCost(1), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100.0, force->resourceProduction(1), Delta7 );

    // ContainSim
    Sem::ContainSim* sim = new Sem::ContainSim(
        1.,                 //!< report fire size (ac)
        10.,                //!< reported fire spread rate (ch/hr)
        2.0,                //!< reported fire length-to-width ratio
        force,              //!< Assigned ContainForce
        Sem::Contain::HeadAttack,    //!< Containment attack tactic
        0.0,                //!< Attack distance from the fire perimeter (ft)
        true,               //!< Retry simulation to get time step target range
        250,                //!< Minimum simulation time steps
        1000 ) ;            //!< Maximum simulation time steps

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, sim->fireSizeAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, sim->fireSpreadRateAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, sim->fireLwRatioAtReport(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::Contain::HeadAttack, (int)sim->tactic() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, sim->attackDistance(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 250, sim->minimumSimulationSteps() );
    CPPUNIT_ASSERT_EQUAL( 1000, sim->maximumSimulationSteps() );
    
    return;
}

//------------------------------------------------------------------------------
void ContainTest::testRun()
{
std::cerr << "ContainTest::testUpdates()" << std::endl;
    Sem::ContainResource *crew2 = new Sem::ContainResource(
        60.,                //!< arrival (min after ignition)
        25.0,               //!< production (ch/hr)
        600.,               //!< duration (min)
        Sem::LeftFlank,     //!< flank
        "crew 2",           //!< description
        500.,               //!< baseCost,
        600. );             //!< hourly cost
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 60.0, crew2->arrival(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, crew2->baseCost(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( crew2->description().toLatin1().constData(), "crew 2" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, crew2->duration(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)crew2->flank() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, crew2->hourCost(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.0, crew2->production(), Delta7 );

    // ContainForce
    Sem::ContainForce *force = new Sem::ContainForce();
    CPPUNIT_ASSERT_EQUAL( 0, force->resources() );

    force->addResource( crew2 );
    CPPUNIT_ASSERT_EQUAL( 1, force->resources() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 60.0, force->resourceArrival(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 500.0, force->resourceBaseCost(0), Delta7 );
    CPPUNIT_ASSERT_EQUAL( strcmp( force->resourceDescription(0).toLatin1().constData(), "crew 2" ), 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, force->resourceDuration(0), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::LeftFlank, (int)force->resourceFlank(0) );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 600.0, force->resourceHourCost(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.0, force->resourceProduction(0), Delta7 );

    // ContainSim
    Sem::ContainSim* sim = new Sem::ContainSim(
        1.,                 //!< report fire size (ac)
        10.,                //!< reported fire spread rate (ch/hr)
        2.0,                //!< reported fire length-to-width ratio
        force,              //!< Assigned ContainForce
        Sem::Contain::HeadAttack,    //!< Containment attack tactic
        0.0,                //!< Attack distance from the fire perimeter (ft)
        true,               //!< Retry simulation to get time step target range
        250,                //!< Minimum simulation time steps
        1000 ) ;            //!< Maximum simulation time steps

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, sim->fireSizeAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, sim->fireSpreadRateAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, sim->fireLwRatioAtReport(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::Contain::HeadAttack, (int)sim->tactic() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, sim->attackDistance(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 250, sim->minimumSimulationSteps() );
    CPPUNIT_ASSERT_EQUAL( 1000, sim->maximumSimulationSteps() );

    sim->run();
    CPPUNIT_ASSERT_EQUAL( (int) Sem::Contain::Contained, (int) sim->status() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 18.173658, sim->finalFireSize(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 49.989943, sim->finalFireLine(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.054, sim->finalFireTime(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1700.54, sim->finalFireCost(), Delta1 );

    // Start over
    delete sim;
    sim = new Sem::ContainSim(
        1.,                 //!< report fire size (ac)
        15.,                //!< reported fire spread rate (ch/hr)
        2.0,                //!< reported fire length-to-width ratio
        force,              //!< Assigned ContainForce
        Sem::Contain::HeadAttack,    //!< Containment attack tactic
        0.0,                //!< Attack distance from the fire perimeter (ft)
        true,               //!< Retry simulation to get time step target range
        250,                //!< Minimum simulation time steps
        1000 ) ;            //!< Maximum simulation time steps

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, sim->fireSizeAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.0, sim->fireSpreadRateAtReport(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, sim->fireLwRatioAtReport(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::Contain::HeadAttack, (int)sim->tactic() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, sim->attackDistance(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 250, sim->minimumSimulationSteps() );
    CPPUNIT_ASSERT_EQUAL( 1000, sim->maximumSimulationSteps() );

    sim->run();
    CPPUNIT_ASSERT_EQUAL( (int) Sem::Contain::Exhausted, (int) sim->status() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, sim->finalFireSize(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, sim->finalFireLine(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 60.0, sim->finalFireTime(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.00, sim->finalFireCost(), Delta1 );

    return;
}

//------------------------------------------------------------------------------
void ContainTest::setUp( void )
{
    m_asciiFile = "./data/ContainAscii.dat";
    m_binaryFile = "./data/ContainBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void ContainTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of ContainTest.cpp
//------------------------------------------------------------------------------

