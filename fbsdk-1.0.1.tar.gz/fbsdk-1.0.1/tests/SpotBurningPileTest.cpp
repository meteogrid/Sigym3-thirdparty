//------------------------------------------------------------------------------
/*! \file SpotBurningPileTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SpotBurningPile.
 */

#include "Handler.h"
#include "SpotBurningPile.h"
#include "SpotBurningPileTest.h"
#include <QString>
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SpotBurningPileTest );

// Non-integral static data members must be initialized outside the class
const double SpotBurningPileTest::Delta1 = 0.1;    
const double SpotBurningPileTest::Delta2 = 0.01;    
const double SpotBurningPileTest::Delta3 = 0.001;    
const double SpotBurningPileTest::Delta4 = 0.0001;    
const double SpotBurningPileTest::Delta5 = 0.00001;    
const double SpotBurningPileTest::Delta6 = 0.000001;    
const double SpotBurningPileTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SpotBurningPileTest::testConstructors()
{
std::cerr << "SpotBurningPileTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SpotBurningPile t1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.coverHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.ridgetopToValleyDistance(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.ridgetopToValleyElevation(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.flameHeight(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 1, (int) t1.source() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.windSpeedAt20Ft(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.firebrandHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.flatTerrainSpottingDistance(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.mountainTerrainSpottingDistance(), Delta7 );

    // Custom constructor
    Sem::SpotBurningPile t2( Sem::SpotAlgorithm::SpotSourceMidslopeWindward,
        4.,         // ridgetop to valley horizontal distance
        4000.,      // ridgetop to valley elevation difference
        100.,       // mean cover height along firebrand path
        30.,        // wind speed at 20 ft
        10. );      // steady flame height
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100.0,  t2.coverHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.0,    t2.ridgetopToValleyDistance(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4000.0, t2.ridgetopToValleyElevation(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 0, (int) t2.source() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, t2.windSpeedAt20Ft(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, t2.flameHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 122.0, t2.firebrandHeight(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10163, t2.flatTerrainSpottingDistance(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.103305, t2.mountainTerrainSpottingDistance(), Delta6 );
    return;
}

//------------------------------------------------------------------------------
void SpotBurningPileTest::testEquality()
{
std::cerr << "SpotBurningPileTest::testEquality()" << std::endl;
    Sem::SpotBurningPile p1;
    Sem::SpotBurningPile p2( Sem::SpotAlgorithm::SpotSourceMidslopeWindward,
        4.,         // ridgetop to valley horizontal distance
        4000.,      // ridgetop to valley elevation difference
        100.,       // mean cover height along firebrand path
        30.,        // wind speed at 20 ft
        10. );      // steady flame height
    Sem::SpotBurningPile p3( p1 );
    Sem::SpotBurningPile p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void SpotBurningPileTest::testUpdates()
{
std::cerr << "SpotBurningPileTest::testUpdates()" << std::endl;
    Sem::SpotBurningPile t1;

    t1.setCoverHeight( 123. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123.0,  t1.coverHeight(), Delta7 );

    t1.setRidgetopToValleyDistance( 2. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0,    t1.ridgetopToValleyDistance(), Delta7 );

    t1.setRidgetopToValleyElevation( 1234. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1234.0, t1.ridgetopToValleyElevation(), Delta7 );

    t1.setSource( Sem::SpotAlgorithm::SpotSourceRidgetop );
    CPPUNIT_ASSERT_EQUAL( 3, (int) t1.source() );

    t1.setFlameHeight( 123.45 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123.45, t1.flameHeight(), Delta7 );

    t1.setWindSpeedAt20Ft( 12.345 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 12.345, t1.windSpeedAt20Ft(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SpotBurningPileTest::setUp( void )
{
    m_asciiFile = "./data/SpotBurningPileAscii.dat";
    m_binaryFile = "./data/SpotBurningPileBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SpotBurningPileTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SpotBurningPileTest.cpp
//------------------------------------------------------------------------------

