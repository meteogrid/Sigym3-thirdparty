//------------------------------------------------------------------------------
/*! \file SpotTorchingTreesTest.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SpotTorchingTrees.
 */

#ifndef _SPOTTORCHINGTREESTEST_H_INCLUDED_
#define _SPOTTORCHINGTREESTEST_H_INCLUDED_

#include <cppunit/extensions/HelperMacros.h>

class SpotTorchingTreesTest : public CppUnit::TestFixture
{
public:
    static const double Delta1;
    static const double Delta2;
    static const double Delta3;
    static const double Delta4;
    static const double Delta5;
    static const double Delta6;
    static const double Delta7;
    void setUp();
    void tearDown();
    void testConstructors();
    void testEquality();
    void testUpdates();

    // Create the SpotTorchingTrees test suite
    CPPUNIT_TEST_SUITE( SpotTorchingTreesTest );
    CPPUNIT_TEST( testConstructors );
    CPPUNIT_TEST( testEquality );
    //CPPUNIT_TEST( testUpdates );
    CPPUNIT_TEST_SUITE_END();

private:
    char *m_asciiFile;
    char *m_binaryFile;
};

#endif // _SPOTTORCHINGTREESTEST_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SpotTorchingTreesTest.h
//------------------------------------------------------------------------------

