//------------------------------------------------------------------------------
/*! \file SurfaceFireMoistureTimeLagTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireMoistureTimeLag.
 */

// Custom header files
#include "Handler.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireMoistureTimeLagTest.h"

// Standard headers
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireMoistureTimeLagTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireMoistureTimeLagTest::Delta1 = 0.1;    
const double SurfaceFireMoistureTimeLagTest::Delta2 = 0.01;    
const double SurfaceFireMoistureTimeLagTest::Delta3 = 0.001;    
const double SurfaceFireMoistureTimeLagTest::Delta4 = 0.0001;    
const double SurfaceFireMoistureTimeLagTest::Delta5 = 0.00001;    
const double SurfaceFireMoistureTimeLagTest::Delta6 = 0.000001;    
const double SurfaceFireMoistureTimeLagTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireMoistureTimeLagTest::testConstructors()
{
std::cerr << "SurfaceFireMoistureTimeLagTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SurfaceFireMoistureTimeLag m1;
    CPPUNIT_ASSERT_EQUAL( 1, m1.classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, m1.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, m1.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, m1.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, m1.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, m1.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, m1.liveWood(), Delta7 );

    // Custom constructor
    Sem::SurfaceFireMoistureTimeLag m2( 0.04, 0.06, 0.08, 0.12, 1.5, 2.5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m2.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m2.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m2.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m2.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m2.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m2.liveWood(), Delta7 );

    // Copy constructor
    Sem::SurfaceFireMoistureTimeLag m3( m2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m3.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m3.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m3.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m3.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m3.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m3.liveWood(), Delta7 );

    // Assignment operator
    m1 = m3;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m1.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m1.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m1.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m1.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m1.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m1.liveWood(), Delta7 );
    CPPUNIT_ASSERT( m1 == m3 );

    // moisture()
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h ), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureDead10h ), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureDead100h ), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureDead1000h ), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb ), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m1.moisture( Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood ), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireMoistureTimeLagTest::testEquality()
{
std::cerr << "SurfaceFireMoistureTimeLagTest::testEquality()" << std::endl;
    Sem::SurfaceFireMoistureTimeLag m1( 0.04, 0.06, 0.08, 0.12, 1.5, 2.5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m1.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m1.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m1.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m1.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m1.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m1.liveWood(), Delta7 );

    Sem::SurfaceFireMoistureTimeLag m2( 0.04, 0.06, 0.08, 0.12, 1.5, 2.51 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m2.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m2.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m2.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m2.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m2.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.51, m2.liveWood(), Delta7 );

    Sem::SurfaceFireMoistureTimeLag m3( m1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m3.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m3.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m3.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m3.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m3.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m3.liveWood(), Delta7 );

    Sem::SurfaceFireMoistureTimeLag m4 = m2;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m4.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m4.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m4.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m4.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m4.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.51, m4.liveWood(), Delta7 );

    CPPUNIT_ASSERT( m1 == m1 );
    CPPUNIT_ASSERT( m1 != m2 );
    CPPUNIT_ASSERT( m1 == m3 );
    CPPUNIT_ASSERT( m1 != m4 );

    CPPUNIT_ASSERT( m2 != m1 );
    CPPUNIT_ASSERT( m2 == m2 );
    CPPUNIT_ASSERT( m2 != m3 );
    CPPUNIT_ASSERT( m2 == m4 );

    CPPUNIT_ASSERT( m3 == m1 );
    CPPUNIT_ASSERT( m3 != m2 );
    CPPUNIT_ASSERT( m3 == m3 );
    CPPUNIT_ASSERT( m3 != m4 );

    CPPUNIT_ASSERT( m4 != m1 );
    CPPUNIT_ASSERT( m4 == m2 );
    CPPUNIT_ASSERT( m4 != m3 );
    CPPUNIT_ASSERT( m4 == m4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireMoistureTimeLagTest::testUpdates()
{
std::cerr << "SurfaceFireMoistureTimeLagTest::testUpdates()" << std::endl;
    Sem::SurfaceFireMoistureTimeLag m1( 0.04, 0.06, 0.08, 0.12, 1.5, 2.5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m1.dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m1.dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m1.dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, m1.dead1000h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m1.liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, m1.liveWood(), Delta7 );

    m1.setDead1h( 0.05 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, m1.dead1h(), Delta7 );

    m1.setDead10h( 0.07 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, m1.dead10h(), Delta7 );

    m1.setDead100h( 0.09 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.09, m1.dead100h(), Delta7 );

    m1.setDead1000h( 0.13 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.13, m1.dead1000h(), Delta7 );

    m1.setLiveHerb( 1.7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.70, m1.liveHerb(), Delta7 );

    m1.setLiveWood( 2.9 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.90, m1.liveWood(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireMoistureTimeLagTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireMoistureTimeLagAscii.dat";
    m_binaryFile = "./data/SurfaceFireMoistureTimeLagBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireMoistureTimeLagTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireMoistureTimeLagTest.cpp
//------------------------------------------------------------------------------

