//------------------------------------------------------------------------------
/*! \file SurfaceFireParticleTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireParticle.
 */

// Custom header files
#include "Handler.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireParticle.h"
#include "SurfaceFireParticleTest.h"

// Standard headers
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireParticleTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireParticleTest::Delta1 = 0.1;    
const double SurfaceFireParticleTest::Delta2 = 0.01;    
const double SurfaceFireParticleTest::Delta3 = 0.001;    
const double SurfaceFireParticleTest::Delta4 = 0.0001;    
const double SurfaceFireParticleTest::Delta5 = 0.00001;    
const double SurfaceFireParticleTest::Delta6 = 0.000001;    
const double SurfaceFireParticleTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireParticleTest::testConstructors()
{
std::cerr << "SurfaceFireParticleTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SurfaceFireParticle p1;
    CPPUNIT_ASSERT_EQUAL( 1, p1.classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1000., p1.savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, p1.siEffective(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0555, p1.siTotal(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 32.0, p1.density(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000., p1.heatOfCombustion(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, p1.height(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::CureNone, p1.cureAlgorithm() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h, p1.moistureClassDead() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood, p1.moistureClassLive() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, p1.moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.loadLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.fineFuelDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.fineFuelLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.8710987, p1.effectiveHeatingNumber(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.areaWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.areaWtgLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.sizeWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.sizeWtgLive(), Delta7 );

    // Custom constructor, dynamic fuel load transfer
    Sem::SurfaceFireParticle p2(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,
        2000.,      //!< Fuel particle surface area to volume ratio (ft2/ft3) [input].
        2.0,        //!< Fuel particle height above the surface (ft).
        0.0,        //<! Fuel particle dead load (lb/ft2) [input].
        0.2296,     //<! Fuel particle live load (lb/ft2) (5.0 tons per acre)
        0.3,        //<! Fuel particle dead moisture content (fraction odw).
        1.0,        //<! Fuel particle live moisture content (fraction odw).
        6000.0,     //<! Fuel particle low heat of combustion (Btu/lb) [input].
        30.,        //<! Fuel particle density (lb/ft3) [input].
        0.05,       //<! Fuel particle total silica content (lb si/lb fuel) [input].
        0.02 );     //<! Fuel particle effective silica content (lb si/lb fuel) [input].
    CPPUNIT_ASSERT_EQUAL( 1, p2.classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p2.savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p2.siEffective(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p2.siTotal(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, p2.density(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6000., p2.heatOfCombustion(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, p2.height(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::CureHerb1, p2.cureAlgorithm() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h, p2.moistureClassDead() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb, p2.moistureClassLive() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p2.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, p2.moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0512008, p2.loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.1783992, p2.loadLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.9333267, p2.effectiveHeatingNumber(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.047786327, p2.fineFuelDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.13893806, p2.fineFuelLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p2.areaWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p2.areaWtgLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p2.sizeWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p2.sizeWtgLive(), Delta7 );

    // Copy constructor
    Sem::SurfaceFireParticle p3( p2 );
    CPPUNIT_ASSERT_EQUAL( 1, p3.classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p3.savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p3.siEffective(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p3.siTotal(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, p3.density(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6000., p3.heatOfCombustion(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, p3.height(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::CureHerb1, p3.cureAlgorithm() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h, p3.moistureClassDead() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb, p3.moistureClassLive() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p3.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, p3.moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0512008, p3.loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.1783992, p3.loadLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.9333267, p3.effectiveHeatingNumber(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p3.areaWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p3.areaWtgLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p3.sizeWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p3.sizeWtgLive(), Delta7 );

    // Assignment operator
    p1 = p2;
    CPPUNIT_ASSERT_EQUAL( 1, p1.classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p1.savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p1.siEffective(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1.siTotal(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, p1.density(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6000., p1.heatOfCombustion(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, p1.height(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::CureHerb1, p1.cureAlgorithm() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h, p1.moistureClassDead() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb, p1.moistureClassLive() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, p1.moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0512008, p1.loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.1783992, p1.loadLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.9333267, p1.effectiveHeatingNumber(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.areaWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.areaWtgLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.sizeWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p1.sizeWtgLive(), Delta7 );

    // Clone constructor
    Sem::SurfaceFireParticle* p4 = p1.clone();
    CPPUNIT_ASSERT_EQUAL( 1, p4->classVersion() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p4->savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p4->siEffective(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p4->siTotal(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, p4->density(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6000., p4->heatOfCombustion(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.0, p4->height(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::CureHerb1, p4->cureAlgorithm() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h, p4->moistureClassDead() );
    CPPUNIT_ASSERT_EQUAL( Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb, p4->moistureClassLive() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p4->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, p4->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0512008, p4->loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.1783992, p4->loadLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.9333267, p4->effectiveHeatingNumber(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p4->areaWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p4->areaWtgLive(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p4->sizeWtgDead(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p4->sizeWtgLive(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireParticleTest::testEquality()
{
std::cerr << "SurfaceFireParticleTest::testEquality()" << std::endl;
    Sem::SurfaceFireParticle p1;
    Sem::SurfaceFireParticle p2(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,
        2000.,      //!< Fuel particle surface area to volume ratio (ft2/ft3) [input].
        2.0,        //!< Fuel particle height above the surface (ft).
        0.0,        //<! Fuel particle dead load (lb/ft2) [input].
        0.2296,     //<! Fuel particle live load (lb/ft2) (5.0 tons per acre)
        0.3,        //<! Fuel particle dead moisture content (fraction odw).
        1.0,        //<! Fuel particle live moisture content (fraction odw).
        6000.0,     //<! Fuel particle low heat of combustion (Btu/lb) [input].
        30.,        //<! Fuel particle density (lb/ft3) [input].
        0.05,       //<! Fuel particle total silica content (lb si/lb fuel) [input].
        0.02 );     //<! Fuel particle effective silica content (lb si/lb fuel) [input].
    Sem::SurfaceFireParticle p3( p1 );
    Sem::SurfaceFireParticle p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireParticleTest::testUpdates()
{
std::cerr << "SurfaceFireParticleTest::testUpdates()" << std::endl;
    Sem::SurfaceFireParticle p1;

    p1.setDensity( 30.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, p1.density(), Delta7 );

    p1.setHeatOfCombustion( 6000. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6000.0, p1.heatOfCombustion(), Delta7 );

    p1.setMoistureDead( 0.123 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.123, p1.moistureDead(), Delta7 );

    p1.setMoistureLive( 1.23 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.23, p1.moistureLive(), Delta7 );

    p1.setSurfaceAreaToVolumeRatio( 2000. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p1.savr(), Delta7 );

    // Ensure correct moisture is returned based upon the dead fuel size class
    Sem::SurfaceFireMoistureInterface* tl =
        new Sem::SurfaceFireMoistureTimeLag( 0.02, 0.04, 0.06, 0.08, 0.80, 1.20 );
    p1.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.20, p1.moistureLive(), Delta7 );

    p1.setSurfaceAreaToVolumeRatio( 130. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 130., p1.savr(), Delta7 );
    p1.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.20, p1.moistureLive(), Delta7 );

    p1.setSurfaceAreaToVolumeRatio( 40. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 40., p1.savr(), Delta7 );
    p1.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.20, p1.moistureLive(), Delta7 );

    p1.setSurfaceAreaToVolumeRatio( 10. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10., p1.savr(), Delta7 );
    p1.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, p1.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.20, p1.moistureLive(), Delta7 );

    // Herbaceous live fuel
    Sem::SurfaceFireParticle p2(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,
        2000.,      //!< Fuel particle surface area to volume ratio (ft2/ft3) [input].
        2.0,        //!< Fuel particle height above the surface (ft).
        0.0,        //<! Fuel particle dead load (lb/ft2) [input].
        0.2296,     //<! Fuel particle live load (lb/ft2) (5.0 tons per acre)
        0.3,        //<! Fuel particle dead moisture content (fraction odw).
        1.0,        //<! Fuel particle live moisture content (fraction odw).
        6000.0,     //<! Fuel particle low heat of combustion (Btu/lb) [input].
        30.,        //<! Fuel particle density (lb/ft3) [input].
        0.05,       //<! Fuel particle total silica content (lb si/lb fuel) [input].
        0.02 );     //<! Fuel particle effective silica content (lb si/lb fuel) [input].
    p2.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p2.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.80, p2.moistureLive(), Delta7 );

    // Woody live fuel
    Sem::SurfaceFireParticle p3(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,
        190.,       //!< Fuel particle surface area to volume ratio (ft2/ft3) [input].
        2.0,        //!< Fuel particle height above the surface (ft).
        0.0,        //<! Fuel particle dead load (lb/ft2) [input].
        0.2296,     //<! Fuel particle live load (lb/ft2) (5.0 tons per acre)
        0.3,        //<! Fuel particle dead moisture content (fraction odw).
        1.0,        //<! Fuel particle live moisture content (fraction odw).
        6000.0,     //<! Fuel particle low heat of combustion (Btu/lb) [input].
        30.,        //<! Fuel particle density (lb/ft3) [input].
        0.05,       //<! Fuel particle total silica content (lb si/lb fuel) [input].
        0.02 );     //<! Fuel particle effective silica content (lb si/lb fuel) [input].
    p3.setMoisture( tl );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p3.moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.20, p3.moistureLive(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireParticleTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireParticleAscii.dat";
    m_binaryFile = "./data/SurfaceFireParticleBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireParticleTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireParticleTest.cpp
//------------------------------------------------------------------------------

