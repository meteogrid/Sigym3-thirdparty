//------------------------------------------------------------------------------
/*! \file TreeMortalityTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::TreeMortality.
 */

#include "Handler.h"
#include "TreeMortality.h"
#include "TreeMortalityTest.h"
#include <QString>
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( TreeMortalityTest );

// Non-integral static data members must be initialized outside the class
const double TreeMortalityTest::Delta1 = 0.1;    
const double TreeMortalityTest::Delta2 = 0.01;    
const double TreeMortalityTest::Delta3 = 0.001;    
const double TreeMortalityTest::Delta4 = 0.0001;    
const double TreeMortalityTest::Delta5 = 0.00001;    
const double TreeMortalityTest::Delta6 = 0.000001;    
const double TreeMortalityTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void TreeMortalityTest::testConstructors()
{
std::cerr << "TreeMortalityTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::TreeMortality t1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.scorchHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.treeCrownRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.0, t1.treeDbh(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10., t1.treeHeight(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::FofemTreeSpecies::FofemSpeciesPINPON, (int) t1.species() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.325000, t1.barkThickness(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.crownLengthScorched(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1.crownVolumeScorched(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.5469817, t1.mortalityProbability(), Delta7 );

    // Custom constructor
    Sem::TreeMortality t2(
        Sem::FofemTreeSpecies::FofemSpeciesPINCON,    //!< FofemSpecies species,
        50.,                        //!< treeHeight,
        0.9,                        //!< treeCrownRatio,
        10.0,                       //!< treeDbh,
        30. );                      //!< scorchHeight
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.0, t2.scorchHeight(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.90, t2.treeCrownRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, t2.treeDbh(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 50.0, t2.treeHeight(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::FofemTreeSpecies::FofemSpeciesPINCON, (int) t2.species() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.280000, t2.barkThickness(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.0, t2.crownLengthScorched(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.8024691, t2.crownVolumeScorched(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.9790347, t2.mortalityProbability(), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void TreeMortalityTest::testEquality()
{
std::cerr << "TreeMortalityTest::testEquality()" << std::endl;
    Sem::TreeMortality p1;
    Sem::TreeMortality p2(
        Sem::FofemTreeSpecies::FofemSpeciesPINCON,    //!< FofemSpecies species,
        50.,                        //!< treeHeight,
        0.9,                        //!< treeCrownRatio,
        10.0,                       //!< treeDbh,
        30. );                      //!< scorchHeight
    Sem::TreeMortality p3( p1 );
    Sem::TreeMortality p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void TreeMortalityTest::testUpdates()
{
std::cerr << "TreeMortalityTest::testUpdates()" << std::endl;
    Sem::TreeMortality t1;

    t1.setScorchHeight( 123.456 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123.456, t1.scorchHeight(), Delta7 );

    t1.setTreeCrownRatio( 0.123456 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.123456, t1.treeCrownRatio(), Delta7 );

    t1.setTreeDbh( 12.3456 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 12.3456, t1.treeDbh(), Delta7 );

    t1.setTreeHeight( 123.456 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123.456, t1.treeHeight(), Delta7 );

    t1.setSpecies( Sem::FofemTreeSpecies::FofemSpeciesPINCON );
    CPPUNIT_ASSERT_EQUAL( (int) Sem::FofemTreeSpecies::FofemSpeciesPINCON, (int) t1.species() );

    return;
}

//------------------------------------------------------------------------------
void TreeMortalityTest::setUp( void )
{
    m_asciiFile = "./data/TreeMortalityAscii.dat";
    m_binaryFile = "./data/TreeMortalityBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void TreeMortalityTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of TreeMortalityTest.cpp
//------------------------------------------------------------------------------

