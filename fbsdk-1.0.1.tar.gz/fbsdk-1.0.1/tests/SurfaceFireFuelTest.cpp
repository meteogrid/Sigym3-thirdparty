//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireFuel.
 */

// Custom header files
#include "Handler.h"
#include "SurfaceFireFuel.h"
#include "SurfaceFireFuelInterface.h"
#include "SurfaceFireFuelTest.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireParticle.h"
#include "SurfaceFireParticleInterface.h"

// Standard header files
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireFuelTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireFuelTest::Delta1 = 0.1;    
const double SurfaceFireFuelTest::Delta2 = 0.01;    
const double SurfaceFireFuelTest::Delta3 = 0.001;    
const double SurfaceFireFuelTest::Delta4 = 0.0001;    
const double SurfaceFireFuelTest::Delta5 = 0.00001;    
const double SurfaceFireFuelTest::Delta6 = 0.000001;    
const double SurfaceFireFuelTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::testConstructors()
{
std::cerr << "SurfaceFireFuelTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SurfaceFireFuel b1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, b1.mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 0, b1.fuels() );

    // Custom constructor
    Sem::SurfaceFireFuel b2( 0.25 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.25, b2.mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 0, b2.fuels() );

    // Copy constructor
    Sem::SurfaceFireFuel b3( b2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.25, b3.mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 0, b3.fuels() );

    // Assignment operator
    b1 = b2;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.25, b1.mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 0, b1.fuels() );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::testEquality()
{
std::cerr << "SurfaceFireFuelTest::testEquality()" << std::endl;
    Sem::SurfaceFireFuel b1;
    Sem::SurfaceFireFuel b2( 0.25 );
    Sem::SurfaceFireFuel b3( b1 );
    Sem::SurfaceFireFuel b4 = b2;
    CPPUNIT_ASSERT( b1 == b1 );
    CPPUNIT_ASSERT( b1 != b2 );
    CPPUNIT_ASSERT( b1 == b3 );
    CPPUNIT_ASSERT( b1 != b4 );

    CPPUNIT_ASSERT( b2 != b1 );
    CPPUNIT_ASSERT( b2 == b2 );
    CPPUNIT_ASSERT( b2 != b3 );
    CPPUNIT_ASSERT( b2 == b4 );

    CPPUNIT_ASSERT( b3 == b1 );
    CPPUNIT_ASSERT( b3 != b2 );
    CPPUNIT_ASSERT( b3 == b3 );
    CPPUNIT_ASSERT( b3 != b4 );

    CPPUNIT_ASSERT( b4 != b1 );
    CPPUNIT_ASSERT( b4 == b2 );
    CPPUNIT_ASSERT( b4 != b3 );
    CPPUNIT_ASSERT( b4 == b4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::testSignals()
{
std::cerr << "SurfaceFireFuelTest::testSignals()" << std::endl;

    // Create dynamic model 124, "gs4" (High load, humid climate grass-shrub)
    Sem::SurfaceFireFuel* fm124 = create124();

    // Get the particle pointers
    Sem::SurfaceFireParticleInterface* p0 = fm124->fuelPtr( 0 );
    Sem::SurfaceFireParticleInterface* p1 = fm124->fuelPtr( 1 );
    Sem::SurfaceFireParticleInterface* p2 = fm124->fuelPtr( 2 );
    Sem::SurfaceFireParticleInterface* p3 = fm124->fuelPtr( 3 );
    Sem::SurfaceFireParticleInterface* p4 = fm124->fuelPtr( 4 );

    // Validate properties
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, p4->moistureLive(), Delta7 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.40, fm124->mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 5, fm124->fuels() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.1, fm124->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 24.1046832, fm124->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.958247245, fm124->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 29.06293045, fm124->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.17060383, fm124->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.82939617, fm124->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1782.462106, fm124->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1600., fm124->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1631.128734, fm124->sigma(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, fm124->heatOfCombustionDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, fm124->heatOfCombustionLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, fm124->siEffectiveDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, fm124->siEffectiveLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.105601469, fm124->loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.482093664, fm124->loadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.081670072, fm124->netLoadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.455337466, fm124->netLoadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.008745463, fm124->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.279854825, fm124->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0078357, fm124->optimumPackingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.2354198, fm124->residenceTime(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, fm124->mineralDampingCoefficientDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, fm124->mineralDampingCoefficientLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.113086, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 590.458295, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2508.108050, fm124->reactionIntensity(), Delta1 );

    // Change fuel moisture contents of particles individually ...
    Sem::SurfaceFireMoistureInterface* m1 = new Sem::SurfaceFireMoistureTimeLag(
        0.04, 0.06, 0.08, 0.10, 1.5, 2.5 );
    p0->setMoisture( m1 );
    p1->setMoisture( m1 );
    p2->setMoisture( m1 );
    p3->setMoisture( m1 );
    p4->setMoisture( m1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.193577, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 753.914521, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3202.426143, fm124->reactionIntensity(), Delta1 );

    // Change the moisture object ...
    Sem::SurfaceFireMoistureTimeLag* m2 = new Sem::SurfaceFireMoistureTimeLag(
        0.03, 0.05, 0.07, 0.09, 1.3, 2.3 );
    fm124->connectMoisture( m2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.03, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.222809, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 796.328581, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3382.589664, fm124->reactionIntensity(), Delta1 );

    // Change the moisture object value ...
    m2->setDead1h( 0.02 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.236189, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 843.379269, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3582.448141, fm124->reactionIntensity(), Delta1 );

    // Change a fuel particle property ...
    dynamic_cast<Sem::SurfaceFireParticle*>(p0)->setSurfaceAreaToVolumeRatio( 2000. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p0->savr(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.245778, fm124->spreadRate(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 826.672393, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3597.462078, fm124->reactionIntensity(), Delta1 );

    // Remove moisture connection
    fm124->connectMoisture( 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p0->savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.245778, fm124->spreadRate(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 826.672393, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3597.462078, fm124->reactionIntensity(), Delta1 );

    delete m1;
    delete fm124;
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::testUpdates()
{
std::cerr << "SurfaceFireFuelTest::testUpdates()" << std::endl;
    Sem::SurfaceFireFuel b1;

    b1.setMextDead( 0.15 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.15, b1.mextDead(), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireFuelAscii.dat";
    m_binaryFile = "./data/SurfaceFireFuelBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
Sem::SurfaceFireFuel* SurfaceFireFuelTest::create124()
{
    // Create dynamic model 124, "gs4" (High load, humid climate grass-shrub)
    Sem::SurfaceFireFuel* fm124 = new Sem::SurfaceFireFuel( 0.40 );

    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2

    Sem::SurfaceFireParticleInterface* p1 = new Sem::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        0.5,                        // maximum height (ft)
        1.9 * f,                    // dead fuel load (lb/ft2)
        0.0 );                      // live fuel load (lb/ft2)
    fm124->addSurfaceFireParticle( p1 );

    Sem::SurfaceFireParticleInterface* p2 = new Sem::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        0.5,                        // maximum height (ft)
        0.3 * f,                    // dead fuel load (lb/ft2)
        0.0 );                      // live fuel load (lb/ft2)
    fm124->addSurfaceFireParticle( p2 );

    Sem::SurfaceFireParticleInterface* p3 = new Sem::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        0.5,                        // maximum height (ft)
        0.1 * f,                    // dead fuel load (lb/ft2)
        0.0 );                      // live fuel load (lb/ft2)
    fm124->addSurfaceFireParticle( p3 );

    Sem::SurfaceFireParticleInterface* p4 = new Sem::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        2.1,                        // maximum height (ft)
        0.0,                        // dead fuel load (lb/ft2)
        3.4 * f );                  // live fuel load (lb/ft2)
    fm124->addSurfaceFireParticle( p4 );

    Sem::SurfaceFireParticleInterface* p5 = new Sem::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        2.1,                        // maximum height (ft)
        0.0,                        // dead fuel load (lb/ft2)
        7.1 * f );                  // live fuel load (lb/ft2)
    fm124->addSurfaceFireParticle( p5 );
    return( fm124 );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelTest.cpp
//------------------------------------------------------------------------------

