//------------------------------------------------------------------------------
/*! \file TreeMortalityTest.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::TreeMortality.
 */

#ifndef _TREEMORTALITYTEST_H_INCLUDED_
#define _TREEMORTALITYTEST_H_INCLUDED_

#include <cppunit/extensions/HelperMacros.h>

class TreeMortalityTest : public CppUnit::TestFixture
{
public:
    static const double Delta1;
    static const double Delta2;
    static const double Delta3;
    static const double Delta4;
    static const double Delta5;
    static const double Delta6;
    static const double Delta7;
    void setUp();
    void tearDown();
    void testConstructors();
    void testEquality();
    void testUpdates();

    // Create the TreeMortality test suite
    CPPUNIT_TEST_SUITE( TreeMortalityTest );
    CPPUNIT_TEST( testConstructors );
    CPPUNIT_TEST( testEquality );
    CPPUNIT_TEST( testUpdates );
    CPPUNIT_TEST_SUITE_END();

private:
    char *m_asciiFile;
    char *m_binaryFile;
};

#endif // _TREEMORTALITYTEST_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of TreeMortalityTest.h
//------------------------------------------------------------------------------

