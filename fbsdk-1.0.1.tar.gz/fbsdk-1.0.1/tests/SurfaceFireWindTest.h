//------------------------------------------------------------------------------
/*! \file SurfaceFireWindTest.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireWind.
 */

#ifndef _SURFACEFIREWINDTEST_H_INCLUDED_
#define _SURFACEFIREWINDTEST_H_INCLUDED_

#include <cppunit/extensions/HelperMacros.h>

class SurfaceFireWindTest : public CppUnit::TestFixture
{
public:
    static const double Delta1;
    static const double Delta2;
    static const double Delta3;
    static const double Delta4;
    static const double Delta5;
    static const double Delta6;
    static const double Delta7;
    void setUp();
    void tearDown();
    void testConstructors();
    void testEquality();
    void testUpdates();

    // Create the SurfaceFireWind test suite
    CPPUNIT_TEST_SUITE( SurfaceFireWindTest );
    CPPUNIT_TEST( testConstructors );
    CPPUNIT_TEST( testEquality );
    CPPUNIT_TEST( testUpdates );
    CPPUNIT_TEST_SUITE_END();

private:
    char *m_asciiFile;
    char *m_binaryFile;
};

#endif // _SURFACEFIREWINDTEST_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireWindTest.h
//------------------------------------------------------------------------------

