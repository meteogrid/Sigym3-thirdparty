//------------------------------------------------------------------------------
/*! \file SurfaceFireSpreadTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireSpread.
 */

#include "Handler.h"
#include "SurfaceFireFuelModelFactory.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireSpread.h"
#include "SurfaceFireSpreadTest.h"
#include "SurfaceFireTerrain.h"
#include "SurfaceFireWind.h"

#include <QString>

#include <iostream>
#include <iomanip>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireSpreadTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireSpreadTest::Delta1 = 0.1;    
const double SurfaceFireSpreadTest::Delta2 = 0.01;    
const double SurfaceFireSpreadTest::Delta3 = 0.001;    
const double SurfaceFireSpreadTest::Delta4 = 0.0001;    
const double SurfaceFireSpreadTest::Delta5 = 0.00001;    
const double SurfaceFireSpreadTest::Delta6 = 0.000001;    
const double SurfaceFireSpreadTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireSpreadTest::testConstructors()
{
std::cerr << "SurfaceFireSpreadTest::testConstructors()" << std::endl;
    // Create supporting moisture, fuel, terrain, and wind objects
    Sem::SurfaceFireMoistureTimeLag* m1 = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, m1->dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, m1->dead10h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, m1->dead100h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.00, m1->liveHerb(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, m1->liveWood(), Delta7 );

    Sem::SurfaceFireFuelModel* f1 = Sem::createFuelModel( 1, m1 );
    CPPUNIT_ASSERT_EQUAL( 1, f1->fuels() );
    Sem::SurfaceFireParticleInterface* p0 = f1->fuelPtr( 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p0->moistureDead(), Delta7 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, f1->mextDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, f1->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.71875, f1->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, f1->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.71875, f1->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, f1->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, f1->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3500., f1->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, f1->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3500., f1->sigma(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0010625, f1->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0340, f1->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0041932, f1->optimumPackingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0041932, f1->optimumPackingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.961338619, f1->fuelEffectiveHeatingNumber(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.032685513, f1->fuelFineDead(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, f1->fuelFineLive(0), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 874.214454, f1->reactionIntensity(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 95.913814, f1->heatPerUnitArea(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510, f1->spreadRate(), Delta6 );

    Sem::SurfaceFireTerrain* t0 = new Sem::SurfaceFireTerrain( 0., 0. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t0->slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t0->slopePercent(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t0->slopeDegrees(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t0->aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t0->downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, t0->upslopeCompass(), Delta7 );

    Sem::SurfaceFireTerrain* t1 = new Sem::SurfaceFireTerrain( 100., 180. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, t1->slopeFraction(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100.0, t1->slopePercent(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45.0, t1->slopeDegrees(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, t1->aspectCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, t1->downslopeCompass(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, t1->upslopeCompass(), Delta7 );

    Sem::SurfaceFireWind* w0 = new Sem::SurfaceFireWind( 0., 0. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w0->mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w0->fpm(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w0->source(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, w0->bearing(), Delta7 );

    Sem::SurfaceFireWind* w1 = new Sem::SurfaceFireWind( 5., 180. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.0, w1->mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 440.0, w1->fpm(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, w1->source(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1->bearing(), Delta7 );

    // Default constructor
    Sem::SurfaceFireSpread s1a;
    CPPUNIT_ASSERT_EQUAL( 0, (int) s1a.connectedFuel() );
    CPPUNIT_ASSERT_EQUAL( 0, (int) s1a.connectedTerrain() );
    CPPUNIT_ASSERT_EQUAL( 0, (int) s1a.connectedWind() );
    s1a.connectFuel( f1 );
    s1a.connectTerrain( t0 );
    s1a.connectWind( w0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 41.14563625, s1a.slopeK(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510, s1a.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510, s1a.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1a.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, s1a.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486, s1a.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486, s1a.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.196510, s1a.flameLengthAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.196510, s1a.flameLengthAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, s1a.lengthToWidthRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1a.eccentricity(), Delta7 );

    // Custom constructor 1
    Sem::SurfaceFireSpread s1b( f1, t0, w0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 41.14563625, s1b.slopeK(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510, s1b.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510, s1b.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1b.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, s1b.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486, s1b.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486, s1b.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.196510, s1b.flameLengthAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.196510, s1b.flameLengthAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, s1b.lengthToWidthRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1b.eccentricity(), Delta7 );

    // Custom constructor 2
    Sem::SurfaceFireSpread s1c( f1, t1, w1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 41.14563625, s1c.slopeK(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 333.276754, s1c.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.170839, s1c.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1c.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, s1c.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 532.764079, s1c.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 14.660169, s1c.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.080134, s1c.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.547521, s1c.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.1, s1c.lengthToWidthRatio(), Delta1 );

    // If we change the fuel moisture ...
    m1->setDead1h( 0.02 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, m1->dead1h(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, f1->fuelPtr(0)->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1056.812473, f1->reactionIntensity(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 115.947426, f1->heatPerUnitArea(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6.856957, f1->spreadRate(), Delta6 );
    // ... the fire behavior should change
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 435.910307, s1c.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.995026, s1c.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, s1c.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, s1c.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 842.377965, s1c.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 23.179873, s1c.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.975754, s1c.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.910573, s1c.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.1, s1c.lengthToWidthRatio(), Delta1 );

    delete m1;
    delete f1;
    delete w0;
    delete t0;
    delete w1;
    delete t1;
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireSpreadTest::testEquality()
{
std::cerr << "SurfaceFireSpreadTest::testEquality()" << std::endl;
    // Set up
    Sem::SurfaceFireMoistureTimeLag* m1 = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );
    Sem::SurfaceFireFuelModel* f1 = Sem::createFuelModel( 1, m1 );
    Sem::SurfaceFireTerrain* t0 = new Sem::SurfaceFireTerrain( 0., 0. );
    Sem::SurfaceFireWind* w0 = new Sem::SurfaceFireWind( 0., 0. );

    Sem::SurfaceFireSpread p1;
    Sem::SurfaceFireSpread p2( f1, t0, w0 );
    Sem::SurfaceFireSpread p3( p1 );
    Sem::SurfaceFireSpread p4 = p2;

    // Test
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireSpreadTest::testSignals()
{
std::cerr << "SurfaceFireSpreadTest::testSignals()" << std::endl;
    // Set up
    Sem::SurfaceFireMoistureTimeLag* m1 = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );
    Sem::SurfaceFireMoistureTimeLag* m2 = 
        new Sem::SurfaceFireMoistureTimeLag( 0.06, 0.08, 0.10, 0.12, 1.5, 2.0 );
    Sem::SurfaceFireFuelModel* f1 = Sem::createFuelModel( 1, m1 );
    Sem::SurfaceFireFuelModel* f124 = Sem::createFuelModel( 124, m1 );
    Sem::SurfaceFireTerrain* t0 = new Sem::SurfaceFireTerrain( 0., 0. );
    Sem::SurfaceFireTerrain* t1 = new Sem::SurfaceFireTerrain( 100., 180. );
    Sem::SurfaceFireWind* w0 = new Sem::SurfaceFireWind( 0., 0. );
    Sem::SurfaceFireWind* w1 = new Sem::SurfaceFireWind( 5., 180. );

    // Create a surface fire
    Sem::SurfaceFireSpread sf;
    CPPUNIT_ASSERT_EQUAL( 0, (int) sf.connectedFuel() );
    CPPUNIT_ASSERT_EQUAL( 0, (int) sf.connectedTerrain() );
    CPPUNIT_ASSERT_EQUAL( 0, (int) sf.connectedWind() );
    sf.connectFuel( f1 );
    sf.connectTerrain( t0 );
    sf.connectWind( w0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 95.913814,  f1->heatPerUnitArea(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 874.214454, f1->reactionIntensity(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510,  sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510,  sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,       sf.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,     sf.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486,  sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486,  sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.125847,  sf.scorchHeightAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.125847,  sf.scorchHeightAtBack(), Delta6 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 314.550612, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 314.550612, sf.distanceAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 629.101225, sf.fireLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 629.101225, sf.fireWidth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1976.379787,sf.firePerimeter(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 7.135806,   sf.fireAcres(), Delta6 );

    // Change terrain and wind instances
    sf.connectTerrain( t1 );
    sf.connectWind( w1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 95.913814,  f1->heatPerUnitArea(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 874.214454, f1->reactionIntensity(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 333.276754, sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.170839,   sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,        sf.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,      sf.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 532.764079, sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 14.660169,  sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.080134,   sf.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.547521,   sf.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 59.145711,  sf.scorchHeightAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  1.940705,  sf.scorchHeightAtBack(), Delta6 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 19996.605251, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 550.250339,   sf.distanceAtBack(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20546.855589, sf.fireLength(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6634.195901,  sf.fireWidth(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45538.181433, sf.firePerimeter(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2457.738366,  sf.fireAcres(), Delta4 );

    // Change terrain and wind individual properties
    t1->setAspectCompass( 0.0 );
    t1->setSlopeFraction( 0.0 );
    w1->setMph( 0.0 );
    w1->setSource( 0.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510,  sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.242510,  sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,       sf.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,     sf.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486,  sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.380486,  sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.125847,  sf.scorchHeightAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.125847,  sf.scorchHeightAtBack(), Delta6 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 314.550612, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 314.550612, sf.distanceAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 629.101225, sf.fireLength(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 629.101225, sf.fireWidth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1976.379787,sf.firePerimeter(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 7.135806,   sf.fireAcres(), Delta6 );

    // Change dead fuel moisture content
    m1->setDead1h( 0.02 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6.856957,  sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6.856957,  sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,       sf.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,     sf.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.250774, sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.250774, sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.477214,  sf.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.477214,  sf.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.599654,  sf.scorchHeightAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.599654,  sf.scorchHeightAtBack(), Delta6 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 411.417395, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 411.417395, sf.distanceAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 822.834790, sf.fireLength(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 822.834790, sf.fireWidth(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2585.011733,sf.firePerimeter(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 12.207515,  sf.fireAcres(), Delta6 );

    // Upslope wind
    m1->setDead1h( 0.04 );
    t1->setSlopeFraction( 1.0 );
    t1->setAspectCompass( 180.0 );
    w1->setMph( 5.0 );
    w1->setSource( 180.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 333.276754, sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.170839,   sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,        sf.spreadDirectionAtHead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,      sf.spreadDirectionAtBack(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 532.764079, sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 14.660169,  sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.080134,   sf.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.547521,   sf.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 59.145711,  sf.scorchHeightAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  1.940705,  sf.scorchHeightAtBack(), Delta6 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 19996.605251, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 550.250339,   sf.distanceAtBack(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20546.855589, sf.fireLength(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6634.195901,  sf.fireWidth(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45538.181433, sf.firePerimeter(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2457.738366,  sf.fireAcres(), Delta4 );

    // Downslope wind
    w1->setMph( 10.0 );
    w1->setSource( 0.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 261.590700, sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8.513749,   sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0,      sf.spreadDirectionAtHead(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0,        sf.spreadDirectionAtBack(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 418.169364, sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.609769,  sf.firelineIntAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 7.228273,   sf.flameLengthAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.495491,   sf.flameLengthAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 30.365554,  sf.scorchHeightAtHead(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  0.660527,  sf.scorchHeightAtBack(), Delta5 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 15695.442010, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 510.824947,   sf.distanceAtBack(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 16206.266957, sf.fireLength(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5663.081611,  sf.fireWidth(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 36377.320195, sf.firePerimeter(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1654.770605,  sf.fireAcres(), Delta4 );

    // Cross slope wind
    w1->setSource( 90.0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 379.597921, sf.spreadRateAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.527781,   sf.spreadRateAtBack(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 294.558,    sf.spreadDirectionAtHead(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 114.558,    sf.spreadDirectionAtBack(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 606.811408, sf.firelineIntAtHead(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.230763,  sf.firelineIntAtBack(), Delta5 );

    // Fire behavior at an arbitrary compass direction
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.954089,  sf.spreadRateAtCompass(45.), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 22.306492,  sf.firelineIntAtCompass(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.877115,   sf.flameLengthAtCompass(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.170522,   sf.scorchHeightAtCompass(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 45.0,       sf.spreadDirectionAtCompass(), Delta5 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 22775.875250, sf.distanceAtHead(60.), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 571.666852,   sf.distanceAtBack(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 23347.542102, sf.fireLength(), Delta4 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 7216.706425,  sf.fireWidth(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 51411.590808, sf.firePerimeter(), Delta3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3037.961002,  sf.fireAcres(), Delta4 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireSpreadTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireSpreadAscii.dat";
    m_binaryFile = "./data/SurfaceFireSpreadBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireSpreadTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireSpreadTest.cpp
//------------------------------------------------------------------------------

