//------------------------------------------------------------------------------
/*! \file SurfaceFireWindTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireWind.
 */

#include "Handler.h"
#include "SurfaceFireWind.h"
#include "SurfaceFireWindTest.h"
#include <QString>
#include <iostream>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireWindTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireWindTest::Delta1 = 0.1;    
const double SurfaceFireWindTest::Delta2 = 0.01;    
const double SurfaceFireWindTest::Delta3 = 0.001;    
const double SurfaceFireWindTest::Delta4 = 0.0001;    
const double SurfaceFireWindTest::Delta5 = 0.00001;    
const double SurfaceFireWindTest::Delta6 = 0.000001;    
const double SurfaceFireWindTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireWindTest::testConstructors()
{
std::cerr << "SurfaceFireWindTest::testConstructors()" << std::endl;
    // Default constructor
    Sem::SurfaceFireWind w1;
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.fpm(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, w1.source(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 180.0, w1.bearing(), Delta7 );

    // Custom constructor
    Sem::SurfaceFireWind w2( 5.0, 270. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.0, w2.mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 440.0, w2.fpm(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270.0, w2.source(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 90.0, w2.bearing(), Delta7 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireWindTest::testEquality()
{
std::cerr << "SurfaceFireWindTest::testEquality()" << std::endl;
    Sem::SurfaceFireWind p1;
    Sem::SurfaceFireWind p2( 5.0, 90. );
    Sem::SurfaceFireWind p3( p1 );
    Sem::SurfaceFireWind p4 = p2;
    CPPUNIT_ASSERT( p1 == p1 );
    CPPUNIT_ASSERT( p1 != p2 );
    CPPUNIT_ASSERT( p1 == p3 );
    CPPUNIT_ASSERT( p1 != p4 );

    CPPUNIT_ASSERT( p2 != p1 );
    CPPUNIT_ASSERT( p2 == p2 );
    CPPUNIT_ASSERT( p2 != p3 );
    CPPUNIT_ASSERT( p2 == p4 );

    CPPUNIT_ASSERT( p3 == p1 );
    CPPUNIT_ASSERT( p3 != p2 );
    CPPUNIT_ASSERT( p3 == p3 );
    CPPUNIT_ASSERT( p3 != p4 );

    CPPUNIT_ASSERT( p4 != p1 );
    CPPUNIT_ASSERT( p4 == p2 );
    CPPUNIT_ASSERT( p4 != p3 );
    CPPUNIT_ASSERT( p4 == p4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireWindTest::testUpdates()
{
std::cerr << "SurfaceFireWindTest::testUpdates()" << std::endl;
    Sem::SurfaceFireWind b1;

    b1.setMph( 10. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.0, b1.mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 880.0, b1.fpm(), Delta7 );

    b1.setFpm( 440. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 5.0, b1.mph(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 440.0, b1.fpm(), Delta7 );

    b1.setBearing( 123. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 123., b1.bearing(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 303., b1.source(), Delta7 );

    b1.setSource( 450. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 270., b1.bearing(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 90., b1.source(), Delta7 );

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireWindTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireWindAscii.dat";
    m_binaryFile = "./data/SurfaceFireWindBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireWindTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireWindTest.cpp
//------------------------------------------------------------------------------

