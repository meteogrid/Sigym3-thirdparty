//------------------------------------------------------------------------------
/*! \file LoggerHandlerTest.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::LoggerHandler.
 */

#ifndef _LOGGERHANDLERTEST_H_INCLUDED_
#define _LOGGERHANDLERTEST_H_INCLUDED_

#include <cppunit/extensions/HelperMacros.h>

class LoggerHandlerTest : public CppUnit::TestFixture
{
    
public:
    void setUp();
    void tearDown();
    void testUsage();

    // Create the LoggerHandler test suite
    CPPUNIT_TEST_SUITE( LoggerHandlerTest );
    CPPUNIT_TEST( testUsage );
    CPPUNIT_TEST_SUITE_END();

private:
    char *m_asciiFile;
};

#endif // _LOGGERHANDLERTEST_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of LoggerHandlerTest.h
//------------------------------------------------------------------------------

