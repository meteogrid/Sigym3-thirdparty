//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelModelTest.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief CppUnit tests for Sem::SurfaceFireFuel.
 */

// Custom header files
#include "Handler.h"
#include "SurfaceFireFuelModel.h"
#include "SurfaceFireFuelModelTest.h"
#include "SurfaceFireFuelModelFactory.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireParticle.h"
#include "SurfaceFireSpread.h"
#include "SurfaceFireTerrain.h"
#include "SurfaceFireWind.h"

// QT header files
#include <QString>

// Standard header files
#include <iostream>
#include <string.h>

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( SurfaceFireFuelModelTest );

// Non-integral static data members must be initialized outside the class
const double SurfaceFireFuelModelTest::Delta1 = 0.1;    
const double SurfaceFireFuelModelTest::Delta2 = 0.01;    
const double SurfaceFireFuelModelTest::Delta3 = 0.001;    
const double SurfaceFireFuelModelTest::Delta4 = 0.0001;    
const double SurfaceFireFuelModelTest::Delta5 = 0.00001;    
const double SurfaceFireFuelModelTest::Delta6 = 0.000001;    
const double SurfaceFireFuelModelTest::Delta7 = 0.0000001;    

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::testBehavior()
{
std::cerr << "SurfaceFireFuelModelTest::testBehavior()" << std::endl;
    // Use this moisture, terrain, wind, and fire
    Sem::SurfaceFireMoistureTimeLag* m1 = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );
    Sem::SurfaceFireTerrain* t1 = new Sem::SurfaceFireTerrain( 100., 180. );
    Sem::SurfaceFireWind*    w1 = new Sem::SurfaceFireWind( 5., 180. );
    Sem::SurfaceFireSpread*  sf = new Sem::SurfaceFireSpread();
    sf->connectTerrain( t1 );
    sf->connectWind( w1 );

    // 001
    Sem::SurfaceFireFuelModel* f001 = Sem::createFuelModel( 1, m1 );
    sf->connectFuel( f001 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 333.276754, sf->spreadRateAtHead(), Delta6 );
    delete f001;

    // 002
    Sem::SurfaceFireFuelModel* f002 = Sem::createFuelModel( 2, m1 );
    sf->connectFuel( f002 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 113.084807, sf->spreadRateAtHead(), Delta6 );
    delete f002;

    // 003
    Sem::SurfaceFireFuelModel* f003 = Sem::createFuelModel( 3, m1 );
    sf->connectFuel( f003 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 370.214365, sf->spreadRateAtHead(), Delta6 );
    delete f003;

    // 004
    Sem::SurfaceFireFuelModel* f004 = Sem::createFuelModel( 4, m1 );
    sf->connectFuel( f004 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 168.517024, sf->spreadRateAtHead(), Delta6 );
    delete f004;

    // 005
    Sem::SurfaceFireFuelModel* f005 = Sem::createFuelModel( 5, m1 );
    sf->connectFuel( f005 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  20.835685, sf->spreadRateAtHead(), Delta6 );
    delete f005;

    // 006
    Sem::SurfaceFireFuelModel* f006 = Sem::createFuelModel( 6, m1 );
    sf->connectFuel( f006 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 110.079372, sf->spreadRateAtHead(), Delta6 );
    delete f006;

    // 007
    Sem::SurfaceFireFuelModel* f007 = Sem::createFuelModel( 7, m1 );
    sf->connectFuel( f007 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  68.139493, sf->spreadRateAtHead(), Delta6 );
    delete f007;

    // 008
    Sem::SurfaceFireFuelModel* f008 = Sem::createFuelModel( 8, m1 );
    sf->connectFuel( f008 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   7.134843, sf->spreadRateAtHead(), Delta6 );
    delete f008;

    // 009
    Sem::SurfaceFireFuelModel* f009 = Sem::createFuelModel( 9, m1 );
    sf->connectFuel( f009 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  29.389206, sf->spreadRateAtHead(), Delta6 );
    delete f009;

    // 010
    Sem::SurfaceFireFuelModel* f010 = Sem::createFuelModel( 10, m1 );
    sf->connectFuel( f010 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 20.4751584, sf->spreadRateAtHead(), Delta6 );
    delete f010;

    // 011
    Sem::SurfaceFireFuelModel* f011 = Sem::createFuelModel( 11, m1 );
    sf->connectFuel( f011 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  20.398794, sf->spreadRateAtHead(), Delta6 );
    delete f011;

    // 012
    Sem::SurfaceFireFuelModel* f012 = Sem::createFuelModel( 12, m1 );
    sf->connectFuel( f012 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  46.327007, sf->spreadRateAtHead(), Delta6 );
    delete f012;

    // 013
    Sem::SurfaceFireFuelModel* f013 = Sem::createFuelModel( 13, m1 );
    sf->connectFuel( f013 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  57.554923, sf->spreadRateAtHead(), Delta6 );
    delete f013;

    // 101
    Sem::SurfaceFireFuelModel* f101 = Sem::createFuelModel( 101, m1 );
    sf->connectFuel( f101 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  6.174512,  sf->spreadRateAtHead(), Delta6 );
    delete f101;

    // 102
    Sem::SurfaceFireFuelModel* f102 = Sem::createFuelModel( 102, m1 );
    sf->connectFuel( f102 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  3.123186,  sf->spreadRateAtHead(), Delta7 );
    delete f102;

    // 103
    Sem::SurfaceFireFuelModel* f103 = Sem::createFuelModel( 103, m1 );
    sf->connectFuel( f103 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  41.721256, sf->spreadRateAtHead(), Delta6 );
    delete f103;

    // 104
    Sem::SurfaceFireFuelModel* f104 = Sem::createFuelModel( 104, m1 );
    sf->connectFuel( f104 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  18.935258, sf->spreadRateAtHead(), Delta7 );
    delete f104;

    // 105
    Sem::SurfaceFireFuelModel* f105 = Sem::createFuelModel( 105, m1 );
    sf->connectFuel( f105 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  59.029355, sf->spreadRateAtHead(), Delta6 );
    delete f105;

    // 106
    Sem::SurfaceFireFuelModel* f106 = Sem::createFuelModel( 106, m1 );
    sf->connectFuel( f106 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  24.723307, sf->spreadRateAtHead(), Delta6 );
    delete f106;

    // 107
    Sem::SurfaceFireFuelModel* f107 = Sem::createFuelModel( 107, m1 );
    sf->connectFuel( f107 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  93.124178, sf->spreadRateAtHead(), Delta6 );
    delete f107;

    // 108
    Sem::SurfaceFireFuelModel* f108 = Sem::createFuelModel( 108, m1 );
    sf->connectFuel( f108 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  82.118855, sf->spreadRateAtHead(), Delta4 );
    delete f108;

    // 109
    Sem::SurfaceFireFuelModel* f109 = Sem::createFuelModel( 109, m1 );
    sf->connectFuel( f109 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 161.253845, sf->spreadRateAtHead(), Delta6 );
    delete f109;

    // 121
    Sem::SurfaceFireFuelModel* f121 = Sem::createFuelModel( 121, m1 );
    sf->connectFuel( f121 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.786004,   sf->spreadRateAtHead(), Delta5 );
    delete f121;

    // 122
    Sem::SurfaceFireFuelModel* f122 = Sem::createFuelModel( 122, m1 );
    sf->connectFuel( f122 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 9.157790,   sf->spreadRateAtHead(), Delta6 );
    delete f122;

    // 123
    Sem::SurfaceFireFuelModel* f123 = Sem::createFuelModel( 123, m1 );
    sf->connectFuel( f123 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 11.778337,  sf->spreadRateAtHead(), Delta7 );
    delete f123;

    // 124
    Sem::SurfaceFireFuelModel* f124 = Sem::createFuelModel( 124, m1 );
    sf->connectFuel( f124 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.302688,  sf->spreadRateAtHead(), Delta7 );
    delete f124;

    // 141
    Sem::SurfaceFireFuelModel* f141 = Sem::createFuelModel( 141, m1 );
    sf->connectFuel( f141 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  0.919223,  sf->spreadRateAtHead(), Delta6 );
    delete f141;

    // 142
    Sem::SurfaceFireFuelModel* f142 = Sem::createFuelModel( 142, m1 );
    sf->connectFuel( f142 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  4.639903,  sf->spreadRateAtHead(), Delta6 );
    delete f142;

    // 143
    Sem::SurfaceFireFuelModel* f143 = Sem::createFuelModel( 143, m1 );
    sf->connectFuel( f143 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   7.761775, sf->spreadRateAtHead(), Delta6 );
    delete f143;

    // 144
    Sem::SurfaceFireFuelModel* f144 = Sem::createFuelModel( 144, m1 );
    sf->connectFuel( f144 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  19.998352, sf->spreadRateAtHead(), Delta6 );
    delete f144;

    // 145
    Sem::SurfaceFireFuelModel* f145 = Sem::createFuelModel( 145, m1 );
    sf->connectFuel( f145 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 100.550923, sf->spreadRateAtHead(), Delta6 );
    delete f145;

    // 146
    Sem::SurfaceFireFuelModel* f146 = Sem::createFuelModel( 146, m1 );
    sf->connectFuel( f146 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  44.615402, sf->spreadRateAtHead(), Delta6 );
    delete f146;

    // 147
    Sem::SurfaceFireFuelModel* f147 = Sem::createFuelModel( 147, m1 );
    sf->connectFuel( f147 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  66.988685, sf->spreadRateAtHead(), Delta6 );
    delete f147;

    // 148
    Sem::SurfaceFireFuelModel* f148 = Sem::createFuelModel( 148, m1 );
    sf->connectFuel( f148 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  37.151491, sf->spreadRateAtHead(), Delta4 );
    delete f148;

    // 149
    Sem::SurfaceFireFuelModel* f149 = Sem::createFuelModel( 149, m1 );
    sf->connectFuel( f149 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  73.631191, sf->spreadRateAtHead(), Delta6 );
    delete f149;

    // 161
    Sem::SurfaceFireFuelModel* f161 = Sem::createFuelModel( 161, m1 );
    sf->connectFuel( f161 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  0.995703,  sf->spreadRateAtHead(), Delta6 );
    delete f161;

    // 162
    Sem::SurfaceFireFuelModel* f162 = Sem::createFuelModel( 162, m1 );
    sf->connectFuel( f162 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 32.085410,  sf->spreadRateAtHead(), Delta6 );
    delete f162;

    // 163
    Sem::SurfaceFireFuelModel* f163 = Sem::createFuelModel( 163, m1 );
    sf->connectFuel( f163 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  46.427557, sf->spreadRateAtHead(), Delta6 );
    delete f163;

    // 164
    Sem::SurfaceFireFuelModel* f164 = Sem::createFuelModel( 164, m1 );
    sf->connectFuel( f164 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  27.914839, sf->spreadRateAtHead(), Delta6 );
    delete f164;

    // 165
    Sem::SurfaceFireFuelModel* f165 = Sem::createFuelModel( 165, m1 );
    sf->connectFuel( f165 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  21.843083, sf->spreadRateAtHead(), Delta6 );
    delete f165;

    // 181
    Sem::SurfaceFireFuelModel* f181 = Sem::createFuelModel( 181, m1 );
    sf->connectFuel( f181 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  1.283855,  sf->spreadRateAtHead(), Delta6 );
    delete f181;

    // 182
    Sem::SurfaceFireFuelModel* f182 = Sem::createFuelModel( 182, m1 );
    sf->connectFuel( f182 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  3.260956,  sf->spreadRateAtHead(), Delta6 );
    delete f182;

    // 183
    Sem::SurfaceFireFuelModel* f183 = Sem::createFuelModel( 183, m1 );
    sf->connectFuel( f183 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   4.398674, sf->spreadRateAtHead(), Delta6 );
    delete f183;

    // 184
    Sem::SurfaceFireFuelModel* f184 = Sem::createFuelModel( 184, m1 );
    sf->connectFuel( f184 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(   8.572100, sf->spreadRateAtHead(), Delta6 );
    delete f184;

    // 185
    Sem::SurfaceFireFuelModel* f185 = Sem::createFuelModel( 185, m1 );
    sf->connectFuel( f185 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  15.729396, sf->spreadRateAtHead(), Delta6 );
    delete f185;

    // 186
    Sem::SurfaceFireFuelModel* f186 = Sem::createFuelModel( 186, m1 );
    sf->connectFuel( f186 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  20.999072, sf->spreadRateAtHead(), Delta6 );
    delete f186;

    // 187
    Sem::SurfaceFireFuelModel* f187 = Sem::createFuelModel( 187, m1 );
    sf->connectFuel( f187 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  10.257380, sf->spreadRateAtHead(), Delta6 );
    delete f187;

    // 188
    Sem::SurfaceFireFuelModel* f188 = Sem::createFuelModel( 188, m1 );
    sf->connectFuel( f188 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  21.788104, sf->spreadRateAtHead(), Delta4 );
    delete f188;

    // 189
    Sem::SurfaceFireFuelModel* f189 = Sem::createFuelModel( 189, m1 );
    sf->connectFuel( f189 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  32.392306, sf->spreadRateAtHead(), Delta6 );
    delete f189;

    // 201
    Sem::SurfaceFireFuelModel* f201 = Sem::createFuelModel( 201, m1 );
    sf->connectFuel( f201 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 22.223557,  sf->spreadRateAtHead(), Delta6 );
    delete f201;

    // 202
    Sem::SurfaceFireFuelModel* f202 = Sem::createFuelModel( 202, m1 );
    sf->connectFuel( f202 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 53.636436,  sf->spreadRateAtHead(), Delta6 );
    delete f202;

    // 203
    Sem::SurfaceFireFuelModel* f203 = Sem::createFuelModel( 203, m1 );
    sf->connectFuel( f203 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL(  96.367544, sf->spreadRateAtHead(), Delta6 );
    delete f203;

    // 204
    Sem::SurfaceFireFuelModel* f204 = Sem::createFuelModel( 204, m1 );
    sf->connectFuel( f204 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 183.172515, sf->spreadRateAtHead(), Delta6 );
    delete f204;

    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::testConstructors()
{
std::cerr << "SurfaceFireFuelModelTest::testConstructors()" << std::endl;
    // Use this moisture scenario
    Sem::SurfaceFireMoistureTimeLag* m1 = new Sem::SurfaceFireMoistureTimeLag(
        0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );
    // Factory constructor Model 1
    Sem::SurfaceFireFuelModel* p001 = Sem::createFuelModel( 1, m1 );
    CPPUNIT_ASSERT_EQUAL( 1, p001->id() );
    CPPUNIT_ASSERT( strcmp( "1", p001->name().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT( strcmp( "Short Grass (1 ft)", p001->description().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT_EQUAL( 1, p001->fuels() );

    Sem::SurfaceFireParticleInterface* p0 = p001->fuelPtr( 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0340, p0->loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3500., p0->savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p0->moistureDead(), Delta7 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.12, p001->mextDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, p001->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.71875, p001->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p001->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.71875, p001->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.0, p001->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p001->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3500., p001->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0, p001->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3500., p001->sigma(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0010625, p001->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0340, p001->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0041932, p001->optimumPackingRatio(), Delta7 );
    //CPPUNIT_ASSERT_DOUBLES_EQUAL( 41.14563625, p001->slopeK(), Delta7 );

    // Factory constructor Model 4
    Sem::SurfaceFireFuelModel* p004 = Sem::createFuelModel( 4, m1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.20, p004->mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 4, p004->id() );
    CPPUNIT_ASSERT( strcmp( "4", p004->name().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT( strcmp( "Chaparral (6 ft)", p004->description().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT_EQUAL( 4, p004->fuels() );

    p0 = p004->fuelPtr( 0 );
    Sem::SurfaceFireParticleInterface* p1 = p004->fuelPtr( 1 );
    Sem::SurfaceFireParticleInterface* p2 = p004->fuelPtr( 2 );
    Sem::SurfaceFireParticleInterface* p3 = p004->fuelPtr( 3 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, p3->moistureLive(), Delta7 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 6.0, p004->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 10.78125, p004->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 15.08800, p004->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 25.86925, p004->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.41675928, p004->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.58324072, p004->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1500.0, p004->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1910.18711900, p004->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1739.237831, p004->sigma(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.003833333, p004->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.122666667, p004->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0074346, p004->optimumPackingRatio(), Delta7 );

    // Factory constructor Model 108
    Sem::SurfaceFireFuelModel* p108 = Sem::createFuelModel( "gr8" );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.30, p108->mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 108, p108->id() );
    CPPUNIT_ASSERT( strcmp( "gr8", p108->name().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT( strcmp( "High load, very coarse, humid climate grass",
        p108->description().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT_EQUAL( 3, p108->fuels() );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.0, p108->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 13.6162764, p108->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.232495408, p108->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 14.84877181, p108->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.083003189, p108->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.916996811, p108->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.003156566, p108->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.101010101, p108->bulkDensity(), Delta7 );

    // Factory constructor Model 124
    Sem::SurfaceFireFuelModel* p124 = Sem::createFuelModel( "gs4" );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.40, p124->mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 124, p124->id() );
    CPPUNIT_ASSERT( strcmp( "gs4", p124->name().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT( strcmp( "High load, humid climate grass-shrub",
        p124->description().toLatin1().constData() ) == 0 );
    CPPUNIT_ASSERT_EQUAL( 5, p124->fuels() );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.1, p124->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 24.1046832, p124->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.958247245, p124->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 29.06293045, p124->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.17060383, p124->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.82939617, p124->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1782.462106, p124->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1600., p124->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1631.128734, p124->sigma(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, p124->heatOfCombustionDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, p124->heatOfCombustionLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, p124->siEffectiveDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, p124->siEffectiveLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.105601469, p124->loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.482093664, p124->loadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.081670072, p124->netLoadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.455337466, p124->netLoadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.008745463, p124->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.279854825, p124->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0078357, p124->optimumPackingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.2354198, p124->residenceTime(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, p124->mineralDampingCoefficientDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, p124->mineralDampingCoefficientLive(), Delta7 );

    delete m1;
    delete p001;
    delete p004;
    delete p108;
    delete p124;
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::testEquality()
{
std::cerr << "SurfaceFireFuelModelTest::testEquality()" << std::endl;
    Sem::SurfaceFireFuelModel* b1 = Sem::createFuelModel( 1 );
    Sem::SurfaceFireFuelModel* b2 = Sem::createFuelModel( 124 );
    Sem::SurfaceFireFuelModel b3( *b1 );
    Sem::SurfaceFireFuelModel b4 = *b2;
    CPPUNIT_ASSERT( *b1 == *b1 );
    CPPUNIT_ASSERT( *b1 != *b2 );
    CPPUNIT_ASSERT( *b1 == b3 );
    CPPUNIT_ASSERT( *b1 != b4 );

    CPPUNIT_ASSERT( *b2 != *b1 );
    CPPUNIT_ASSERT( *b2 == *b2 );
    CPPUNIT_ASSERT( *b2 != b3 );
    CPPUNIT_ASSERT( *b2 == b4 );

    CPPUNIT_ASSERT( b3 == *b1 );
    CPPUNIT_ASSERT( b3 != *b2 );
    CPPUNIT_ASSERT( b3 == b3 );
    CPPUNIT_ASSERT( b3 != b4 );

    CPPUNIT_ASSERT( b4 != *b1 );
    CPPUNIT_ASSERT( b4 == *b2 );
    CPPUNIT_ASSERT( b4 != b3 );
    CPPUNIT_ASSERT( b4 == b4 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::testSignals()
{
std::cerr << "SurfaceFireFuelModelTest::testSignals()" << std::endl;
    // Create dynamic model 124, "gs4" (High load, humid climate grass-shrub)
    Sem::SurfaceFireFuelModel* fm124 = Sem::createFuelModel( "gs4" );

    // Get the particle pointers
    Sem::SurfaceFireParticleInterface* p0 = fm124->fuelPtr( 0 );
    Sem::SurfaceFireParticleInterface* p1 = fm124->fuelPtr( 1 );
    Sem::SurfaceFireParticleInterface* p2 = fm124->fuelPtr( 2 );
    Sem::SurfaceFireParticleInterface* p3 = fm124->fuelPtr( 3 );
    Sem::SurfaceFireParticleInterface* p4 = fm124->fuelPtr( 4 );

    // Validate properties
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.10, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3.00, p4->moistureLive(), Delta7 );

    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.40, fm124->mextDead(), Delta7 );
    CPPUNIT_ASSERT_EQUAL( 5, fm124->fuels() );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.1, fm124->depth(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 24.1046832, fm124->surfaceAreaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 4.958247245, fm124->surfaceAreaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 29.06293045, fm124->surfaceArea(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.17060383, fm124->surfaceAreaWtgDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.82939617, fm124->surfaceAreaWtgLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1782.462106, fm124->sigmaDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1600., fm124->sigmaLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1631.128734, fm124->sigma(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, fm124->heatOfCombustionDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 8000.0, fm124->heatOfCombustionLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, fm124->siEffectiveDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.01, fm124->siEffectiveLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.105601469, fm124->loadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.482093664, fm124->loadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.081670072, fm124->netLoadDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.455337466, fm124->netLoadLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.008745463, fm124->packingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.279854825, fm124->bulkDensity(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.0078357, fm124->optimumPackingRatio(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.2354198, fm124->residenceTime(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, fm124->mineralDampingCoefficientDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.417396928, fm124->mineralDampingCoefficientLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.113086, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 590.458295, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2508.108050, fm124->reactionIntensity(), Delta1 );

    // Change fuel moisture contents of particles individually ...
    Sem::SurfaceFireMoistureInterface* m1 = new Sem::SurfaceFireMoistureTimeLag(
        0.04, 0.06, 0.08, 0.10, 1.5, 2.5 );
    p0->setMoisture( m1 );
    p1->setMoisture( m1 );
    p2->setMoisture( m1 );
    p3->setMoisture( m1 );
    p4->setMoisture( m1 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.04, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.06, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.08, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.50, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.50, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.193577, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 753.914521, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3202.426143, fm124->reactionIntensity(), Delta1 );

    // Change the moisture object ...
    Sem::SurfaceFireMoistureTimeLag* m2 = new Sem::SurfaceFireMoistureTimeLag(
        0.03, 0.05, 0.07, 0.09, 1.3, 2.3 );
    fm124->connectMoisture( m2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.03, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.222809, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 796.328581, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3382.589664, fm124->reactionIntensity(), Delta1 );

    // Change the moisture object value ...
    m2->setDead1h( 0.02 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.236189, fm124->spreadRate(), Delta6 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 843.379269, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3582.448141, fm124->reactionIntensity(), Delta1 );

    // Change a fuel particle property ...
    dynamic_cast<Sem::SurfaceFireParticle*>(p0)->setSurfaceAreaToVolumeRatio( 2000. );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p0->savr(), Delta7 );
    // ... and the fire behavior should change as well
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.245778, fm124->spreadRate(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 826.672393, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3597.462078, fm124->reactionIntensity(), Delta1 );

    // Remove moisture connection
    fm124->connectMoisture( 0 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.02, p0->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.05, p1->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.07, p2->moistureDead(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 1.30, p3->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2.30, p4->moistureLive(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 2000., p0->savr(), Delta7 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.245778, fm124->spreadRate(), Delta5 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 826.672393, fm124->heatPerUnitArea(), Delta2 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 3597.462078, fm124->reactionIntensity(), Delta1 );

    delete m1;
    delete fm124;
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::testUpdates()
{
std::cerr << "SurfaceFireFuelModelTest::testUpdates()" << std::endl;
    Sem::SurfaceFireFuelModel b1;

    b1.setMextDead( 0.15 );
    CPPUNIT_ASSERT_DOUBLES_EQUAL( 0.15, b1.mextDead(), Delta7 );

    //b1.setName( "MyName" );
    //CPPUNIT_ASSERT( strcmp( "MyName", b1.name().toLatin1().constData() ) == 0 );

    //b1.setDescription( "My Description" );
    //CPPUNIT_ASSERT( strcmp( "My Description",
    //    b1.description().toLatin1().constData() ) == 0 );
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::setUp( void )
{
    m_asciiFile = "./data/SurfaceFireFuelAscii.dat";
    m_binaryFile = "./data/SurfaceFireFuelBinary.dat";
    return;
}

//------------------------------------------------------------------------------
void SurfaceFireFuelModelTest::tearDown( void )
{
    return;
}

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelModelTest.cpp
//------------------------------------------------------------------------------

