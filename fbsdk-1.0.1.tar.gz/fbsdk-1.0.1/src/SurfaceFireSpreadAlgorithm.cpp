//------------------------------------------------------------------------------
/*! \file SurfaceFireSpreadAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief All surface fire spread algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

// Custom header files
#include "CompassAlgorithm.h"
#include "SurfaceFireSpreadAlgorithm.h"
//#include "SurfaceFuelAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Converts from arc radians to arc degrees.
  
    \param[in] degrees Arc degrees.
  
    \return Equivalent arc in radians (1 radian = \f$ \frac {PI}{180.} \f$).
 */

double Sem::SurfaceFireSpreadAlgorithm::degreesToRadians( double degrees )
{
    return( degrees * 0.017453293 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire ellipse eccentricity.

    \param[in] lwRatio Fire ellipse length-to-width ratio.
  
    \return Surface fire ellipse eccentricity (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::eccentricity( double lwRatio )
{
    return( ( lwRatio > Sem::Smidgen )
          ? ( sqrt( lwRatio * lwRatio - 1.0 ) ) / lwRatio : 1.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the spread rate effective wind factor based upon the
    maximum spread rate and the basic no-wind, no-slope spread rate.
  
    \param[in] ros0   Basic no-wind, no-slope spread rate (ft/min).
    \param[in] rosMax Maximum spread rate (ft/min).
  
    \return Effective wind speed factor (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::effectiveWindFactor(
        double ros0, double rosMax )
{
    return( ( ros0 > Sem::Smidgen ) ? ( ( rosMax / ros0 ) - 1.0 ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire effective wind speed (the equivalent
    amount of wind required to attain the same spread rate as the combined
    amount of wind and slope).

    \param[in] phiEw Effective wind factor (dimensionless).
                 This may be the sum of phiSlope and phiWind, or it may have
                 been mathematically from the ratio of the maximum spread rate
                 to the no-wind, no-slope spread rate.
    \param[in] windB The wind parameter estimated by windParameterB().
    \param[in] windX The wind parameter estimated by windParameterX().
  
    \return Surface fire effective wind speed (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::effectiveWindSpeed(
        double phiEw, double windB, double windX )
{
    return( ( windB > Smidgen && windX > Smidgen && phiEw > Smidgen )
          ? ( pow( ( phiEw * windX ), (1. / windB ) ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire ellipse area from its length and width.
  
    \param[in] length Fire length (ft).
    \param[in] width  Fire width (ft).
  
    \return Surface fire ellipse area (ac).
 */

double Sem::SurfaceFireSpreadAlgorithm::fireAcres( double length, double width )
{
    return( 2.295684e-05 * fireArea( length, width ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire ellipse area from its length and width.
  
    \param[in] length Fire length (ft).
    \param[in] width  Fire width (ft).
  
    \return Surface fire ellipse area (ft<sup>2</sup>).
 */

double Sem::SurfaceFireSpreadAlgorithm::fireArea( double length, double width )
{
    return( M_PI * ( 0.5 * length ) * ( 0.5 * width ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire ellipse length-to-width ratio based upon
    its <i>effective</i> wind speed (i.e., wind plus slope effect).
  
    \param[in] effWindSpeed Effective wind speed (ft/min).
  
    \par Reference:
    \f[ r = 1. + 0.25 \cdot U \f]
    where
    \f$ r \f$ is the fire ellipse length-to-width ratio and
    \f$ U \f$ is the effective wind speed (mi/h).
  
    Since the method requires wind speed in ft/min:
    \f[ r = 1. + 0.002840909 \cdot U_{ft/min} \f]
  
    \return Surface fire ellipse length-to-width ratio (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::fireLengthToWidthRatio(
        double effWindSpeed )
{
    return( 1. + 0.002840909 * effWindSpeed );
    // == 1. + 0.25 * effWindSpeed / 88.0)
}

//------------------------------------------------------------------------------
/*! \brief Reverse calculates fireline intensity from flame length.
  
    \param flameLength Flame length (ft)
  
    \return Fireline (Byram's) intensity (Btu/ft/s).
 */

double Sem::SurfaceFireSpreadAlgorithm::firelineIntensity( double flameLength )
{
    return( ( flameLength < Smidgen )
          ? ( 0.0 )
          : ( pow( ( flameLength / 0.45 ), ( 1. / 0.46 ) ) ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire fireline intensity (also known as
    Byram's intensity).
  
    \param[in] ros   Fire spread rate (ft/min).
    \param[in] rxInt Fire reaction intensity (Btu/ft<sup>2</sup>-min).
    \param[in] tauR Fire residence time (min).
  
    \par Reference:
    \f[ I_{F} = \frac {R \cdot I_{R} \cdot \tau_{r}}{60.} \f]
    where
    - \f$ I_{F} \f$ is the fireline intensity (Btu/ft-s),
    - \f$ R \f$ is the rate of spread (ft/min),
    - \f$ I_{R} \f$ is the reaction intensity (Btu/ft<sup>2</sup>-min), and
    - \f$ \tau_{r} \f$ is the fire residence time (min).
  
    \return Surface fire fireline (Byram's) intensity (Btu/ft-s).
 */

double Sem::SurfaceFireSpreadAlgorithm::firelineIntensity(
        double ros, double rxInt, double tauR )
{
    return( ros * rxInt * tauR / 60. );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire ellipse perimeter
    from its length and width.
  
    \param[in] length Fire length (ft).
    \param[in] width  Fire width (ft).
  
    \return Surface fire ellipse perimeter (ft).
 */

double Sem::SurfaceFireSpreadAlgorithm::firePerimeter(
        double length, double width )
{
    double a = 0.5 * length;
    double b = 0.5 * width;
    double xm = ( ( a + b ) < Smidgen ) ? ( 0. ) : ( ( a - b ) / ( a + b ) );
    double xk = 1. + xm * xm / 4. + xm * xm * xm * xm / 64.;
    double perim = M_PI * ( a + b ) * xk;
    return( perim );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire flame length
    based upon surface fire fireline intensity.
  
    \param firelineInt Fireline intensity (Btu/ft-s).
  
    \par Reference:
    \f[ L_F = 0.45 I_F^{0.46} \f]
    where
    - \f$ L_F \f$ is the maximum flame length (ft) and
    - \f$ I_F \f$ is the fireline intensity (Btu/ft-s).
  
    \return Surface fire flame length (ft).
 */

double Sem::SurfaceFireSpreadAlgorithm::flameLength( double firelineInt )
{
    return( ( firelineInt > Sem::Smidgen )
          ? ( 0.45 * pow( firelineInt, 0.46) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire maximum reliable wind speed
    for predicting fire spread rate.
  
    \param[in] rxInt Fire reaction intensity (Btu/ft<sup>2</sup>-min).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 85, Equation 86,
    and Equation 87:
    \f[ if \frac {U}{I_R} > 0.9, then U = 0.9 \cdot I_R \f]
    where
    - \f$ U \f$ is the effective wind speed (ft/min), and
    - \f$ I_R \f$ is the fire reaction intensity (Btu/ft<sup>2</sup>).
  
    \return Surface fire maximum reliable effective wind speed (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::maximumReliableWindSpeed( double rxInt )
{
    return( 0.9 * rxInt );
}

//------------------------------------------------------------------------------
/*! \brief Converts from arc radians to arc degrees.
  
    \param[in] radians Arc radians (1 radian = \f$ \frac {PI}{180.} \f$).
  
    \return Equivalent arc in degrees.
 */

double Sem::SurfaceFireSpreadAlgorithm::radiansToDegrees( double radians )
{
    return( radians * 57.29577951 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire scorch height.
  
    \param[in] firelineInt  Fireline intensity (Btu/ft-s).
    \param[in] windFpm      Midflame wind speed (ft/min).
    \param[in] tempF        Air temperature (oF).  If omitted, 77 oF is used,
                        which reduces the temperature factor to unity.
    \par Reference:
    \ref vanwagner1973 "Van Wagner (1973)" Equation ??:
    \f[ H_S = \frac {3.94 I_F^{ \left ( 7/6 \right ) } }
    {\left ( 0.107 I_F + U^3 \right ) \left ( 60 - T \right ) } \f]
    where
    - \f$ H_S \f$ is the maximum scorch height (m),
    - \f$ I_F \f$ is the fireline intensity (Kcal/m-s).
    - \f$ U \f$ is the wind speed (m/s), and
    - \f$ T \f$ is the ambient air temperature (oC).
  
    \ref albini1976b "Albini (1976)" rearranged Van Wagner's metric form into
    English units (Equation ??):
    \f[ H_S = \left ( \frac {63}{140-T} \right ) \cdot
    \left ( \frac {I_F^{ \left( 7/6 \right ) } }
    {\left ( I_F + U^3 \right )^{1/2} } \right ) \f]
    where
    - \f$ H_S \f$ is the maximum scorch height (ft),
    - \f$ I_F \f$ is the fireline intensity (Btu/f-s).
    - \f$ U \f$ is the wind speed (mi/h), and
    - \f$ T \f$ is the ambient air temperature (oF).
  
    \return Surface fire scorch height (ft).
 */

double Sem::SurfaceFireSpreadAlgorithm::scorchHeight( double firelineInt,
        double windFpm, double tempF )
{
    double scorch = 0;
    if ( firelineInt > Sem::Smidgen )
    {
        double mph = windFpm / 88.;
        scorch = pow( firelineInt, 1.166667 )
               / sqrt( firelineInt + ( mph * mph * mph ) );
        if ( tempF > 120. )
        {
            tempF = 120.;
        }
        scorch *= ( 63. / ( 140. - tempF ) );
    }
    return( scorch );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire spread rate slope factor.
  
    \param[in] slope Terrain slope (ft vertical rise/ft horizontal distance).
    \param[in] k Bevins slope parameter K.
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 51 and Equation 80:
    \f[\phi_s = k \left(\tan \phi\right)^2\f]
    where
    - \f$ \phi_s \f$ is the slope factor (dimensionless),
    - \f$ \phi \f$ is the slope steepness (degrees),
    - \f$ k = 5.275 \beta^{-0.3} \f$, and
    - \f$ \beta \f$ is the fuel bed packing ratio (dimensionless).
  
    \return Surface fire slope factor (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::slopeFactor( double slope, double k )
{
    return( k * slope * slope );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed fire spread rate slope factor
    parameter K.
  
    \param[in] beta Surface fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 51 and Equation 80:
    \f[\phi_s = 5.275 \beta^{-0.3} \left(\tan \phi\right)^2\f]
    where
    - \f$ \phi_s \f$ is the slope factor (dimensionless),
    - \f$ \phi \f$ is the slope steepness (degrees), and
    - \f$ \beta \f$ is the fuel bed packing ratio (dimensionless).
  
    The equation can be divided into a slope dependent term and a fuel
    dependent term k:
    \f[ \phi_s = k \left(\tan \phi\right)^2 \f]
    where
    - \f$ \phi_s \f$ is the slope factor (dimensionless) and
    - \f$ k = 5.275 \beta^{-0.3} \f$.
  
    \return Surface fuel bed fire spread rate slope factor parameter K (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::slopeParameterK( double beta )
{
    return( ( beta > Sem::Smidgen ) ? ( 5.275 * pow( beta, -0.3 ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire backing spread rate.
  
    \param[in] ros Spread rate at fire head (ft/min).
    \param[in] eccent Fire ellipse eccentricity (see eccentricity() ).
  
    \return Surface fire backing spread rate (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::spreadRateAtBack(
        double ros, double eccent )
{
    return( ros * ( 1. - eccent ) / ( 1. + eccent ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire spread rate
    at a specified compass bearing.
  
    \param[in] degrees  Compass bearing of interest
                    (compass decimal degrees clockwise from north).
    \param[in] headRos  Spread rate at fire head (ft/min).
    \param[in] headDir  Fire heading direction (direction of maximum spread)
                    (compass decimal degrees clockwise from north).
    \param[in] eccent   Fire ellipse eccentricity (see eccentricity() ).
  
    \return Surface fire spread rate at the specified compass bearing (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::spreadRateAtCompass(
            double degrees, double headRos, double headDir, double eccent )
{
    // Angle between fire heading azimuth and requested azimuth.
    double diff = fabs( headDir - degrees );
    if ( diff > 180. )
    {
        diff = 360. - diff;
    }
    double radians = degreesToRadians( diff );

    // Calculate the fire spread rate in this azimuth.
    return( headRos * ( 1. - eccent ) / ( 1. - eccent * cos( radians ) ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire spread rate
    when the wind is blowing up-slope.
  
    \param[in] ros0     No-wind, no-slope fire spread rate (ft/min).
    \param[in] phiWind  The fire spread wind coefficient (see windCoefficient()).
    \param[in] phiSlope The fire spread slope factor (see slopeFactor()).
  
    \return Surface fire spread rate in the up-slope direction (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( double ros0,
        double phiWind, double phiSlope )
{
    return( ros0 * ( 1. + phiWind + phiSlope ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire fire spread rate
    when the wind is blowing up-slope.
  
    \param[in] ros0     No-wind, no-slope fire spread rate (ft/min).
    \param[in] phiEffWind The fire spread effective wind coefficient (sum of
                    the wind and slope coefficients).
  
    \return Surface fire spread rate in the up-slope direction (ft/min).
 */

double Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( double ros0,
        double phiEffWind )
{
    return( ros0 * ( 1. + phiEffWind ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire spread rate in the direction of maximum
    spread when the wind is blowing cross-slope.
  
    The direction of maximum spread depends upon the slope and wind vectors
    and their spread rate coefficients.
  
    \param[in] ros0     No-wind, no-slope fire spread rate (ft/min).
    \param[in] upWind   Direction the wind is blowing
                        (compass decimal degrees clockwise from north).
    \param[in] upSlope  The up-slope direction
                        (compass decimal degrees clockwise from north).
    \param[in] phiWind  The fire spread wind coefficient
                        (see windCoefficient()).
    \param[in] phiSlope The fire spread slope factor (see slopeFactor()).
    \param[out] maxDir  Pointer to double that contains the direction of
                        maximum spread on return
                        (compass decimal degrees clockwise from north).
  
    \return Surface fire spread rate in the direction of maximum spread (ft/min).
    The surface fire direction of maximum spread is returned in \a maxDir.
 */

double Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum(
        double ros0, double upWind, double upSlope,
        double phiWind, double phiSlope, double *maxDir )
{
    // Don't try to simplify the next statement!!
    double splitDeg = ( upSlope <= upWind )
                    ? ( upWind - upSlope )
                    : ( 360. - upSlope + upWind );
    double splitRad = degreesToRadians( splitDeg );
    double slpRate  = ros0 * phiSlope;
    double wndRate  = ros0 * phiWind;
    double x        = slpRate + wndRate * cos( splitRad );
    double y        = wndRate * sin( splitRad );
    double rv       = sqrt( x*x + y*y );
    double rosMax   = ros0 + rv;

    // Recalculate direction of maximum spread in azimuth degrees.
    double al = asin( fabs(y) / rv );
    double a;
    if ( x >= 0. )
    {
        a = (y >= 0.) ? al          : M_PI + M_PI - al;
    }
    else
    {
        a = (y >= 0.) ? (M_PI - al) : (M_PI + al);
    }
    splitDeg = radiansToDegrees( a );
    double dirMax = Sem::CompassAlgorithm::constrain( upSlope + splitDeg );
    *maxDir = dirMax;
    return( rosMax );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fire spread rate wind coefficient.
  
    There are two overloaded versions of this method.  This version uses a
    literal translation of Rothermel's Equation 47, which may result in
    numerous unnecessary recalculations within a program.  It requires six
    arguments:
  
    \param[in] u Wind velocity at midflame height (ft/min).
    \param[in] b Rothermel's wind coefficient parameter B (dimensionless)
    as returned by windParameterB().
    \param[in] c Rothermel's wind coefficient parameter C (dimensionless)
    as returned by windParameterC().
    \param[in] e Rothermel's wind coefficient parameter E (dimensionless)
    as returned by windParameterE().
    \param[in] beta Fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
    \param[in] betaOpt Fuel bed optimum packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 47 and Equation 79:
    \f[\phi_w = C \cdot U^B \left(\frac{\beta}{\beta_{op}}\right)^{-E}\f]
    where
    - \f$ \phi_w \f$ is the fire spread rate wind coefficient (dimensionless),
    - \f$ U \f$ is the midflame wind speed (ft/min),
    - \f$ B \f$ is Rothermel's wind coefficient parameter B,
    - \f$ C \f$ is Rothermel's wind coefficient parameter C,
    - \f$ E \f$ is Rothermel's wind coefficient parameter E,
    - \f$ \beta \f$ is the fuel bed packing ratio (dimensionless), and
    - \f$ \beta_{op} \f$ is the fuel bed optimum packing ratio (dimensionless).
  
    \return Surface fire spread rate wind coefficient (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windCoefficient(
        double u, double b, double c, double e, double beta, double betaOpt )
{
    return( ( betaOpt > Sem::Smidgen && u > Sem::Smidgen )
          ? ( c * pow( u, b ) * pow( ( beta / betaOpt ), -e ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the fire spread rate wind coefficient.
  
    There are two overloaded versions of this method.  This version uses an
    optimization to reduce computation time.  If fuel bed load and depth
    doesn't change, it is more efficient to call windParameterB() and
    windParameterK() to determine the invariant intermediates, and pass
    them to the 3 argument form of this method.
  
    \param[in] u Wind velocity at midflame height (ft/min).
    \param[in] b Rothermel's wind coefficient parameter B (dimensionless).
    \param[in] k Bevins' wind coefficient parameter K (dimensionless).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 47 and Equation 79:
    \f[ \phi_w = K \cdot U^B \f]
    where
    - \f$ \phi_w \f$ is the fire spread rate wind coefficient (dimensionless),
    - \f$ U \f$ is the midflame wind speed (ft/min),
    - \f$ B \f$ is Rothermel's wind coefficient parameter B,
    - \f$ K = C \left(\frac{\beta}{\beta_{op}}\right)^{-E} \f$,
    - \f$ C \f$ is Rothermel's wind coefficient parameter C,
    - \f$ E \f$ is Rothermel's wind coefficient parameter E,
    - \f$ \beta \f$ is the fuel bed packing ratio (dimensionless), and
    - \f$ \beta_{op} \f$ is the fuel bed optimum packing ratio (dimensionless).
  
    \return Surface fire spread rate wind coefficient (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windCoefficient( double u, double b, double k )
{
    return( ( u > Sem::Smidgen ) ? ( k * pow( u, b ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed wind coefficient parameter B.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 49:
    \f[B = 0.02526 \sigma^{0.54}\f]
    where
    - \f$ B \f$ is Rothermel's wind coefficient parameter B (dimensionless) and
    - \f$ \sigma \f$ is the fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed wind coefficient parameter B (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windParameterB( double sigma )
{
    return( ( sigma > Smidgen ) ? ( 0.02526 * pow( sigma, 0.54 ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed wind coefficient parameter C.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 48:
    \f[C = 7.47 e^{\left(-0.133 \sigma^{0.55}\right)}\f]
    where
    - \f$ C \f$ is Rothermel's wind coefficient parameter C (dimensionless) and
    - \f$ \sigma \f$ is the fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed wind coefficient parameter C (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windParameterC( double sigma )
{
    return( ( sigma > Sem::Smidgen )
          ? ( 7.47 * exp( -0.133 * pow( sigma, 0.55 ) ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed wind coefficient parameter E.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 50:
    \f[E = 0.715 e^{-0.000359 \sigma}\f]
    where
    - \f$ E \f$ is Rothermel's wind coefficient parameter E (dimensionless) and
    - \f$ \sigma \f$ is the fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed wind coefficient parameter E (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windParameterE( double sigma )
{
    return( ( sigma > Smidgen ) ? ( 0.715 * exp( -0.000359 * sigma ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed wind coefficient parameter K.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] beta Surface fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
    \param[in] betaOpt Surface fuel bed optimum packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 47
    \f[ \phi_w = C \cdot U^B \left(\frac{\beta}{\beta_{op}}\right)^{-E} \f]
    where
    - \f$ \phi_w \f$ is the fire spread rate wind coefficient (dimensionless),
    - \f$ U \f$ is the midflame wind speed (ft/min),
    - \f$ B \f$ is Rothermel's wind coefficient parameter B,
    - \f$ C \f$ is Rothermel's wind coefficient parameter C,
    - \f$ E \f$ is Rothermel's wind coefficient parameter E,
    - \f$ \beta \f$ is the fuel bed packing ratio (dimensionless), and
    - \f$ \beta_{op} \f$ is the fuel bed optimum packing ratio (dimensionless), and
  
    In the interest of reducing the number of computations, Equation 47 can be
    divided into a wind-dependent factor and a fuel-dependent factor:
    \f[ \phi_w = K \cdot U^B \f]
    where
    \f[ K = C \left(\frac{\beta}{\beta_{op}}\right)^{-E} \f]
  
    \return Surface fuel bed wind coefficient parameter K (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windParameterK(
        double sigma, double beta, double betaOpt )
{
    double k = 0.;
    if ( betaOpt > Sem::Smidgen )
    {
        double c = Sem::SurfaceFireSpreadAlgorithm::windParameterC( sigma );
        double e = Sem::SurfaceFireSpreadAlgorithm::windParameterE( sigma );
        k = c * pow( ( beta / betaOpt ), -e );
    }
    return( k );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed wind coefficient parameter X.
    This is an inversion of wind parameter K used to determine
    effective wind speed.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] beta Surface fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
    \param[in] betaOpt Surface fuel bed optimum packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
  
    \return Wind coefficient parameter X (dimensionless).
 */

double Sem::SurfaceFireSpreadAlgorithm::windParameterX(
        double sigma, double beta, double betaOpt )
{
    double x = 0.;
    if ( betaOpt > Sem::Smidgen && sigma > Sem::Smidgen )
    {
        double c = Sem::SurfaceFireSpreadAlgorithm::windParameterC( sigma );
        double e = Sem::SurfaceFireSpreadAlgorithm::windParameterE( sigma );
        if ( c > Sem::Smidgen )
        {
            x = pow( ( beta / betaOpt ), e ) / c;
        }
    }
    return( x );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireSpreadAlgorithm.cpp
//------------------------------------------------------------------------------

