//------------------------------------------------------------------------------
/*! \file SafetyAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire safety zone algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

// Custom header files
#include "SafetyAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Calculates the fire safety zone for personnel and equipment.
  
        This is roughly the distance at which the heat flux drops to 7 kW/m2.
  
    \param separationDistance   Separation distance (ft)
    \param numberOfPeople  Number of people to be sheltered in the safety zone.
    \param areaPerPerson Mean area required per person within the safety zone (ft2).
    \param numberOfEquipment Number of pieces of heavy equipment
                            to be sheltered in the safety zone.
    \param areaPerEquipment  Mean area occupied by each piece of heavy equipment (ft2).
  
    \return Radius of a cleared safety zone within which people and
            equipment are exposed to less than 7 kW/m2 heat flux.
 */

double Sem::SafetyAlgorithm::safetyZoneRadius(
            double separationDistance,
            double numberOfPeople,
            double areaPerPerson,
            double numberOfEquipment,
            double areaPerEquipment )
{
    // Space needed by firefighters and equipment in core of safety zone
    double coreRadius = ( numberOfPeople * areaPerPerson
                      +   numberOfEquipment * areaPerEquipment )
                      / M_PI;
    if ( coreRadius > Smidgen )
    {
        coreRadius = sqrt( coreRadius );
    }
    // Add separation distance (4 times the flame ht) to the protected safety zone core
    double fullRadius = separationDistance + coreRadius;
    return( fullRadius );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fire safety zone separation distance for personnel
        and equipment.
  
    This is roughly the distance at which the heat flux drops to 7 kW/m2.
  
    \param flameHeight  Height of the flame front (ft).
  
    \return Separation distance between the flame front and personnel/equipment
 */

double Sem::SafetyAlgorithm::safetyZoneSeparationDistance( double flameHeight )
{
    return( 4. * flameHeight );
}

//------------------------------------------------------------------------------
//  End of SafetyAlgorithm.cpp
//------------------------------------------------------------------------------

