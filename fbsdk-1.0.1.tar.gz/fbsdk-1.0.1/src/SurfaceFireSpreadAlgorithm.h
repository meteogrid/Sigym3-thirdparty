//------------------------------------------------------------------------------
/*! \file SurfaceFireSpreadAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief All surface fire spread algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

#ifndef _SURFACEFIRESPREADALGORITHM_H_INCLUDED_
#define _SURFACEFIRESPREADALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireSpreadAlgorithm SurfaceFireSpreadAlgorithm.h
    \brief All surface fire spread algorithms are encapsulated in this static
    class of <i>pure functions</i>.

    ANSI standard C89 implementation of all surface fire behavior equations and
    algorithms.  These can be used to create surface fire simulations from
    scratch without linking to additional libraries, but you have to provide
    your own state classes.
    
    Additional structure, state, and framework is provided by the
    SurfaceFireParticle and SurfaceFireModel classes, which require the QtCore
    library for signals/slots, multithreading, etc.
 */

class SurfaceFireSpreadAlgorithm
{
public:
    static double degreesToRadians( double degrees ) ;
    static double eccentricity( double lwRatio ) ;
    static double effectiveWindFactor( double ros0, double rosMax ) ;
    static double effectiveWindSpeed( double phiEw, double windB, double windX ) ;
    static double fireAcres( double length, double width ) ;
    static double fireArea( double length, double width ) ;
    static double fireLengthToWidthRatio( double effWindSpeed ) ;
    static double firelineIntensity( double flameLength ) ;
    static double firelineIntensity( double ros, double rxInt, double tauR ) ;
    static double firePerimeter( double length, double width ) ;
    static double flameLength( double firelineInt ) ;
    static double maximumReliableWindSpeed( double rxInt ) ;
    static double radiansToDegrees( double radians ) ;
    static double scorchHeight( double firelineInt, double windFpm,
                    double tempF=77. ) ;
    static double slopeFactor( double slope, double k ) ;
    static double slopeParameterK( double beta ) ;
    static double spreadRateAtBack( double ros, double eccent ) ;
    static double spreadRateAtCompass( double degrees, double headRos,
                    double headDir, double eccent ) ;
    static double spreadRateMaximum( double ros0, double phiWind, double phiSlope ) ;
    static double spreadRateMaximum( double ros0, double phiEffWind ) ;
    static double spreadRateMaximum( double ros0, double upWind, double upSlope,
                    double phiWind, double phiSlope, double *maxDir ) ;
    static double windCoefficient( double u, double b, double c, double e,
                    double beta, double betaOpt ) ;
    static double windCoefficient( double u, double b, double k ) ;
    static double windParameterB( double sigma ) ;
    static double windParameterC( double sigma ) ;
    static double windParameterE( double sigma ) ;
    static double windParameterK( double sigma, double beta, double betaOpt ) ;
    static double windParameterX( double sigma, double beta, double betaOpt ) ;
};

}   // End of namespace Sem

#endif  // _SURFACEFIRESPREADALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireSpreadAlgorithm.h
//------------------------------------------------------------------------------

