//------------------------------------------------------------------------------
/*! \file SpotBurningPile.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of Albini's \ref albini1979 model for
    predicting maximum spotting distance from a group of burning trees.
 */

// Custom header files
#include "Logger.h"
#include "SpotBurningPile.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::SpotBurningPile::coverHeightMin = 0.0;
const double Sem::SpotBurningPile::coverHeightMax = 300.0;
const double Sem::SpotBurningPile::flameHeightMin = 0.0;
const double Sem::SpotBurningPile::flameHeightMax = 100.0;
const double Sem::SpotBurningPile::ridgetopToValleyDistanceMin = 0.0;
const double Sem::SpotBurningPile::ridgetopToValleyDistanceMax = 4.0;
const double Sem::SpotBurningPile::ridgetopToValleyElevationMin = 0.0;
const double Sem::SpotBurningPile::ridgetopToValleyElevationMax = 4000.0;
const double Sem::SpotBurningPile::windSpeedAt20FtMin = 0.0;
const double Sem::SpotBurningPile::windSpeedAt20FtMax = 99.0;

//------------------------------------------------------------------------------
/*! \brief SpotBurningPile default constructor.
 */

Sem::SpotBurningPile::SpotBurningPile( void ) :
    Signal(),
    m_coverHeight(0.0),
    m_distance(0.0),
    m_elevation(0.0),
    m_flameHeight(0.0),
    m_source(Sem::SpotAlgorithm::SpotSourceValleyBottom),
    m_windSpeedAt20Ft(0.0),
    m_firebrandHeight(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    init();
    m_classVersion = spotBurningPileVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotBurningPile custom constructor.

    \param[in] source Burning pile spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
    \param[in] ridgetopToValleyDistance Ridgetop-to-valley horizontal distance (0-4 mi).
    \param[in] ridgetopToValleyElevation Ridgetop-to-valley elevation difference (0-4000 ft).
    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
    \param[in] flameHeight Steady flame height from the burning pile (0-100 ft).
 */

Sem::SpotBurningPile::SpotBurningPile(
            Sem::SpotAlgorithm::SpotSource source,
            double ridgetopToValleyDistance,
            double ridgetopToValleyElevation,
            double coverHeight,
            double windSpeedAt20Ft,
            double flameHeight ) :
    Signal(),
    m_coverHeight( coverHeight ),
    m_distance( ridgetopToValleyDistance ),
    m_elevation( ridgetopToValleyElevation ),
    m_flameHeight( flameHeight ),
    m_source( source ),
    m_windSpeedAt20Ft( windSpeedAt20Ft ),
    m_firebrandHeight(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    assert( m_coverHeight     >= coverHeightMin
         && m_coverHeight     <= coverHeightMax );
    assert( m_distance        >= ridgetopToValleyDistanceMin
         && m_distance        <= ridgetopToValleyDistanceMax );
    assert( m_elevation       >= ridgetopToValleyElevationMin
         && m_elevation       <= ridgetopToValleyElevationMax );
    assert( m_flameHeight     >= flameHeightMin
         && m_flameHeight     <= flameHeightMax );
    assert( m_windSpeedAt20Ft >= windSpeedAt20FtMin
         && m_windSpeedAt20Ft <= windSpeedAt20FtMax );
    init();
    m_classVersion = spotBurningPileVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SpotBurningPile::~SpotBurningPile( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotBurningPile copy constructor.
    \param[in] right Reference to the SpotBurningPile from which to copy.
    \return Reference to the newly allocated SpotBurningPile.
 */

Sem::SpotBurningPile::SpotBurningPile( const SpotBurningPile &right ) :
    Signal()
{
    init();
    m_classVersion    = right.m_classVersion;
    m_coverHeight     = right.m_coverHeight;
    m_distance        = right.m_distance;
    m_elevation       = right.m_elevation;
    m_flameHeight     = right.m_flameHeight;
    m_source          = right.m_source;
    m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
    m_firebrandHeight = right.m_firebrandHeight;
    m_flatSpottingDistance = right.m_flatSpottingDistance;
    m_mtnSpottingDistance  = right.m_mtnSpottingDistance;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotBurningPile assignment operator.
    \param[in] right Reference to the SpotBurningPile from which to assign.
    \return Reference to the newly assigned SpotBurningPile.
 */

const Sem::SpotBurningPile& Sem::SpotBurningPile::operator=(
        const SpotBurningPile &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion    = right.m_classVersion;
        m_coverHeight     = right.m_coverHeight;
        m_distance        = right.m_distance;
        m_elevation       = right.m_elevation;
        m_flameHeight     = right.m_flameHeight;
        m_source          = right.m_source;
        m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
        m_firebrandHeight = right.m_firebrandHeight;
        m_flatSpottingDistance = right.m_flatSpottingDistance;
        m_mtnSpottingDistance  = right.m_mtnSpottingDistance;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SpotBurningPile::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SpotBurningPile::classVersion( void ) const
{
    return( spotBurningPileVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the mean treetop/vegetation cover height
    along the firebrand path.

    \return Mean treetop/vegetation cover height along the firebrand path (ft).
 */

double Sem::SpotBurningPile::coverHeight( void ) const
{
    return( m_coverHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to lofted firebrand height.

    \return Lofted firebrand height (ft).
 */

double Sem::SpotBurningPile::firebrandHeight( void ) const
{
    checkUpdate();
    return( m_firebrandHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to the steady flame height from a burning pile.

    \return Steady flame height from a burning pile (ft).
 */

double Sem::SpotBurningPile::flameHeight( void ) const
{
    return( m_flameHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum flat terrain spotting distance (mi).

    \return Maximum flat terrain spotting distance (mi).
 */

double Sem::SpotBurningPile::flatTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_flatSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SpotBurningPile::init( void ) const
{
    m_firebrandHeight      = 0.0;
    m_flatSpottingDistance = 0.0;
    m_mtnSpottingDistance  = 0.0;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum mountainous terrain spotting distance (mi).

    \return Maximum mountainous terrain spotting distance (mi).
 */

double Sem::SpotBurningPile::mountainTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_mtnSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley horizontal distance (mi).

    \return Ridgetop-to-valley horizontal distance (mi).
 */

double Sem::SpotBurningPile::ridgetopToValleyDistance( void ) const
{
    return( m_distance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley elevation difference (ft).

    \return Ridgetop-to-valley elevation difference (ft).
 */

double Sem::SpotBurningPile::ridgetopToValleyElevation( void ) const
{
    return( m_elevation );
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean treetop/vegetation cover height
    along the firebrand path.

    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
 */

void Sem::SpotBurningPile::setCoverHeight( double coverHeight )
{
    assert( coverHeight >= coverHeightMin
         && coverHeight <= coverHeightMax );
    if ( coverHeight != m_coverHeight )
    {
        m_coverHeight = coverHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the burning pile steady flame height.

    \param[in] flameHeight Burning pile steady flame height (0-100 ft).
 */

void Sem::SpotBurningPile::setFlameHeight( double flameHeight )
{
    assert( flameHeight >= flameHeightMin
         && flameHeight <= flameHeightMax );
    if ( flameHeight != m_flameHeight )
    {
        m_flameHeight = flameHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the burning pile spotting source Sem::SpotSource.

    \param[in] source Burning pile spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
 */

void Sem::SpotBurningPile::setSource( Sem::SpotAlgorithm::SpotSource source )
{
    if ( source != m_source )
    {
        m_source = source;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley horizontal distance.

    \param[in] distance Ridgetop-to-valley horizontal distance (0-4 mi).
 */

void Sem::SpotBurningPile::setRidgetopToValleyDistance( double distance )
{
    assert( distance >= ridgetopToValleyDistanceMin
         && distance <= ridgetopToValleyDistanceMax );
    if ( distance != m_distance )
    {
        m_distance = distance;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley elevation difference.

    \param[in] elevation Ridgetop-to-valley elevation difference (0-4000 ft).
 */

void Sem::SpotBurningPile::setRidgetopToValleyElevation( double elevation )
{
    assert( elevation >= ridgetopToValleyElevationMin
         && elevation <= ridgetopToValleyElevationMax );
    if ( elevation != m_elevation )
    {
        m_elevation = elevation;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind speed at 20 ft.

    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
 */

void Sem::SpotBurningPile::setWindSpeedAt20Ft( double windSpeedAt20Ft )
{
    assert( windSpeedAt20Ft >= windSpeedAt20FtMin
         && windSpeedAt20Ft <= windSpeedAt20FtMax );
    if ( windSpeedAt20Ft != m_windSpeedAt20Ft )
    {
        m_windSpeedAt20Ft = windSpeedAt20Ft;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the burning piles Sem::SpotSource location.

    \return Burning pile spotting source Sem::SpotSource location.
 */

Sem::SpotAlgorithm::SpotSource Sem::SpotBurningPile::source( void ) const
{
    return( m_source );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access METHODS to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SpotBurningPile::update( void ) const
{
    // Initialize all mutables
    init();

    m_firebrandHeight = Sem::SpotAlgorithm::firebrandHeightFromBurningPile(
        m_flameHeight );

    m_flatSpottingDistance = 
        Sem::SpotAlgorithm::flatTerrainSpotDistanceFromBurningPile(
            m_firebrandHeight, m_windSpeedAt20Ft, m_coverHeight );

    m_mtnSpottingDistance = Sem::SpotAlgorithm::mountainTerrainSpotDistance(
        m_flatSpottingDistance, m_source, m_distance, m_elevation );

    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at 20 ft.

    \return Wind speed at 20 ft (mi/h).
 */

double Sem::SpotBurningPile::windSpeedAt20Ft( void ) const
{
    return( m_windSpeedAt20Ft );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SpotBurningPile objects.

    \param[in] lhs Left-hand-side SpotBurningPile object.
    \param[in] rhs Right-hand-side SpotBurningPile object.
 */
bool Sem::operator ==( const Sem::SpotBurningPile &lhs,
                       const Sem::SpotBurningPile &rhs )
{ 
  return( fabs( lhs.coverHeight() - rhs.coverHeight() ) < Smidgen
       && fabs( lhs.ridgetopToValleyDistance() - rhs.ridgetopToValleyDistance() ) < Smidgen
       && fabs( lhs.ridgetopToValleyElevation() - rhs.ridgetopToValleyElevation() ) < Smidgen
       && fabs( lhs.flameHeight() - rhs.flameHeight() ) < Smidgen
       && lhs.source() == rhs.source()
       && fabs( lhs.windSpeedAt20Ft() - rhs.windSpeedAt20Ft() ) < Smidgen );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SpotBurningPile objects.

    \param[in] lhs Left-hand-side SpotBurningPile object.
    \param[in] rhs Right-hand-side SpotBurningPile object.
 */
bool Sem::operator !=( const Sem::SpotBurningPile &lhs,
                       const Sem::SpotBurningPile &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SpotBurningPile.cpp
//------------------------------------------------------------------------------

