//------------------------------------------------------------------------------
/*! \file CrownFireAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All crown fire algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _CROWNFIREALGORITHM_H_INCLUDED_
#define _CROWNFIREALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class CrownFireAlgorithm CrownFireAlgorithm.h
    \brief All fire safety zone algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all crown fire equations and
    algorithms.  These can be used to estimate crown firefrom
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
 */

class CrownFireAlgorithm
{

// Public enums
public:
//------------------------------------------------------------------------------
/*! \enum FireStatus
    \brief Indicates the status of the surface-crown fire.
 */

enum FireStatus
{
    FireStatusSurface  = 0,
    FireStatusTorching = 1,
    FireStatusCrowning = 2
};
const static int FireStatusEnums = 3;    //!< Number of FireStatus

// Public API
public:

    static double activeRatio(
        double crownSpreadRate,
        double criticalSpreadRate ) ;

    static double criticalCrownFireSpreadRate(
        double canopyBulkDensity ) ;

    static double criticalSurfaceFirelineIntensity(
        double foliarMoisture,
        double crownBaseHt ) ;

    static double criticalSurfaceFireIntensity(
        double criticalFlameLength ) ;

    static double criticalSurfaceFlameLength(
        double criticalFireInt ) ;

    static double crownFireSpreadRate(
        double windSpeedAt20Ft,
        double mc1,
        double mc10,
        double mc100,
        double mcWood ) ;

    static double transitionRatio(
        double surfaceFireInt,
        double criticalFireInt ) ;
};

}   // End of namespace Sem

#endif  // _CROWNFIREALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of CrownFireAlgorithm.h
//------------------------------------------------------------------------------

