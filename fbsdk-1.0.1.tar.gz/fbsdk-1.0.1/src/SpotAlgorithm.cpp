//------------------------------------------------------------------------------
/*! \file SpotAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire spot distance fuel algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

// Custom header files
#include "SpotAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Determines the minimum value used for cover height to calculate
    the flat terrain spotting distance using logarithmic variation with height.
 
    Based on \ref albini1979

    Called directly only by flatTerrainSpotDistanceFromTorchingTrees(),
    and indirectly by flatTerrainSpotDistanceFromBurningPile() and
    flatTerrainSpotDistanceFromSurfaceFire().
     
    \param[in] firebrandHeight Lofted firebrand height (ft).
    \param[in] coverHeight      Mean treetop/vegetation cover height
                                along the firebrand path (0-300 ft).
  
    \return Cover height to use with flat terrain spotting distance (ft).
 */

double Sem::SpotAlgorithm::criticalCoverHeight(
            double firebrandHeight,
            double coverHeight )
{
    double htCrit = 2.2 * pow( firebrandHeight, 0.337 ) - 4.0;
    double htUsed = ( coverHeight > htCrit ) ? ( coverHeight ) : ( htCrit );
    return( htUsed );
}

//------------------------------------------------------------------------------
/*! \brief Calculates lofted firebrand height from a burning pile.
 
    Based on \ref albini1979

    Burning pile spot distance estimation various from torching trees only in
    how the firebrand height is calculated.
     
    \param[in] flameHeight Burning pile's steady flame height (ft).
  
    \return Lofted firebrand height from a burning pile (ft).
 */

double Sem::SpotAlgorithm::firebrandHeightFromBurningPile( double flameHeight )
{
    double z = 12.2 * flameHeight;
    return( z );
}

//------------------------------------------------------------------------------
/*! \brief Calculates lofted firebrand height from wind-driven surface fire.
 
    Based on \ref albini1979 and \ref albini1973
     
    \param[in] flameLength Surface fire flame length (ft).
    \param[in] windSpeedAt20Ft Wind speed at 20 ft (mi/h).
  
    \return Lofted firebrand height from a surface fire (ft).
 */

double Sem::SpotAlgorithm::firebrandHeightFromSurfaceFire(
            double flameLength,
            double windSpeedAt20Ft )
{
    double z = 0.0;
    if ( flameLength > Smidgen )
    {
        // f is function relating thermal energy to windspeed.
        double f = 322. * pow( ( 0.474 * windSpeedAt20Ft ), -1.01 );

        // Byram's fireline intensity is derived back from flame length.
        double byrams = pow( ( flameLength / .45 ), ( 1. / 0.46 ) );

        // Strength of thermal updraft (Btu/ft)
        double energy = f * byrams;

        // Initial firebrand height (ft).
        z = ( energy < Smidgen ) ? ( 0.0 ) : ( 1.055 * sqrt( energy ) );
    }
    return( z );
}

//------------------------------------------------------------------------------
/*! \brief Calculates lofted firebrand height from torching trees.
 
    Based on \ref albini1979
     
    \param[in] treeHeight       Torching tree height (10-300 ft).
    \param[in] flameHeight      Torching tree steady flame height (ft).
    \param[in] flameDuration    Torching tree steady flame durection (dl).
  
    \return Lofted firebrand height from torching trees (mi).
 */

double Sem::SpotAlgorithm::firebrandHeightFromTorchingTrees(
            double treeHeight,
            double flameHeight,
            double flameDuration )
{
    /*! \var FirebrandFlameHeightRatio
        \brief Equation parameters for \ref albini1979 Figure 7.
     */
    static double FirebrandFlameHeightRatio[4][2] = {
        {4.24, 0.332},  //!< treeHeight / flameHeight >= 1.0
        {3.64, 0.391},  //!< treeHeight / flameHeight >= 0.5
        {2.78, 0.418},  //!< treeHeight / flameHeight < 0.5 && duration < 3.5
        {4.70, 0.000}   //!< treeHeight / flameHeight < 0.5 && duration >= 3.5
    };

    // Constrain flameHeight
    double z = 0.0;
    if ( flameHeight > Smidgen && flameDuration > Smidgen )
    {
        // Determine which Figure 7 curve to apply
        int j;
        double y;
        if ( ( y = treeHeight / flameHeight ) >= 1. )
        {
            j = 0;  // y >= 1.0
        }
        else if ( y >= 0.5 )
        {
            j = 1;  // y >= 0.5
        }
        else if ( flameDuration < 3.5 )
        {
            j = 2;  // y < 0.5 and flameDuration < 3.5
        }
        else
        {
            j = 3;  // y < 0.5 and flameDuration >= 3.5
        }
        // Figure 7 lofted firebrand height / steady flame height
        z = FirebrandFlameHeightRatio[j][0]
            * pow( flameDuration, FirebrandFlameHeightRatio[j][1] )
            // multiply by steady flame height
            * flameHeight
            // add 1/2 tree height
            + treeHeight / 2.;
    }
    return( z );
}

//------------------------------------------------------------------------------
/*! \brief Determines maximum spotting distance from a burning pile
    in flat terrain.
 
    Based on \ref albini1979 Figures 8a and 8b.

    Burning pile spot distance estimation various from torching trees only in
    how the firebrand height is calculated, se we delegate to
    flatTerrainSpotDistanceFromTorchingTrees().
    
    \param[in] firebrandHeight  Lofted firebrand height (ft).
    \param[in] windSpeedAt20Ft  Wind speed at 20 ft (0-99 mi/h).
    \param[in] coverHeight      Mean treetop/vegetation cover height
                                along the firebrand path (0-300 ft).
  
    \return Maximum spotting distance from a burning pile
    in flat terrain (mi).
 */

double Sem::SpotAlgorithm::flatTerrainSpotDistanceFromBurningPile(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight )
{
    return( Sem::SpotAlgorithm::flatTerrainSpotDistanceFromTorchingTrees(
        firebrandHeight, windSpeedAt20Ft, coverHeight ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines maximum spotting distance from a spreading surface fire
    in flat terrain.
 
    Based on \ref albini1983

    Surface fire spot distance estimation various from torching trees only in
    the addition of a drift factor, se we delegate to
    flatTerrainSpotDistanceFromTorchingTrees() then add the drift factor.
    
    \param[in] firebrandHeight  Lofted firebrand height (ft).
    \param[in] windSpeedAt20Ft  Wind speed at 20 ft (0-99 mi/h).
    \param[in] coverHeight      Mean treetop/vegetation cover height
                                along the firebrand path (0-300 ft).
  
    \return Maximum spotting distance from spreading surface fire
    in flat terrain (mi).
 */

double Sem::SpotAlgorithm::flatTerrainSpotDistanceFromSurfaceFire(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight )
{
    double flatDist = Sem::SpotAlgorithm::flatTerrainSpotDistanceFromTorchingTrees(
        firebrandHeight, windSpeedAt20Ft, coverHeight );
    if ( flatDist > Smidgen )
    {
        // Downward drift during lofting (mi)
        double drift = 0.000278 * windSpeedAt20Ft * pow( firebrandHeight, 0.643 );
        flatDist += drift;
    }
    return( flatDist );
}

//------------------------------------------------------------------------------
/*! \brief Determines maximum spotting distance from torching trees
    in flat terrain.
 
    Based on \ref albini1979 Figures 8a and 8b.
    
    \param[in] firebrandHeight  Lofted firebrand height (ft).
    \param[in] windSpeedAt20Ft  Wind speed at 20 ft (0-99 mi/h).
    \param[in] coverHeight      Mean treetop/vegetation cover height
                                along the firebrand path (0-300 ft).
  
    \return Maximum spotting distance from the torching trees
    in flat terrain (mi).
 */

double Sem::SpotAlgorithm::flatTerrainSpotDistanceFromTorchingTrees(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight )
{
    double flatDist = 0.0;
    if ( firebrandHeight > Smidgen )
    {
        // Cover height used
        double htUsed = Sem::SpotAlgorithm::criticalCoverHeight(
            firebrandHeight, coverHeight );
        if ( htUsed > Sem::Smidgen )
        {
            flatDist = 0.000718 * windSpeedAt20Ft * sqrt( htUsed )
                     * ( 0.362 + sqrt( firebrandHeight / htUsed ) / 2.
                     * log( firebrandHeight / htUsed ) );
        }
    }
    return( flatDist );
}

//------------------------------------------------------------------------------
/*! \brief Adjusts the flat terrain spotting distance to mountainous terrain.
 
    Based on \ref albini1979 Figures 9a, 9b, 9c, and 9d.
     
    \param[in] flatSpotDistance  Spot distance on flat terrain (mi).
    \param[in] source       Torching tree Sem::SpotSource:
                                    - SpotSourceMidslopeWindward
                                    - SpotSourceValleyBottom
                                    - SpotSourceMidslopeLeeward
                                    - SpotSourceRidgetop
    \param[in] ridgetopToValleyDistance Horizontal distance from ridge top
                                        to valley bottom (0-4 mi).
    \param[in] ridgetopToValleyElevation Vertical distance from ridge top
                                        to valley bottom (0-4000 ft).
  
    \return Maximum spotting distance from the torching trees in mountainous
    terrain (mi).
 */

double Sem::SpotAlgorithm::mountainTerrainSpotDistance(
        double flatSpotDistance,
        SpotSource source,
        double ridgetopToValleyDistance,
        double ridgetopToValleyElevation )
{
    double mtnSpotDistance = flatSpotDistance;
    if ( ridgetopToValleyElevation > Sem::Smidgen
      && ridgetopToValleyDistance > Sem::Smidgen )
    {
        double a1 = flatSpotDistance / ridgetopToValleyDistance;
        double b1 = ridgetopToValleyElevation / ( 10. * M_PI ) / 1000.;
        double x = a1;
        for ( int i=0; i<6; i++ )
        {
            x = a1 - b1 * ( cos( M_PI * x - source * M_PI / 2. )
              - cos( source * M_PI / 2. ) );
        }
        mtnSpotDistance = x * ridgetopToValleyDistance;
    }
    return( mtnSpotDistance );
}

//------------------------------------------------------------------------------
/*! \brief Calculates steady flame duration from torching trees.

    This estimates steady flame duration height from \ref albini1979
    Figures 3b, 4b, or 5b, depending upon the tree species involved.

    \param[in] treeSpecies      Torching tree Sem::SpotSpecies
                                    - SpotSpeciesEngelmannSpruce
                                    - SpotSpeciesDouglasFir
                                    - SpotSpeciesSubalpineFir
                                    - SpotSpeciesWesternHemlock
                                    - SpotSpeciesPonderosaPine
                                    - SpotSpeciesLodgepolePine
                                    - SpotSpeciesWesternWhitePine
                                    - SpotSpeciesGrandFir
                                    - SpotSpeciesBalsamFir
                                    - SpotSpeciesSlashPine
                                    - SpotSpeciesLongleafPine
                                    - SpotSpeciedsPondPine
                                    - SpotSpeciesShortleafPine
                                    - SpotSpeciesLoblollyPine
    \param[in] treeDbh          Torching tree dbh (5-40 in).
    \param[in] torchingTrees    Number of torching trees (0-30).

    \return Steady flame dureation (which Albini says is dimensionless).
 */

double Sem::SpotAlgorithm::steadyFlameDurationFromTorchingTrees(
        SpotSpecies treeSpecies,
        double treeDbh,
        double torchingTrees )
{

//------------------------------------------------------------------------------
/*! \var SteadyFlame
    \brief Equations parameters for \ref albini1979 steady flame height curves
    3a, 4a, and 5a based on torching tree species, and steady flame
    duration curves 3b, 4b, 5b, also based on torching tree species.

    The flame height curves have the form h = a * pow( treeDbh, b ), where
        - a = SteadyFlame[Sem::SpotSpecies][0]
        - b = SteadyFlame[Sem::SpotSpecies][1]

    The flame duration curves have the form d = a * pow( treeDbh, b ), where
        - a = SteadyFlame[Sem::SpotSpecies][2]
        - b = SteadyFlame[Sem::SpotSpecies][3]
 */

    const static double Duration[][4] =
    {
    //   ht_a  ht_b dur_a   dur_b
        {12.6, -.256},  //  0 Engelmann spruce
        {10.7, -.278},  //  1 Douglas-fir
        {10.7, -.278},  //  2 subalpine fir
        { 6.3, -.249},  //  3 western hemlock
        {12.6, -.256},  //  4 ponderosa pine
        {12.6, -.256},  //  5 lodgepole pine
        {10.7, -.278},  //  6 western white pine
        {10.7, -.278},  //  7 grand fir
        {10.7, -.278},  //  8 balsam fir
        {11.9, -.389},  //  9 slash pine
        {11.9, -.389},  // 10 longleaf pine
        {7.91, -.344},  // 11 pond pine
        {7.91, -.344},  // 12 shortleaf pine
        {13.5, -.544}   // 13 loblolly pine
    //  { 6.3, -.249},  // 14 western larch (guessed)
    //  {12.6, -.256}   // 15 western red cedar (guessed)
    } ;
    double duration = 0.0;
    if ( torchingTrees > Smidgen && treeDbh > Smidgen )
    {
        duration =
            // Figure 3b, 4b, or 5b duration
            Duration[treeSpecies][0] * pow( treeDbh, Duration[treeSpecies][1] )
            // Figure 6 flame duration multiplier
            * pow( torchingTrees, -0.2 );
    }
    return( duration );
}

//------------------------------------------------------------------------------
/*! \brief Calculates steady flame height from torching trees.

    This estimates steady flame height from \ref albini1979 Figures 3a, 4a,
    or 5a, depending upon the tree species involved.
    \param[in] treeSpecies      Torching tree Sem::SpotSpecies
                                    - SpotSpeciesEngelmannSpruce
                                    - SpotSpeciesDouglasFir
                                    - SpotSpeciesSubalpineFir
                                    - SpotSpeciesWesternHemlock
                                    - SpotSpeciesPonderosaPine
                                    - SpotSpeciesLodgepolePine
                                    - SpotSpeciesWesternWhitePine
                                    - SpotSpeciesGrandFir
                                    - SpotSpeciesBalsamFir
                                    - SpotSpeciesSlashPine
                                    - SpotSpeciesLongleafPine
                                    - SpotSpeciedsPondPine
                                    - SpotSpeciesShortleafPine
                                    - SpotSpeciesLoblollyPine
    \param[in] treeDbh          Torching tree dbh (5-40 in).
    \param[in] torchingTrees    Number of torching trees (0-30).

    \return Steady flame height (ft).
 */

double Sem::SpotAlgorithm::steadyFlameHeightFromTorchingTrees(
            SpotSpecies treeSpecies,
            double treeDbh,
            double torchingTrees )
{
    const static double FlameHeight[][2] =
    {
        {15.7, .451},  //  0 Engelmann spruce
        {15.7, .451},  //  1 Douglas-fir
        {15.7, .451},  //  2 subalpine fir
        {15.7, .451},  //  3 western hemlock
        {12.9, .453},  //  4 ponderosa pine
        {12.9, .453},  //  5 lodgepole pine
        {12.9, .453},  //  6 western white pine
        {16.5, .515},  //  7 grand fir
        {16.5, .515},  //  8 balsam fir
        {2.71, 1.00},  //  9 slash pine
        {2.71, 1.00},  // 10 longleaf pine
        {2.71, 1.00},  // 11 pond pine
        {2.71, 1.00},  // 12 shortleaf pine
        {2.71, 1.00}   // 13 loblolly pine
    //  {12.9, .453},  // 14 western larch (guessed)
    //  {15.7, .515}   // 15 western red cedar (guessed)
    } ;
    double flameHeight = 0.0;
    if ( torchingTrees > Smidgen && treeDbh > Smidgen )
    {
        flameHeight =
            // Figure 3a, 4a, or 5a flame height
            FlameHeight[treeSpecies][0] * pow( treeDbh, FlameHeight[treeSpecies][1] )
            // Figure 6 flame height multiplier
            * pow( torchingTrees, 0.4 );
    }
    return( flameHeight );
}

//------------------------------------------------------------------------------
//  End of SpotAlgorithm.cpp
//------------------------------------------------------------------------------

