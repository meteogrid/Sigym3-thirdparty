//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelModel.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A derivation of SurfaceFireFuel with added support for model
    name, id, and description.
 */

// Custom include files
#include "Logger.h"
#include "SurfaceFireFuelModel.h"
#include "SurfaceFireParticle.h"

// Standard headers
#include <cmath>
#include <iostream>

//------------------------------------------------------------------------------
/*! \brief Default constructor.
 */

Sem::SurfaceFireFuelModel::SurfaceFireFuelModel( void ) :
    SurfaceFireFuel(),
    m_desc( "" ),
    m_id( -1 ),
    m_name( "" )
{
    init();
    m_classVersion = surfaceFireFuelModelVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Custom constructor.

    \param[in] id Fuel model id number.
    \param[in] name Fuel model name.
    \param[in] desc Fuel model description.
    \param[in] mextDead Surface fuel bed dead fuel extinction moisture content.

    \note Unfortunately, we cannot also pass in the address of a
    SurfaceFuelMoistureInterface to the constructor, since 'this' doesn't
    yet exist and we can't make the signal-slot connections with out.
 */

Sem::SurfaceFireFuelModel::SurfaceFireFuelModel( int id, const QString& name,
        const QString& desc, double mextDead ) :
    SurfaceFireFuel( mextDead ),
    m_desc( desc ),
    m_id( id ),
    m_name( name )
{
    init();
    m_classVersion = surfaceFireFuelModelVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SurfaceFireFuelModel::~SurfaceFireFuelModel( void )
{
    clearFuel();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireFuelModel copy constructor.

    \param[in] right Reference to the SurfaceFireFuelModel from which to copy.

    Note that this results in a shallow copy of rhs; the lhs shares the same
    set of SurfaceFireParticlePtrs.

    \return Reference to the newly allocated SurfaceFireFuelModel.
 */

Sem::SurfaceFireFuelModel::SurfaceFireFuelModel(
        const SurfaceFireFuelModel &right ) :
    SurfaceFireFuel()
{
    init();
    clearFuel();
    m_classVersion = right.m_classVersion;
    m_desc         = right.m_desc;
    m_id           = right.m_id;
    m_mextDead     = right.m_mextDead;
    m_moisture     = right.m_moisture;
    m_name         = right.m_name;
    foreach( SurfaceFireParticleInterface* ptr, right.m_fuel )
    {
        addSurfaceFireParticle( ptr->clone() );
    }
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireFuelModel assignment operator.

    \param[in] right Reference to the SurfaceFireFuelModel from which to assign.

    \return Reference to the newly assigned SurfaceFireFuelModel.
 */

const Sem::SurfaceFireFuelModel& Sem::SurfaceFireFuelModel::operator=(
        const SurfaceFireFuelModel &right )
{
    if ( this != &right )
    {
        init();
        clearFuel();
        m_classVersion = right.m_classVersion;
        m_desc         = right.m_desc;
        m_id           = right.m_id;
        m_mextDead     = right.m_mextDead;
        m_moisture     = right.m_moisture;
        m_name         = right.m_name;
        foreach( SurfaceFireParticleInterface* ptr, right.m_fuel )
        {
            addSurfaceFireParticle( ptr->clone() );
        }
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Adds a new SurfaceFuelParticle to the SurfaceFuelBed.

    \param[in] savr Fuel particle surface area-to-volume ratio
                (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] moistureClass SurfaceFuelMoistureClass used to get the correct
                moisture content for this fuel particle.
    \param[in] cureAlgorithm ParticleCureAlgorithm used to determine
                if and how live fuel load is transferred to dead load.
    \param[in] height Maximum height above the surface (ft).
    \param[in] load Total dead plus live fuel load (lb/ft<sup>2</sup>).
    \param[in] moisDead Dead fuel moisture content (fraction oven-dry weight).
    \param[in] moisLive Live fuel moisture content (fraction oven-dry weight).
    \param[in] heat Low heat of combustion (BTU/lb).
    \param[in] density Fuel particle density (lb/ft<sup>3</sup>).
    \param[in] totalSi Total silica content (fraction oven-dry weight).
    \param[in] effectiveSi Effective silica content (fraction oven-dry weight).
 */

void Sem::SurfaceFireFuelModel::addParticleNew(double savr,
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClass,
        Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm cureAlgorithm,
        double height, double load, double moisDead, double moisLive,
        double heat, double density, double totalSi, double effectiveSi )
{
    double loadDead = load;
    double loadLive = 0.0;
    if ( moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb
      || moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood )
    {
        loadDead = 0.0;
        loadLive = load;
    }

    // Create a new SurfaceFireParticle owned by this SurfaceFireFuelModel
    Sem::SurfaceFireParticleInterface* ptr = new SurfaceFireParticle(
        moistureClass, cureAlgorithm, savr, height, loadDead, loadLive,
        moisDead, moisLive, heat, density, totalSi, effectiveSi );
    Q_ASSERT_X( (ptr != 0 ), "Sem::SurfaceFireFuelModel::addParticleNew()",
        "SurfaceFireParticle allocation failure." );
    addSurfaceFireParticle( ptr );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.

    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireFuelModel::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.

    \return Current class version.
 */

int Sem::SurfaceFireFuelModel::classVersion( void ) const
{
    return( surfaceFireFuelModelVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel model description.

    \return Copy of the surface fire fuel model description.
 */

QString Sem::SurfaceFireFuelModel::description( void ) const
{
    return( m_desc );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel model id number.

    \return Copy of the surface fire fuel model id number.
 */

int Sem::SurfaceFireFuelModel::id( void ) const
{
    return( m_id );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel model name.

    \return Copy of the surface fire fuel model name.
 */

QString Sem::SurfaceFireFuelModel::name( void ) const
{
    return( m_name );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireFuelModel objects.

    \param[in] lhs Left-hand-side SurfaceFireFuelModel object.
    \param[in] rhs Right-hand-side SurfaceFireFuelModel object.

    \note Note that the SurfaceFireParticleInterface objects contents are
    compared between the lhs and rhs.

    \return TRUE if equal, FALSE if not equal.
 */

bool Sem::operator ==( const Sem::SurfaceFireFuelModel &lhs,
        const Sem::SurfaceFireFuelModel &rhs )
{ 
    if ( lhs.id() != rhs.id()
        || lhs.name() != rhs.name()
        || lhs.description() != rhs.description() )
    {
        return( false );
    }
      
    if ( fabs( lhs.mextDead() - rhs.mextDead() ) > Smidgen
        || lhs.fuels() != rhs.fuels() )
    {
        return( false );
    }
    for ( int i=0; i<lhs.fuels(); i++ )
    {
        if ( *lhs.fuelPtr( i ) != *rhs.fuelPtr( i ) )
        {
            return( false );
        }
    }
    return( true );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireFuelModel objects.

    \param[in] lhs Left-hand-side SurfaceFireFuelModel object.
    \param[in] rhs Right-hand-side SurfaceFireFuelModel object.

    \return TRUE if not equal, FALSE if equal.
 */

bool Sem::operator !=( const Sem::SurfaceFireFuelModel &lhs,
        const Sem::SurfaceFireFuelModel &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SurfaceFuelModel.cpp
//------------------------------------------------------------------------------

