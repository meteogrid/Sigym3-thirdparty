//------------------------------------------------------------------------------
/*! \file Signal.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief Base class for implementing SEM object signal/slot and
    meta class communication.
    \par License
    This is released under the GNU Public License 2.
 */

// Custom header files
#include "Logger.h"
#include "Signal.h"

// Qt headers
#include <QString>

// Standard headers
#include <iomanip>
#include <iostream>

//------------------------------------------------------------------------------
/*! \brief Signal default constructor.
 */

Sem::Signal::Signal( void ) :
    m_classVersion( 1 ),
    m_dirty( true )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief Signal custom constructor.

    \param[in] classVersion Class version number.
 */

Sem::Signal::Signal( int classVersion ) :
    m_classVersion( classVersion ),
    m_dirty( true )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::Signal::~Signal( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief Signal copy constructor.

    \param[in] right Reference to the Signal from which to copy.

    \return Reference to the newly allocated Signal.
 */

Sem::Signal::Signal( const Signal &right ) : QObject()
{
    m_classVersion = right.m_classVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Signal assignment operator.

    \param[in] right Reference to the Signal from which to assign.

    \return Reference to the newly assigned Signal.
 */

const Sem::Signal& Sem::Signal::operator=( const Signal &right )
{
    if ( this != &right )
    {
        m_classVersion = right.m_classVersion;
        setDirty();
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Called by access methods to see if the object needs to update
    itself before returning a requested property.
 */

void Sem::Signal::checkUpdate( void ) const
{
    if ( m_dirty )
    {
        updateObject();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Static function that returns the class name.
    \return Class name string with namespace qualifier.
 */

const char* Sem::Signal::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Static function that returns the current class version.
    \return Class version (integer base 1).
 */

int Sem::Signal::classVersion( void ) const
{
    return( m_classVersion );
}

//------------------------------------------------------------------------------
/*! \brief Text stream input reader.

    \param[in] input Reference to the input stream.
 */

bool Sem::Signal::readHeader( std::istream& input )
{
    // Get and validate the className
    bool status = true;
    std::string name;
    input >> name;
    if ( name != className() )
    {
        Sem::Logger::Instance().send( 3,
            QString( "Class '%1' is unsupported for class '%2' text input." )
            .arg( name.c_str() ).arg( className() ) );
        status = false;
    }
    // Read the class version
    input >> m_classVersion;
    // Set the dirty flag
    setDirty();
    return( status );
}

//------------------------------------------------------------------------------
/*! \brief Binary stream input reader.

    \param[in] input Reference to the input QDataStream.
 */

bool Sem::Signal::readHeader( QDataStream& input )
{
    // Get and validate the className
    bool status = true;
    QString name;
    input >> name;
    if ( name != className() )
    {
        Sem::Logger::Instance().send( 3,
            QString( "Class '%1' is unsupported for class '%2' text input." )
            .arg( name ).arg( className() ) );
        status = false;
    }
    // Read the class version
    input >> m_classVersion;
    // Set the dirty flag
    setDirty();
    return( status );
}

//------------------------------------------------------------------------------
/*! \brief Sets the dirty flag and emits valueChanged() signal.

    \note Its important that methods that change the object state call
    setDirty() rather than update(), as this (1) emits the valueChanged()
    signal and (2) permits lazy updating.
 */

void Sem::Signal::setDirty( void )
{
    emit valueChanged();
    m_dirty = true;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object properties up to date.

    \note Make sure NOT to call any member update methods on properties,
    such as "property()", as these then call checkUpdate(), resulting in an
    infinite loop!  Access member properties directly, as in "m_property".
 */

void Sem::Signal::updateObject( void ) const
{
    // Do whatever is necessary to update the object state
    update();
    // Clear the dirty flag and return
    m_dirty = false;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Text stream output writer.

    \param[in] output Reference to the output stream.
 */

void Sem::Signal::writeHeader( std::ostream &output ) const
{
    output << className() << " "
           << classVersion() << " "
           << std::setprecision(15);
    return;
}

//------------------------------------------------------------------------------
/*! \brief Binary stream output writer.

    \param[in] output Reference to the output QDataStream.
 */

void Sem::Signal::writeHeader( QDataStream& output ) const
{
    output << QString( className() )
           << (qint32) classVersion();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two Signal objects.

    \param[in] lhs Left-hand-side Signal object.
    \param[in] rhs Right-hand-side Signal object.
 */
bool Sem::operator ==( const Sem::Signal &lhs, const Sem::Signal &rhs )
{ 
    return( lhs.className() == rhs.className()
         && lhs.classVersion() == rhs.classVersion() );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two Signal objects.

    \param[in] lhs Left-hand-side Signal object.
    \param[in] rhs Right-hand-side Signal object.
 */
bool Sem::operator !=( const Sem::Signal &lhs, const Sem::Signal &rhs )
{ 
    return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of Signal.cpp
//------------------------------------------------------------------------------

