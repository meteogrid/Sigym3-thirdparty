//------------------------------------------------------------------------------
/*! \file SurfaceFireParticleInterface.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An abstract base class defining an interface to provide surface fire
    fuel particle information (size, load, moisture, etc.).
 */

#ifndef _SURFACEFIREPARTICLEINTERFACE_H_INCLUDED_
#define _SURFACEFIREPARTICLEINTERFACE_H_INCLUDED_

// Custom include files
#include "Signal.h"

// Qt include files
#include <QVector>

namespace Sem
{

// Forward class references
class SurfaceFireMoistureInterface;

//------------------------------------------------------------------------------
/*! \class SurfaceFireParticleInterface SurfaceFireParticleInterface.h
    \brief An abstract base class defining an interface to provide surface fire
    fuel particle information (size, load, moisture, etc.).

    Classes implementing the SurfaceFireParticleInterface generally represent
    a particular fuel particle type.
    Examples include dead and down 1-h, 10-h, and 100-h time lag round wood,
    and herbaceous and woody plants.
    A class may have both a dead and live fuel component.
    Under the traditional, 'static' fuel model notion, all the fuel in a
    particular class is in either the dead or live component, but not both.
    Under the 'dynamic' fuel model notion, load may shift from the live to
    dead component, for example, during seasonal curing of herbaceous fuels.
    Details of how load is transferred and moisture content is updated are
    left for the derived classes.

    The API consists of methods for accessing the fuel particle properties
    including dead and live load, dead and live moisture content, height,
    surface area-to-volume ratio, density, heat of combustion, and total and
    effective silica content.

    SurfaceFireParticleInterface inherits from Signal, so derived classes
    must implement the virtual update() method.

    The SurfaceFireParticle class is a concrete derivation of this abstract
    interface, implementing the classic BEHAVE/BehavePlus fuel particle.
 */

class SurfaceFireParticleInterface : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireParticleInterfaceVersion = 1;   //!< Class version

// Public interface
public:
    /*! \brief Virtual destructor implemented here
     */
    virtual ~SurfaceFireParticleInterface( void ) {}

    /*! \fn virtual SurfaceFireParticleInterface* clone( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.

        Virtual constructor.
        \return Surface fuel particle low heat of combustion (Btu/lb).
    */
    virtual SurfaceFireParticleInterface* clone( void ) const = 0;

    // Property access methods
    const char* className( void ) const { return( metaObject()->className() ); }
    int classVersion( void ) const { return ( surfaceFireParticleInterfaceVersion ); }

    /*! \fn virtual double density( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle density (lb/ft<sup>3</sup>).
        (Multiply by 16.0185 to convert to kg/m3).
    */
    virtual double density( void ) const = 0 ;

    /*! \fn virtual double endPyrolisisTemperature( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle char end pyrolisys temperature (oF).
        (oK = 273 + 5(oF-32)/9).
    */
    virtual double endPyrolisisTemperature( void ) const = 0;

    /*! \fn virtual virtual bool   hasLiveHerb( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return TRUE if the surface fuel particle has live herb fuel.
    */
    virtual bool   hasLiveHerb( void ) const = 0 ;

    /*! \fn virtual bool   hasLiveWood( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return TRUE if the surface fuel particle has live wood fuel.
    */
    virtual bool   hasLiveWood( void ) const = 0 ;

    /*! \fn virtual double heatCapacity( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle heat capacity (Btu/lb/oF).
        (Multiply by 4190.03 to convert to J/kg/oK.)
    */
    virtual double heatCapacity( void ) const = 0;

    /*! \fn virtual double heatOfCombustion( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle low heat of combustion (Btu/lb).
        (Multiply by 2327.79 to convert to J/kg.)
    */
    virtual double heatOfCombustion( void ) const = 0;

    /*! \fn virtual double height( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle maximum height above the surface (ft).
    */
    virtual double height( void ) const = 0 ;

    /*! \fn virtual double ignitionTemperature( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle ignition temperature (oF).
        (oK = 273 + 5(oF-32)/9).
    */
    virtual double ignitionTemperature( void ) const = 0;

    /*! \fn virtual virtual double loadDead( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle dead fuel load (lb/ft<sup>2</sup>).
        (Multiply by 4.88243 to convert to kg/m2).
    */
    virtual double loadDead( void ) const = 0 ;

    /*! \fn virtual double loadLive( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle live fuel load (lb/ft<sup>2</sup>).
        (Multiply by 4.88243 to convert to kg/m2).
    */
    virtual double loadLive( void ) const = 0 ;

    /*! \fn virtual double moistureDead( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle dead fuel moisture content
        (fraction oven-dry weight).
    */
    virtual double moistureDead( void ) const = 0 ;

    /*! \fn virtual double moistureLive( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle live fuel moisture content
        (fraction oven-dry weight).
    */
    virtual double moistureLive( void ) const = 0 ;

    /*! \fn virtual double savr( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle surface area to volume ratio
        (ft<sup>2</sup>/ft<sup>3</sup>).
        (Multiply by 3.28084 to convert to m<sup>2</sup>/m<sup>3</sup>).
    */
    virtual double savr( void ) const = 0 ;

    /*! \fn virtual double siEffective( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle effective silica content
        (fraction oven-dry weight).
    */
    virtual double siEffective( void ) const = 0;

    /*! \fn virtual double siTotal( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle total silica content (fraction oven-dry weight).
    */
    virtual double siTotal( void ) const = 0;

    /*! \fn virtual void setMoisture( const SurfaceFireMoistureInterface* sfm ) = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \param[in] sfm Pointer to a SurfaceFuelMoistureInterface object.
    */
    virtual void setMoisture( const SurfaceFireMoistureInterface* sfm ) = 0;

    /*! \fn virtual void setMoisture( const SurfaceFireMoistureInterface& sfm ) = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \param[in] sfm Reference to a SurfaceFireMoistureInterface object.
    */
    virtual void setMoisture( const SurfaceFireMoistureInterface& sfm ) = 0;

    /*! \fn virtual double thermalConductance( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel particle thermal conductance (Btu/s/ft/0F).
        (Multiply by 6235.45 to convert to W/m/oK.)
    */
    virtual double thermalConductance( void ) const = 0;

};

}   // End of namespace Sem

#endif  // _SURFACEFIREPARTICLEINTERFACE_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireParticleInterface.h
//------------------------------------------------------------------------------

