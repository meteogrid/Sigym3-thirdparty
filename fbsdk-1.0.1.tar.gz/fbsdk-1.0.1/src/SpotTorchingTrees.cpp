//------------------------------------------------------------------------------
/*! \file SpotTorchingTrees.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of Albini's \ref albini1979 model for
    predicting maximum spotting distance from a group of burning trees.
 */

// Custom header files
#include "Logger.h"
#include "SpotTorchingTrees.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::SpotTorchingTrees::coverHeightMin = 0.0;
const double Sem::SpotTorchingTrees::coverHeightMax = 300.0;
const double Sem::SpotTorchingTrees::ridgetopToValleyDistanceMin = 0.0;
const double Sem::SpotTorchingTrees::ridgetopToValleyDistanceMax = 4.0;
const double Sem::SpotTorchingTrees::ridgetopToValleyElevationMin = 0.0;
const double Sem::SpotTorchingTrees::ridgetopToValleyElevationMax = 4000.0;
const double Sem::SpotTorchingTrees::treeDbhMin = 5.0;
const double Sem::SpotTorchingTrees::treeDbhMax = 40.0;
const double Sem::SpotTorchingTrees::treeHeightMin = 10.0;
const double Sem::SpotTorchingTrees::treeHeightMax = 300.0;
const int    Sem::SpotTorchingTrees::torchingTreesMin = 0;
const int    Sem::SpotTorchingTrees::torchingTreesMax = 30;
const double Sem::SpotTorchingTrees::windSpeedAt20FtMin = 0.0;
const double Sem::SpotTorchingTrees::windSpeedAt20FtMax = 99.0;

//------------------------------------------------------------------------------
/*! \brief SpotTorchingTrees default constructor.
 */

Sem::SpotTorchingTrees::SpotTorchingTrees( void ) :
    Signal(),
    m_coverHeight(0.0),
    m_distance(0.0),
    m_elevation(0.0),
    m_source(Sem::SpotAlgorithm::SpotSourceValleyBottom),
    m_species(Sem::SpotAlgorithm::SpotSpeciesLodgepolePine),
    m_torchingTrees(0.0),
    m_treeDbh(5.0),
    m_treeHeight(10.0),
    m_windSpeedAt20Ft(0.0),
    m_firebrandHeight(0.0),
    m_flameHeight(0.0),
    m_flameDuration(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    init();
    m_classVersion = spotTorchingTreesVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotTorchingTrees custom constructor.

    \param[in] source Torching tree spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
    \param[in] ridgetopToValleyDistance Ridgetop-to-valley horizontal distance (0-4 mi).
    \param[in] ridgetopToValleyElevation Ridgetop-to-valley elevation difference (0-4000 ft).
    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
    \param[in] torchingTrees Number of torching trees (0-30).
    \param[in] treeDbh Torching tree dbh (5-40 in.
    \param[in] treeHeight Torching tree height (10-300 ft).
    \param[in] treeSpecies Torching tree species Sem::Species.
        - SpotSpeciesEngelmannSpruce
        - SpotSpeciesDouglasFir
        - SpotSpeciesSubalpineFir
        - SpotSpeciesWesternHemlock
        - SpotSpeciesPonderosaPine
        - SpotSpeciesLodgepolePine
        - SpotSpeciesWesternWhitePine
        - SpotSpeciesGrandFir
        - SpotSpeciesBalsamFir
        - SpotSpeciesSlashPine
        - SpotSpeciesLongleafPine
        - SpotSpeciedsPondPine
        - SpotSpeciesShortleafPine
        - SpotSpeciesLoblollyPine
 */

Sem::SpotTorchingTrees::SpotTorchingTrees(
            Sem::SpotAlgorithm::SpotSource source,
            double ridgetopToValleyDistance,
            double ridgetopToValleyElevation,
            double coverHeight,
            double windSpeedAt20Ft,
            double torchingTrees,
            double treeDbh,
            double treeHeight,
            Sem::SpotAlgorithm::SpotSpecies treeSpecies ) :
    Signal(),
    m_coverHeight( coverHeight ),
    m_distance( ridgetopToValleyDistance ),
    m_elevation( ridgetopToValleyElevation ),
    m_source( source ),
    m_species( treeSpecies ),
    m_torchingTrees( torchingTrees ),
    m_treeDbh( treeDbh ),
    m_treeHeight( treeHeight ),
    m_windSpeedAt20Ft( windSpeedAt20Ft ),
    m_firebrandHeight(0.0),
    m_flameHeight(0.0),
    m_flameDuration(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    assert( m_coverHeight     >= coverHeightMin
         && m_coverHeight     <= coverHeightMax );
    assert( m_distance        >= ridgetopToValleyDistanceMin
         && m_distance        <= ridgetopToValleyDistanceMax );
    assert( m_elevation       >= ridgetopToValleyElevationMin
         && m_elevation       <= ridgetopToValleyElevationMax );
    assert( m_torchingTrees   >= torchingTreesMin
         && m_torchingTrees   <= torchingTreesMax );
    assert( m_treeDbh         >= treeDbhMin
         && m_treeDbh         <= treeDbhMax );
    assert( m_treeHeight      >= treeHeightMin
         && m_treeHeight      <= treeHeightMax );
    assert( m_windSpeedAt20Ft >= windSpeedAt20FtMin
         && m_windSpeedAt20Ft <= windSpeedAt20FtMax );
    init();
    m_classVersion = spotTorchingTreesVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SpotTorchingTrees::~SpotTorchingTrees( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotTorchingTrees copy constructor.
    \param[in] right Reference to the SpotTorchingTrees from which to copy.
    \return Reference to the newly allocated SpotTorchingTrees.
 */

Sem::SpotTorchingTrees::SpotTorchingTrees( const SpotTorchingTrees &right ) :
    Signal()
{
    init();
    m_classVersion    = right.m_classVersion;
    m_coverHeight     = right.m_coverHeight;
    m_distance        = right.m_distance;
    m_elevation       = right.m_elevation;
    m_source          = right.m_source;
    m_species         = right.m_species;
    m_torchingTrees   = right.m_torchingTrees;
    m_treeDbh         = right.m_treeDbh;
    m_treeHeight      = right.m_treeHeight;
    m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
    m_firebrandHeight = right.m_firebrandHeight;
    m_flameHeight     = right.m_flameHeight;
    m_flameDuration   = right.m_flameDuration;
    m_flatSpottingDistance = right.m_flatSpottingDistance;
    m_mtnSpottingDistance = right.m_mtnSpottingDistance;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotTorchingTrees assignment operator.
    \param[in] right Reference to the SpotTorchingTrees from which to assign.
    \return Reference to the newly assigned SpotTorchingTrees.
 */

const Sem::SpotTorchingTrees& Sem::SpotTorchingTrees::operator=(
        const SpotTorchingTrees &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion    = right.m_classVersion;
        m_coverHeight     = right.m_coverHeight;
        m_distance        = right.m_distance;
        m_elevation       = right.m_elevation;
        m_source          = right.m_source;
        m_species         = right.m_species;
        m_torchingTrees   = right.m_torchingTrees;
        m_treeDbh         = right.m_treeDbh;
        m_treeHeight      = right.m_treeHeight;
        m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
        m_firebrandHeight = right.m_firebrandHeight;
        m_flameHeight     = right.m_flameHeight;
        m_flameDuration   = right.m_flameDuration;
        m_flatSpottingDistance = right.m_flatSpottingDistance;
        m_mtnSpottingDistance = right.m_mtnSpottingDistance;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SpotTorchingTrees::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SpotTorchingTrees::classVersion( void ) const
{
    return( spotTorchingTreesVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the mean treetop/vegetation cover height
    along the firebrand path.

    \return Mean treetop/vegetation cover height along the firebrand path (ft).
 */

double Sem::SpotTorchingTrees::coverHeight( void ) const
{
    return( m_coverHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to lofted firebrand height.

    \return Lofted firebrand height (ft).
 */

double Sem::SpotTorchingTrees::firebrandHeight( void ) const
{
    checkUpdate();
    return( m_firebrandHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to the steady flame height from torching trees.

    \return Steady flame height from torhing trees (ft).
 */

double Sem::SpotTorchingTrees::flameHeight( void ) const
{
    checkUpdate();
    return( m_flameHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to the steady flame duration from torching trees.

    \return Steady flame duration from torching trees (dl).
 */

double Sem::SpotTorchingTrees::flameDuration( void ) const
{
    checkUpdate();
    return( m_flameDuration );
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum flat terrain spotting distance (mi).

    \return Maximum flat terrain spotting distance (mi).
 */

double Sem::SpotTorchingTrees::flatTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_flatSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SpotTorchingTrees::init( void ) const
{
    m_firebrandHeight      = 0.0;
    m_flameHeight          = 0.0;
    m_flameDuration        = 0.0;
    m_flatSpottingDistance = 0.0;
    m_mtnSpottingDistance  = 0.0;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum moutainous terrain spotting distance (mi).

    \return Maximum mountainous terrain spotting distance (mi).
 */

double Sem::SpotTorchingTrees::mountainTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_mtnSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley horizontal distance (mi).

    \return Ridgetop-to-valley horizontal distance (mi).
 */

double Sem::SpotTorchingTrees::ridgetopToValleyDistance( void ) const
{
    return( m_distance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley elevation difference (ft).

    \return Ridgetop-to-valley elevation difference (ft).
 */

double Sem::SpotTorchingTrees::ridgetopToValleyElevation( void ) const
{
    return( m_elevation );
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean treetop/vegetation cover height
    along the firebrand path.

    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
 */

void Sem::SpotTorchingTrees::setCoverHeight( double coverHeight )
{
    assert( coverHeight >= coverHeightMin
         && coverHeight <= coverHeightMax );
    if ( coverHeight != m_coverHeight )
    {
        m_coverHeight = coverHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the torching tree spotting source Sem::SpotSource.

    \param[in] source Torching tree spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
 */

void Sem::SpotTorchingTrees::setSource( Sem::SpotAlgorithm::SpotSource source )
{
    if ( source != m_source )
    {
        m_source = source;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the torching tree species source Sem::SpotSpecies.

    \param[in] species Torching tree species Sem::Species.
        - SpotSpeciesEngelmannSpruce
        - SpotSpeciesDouglasFir
        - SpotSpeciesSubalpineFir
        - SpotSpeciesWesternHemlock
        - SpotSpeciesPonderosaPine
        - SpotSpeciesLodgepolePine
        - SpotSpeciesWesternWhitePine
        - SpotSpeciesGrandFir
        - SpotSpeciesBalsamFir
        - SpotSpeciesSlashPine
        - SpotSpeciesLongleafPine
        - SpotSpeciedsPondPine
        - SpotSpeciesShortleafPine
        - SpotSpeciesLoblollyPine
 */

void Sem::SpotTorchingTrees::setSpecies( Sem::SpotAlgorithm::SpotSpecies species )
{
    if ( species != m_species )
    {
        m_species = species;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley horizontal distance.

    \param[in] distance Ridgetop-to-valley horizontal distance (0-4 mi).
 */

void Sem::SpotTorchingTrees::setRidgetopToValleyDistance( double distance )
{
    assert( distance >= ridgetopToValleyDistanceMin
         && distance <= ridgetopToValleyDistanceMax );
    if ( distance != m_distance )
    {
        m_distance = distance;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley elevation difference.

    \param[in] elevation Ridgetop-to-valley elevation difference (0-4000 ft).
 */

void Sem::SpotTorchingTrees::setRidgetopToValleyElevation( double elevation )
{
    assert( elevation >= ridgetopToValleyElevationMin
         && elevation <= ridgetopToValleyElevationMax );
    if ( elevation != m_elevation )
    {
        m_elevation = elevation;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the number of torching trees.

    \param[in] torchingTrees Number of torching trees (0-30).
 */

void Sem::SpotTorchingTrees::setTorchingTrees( double torchingTrees )
{
    assert( torchingTrees >= torchingTreesMin
         && torchingTrees <= torchingTreesMax );
    if ( torchingTrees != m_torchingTrees )
    {
        m_torchingTrees = torchingTrees;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the torching tree dbh.

    \param[in] treeDbh Torching tree dbh (5-40 in.
 */

void Sem::SpotTorchingTrees::setTreeDbh( double treeDbh )
{
    assert( treeDbh >= treeDbhMin
         && treeDbh <= treeDbhMax );
    if ( treeDbh != m_treeDbh )
    {
        m_treeDbh = treeDbh;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the torching tree height.

    \param[in] treeHeight Torching tree height (10-300 ft).
 */

void Sem::SpotTorchingTrees::setTreeHeight( double treeHeight )
{
    assert( treeHeight >= treeHeightMin
         && treeHeight <= treeHeightMax );
    if ( treeHeight != m_treeHeight )
    {
        m_treeHeight = treeHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind speed at 20 ft.

    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
 */

void Sem::SpotTorchingTrees::setWindSpeedAt20Ft( double windSpeedAt20Ft )
{
    assert( windSpeedAt20Ft >= windSpeedAt20FtMin
         && windSpeedAt20Ft <= windSpeedAt20FtMax );
    if ( windSpeedAt20Ft != m_windSpeedAt20Ft )
    {
        m_windSpeedAt20Ft = windSpeedAt20Ft;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the torching trees Sem::SpotSource location.

    \return Torching trees spotting source Sem::SpotSource location.
 */

Sem::SpotAlgorithm::SpotSource Sem::SpotTorchingTrees::source( void ) const
{
    return( m_source );
}

//------------------------------------------------------------------------------
/*! \brief Access to the torching trees Sem::SpotSpecies.

    \return Torching trees spotting source Sem::SpotSpecies.
 */

Sem::SpotAlgorithm::SpotSpecies Sem::SpotTorchingTrees::species( void ) const
{
    return( m_species );
}

//------------------------------------------------------------------------------
/*! \brief Access to the number of torching trees.

    \return Number of torching trees.
 */

double Sem::SpotTorchingTrees::torchingTrees( void ) const
{
    return( m_torchingTrees );
}

//------------------------------------------------------------------------------
/*! \brief Access to the torching tree dbh.

    \return Torching tree dbh (in).
 */

double Sem::SpotTorchingTrees::treeDbh( void ) const
{
    return( m_treeDbh );
}

//------------------------------------------------------------------------------
/*! \brief Access to the torching tree height.

    \return Torching tree height (ft).
 */

double Sem::SpotTorchingTrees::treeHeight( void ) const
{
    return( m_treeHeight );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access METHODS to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SpotTorchingTrees::update( void ) const
{
    // Initialize all mutables
    init();

    m_flameHeight = Sem::SpotAlgorithm::steadyFlameHeightFromTorchingTrees(
        m_species, m_treeDbh, m_torchingTrees );

    m_flameDuration = Sem::SpotAlgorithm::steadyFlameDurationFromTorchingTrees(
        m_species, m_treeDbh, m_torchingTrees );

    m_firebrandHeight = Sem::SpotAlgorithm::firebrandHeightFromTorchingTrees(
        m_treeHeight, m_flameHeight, m_flameDuration );

    m_flatSpottingDistance = 
        Sem::SpotAlgorithm::flatTerrainSpotDistanceFromTorchingTrees(
            m_firebrandHeight, m_windSpeedAt20Ft, m_coverHeight );

    m_mtnSpottingDistance = Sem::SpotAlgorithm::mountainTerrainSpotDistance(
        m_flatSpottingDistance, m_source, m_distance, m_elevation );

    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at 20 ft.

    \return Wind speed at 20 ft (mi/h).
 */

double Sem::SpotTorchingTrees::windSpeedAt20Ft( void ) const
{
    return( m_windSpeedAt20Ft );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SpotTorchingTrees objects.

    \param[in] lhs Left-hand-side SpotTorchingTrees object.
    \param[in] rhs Right-hand-side SpotTorchingTrees object.
 */
bool Sem::operator ==( const Sem::SpotTorchingTrees &lhs,
                       const Sem::SpotTorchingTrees &rhs )
{ 
  return( fabs( lhs.coverHeight() - rhs.coverHeight() ) < Smidgen
       && fabs( lhs.ridgetopToValleyDistance() - rhs.ridgetopToValleyDistance() ) < Smidgen
       && fabs( lhs.ridgetopToValleyElevation() - rhs.ridgetopToValleyElevation() ) < Smidgen
       && lhs.source() == rhs.source()
       && lhs.species() == rhs.species()
       && fabs( lhs.torchingTrees() - rhs.torchingTrees() ) < Smidgen
       && fabs( lhs.treeDbh() - rhs.treeDbh() ) < Smidgen
       && fabs( lhs.treeHeight() - rhs.treeHeight() ) < Smidgen
       && fabs( lhs.windSpeedAt20Ft() - rhs.windSpeedAt20Ft() ) < Smidgen );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SpotTorchingTrees objects.

    \param[in] lhs Left-hand-side SpotTorchingTrees object.
    \param[in] rhs Right-hand-side SpotTorchingTrees object.
 */
bool Sem::operator !=( const Sem::SpotTorchingTrees &lhs,
                       const Sem::SpotTorchingTrees &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SpotTorchingTrees.cpp
//------------------------------------------------------------------------------

