//------------------------------------------------------------------------------
/*! \file IgnitionAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

// Custom header files
#include "IgnitionAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Calculates the probability of a firebrand starting a fire.
  
    \param[in] fuelTemperature  Dead surface fuel temperature (oF).
    \param[in] fuelMoisture     Dead surface fuel moisture content (lb/lb).
  
    \return Probability of a firebrand starting a fire [0..1].
 */

double Sem::IgnitionAlgorithm::firebrandIgnitionProbability(
            double fuelTemperature,
            double fuelMoisture )
{
    double fuelTemp = ( fuelTemperature - 32. ) * 5. / 9.;
    double qign = 144.51
                - 0.26600 * fuelTemp
                - 0.00058 * fuelTemp * fuelTemp
                - fuelTemp * fuelMoisture
                + 18.5400 * ( 1. - exp( -15.1 * fuelMoisture ) )
                + 640.000 * fuelMoisture;
    qign = ( qign > 400.0 ) ? 400. : qign;

    double x = 0.1 * ( 400. - qign );
    double prob = ( 0.000048 * pow( x, 4.3 ) ) / 50.;
    prob = ( prob > 1.0 ) ? 1.0 : prob;
    prob = ( prob < 0.0 ) ? 0.0 : prob;
    return( prob );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the probability of a lightning strike starting a fire.
  
    \param[in] fuelType Sem::LightningFuel, one of
        - LightningFuelPonderosaPineLitter    Ponderosa Pine Litter
        - LightningFuelPunkyWood              Punky wood, rotten, chunky
        - LightningFuelDeepPunkWoodPowder     Punky wood powder, deep (4.8 cm)
        - LightningFuelShallowPunkWoodPowder  Punk wood powder, shallow (2.4 cm)
        - LightningFuelLodgepolePineDuff      Lodgepole pine duff
        - LightningFuelDouglasFirDuff         Douglas-fir duff
        - LightningFuelHighAltitudeMixed      High altitude mixed (mainly Engelmann spruce)
        - LightningFuelPeatMoss               Peat moss (commercial)
    \param[in] fuelDepth    Ignition fuel bed depth (inches).
    \param[in] fuelMoisture Ignition fuel moisture content (lb/lb).
    \param[in] charge   Sem::LightningCharge, one of
                        0 == negative,
                        1 == positive,
                        2 == unknown
  
    \note  The following assumptions are made by Latham:
        - 20% of negative flashes have continuing current
        - 90% of positive flashes have continuing current
        - Latham and Schlieter found a relative frequency of
            0.723 negative and 0.277 positive strikes
        - Unknown strikes are therefore p = 0.1446 neg + 0.2493 pos
  
    \return Probability of the lightning strike starting a fire [0..1].
 */

double Sem::IgnitionAlgorithm::lightningIgnitionProbability(
            LightningFuel fuelType,
            double fuelDepth,
            double fuelMoisture,
            LightningCharge charge )
{
    // Probability of continuing current by charge type (Latham)
    static const double ccNeg = 0.2;
    static const double ccPos = 0.9;

    // Relative frequency by charge type (Latham and Schlieter)
    static const double freqNeg = 0.723;
    static const double freqPos = 0.277;

    // Convert duff depth to cm and restrict to maximum of 10 cm.
    fuelDepth *= 2.54;
    fuelDepth = ( fuelDepth > 10. ) ? 10.0 : fuelDepth;
    
    // Convert duff moisture to percent and restrict to maximum of 40%.
    fuelMoisture *= 100.;
    fuelMoisture = ( fuelMoisture > 40. ) ? 40. : fuelMoisture;

    // Ponderosa Pine Litter
    double pPos = 0.;
    double pNeg = 0.;
    double prob = 0.;
    if ( fuelType == LightningFuelPonderosaPineLitter )
    {
        pPos = 0.92 * exp( -0.087 * fuelMoisture );
        pNeg = 1.04 * exp( -0.054 * fuelMoisture );
    }
    // Punky wood, rotten, chunky
    else if ( fuelType == LightningFuelPunkyWood )
    {
        pPos = 0.44 * exp( -0.110 * fuelMoisture );
        pNeg = 0.59 * exp( -0.094 * fuelMoisture );
    }
    // Punky wood powder, deep (4.8 cm)
    else if ( fuelType == LightningFuelDeepPunkWoodPowder )
    {
        pPos = 0.86 * exp( -0.060 * fuelMoisture );
        pNeg = 0.90 * exp( -0.056 * fuelMoisture );
    }
    // Punk wood powder, shallow (2.4 cm)
    else if ( fuelType == LightningFuelShallowPunkWoodPowder )
    {
        pPos = 0.60 - ( 0.011 * fuelMoisture );
        pNeg = 0.73 - ( 0.011 * fuelMoisture );
    }
    // Lodgepole pine duff
    else if ( fuelType == LightningFuelLodgepolePineDuff )
    {
        pPos = 1. / ( 1. + exp( 5.13 - 0.68 * fuelDepth ) );
        pNeg = 1. / ( 1. + exp( 3.84 - 0.60 * fuelDepth ) );
    }
    // Douglas-fir duff
    else if ( fuelType == LightningFuelDouglasFirDuff )
    {
        pPos = 1. / ( 1. + exp( 6.69 - 1.39 * fuelDepth ) );
        pNeg = 1. / ( 1. + exp( 5.48 - 1.28 * fuelDepth ) );
    }
    // High altitude mixed (mainly Engelmann spruce)
    else if ( fuelType == LightningFuelHighAltitudeMixed )
    {
        pPos = 0.62 * exp( -0.050 * fuelMoisture );
        pNeg = 0.80 - ( 0.014 * fuelMoisture );
    }
    // Peat moss (commercial)
    else if ( fuelType == LightningFuelPeatMoss )
    {
        pPos = 0.71 * exp( -0.070 * fuelMoisture );
        pNeg = 0.84 * exp( -0.060 * fuelMoisture );
    }
    // Return requested result
    if ( charge == LightningChargeNegative )
    {
        prob = ccNeg * pNeg;
    }
    else if ( charge == LightningChargePositive )
    {
        prob = ccPos * pPos;
    }
    else if ( charge == LightningChargeUnknown )
    {
        prob = freqPos * ccPos * pPos
             + freqNeg * ccNeg * pNeg;
    }
    // Constrain result
    prob = ( prob < 0.0 ) ? 0.0 : prob;
    prob = ( prob > 1.0 ) ? 1.0 : prob;
    return( prob );
}

//------------------------------------------------------------------------------
//  End of IgnitionAlgorithm.cpp
//------------------------------------------------------------------------------

