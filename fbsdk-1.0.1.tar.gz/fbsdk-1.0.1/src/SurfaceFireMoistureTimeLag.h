//------------------------------------------------------------------------------
/*! \file SurfaceFireMoistureTimeLag.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireMoistureInterface for
    accessing and updating fuel particle moisture contents
    at a specific location and time.
 */

#ifndef _SURFACEFIREMOISTURETIMELAG_H_INCLUDED_
#define _SURFACEFIREMOISTURETIMELAG_H_INCLUDED_

// Custom header files
#include "Signal.h"
#include "SurfaceFireFuelAlgorithm.h"
#include "SurfaceFireMoistureInterface.h"

// Standard header files
#include <iostream>

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireMoistureTimeLag SurfaceFireMoistureTimeLag.h
    \brief A simple implementation of the SurfaceFireMoistureInterface for
    accessing and updating fuel particle moisture contents
    at a specific location and time.
 */

class SurfaceFireMoistureTimeLag : public SurfaceFireMoistureInterface
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireTimeLagVersion = 1; //!< Class version
// Valid property ranges
    static const double moisDeadMin;    //!< Minimum valid dead fuel moisture (lb/lb)
    static const double moisDeadMax;    //!< Maximum valid dead fuel moisture (lb/lb)
    static const double moisLiveMin;    //!< Minimum valid live fuel moisture (lb/lb)
    static const double moisLiveMax;    //!< Maximum valid live fuel moisture (lb/lb)

// Public interface
public:
    // Default constructor
    SurfaceFireMoistureTimeLag( void ) ;
    // Custom constructor
    SurfaceFireMoistureTimeLag( double dead1h, double dead10h, double dead100h,
        double dead1000h, double liveHerb, double liveWood ) ;
    // Virtual destructor
    virtual ~SurfaceFireMoistureTimeLag( void ) ;
    // Copy constructor
    SurfaceFireMoistureTimeLag( const SurfaceFireMoistureTimeLag & ) ;
    // Assignment operator
    const SurfaceFireMoistureTimeLag &operator=( const SurfaceFireMoistureTimeLag &rhs ) ;

    // Property access methods
    virtual const char *className( void ) const ;
    virtual int classVersion( void ) const ;
    double dead1h( void ) const ;
    double dead10h( void ) const ;
    double dead100h( void ) const ;
    double dead1000h( void ) const ;
    double liveHerb( void ) const ;
    double liveWood( void ) const ;
    double moisture(
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass type ) const ;

    // Property update methods
    void setDead1h( double fractionOdw ) ;
    void setDead10h( double fractionOdw ) ;
    void setDead100h( double fractionOdw ) ;
    void setDead1000h( double fractionOdw ) ;
    void setLiveHerb( double fractionOdw ) ;
    void setLiveWood( double fractionOdw ) ;

// Protected interface
protected:
    void init( void ) const ;
    virtual void update( void ) const ; // Must be reimpelemented by derived classes

// Private properties
private:
    double m_dead1h;        //!< 1-h time lag fuel moisture (fraction odw)
    double m_dead10h;       //!< 10-h time lag fuel moisture (fraction odw)
    double m_dead100h;      //!< 100-h time lag fuel moisture (fraction odw)
    double m_dead1000h;     //!< 1000-h time lag fuel moisture (fraction odw)
    double m_liveHerb;      //!< Live herbaceous fuel moisture (fraction odw)
    double m_liveWood;      //!< Live woody fuel moisture (fraction odw)
};

// Non-member equality operators
bool operator ==( const SurfaceFireMoistureTimeLag & a, const SurfaceFireMoistureTimeLag & b ) ;
bool operator !=( const SurfaceFireMoistureTimeLag & a, const SurfaceFireMoistureTimeLag & b ) ;

}

#endif  // _SURFACEFIREMOISTURETIMELAG_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireMoistureTimeLag.h
//------------------------------------------------------------------------------

