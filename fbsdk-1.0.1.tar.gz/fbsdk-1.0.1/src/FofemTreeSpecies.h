//------------------------------------------------------------------------------
/*! \file FofemTreeSpecies.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _FOFEMTREESPECIES_H_INCLUDED_
#define _FOFEMTREESPECIES_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class FofemTreeSpecies FofemTreeSpecies.h
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all fire ignition equations and
    algorithms.  These can be used to estimate ignition probabilities from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
 */

class FofemTreeSpecies
{
// Public enums
public:

//------------------------------------------------------------------------------
/*! \enum FofemSpecies
    \brief Indicates the type of tree species for BEHAVE-style bark thickness
    estimation.
 */

enum FofemSpecies
{
    FofemSpeciesABIAMA,
    FofemSpeciesABIBAL,
    FofemSpeciesABICON,
    FofemSpeciesABIGRA,
    FofemSpeciesABILAS,
    FofemSpeciesABIMAG,
    FofemSpeciesABIPRO,
    FofemSpeciesABISPP,
    FofemSpeciesACEBAR,
    FofemSpeciesACELEU,
    FofemSpeciesACEMAC,
    FofemSpeciesACENEG,
    FofemSpeciesACENIG,
    FofemSpeciesACEPEN,
    FofemSpeciesACERUB,
    FofemSpeciesACESACI,
    FofemSpeciesACESACU,
    FofemSpeciesACESPI,
    FofemSpeciesACESPP,
    FofemSpeciesAESGLA,
    FofemSpeciesAESOCT,
    FofemSpeciesAILALT,
    FofemSpeciesALNRHO,
    FofemSpeciesALNRUB,
    FofemSpeciesAMEARB,
    FofemSpeciesARBMEN,
    FofemSpeciesBETALL,
    FofemSpeciesBETLEN,
    FofemSpeciesBETNIG,
    FofemSpeciesBETOCC,
    FofemSpeciesBETPAP,
    FofemSpeciesBETSPP,
    FofemSpeciesCELOCC,
    FofemSpeciesCARAQU,
    FofemSpeciesCARCAR,
    FofemSpeciesCARCOR,
    FofemSpeciesCARGLA,
    FofemSpeciesCARILL,
    FofemSpeciesCARLAC,
    FofemSpeciesCAROVA,
    FofemSpeciesCARSPP,
    FofemSpeciesCARTEX,
    FofemSpeciesCARTOM,
    FofemSpeciesCASCHR,
    FofemSpeciesCASDEN,
    FofemSpeciesCATSPP,
    FofemSpeciesCELLAE,
    FofemSpeciesCERCAN,
    FofemSpeciesCHALAW,
    FofemSpeciesCHANOO,
    FofemSpeciesCHATHY,
    FofemSpeciesCORFLO,
    FofemSpeciesCORNUT,
    FofemSpeciesCORSPP,
    FofemSpeciesCRADOU,
    FofemSpeciesCRASPPW,
    FofemSpeciesCRASPPE,
    FofemSpeciesDIOVIR,
    FofemSpeciesFAGGRA,
    FofemSpeciesFRAAMA,
    FofemSpeciesFRANIG,
    FofemSpeciesFRAPEN,
    FofemSpeciesFRAPRO,
    FofemSpeciesFRAQUA,
    FofemSpeciesFRASPP,
    FofemSpeciesGLETRI,
    FofemSpeciesGORLAS,
    FofemSpeciesGYMDIO,
    FofemSpeciesHALSPP,
    FofemSpeciesILEOPA,
    FofemSpeciesJUGCIN,
    FofemSpeciesJUGNIG,
    FofemSpeciesJUNOCC,
    FofemSpeciesJUNSPP,
    FofemSpeciesJUNVIR,
    FofemSpeciesLARLAR,
    FofemSpeciesLARLYA,
    FofemSpeciesLAROCC,
    FofemSpeciesLIBDEC,
    FofemSpeciesLIQSTY,
    FofemSpeciesLIRTUL,
    FofemSpeciesLITDEN,
    FofemSpeciesMACPOM,
    FofemSpeciesMAGACU,
    FofemSpeciesMAGGRA,
    FofemSpeciesMAGMAC,
    FofemSpeciesMAGSPP,
    FofemSpeciesMAGVIR,
    FofemSpeciesMALPRU,
    FofemSpeciesMALSPP,
    FofemSpeciesMORALB,
    FofemSpeciesMORRUB,
    FofemSpeciesMORSPP,
    FofemSpeciesNYSAQU,
    FofemSpeciesNYSOGE,
    FofemSpeciesNYSSPP,
    FofemSpeciesNYSSYL,
    FofemSpeciesNYSSYLB,
    FofemSpeciesOSTVIR,
    FofemSpeciesOXYARB,
    FofemSpeciesPAUTOM,
    FofemSpeciesPERBOR,
    FofemSpeciesPICABI,
    FofemSpeciesPICENG,
    FofemSpeciesPICGLA,
    FofemSpeciesPICMAR,
    FofemSpeciesPICPUN,
    FofemSpeciesPICRUB,
    FofemSpeciesPICSIT,
    FofemSpeciesPICSPP,
    FofemSpeciesPINALB,
    FofemSpeciesPINATT,
    FofemSpeciesPINBAN,
    FofemSpeciesPINCLA,
    FofemSpeciesPINCON,
    FofemSpeciesPINECH,
    FofemSpeciesPINELL,
    FofemSpeciesPINFLE,
    FofemSpeciesPINGLA,
    FofemSpeciesPINJEF,
    FofemSpeciesPINLAM,
    FofemSpeciesPINMON,
    FofemSpeciesPINPAL,
    FofemSpeciesPINPON,
    FofemSpeciesPINPUN,
    FofemSpeciesPINRES,
    FofemSpeciesPINRIG,
    FofemSpeciesPINSAB,
    FofemSpeciesPINSER,
    FofemSpeciesPINSPP,
    FofemSpeciesPINSTR,
    FofemSpeciesPINSYL,
    FofemSpeciesPINTAE,
    FofemSpeciesPINVIR,
    FofemSpeciesPLAOCC,
    FofemSpeciesPOPBAL,
    FofemSpeciesPOPDEL,
    FofemSpeciesPOPGRA,
    FofemSpeciesPOPHET,
    FofemSpeciesPOPSPP,
    FofemSpeciesPOPTRI,
    FofemSpeciesPRUAME,
    FofemSpeciesPRUEMA,
    FofemSpeciesPRUDEN,
    FofemSpeciesPRUSER,
    FofemSpeciesPRUSPP,
    FofemSpeciesPRUVIR,
    FofemSpeciesPSEMEN,
    FofemSpeciesQUEAGR,
    FofemSpeciesQUEALB,
    FofemSpeciesQUEBIC,
    FofemSpeciesQUECHR,
    FofemSpeciesQUEOCC,
    FofemSpeciesQUEDOU,
    FofemSpeciesQUEELL,
    FofemSpeciesQUEENG,
    FofemSpeciesQUEFAL,
    FofemSpeciesQUEGAR,
    FofemSpeciesQUEIMB,
    FofemSpeciesQUEINC,
    FofemSpeciesQUEKEL,
    FofemSpeciesQUELAE,
    FofemSpeciesQUELAU,
    FofemSpeciesQUELOB,
    FofemSpeciesQUELYR,
    FofemSpeciesQUEMAC,
    FofemSpeciesQUEMAR,
    FofemSpeciesQUEMIC,
    FofemSpeciesQUEMUE,
    FofemSpeciesQUENIG,
    FofemSpeciesQUENUT,
    FofemSpeciesQUEPAL,
    FofemSpeciesQUEPHE,
    FofemSpeciesQUEPRI,
    FofemSpeciesQUERUB,
    FofemSpeciesQUESHU,
    FofemSpeciesQUESPP,
    FofemSpeciesQUESTE,
    FofemSpeciesQUEVEL,
    FofemSpeciesQUEVIR,
    FofemSpeciesQUEWIS,
    FofemSpeciesROBPSE,
    FofemSpeciesSALDIA,
    FofemSpeciesSALNIG,
    FofemSpeciesSALSPP,
    FofemSpeciesSASALB,
    FofemSpeciesSEQGIG,
    FofemSpeciesSEQSEM,
    FofemSpeciesSORAME,
    FofemSpeciesTAXBRE,
    FofemSpeciesTAXDIS,
    FofemSpeciesTAXDISN,
    FofemSpeciesTHUOCC,
    FofemSpeciesTHUPLI,
    FofemSpeciesTHUSPP,
    FofemSpeciesTILAME,
    FofemSpeciesTILHET,
    FofemSpeciesTSUCAN,
    FofemSpeciesTSUHET,
    FofemSpeciesTSUMER,
    FofemSpeciesULMALA,
    FofemSpeciesULMAME,
    FofemSpeciesULMPUM,
    FofemSpeciesULMRUB,
    FofemSpeciesULMSPP,
    FofemSpeciesULMTHO,
    FofemSpeciesUMBCAL
};
const static int FofemSpeciesEnums = 207;   //!< Number of FOFEM tree species

// Public interface
public:
    static int         barkEquationIndex( FofemSpecies species ) ;

    static const char* commonName( FofemSpecies species ) ;

    static const char* genusSpeciesCode( FofemSpecies species ) ;
    
    static int         mortalityEquationIndex( FofemSpecies species ) ;

    static const char* regions( FofemSpecies species ) ;

    static const char* scientificName( FofemSpecies species ) ;

};

}   // End of namespace Sem

#endif  // _FOFEMTREESPECIES_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of FofemTreeSpecies.h
//------------------------------------------------------------------------------

