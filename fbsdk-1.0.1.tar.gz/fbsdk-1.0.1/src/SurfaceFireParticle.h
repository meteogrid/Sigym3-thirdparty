//------------------------------------------------------------------------------
/*! \file SurfaceFireParticle.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of the SurfaceFireParticleInterface that follows
    the implementations of Rothermel, Albini, BEHAVE, BehavePlus, etc.
 */

#ifndef _SURFACEFIREPARTICLE_H_
#define _SURFACEFIREPARTICLE_H_

// Configuration
#include "Signal.h"
#include "SurfaceFireFuelAlgorithm.h"
#include "SurfaceFireParticleInterface.h"

// Namespaces
namespace Sem
{

// Forward class references
class SurfaceFireMoistureInterface;

//------------------------------------------------------------------------------
/*! \class SurfaceFireParticle SurfaceFireParticle.h
    \brief An implementation of the SurfaceFireParticleInterface that follows
    the implementations of Rothermel, Albini, BEHAVE, BehavePlus, etc.

    SurfaceFireParticle represents a specific type of surface fuel.
    Properties include size, height, density, low heat of combustion,
    dead and live load, dead and live moisture content, and total and
    effective silica content.
    
    A SurfaceFireFuelModel is usually composed of one or more
    SurfaceFireParticle instances.

    Normally all the particle properties are defined at construction time and
    seldom updated.
    Important exceptions are dead and live moisture content, which are updated
    as frequently as may be required by the application.
    For so-called "dynamic" fuel models, some load may be transferred from
    the live to the dead component based upon the live moisture content.
    Dynamic fuel load transfer behavior is governed by the cureAlgorithm
    property.

    Anytime a property is updated via one of the set<Property>() methods,
    a valueChanged() signal is emitted and the dirty flag is set.

    Anytime a property is accessed, the dirty flag is first checked,
    and if it is set, update() is called, the dirty flag is cleared,
    and the requested property is then returned.
    This allows for "lazy update" of dependent properties; they are only
    updated when requested.
 */

class SurfaceFireParticle : public SurfaceFireParticleInterface
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireParticleVersion = 1;    //!< Class version
// Valid property ranges
    static const double condMin;        //!< Minimum valid thermal conductance (Btu/s/ft/oF)
    static const double condMax;        //!< Maximum valid thermal conductance (Btu/s/ft/oF)
    static const double densityMin;     //!< Minimum valid density (lb/ft3)
    static const double densityMax;     //!< Maximum valid density (lb/ft3)
    static const double endtMin;        //!< Minimum valid char end pyrolisis temperature (oF)
    static const double endtMax;        //!< Maximum valid char end pyrolisis temperature (oF)
    static const double hcapMin;        //!< Minimum valid heat capacity (Btu/lb/oF)
    static const double hcapMax;        //!< Maximum valid heat capacity (Btu/lb/oF)
    static const double heatMin;        //!< Minimum valid heat of combustion (Btu/lb)
    static const double heatMax;        //!< Maximum valid heat of combustion (Btu/lb)
    static const double heightMin;      //!< Minimum valid fuel height (ft)
    static const double heightMax;      //!< Maximum valid fuel height (ft)
    static const double igntMin;        //!< Minimum valid ignition temperature (oF)
    static const double igntMax;        //!< Maximum valid ignition temperature (oF)
    static const double loadDeadMin;    //!< Minimum valid dead fuel load (lb/ft2)
    static const double loadDeadMax;    //!< Maximum valid dead fuel load (lb/ft2)
    static const double loadLiveMin;    //!< Minimum valid live fuel load (lb/ft2)
    static const double loadLiveMax;    //!< Maximum valid live fuel load (lb/ft2)
    static const double moisDeadMin;    //!< Minimum valid dead fuel moisture (lb/lb)
    static const double moisDeadMax;    //!< Maximum valid dead fuel moisture (lb/lb)
    static const double moisLiveMin;    //!< Minimum valid live fuel moisture (lb/lb)
    static const double moisLiveMax;    //!< Maximum valid live fue moisture (lb/lb)
    static const double savrMin;        //!< Minimum valid surface area-to-volume ratio (ft2/ft3)
    static const double savrMax;        //!< Maximum valid surface area-to-volume ratio (ft2/ft3)
    static const double seffMin;        //!< Minimum valid effective silica content (lb/lb)
    static const double seffMax;        //!< Maximum valid effective silica content (lb/lb)
    static const double stotMin;        //!< Minimum valid total silica content (lb/lb)
    static const double stotMax;        //!< Maximum valid total silica content (lb/lb)

// Public interface
public:
    // Default constructor
    SurfaceFireParticle( void ) ;
    // Custom constructor
    SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClass,
        Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm cureAlgorithm,
        double savr,                //!< Fuel particle surface area to volume ratio (ft2/ft3) [input].
        double height,              //!< Fuel particle height above the surface (ft).
        double loadDead=0.0,        //!< Fuel particle dead load (lb/ft2) [input].
        double loadLive=0.0,        //!< Fuel particle live load (lb/ft2) [input].
        double moisDead=0.1,        //!< Fuel particle dead moisture content (fraction odw).
        double moisLive=3.0,        //!< Fuel particle live moisture content (fraction odw).
        double heat=8000.0,         //!< Fuel particle low heat of combustion (Btu/lb) [input].
        double dens=32.,            //!< Fuel particle density (lb/ft3) [input].
        double stot=0.0555,         //!< Fuel particle total silica content (lb si/lb fuel) [input].
        double seff=0.01,           //!< Fuel particle effective silica content (lb si/lb fuel) [input].
        double capacity=0.596654,   //!< Fuel particle heat capacity used by BurnUp (Btu/lb/oF, == 2500 J/kg/oK) [input].
        double conductance=2.68485e-5,  //!< Fuel particle thermal conductance used by BurnUp (Btu/s/ft/oF == 0.13 W/b/oK [input].
        double ignitionTemp=620.33,     //!< Fuel particle ignition temperature used by Burnup (oF == 600 oK).
        double endPyrolisisTemp=710.33  //!< Fuel particle char end pyrolisis temperature used by Burnup (oF == 650 oK).
    );
    // Virtual destructor
    virtual ~SurfaceFireParticle( void ) ;
    // Copy constructor
    SurfaceFireParticle( const SurfaceFireParticle &right ) ;
    // Assignment operator
    const SurfaceFireParticle& operator=( const SurfaceFireParticle &right ) ;
    // Clone
    SurfaceFireParticle* clone( void ) const ;

    // Property access methods
    Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm cureAlgorithm( void ) const ;
    const char *className( void ) const ;
    int     classVersion( void ) const ;
    double  cured( void ) const ;
    double  density( void ) const ;
    double  endPyrolisisTemperature( void ) const ;
    bool    hasLiveHerb( void ) const ;
    bool    hasLiveWood( void ) const ;
    double  heatCapacity( void ) const ;
    double  heatOfCombustion( void ) const ;
    double  height( void ) const ;
    double  ignitionTemperature( void ) const ;
    double  loadDead( void ) const ;
    double  loadLive( void ) const ;
    Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClass( void ) const ;
    Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClassDead( void ) const ;
    Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClassLive( void ) const ;
    double  moistureDead( void ) const ;
    double  moistureLive( void ) const ;
    double  savr( void ) const ;
    double  siEffective( void ) const ;
    double  siTotal( void ) const ;
    double  thermalConductance( void ) const ;

    // Property update methods
    void setDensity( double density ) ;
    void setEndPyrolisisTemperature( double endt ) ;
    void setHeatCapacity( double hcap ) ;
    void setHeatOfCombustion( double heat ) ;
    void setIgnitionTemperature( double ignt ) ;
    void setMoisture( const SurfaceFireMoistureInterface& sfm ) ;
    void setMoisture( const SurfaceFireMoistureInterface* sfm ) ;
    void setMoistureDead( double fractionOdw ) ;
    void setMoistureLive( double fractionOdw ) ;
    void setSurfaceAreaToVolumeRatio( double savr ) ;
    void setThermalConductance( double cond ) ;

// Protected interface
protected:
    void init( void ) const ;
    virtual void update( void ) const ; // Must be reimpelemented by derived classes
    void updateLoad( void ) const ;

// Private properties
private:
    double m_cond;                  //!< Fuel particle thermal conductance used by BurnUp (Btu/s/ft/oF).
    Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm m_cureAlgorithm; //!< Fuel particle dead-to-live load transfer algorithm.
    double m_dens;                  //!< Fuel particle density (lb/ft3) [input]
    double m_endt;                  //!< Fuel particle char end pyrolisis temperature used by Burnup (oF).
    double m_hcap;                  //!< Fuel particle heat capacity used by BurnUp (Btu/lb/oF).
    double m_heat;                  //!< Fuel particle heat of combustion (Btu/lb).
    double m_height;                //!< Fuel particle height (ft).
    double m_ignt;                  //!< Fuel particle ignition temperature used by Burnup (oF).
    mutable double m_loadDead;      //!< Dead fuel particle load (lb/ft2) [input]
    mutable double m_loadLive;      //!< Live fuel particle load (lb/ft2) [input]
    Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass m_moistureClass;   //!< Fuel particle moisture class assignment.
    double m_moisDead;              //!< Dead fuel particle load (fraction owd) [input]
    double m_moisLive;              //!< Live fuel particle load (fraction odw) [input]
    double m_savr;                  //!< Fuel particle surface area-to-volume ratio (ft2/ft3) [input]
    double m_seff;                  //!< Fuel particle effective (silica-free) mineral content (lb minerals/lb fuel) [constant]
    double m_stot;                  //!< Fuel particle total mineral content (lb minerals/lb fuel) [constant]
};

// Non-member equality operators
bool operator ==( const SurfaceFireParticle& a, const SurfaceFireParticle& b ) ;
bool operator !=( const SurfaceFireParticle& a, const SurfaceFireParticle& b ) ;

}       // End of namespace Sem

#endif  // _SURFACEFIREPARTICLE_H_

//------------------------------------------------------------------------------
//  End of SurfaceFireParticle.h
//------------------------------------------------------------------------------

