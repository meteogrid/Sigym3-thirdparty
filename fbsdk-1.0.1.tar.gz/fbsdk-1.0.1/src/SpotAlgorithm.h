//------------------------------------------------------------------------------
/*! \file SpotAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire spotting distance fuel algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _SPOTALGORITHM_H_INCLUDED_
#define _SPOTALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SpotAlgorithm SpotAlgorithm.h
    \brief All fire spotting distance fuel algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all spotting distance equations and
    algorithms.  These can be used to estimate spotting distance from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
    
    Additional structure, state, and framework is provided by the
    SpotBurningPile, SpotSurfaceFire, and SpotTorchingTrees classes,
    which require linking to the the QtCore library for signals/slots,
    multi-threading, etc.
 */

class SpotAlgorithm
{
// Public enums
public:

//------------------------------------------------------------------------------
/*! \enum SpotSource
    \brief Indicates the firebrand source location in the terrain.
 */

enum SpotSource
{
    SpotSourceMidslopeWindward = 0, //!< Midslope, windward side of slope
    SpotSourceValleyBottom     = 1, //!< Valley bottom
    SpotSourceMidslopeLeeward  = 2, //!< Midslope, leeward side
    SpotSourceRidgetop         = 3  //!< Ridgetop
};

//------------------------------------------------------------------------------
/*! \enum SpotSpecies
    \brief Indicates the tree species for spotting from torching trees.
 */

enum SpotSpecies
{
    SpotSpeciesEngelmannSpruce  =  0,
    SpotSpeciesDouglasFir       =  1,
    SpotSpeciesSubalpineFir     =  2,
    SpotSpeciesWesternHemlock   =  3,
    SpotSpeciesPonderosaPine    =  4,
    SpotSpeciesLodgepolePine    =  5,
    SpotSpeciesWesternWhitePine =  6,
    SpotSpeciesGrandFir         =  7,
    SpotSpeciesBalsamFir        =  8,
    SpotSpeciesSlashPine        =  9,
    SpotSpeciesLongleafPine     = 10,
    SpotSpeciedsPondPine        = 11,
    SpotSpeciesShortleafPine    = 12,
    SpotSpeciesLoblollyPine     = 13
};
const static int SpotSpeciesCount = 14; //!< Number of SpotSpecies enums

// Public interface
public:
    static double criticalCoverHeight(
            double firebrandHeight,
            double coverHeight );

    static double firebrandHeightFromBurningPile( double flameHeight ) ;

    static double firebrandHeightFromSurfaceFire(
            double flameLength,
            double windSpeedAt20Ft ) ;

    static double firebrandHeightFromTorchingTrees(
            double treeHeight,
            double flameHeight,
            double flameDuration ) ;

    static double flatTerrainSpotDistanceFromBurningPile(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight ) ;

    static double flatTerrainSpotDistanceFromSurfaceFire(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight ) ;

    static double flatTerrainSpotDistanceFromTorchingTrees(
            double firebrandHeight,
            double windSpeedAt20Ft,
            double coverHeight ) ;

    static double mountainTerrainSpotDistance(
            double flatSpotDistance,
            SpotSource source,
            double ridgetopToValleyDistance,
            double ridgetopToValleyElevation ) ;

    static double steadyFlameDurationFromTorchingTrees(
            SpotSpecies treeSpecies,
            double treeDbh,
            double torchingTrees ) ;

    static double steadyFlameHeightFromTorchingTrees(
            SpotSpecies treeSpecies,
            double treeDbh,
            double torchingTrees ) ;
};

}   // End of namespace Sem

#endif  // _SPOTALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SpotAlgorithm.h
//------------------------------------------------------------------------------

