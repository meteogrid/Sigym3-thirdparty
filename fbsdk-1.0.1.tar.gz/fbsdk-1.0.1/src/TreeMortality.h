//------------------------------------------------------------------------------
/*! \file TreeMortality.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of the FOFEM tree mortality model.
 */

#ifndef _TREEMORTALITY_H_INCLUDED_
#define _TREEMORTALITY_H_INCLUDED_

// Custom header files
#include "Signal.h"
#include "TreeMortalityAlgorithm.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class TreeMortality TreeMortality.h
    \brief An implementation of the FOFEM tree mortality model.

    TreeMortality uses the tree species, height, and crown ratio along with a
    scorch height to determine the length of crown scorched, crown volume
    scorched, and probability of mortality.  The FOFEM model supports
    over 200 species listed in FofemTreeSpecies.h.
    
    The default constructor TreeMortality() creates an uninteresting state
    that can be manipulated be setting independent properties:
        - void setScorchHeight( double scorchHeight ) ;
        - void setSpecies( FofemSpecies species ) ;
        - void setTreeCrownRatio( double treeCrownRatio ) ;
        - void setTreeDbh( double treeDbh ) ;
        - void setTreeHeight( double treeHeight ) ;
    Conversely, the custom TreeMortality() constructor may be invoked to set
    all these properties at object creation.

    After setting any one or more of these properties, you can query any of
    the dependent property results:
        - double barkThickness( void ) const;
        - double crownLengthScorched( void ) const;
        - double crownVolumeScorched( void ) const;
        - double mortalityProbability( void ) const;

    Whenever an independent property is updated, a dirty flag is set.
    Whenever a dependent property is accessed, the dirty flag is check,
    and all necessary updates are performed before the dependent value is
    returned.  The alleviates programmers from having to remember to invoke
    update routines at appropriate times, and enables 'lazy updating' of
    dependent properties; they only get updated when they are requested.
 */

class TreeMortality : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int treeMortalityVersion = 1;  //!< Class version
// Property ranges
    static const double scorchHeightMin;    //!< Minimum valid scorch height (ft)
    static const double scorchHeightMax;    //!< Maximum valid scorch height (ft)
    static const double treeCrownRatioMin;  //!< Minimum valid crown ratio (dl)
    static const double treeCrownRatioMax;  //!< Maximum valid crown ratio (dl)
    static const double treeDbhMin;         //!< Minimum valid tree dbh (in)
    static const double treeDbhMax;         //!< Maximum valid tree dbh (in)
    static const double treeHeightMin;      //!< Minimum valid tree height (ft)
    static const double treeHeightMax;      //!< Maximum valid tree height (ft)

// Public interface
public:
    // Default constructor
    TreeMortality( void ) ;
    // Custom constructors
    TreeMortality(
            Sem::FofemTreeSpecies::FofemSpecies species,
            double treeHeight,
            double treeCrownRatio,
            double treeDbh,
            double scorchHeight );
    // Virtual destructor
    virtual ~TreeMortality( void ) ;
    // Copy constructor
    TreeMortality( const TreeMortality &rhs ) ;
    // Assignment operator
    const TreeMortality &operator=( const TreeMortality &rhs ) ;

    // Property access methods
    const char *className( void ) const ;
    int classVersion( void ) const ;
    double scorchHeight( void ) const;
    double treeDbh( void ) const;
    double treeCrownRatio( void ) const;
    double treeHeight( void ) const;
    Sem::FofemTreeSpecies::FofemSpecies species( void ) const ;

    // Intermediates access methods
    double barkThickness( void ) const;
    double crownLengthScorched( void ) const;
    double crownVolumeScorched( void ) const;
    double mortalityProbability( void ) const;

    // Property update methods
    void setScorchHeight( double scorchHeight ) ;
    void setSpecies( Sem::FofemTreeSpecies::FofemSpecies species ) ;
    void setTreeCrownRatio( double treeCrownRatio ) ;
    void setTreeDbh( double treeDbh ) ;
    void setTreeHeight( double treeHeight ) ;

// Must be re-implemented by derived classes
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;

// Protected properties
protected:
    double m_scorchHeight;      //!< Mean scorch height (10-300 ft).
    double m_treeCrownRatio;    //!< Ratio of crown length to tree height (ft/ft).
    double m_treeDbh;           //!< Tree diameter-at-breast height (5-40 in).
    double m_treeHeight;        //!< Total tree height (ft).
    Sem::FofemTreeSpecies::FofemSpecies m_species;     //!< Sem::FofemSpecies code.
    mutable double m_barkThickness;         //!< Tree bark thickness (in).
    mutable double m_crownLengthScorched;   //!< Crown length scorched (ft).
    mutable double m_crownVolumeScorched;   //!< Fraction of crown volume scorched (dl).
    mutable double m_mortalityProbability;  //!< Probability of mortality (dl).
};

// Non-member equality operators
bool operator ==( const TreeMortality & a, const TreeMortality & b ) ;
bool operator !=( const TreeMortality & a, const TreeMortality & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of TreeMortality.h
//------------------------------------------------------------------------------

