//------------------------------------------------------------------------------
/*! \file SurfaceFireFuel.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of the SurfaceFireFuelInterface applying the
    classic Rothermel/Albini (BEHAVE/BehavePlus) algorithms.
 */

#ifndef _SURFACEFIREFUEL_H_INCLUDED_
#define _SURFACEFIREFUEL_H_INCLUDED_

// Custom include files
#include "SurfaceFireFuelInterface.h"
#include "SurfaceFireMoistureInterface.h"
#include "SurfaceFireParticleInterface.h"

// Qt include files
#include <QVector>

namespace Sem
{

// Forward class references
class SurfaceFireParticleInterface;

//------------------------------------------------------------------------------
/*! \typedef SurfaceFireParticleVector
 *  \brief QVector container of QPointers to SurfaceFireParticleInterface objects.
 */

typedef QVector< SurfaceFireParticleInterface* > SurfaceFireParticleVector;

//------------------------------------------------------------------------------
/*! \class SurfaceFireFuel SurfaceFireFuel.h
    \brief An implementation of the SurfaceFireFuelInterface applying the
    classic Rothermel/Albini (BEHAVE/BehavePlus) algorithms.

    This SurfaceFireFuel class is derived from SurfaceFireFuelInterface and
    implements the traditional Rothermel fire model algorithms with additional
    methods for accessing intermediate variables and debugging.
    It is able to construct the state information required to make fire
    behavior estimates in cooperation with a SurfaceFireSpread object.
    
    SurfaceFireFuel contains pointers to one or more objects that implement
    the SurfaceFireParticleInterface.
    The SurfaceFireFuel queries each SurfaceFireParticleInterface object as
    needed to construct the fuel bed.

    Note that the SurfaceFireParticleInterface objects contained in
    SurfaceFireFuel may be direct and simple, as in the case of a standard
    fire behavior fuel model factory, or more complex, such as biome
    descriptions or landscape bio simulations.

    SurfaceFireFuel also contains a pointer to single object implementing
    the SurfaceFireMoistureInterface.
    This is required to provide the SurfaceFireParticleInterface objects
    with updated moisture state.
    Again, the SurfaceFireMoistureInterface object may be simple and direct,
    as in the case of the SurfaceFireMoistureTimeLag class, or a more
    complex simulation such as the SurfaceFireMoistureStick class.
 */

class SurfaceFireFuel : public SurfaceFireFuelInterface
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireFuelVersion = 1;    //!< Class id
// Valid property ranges
    static const double mextDeadMin;    //!< Minimum valid dead fuel extinction moisture (lb/lb)
    static const double mextDeadMax;    //!< Maximum valid dead fuel extinction moisture (lb/lb)

// Public interface
public:
    // Default constructor
    SurfaceFireFuel( void ) ;
    // Custom constructor
    SurfaceFireFuel( double mextDead, SurfaceFireMoistureInterface* moisture=0 );
    // Virtual destructor
    virtual ~SurfaceFireFuel( void ) ;
    // Copy constructor
    SurfaceFireFuel( const SurfaceFireFuel &right ) ;
    // Assignment operator
    const SurfaceFireFuel& operator=( const SurfaceFireFuel &right ) ;

    // Property access methods
    double  bulkDensity( void ) const ;
    virtual const char *className( void ) const ;
    virtual int classVersion( void ) const ;
    SurfaceFireMoistureInterface* connectedMoisture( void ) const ;
    double  depth( void ) const ;
    double  fineDeadMoisture( void ) const ;
    double  fineFuelDead( void ) const ;
    double  fineFuelLive( void ) const ;
    double  fuelAreaWtgDead( int id ) const ;
    double  fuelAreaWtgLive( int id ) const ;
    double  fuelEffectiveHeatingNumber( int id ) const ;
    double  fuelFineDead( int id ) const ;
    double  fuelFineLive( int id ) const ;
    SurfaceFireParticleInterface* fuelPtr( int id ) const ;
    int     fuels( void ) const ;
    double  heatOfCombustionDead( void ) const ;
    double  heatOfCombustionLive( void ) const ;
    double  heatPerUnitArea( void ) const ;
    double  heatSink( void ) const ;
    double  loadDead( void ) const ;
    double  loadLive( void ) const ;
    double  loadTotal( void ) const ;
    double  maximumReactionVelocity( void ) const ;
    double  mextDead( void ) const ;
    double  mextLive( void ) const ;
    double  mineralDampingCoefficientDead( void ) const ;
    double  mineralDampingCoefficientLive( void ) const ;
    double  netLoadDead( void ) const ;
    double  netLoadLive( void ) const ;
    double  netLoadTotal( void ) const ;
    double  packingRatio( void ) const ;
    double  optimumPackingRatio( void ) const ;
    double  optimumReactionVelocity( void ) const ;
    double  propagatingFluxRatio( void ) const ;
    double  reactionIntensity( void ) const ;
    double  residenceTime( void ) const ;
    double  siEffectiveDead( void ) const ;
    double  siEffectiveLive( void ) const ;
    double  sigma( void ) const ;
    double  sigmaDead( void ) const ;
    double  sigmaLive( void ) const ;
    double  spreadRate( void ) const ;
    double  surfaceArea( void ) const ;
    double  surfaceAreaDead( void ) const ;
    double  surfaceAreaLive( void ) const ;
    double  surfaceAreaWtgDead( void ) const ;
    double  surfaceAreaWtgLive( void ) const ;

    // Property update methods
    virtual void addSurfaceFireParticle( SurfaceFireParticleInterface* fuel ) ;
    void connectMoisture( SurfaceFireMoistureInterface* moisture );
    void setMextDead( double mextDead ) ;

public slots:
    void particleChanged( void );
    void particleDestroyed( QObject* );
    void disconnectMoisture( void ) ;
    void moistureChanged( void ) ;
    void moistureDestroyed( void ) ;

// Protected interface
protected:
    virtual void clearFuel( void ) ;
    virtual void init( void ) const ;
    virtual void update( void ) const ; // Must be reimpelemented by derived classes
    virtual void updateParticleMoistures( void ) const ;

// Private properties
protected:
    mutable double m_area;              //!< Surface fuel bed total fuel surface area (ft2/ft2) [derived].
    mutable double m_areaDead;          //!< Surface fuel bed dead fuel surface area (ft2/ft2) [derived].
    mutable double m_areaLive;          //!< Surface fuel bed live fuel surface area (ft2/ft2) [derived].
    mutable double m_areaWtgDead;       //!< Surface fuel bed dead fuel area weighting factor (dl) [derived].
    mutable double m_areaWtgLive;       //!< Surface fuel bed live fuel area weighting factor (dl) [derived].
    mutable double m_betaRatio;         //!< Surface fuel bed packing ratio-to-optimum packing ratio ratio (dl) [derived].
    mutable double m_bulkDensity;       //!< Surface fuel bed bulk density (lb/ft3) [derived].
    mutable double m_etasDead;          //!< Surface fuel bed dead fuel mineral damping coefficient (dl) [derived].
    mutable double m_etasLive;          //!< Surface fuel bed live fuel mineral damping coefficient (dl) [derived].
    mutable double m_etamDead;          //!< Surface fuel bed dead fuel moisture damping coefficient (dl) [derived].
    mutable double m_etamLive;          //!< Surface fuel bed live fuel moisture damping coefficient (dl) [derived].
    mutable double m_depth;             //!< Surface fuel bed depth (ft) [derived].
    mutable double m_fineDeadMoisture;  //!< Surface fuel bed weighted fine dead fuel moisture content (lb water/lb oven-dry fuel).
    mutable double m_fineFuelDead;      //!< Surface fuel bed fine dead fuel load that must be heated to ignition (lb/ft2).
    mutable double m_fineFuelLive;      //!< Surface fuel bed fine live fuel load that must be heated to ignition (lb/ft2).
    SurfaceFireParticleVector m_fuel;       //!< Vector of QPointers to SurfaceFireParticleInterface objects.
    mutable QVector<double> m_fuelAwtgDead; //!< Vector of SurfaceFireParticleInterface object dead area weighting factors (dl).
    mutable QVector<double> m_fuelAwtgLive; //!< Vector of SurfaceFireParticleInterface object live area weighting factors (dl).
    mutable QVector<double> m_fuelEhn;      //!< Vector of SurfaceFireParticleInterface object effective heating numbewrs (dl ).
    mutable QVector<double> m_fuelFineDead; //!< Vector of SurfaceFireParticleInterface object dead fuel fraction that must be heated to ignition (dl).
    mutable QVector<double> m_fuelFineLive; //!< Vector of SurfaceFireParticleInterface object live fuel fraction that must be heated to ignition (dl).
    mutable double m_gammaMax;          //!< Surface fuel bed maximum reaction velocity (1/min) [derived].
    mutable double m_gammaOpt;          //!< Surface fuel bed optimum reaction velocity (1/min) [derived].
    mutable double m_heatDead;          //!< Surface fuel bed dead fuel low heat of combustion (Btu/lb) [derived].
    mutable double m_heatLive;          //!< Surface fuel bed live fuel low heat of combustion (Btu/lb) [derived].
    mutable double m_heatSink;          //!< Surface fuel bed heat sink (Btu/ft<SUP>3</SUP>).
    mutable double m_hpua;              //!< Surface fuel bed heat per unit area (Btu/ft<SUP>2</SUP>).
    mutable double m_load;              //!< Surface fuel bed net total fuel load (lb/ft2) [derived].
    mutable double m_loadDead;          //!< Surface fuel bed net dead fuel load (lb/ft2) [derived].
    mutable double m_loadLive;          //!< Surface fuel bed net live fuel load (lb/ft2) [derived].
    double  m_mextDead;                 //!< Surface fuel bed dead fuel moisture content of extinction (lb water/lb oven-dry fuel) [input].
    mutable double m_mextLive;          //!< Surface fuel bed live fuel moisture of extinction (lb water/lb fuel) [derived].
    SurfaceFireMoistureInterface* m_moisture;  //!< Surface fire bed SurfaceFireMoistureInterface object.
    mutable double m_moistureDead;      //!< Surface fuel bed weighted dead fuel moisture content (g/g).
    mutable double m_moistureLive;      //!< Surface fuel bed weighted live fuel moisture content (g/g).
    mutable double m_netLoadDead;       //!< Surface fuel bed net dead fuel load (lb/ft2) [derived].
    mutable double m_netLoadLive;       //!< Surface fuel bed net live fuel load (lb/ft2) [derived].
    mutable double m_optPackingRatio;   //!< Surface fuel bed optimum packing ratio (dl) [derived].
    mutable double m_packingRatio;      //!< Surface fuel bed packing ratio (dl) [derived].
    mutable double m_propFluxRatio;     //!< Surface fuel bed propagating flux ratio (dl) [derived].
    mutable double m_q_ig;              //!< Surface fuel bed weighted effective heat of pre-ignition (Btu/lb).
    mutable double m_residenceTime;     //!< Surface fuel bed fire residence time (min) [derived].
    mutable double m_ros;               //!< Surface fuel bed no-wind no-slope spread rate (ft/min).
    mutable double m_rxDead;            //!< Surface fuel bed dead fuel reaction intensity (Btu/ft2/min) [derived].
    mutable double m_rxLive;            //!< Surface fuel bed live fuel reaction intensity (Btu/ft2/min) [derived].
    mutable double m_rxInt;             //!< Surface fuel bed reaction intensity (Btu/ft<SUP>2</SUP>-min).
    mutable double m_savrDead;          //!< Surface fuel bed dead fuel characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    mutable double m_savrLive;          //!< Surface fuel bed live fuel characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    mutable double m_seffDead;          //!< Surface fuel bed dead fuel effective (silica-free) mineral content (lb mineral/lb fuel) [derived].
    mutable double m_seffLive;          //!< Surface fuel bed dead fuel effective (silica-free) mineral content (lb mineral/lb fuel) [derived].
    mutable double m_sigma;             //!< Surface fuel bed characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    mutable double m_sigma15;           //!< Surface fuel bed intermediate factor (pow(sigma, 1.5)) [derived].
    mutable double m_sigmaA;            //!< Surface fuel bed intermediate factor (133. / (pow(sigma, 0.7913)) ) [derived].
    mutable QVector<double> m_sizeWtgDead;  //!< Vector of SurfaceFireParticleInterface object dead area weighting factors accumulated by size category (dl).
    mutable QVector<double> m_sizeWtgLive;  //!< Vector of SurfaceFireParticleInterface object live area weighting factors accumulated by size category (dl).
};

// Non-member equality operators
bool operator ==( const SurfaceFireFuel & a, const SurfaceFireFuel & b ) ;
bool operator !=( const SurfaceFireFuel & a, const SurfaceFireFuel & b ) ;

}   // End of namespace Sem

#endif  // _SURFACEFIREFUEL_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireFuel.h
//------------------------------------------------------------------------------

