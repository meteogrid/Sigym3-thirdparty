//------------------------------------------------------------------------------
/*! \file FofemTreeSpecies.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief Access to all tree species defined by FOFEM 5.0.
 */

// Custom header files
#include "FofemTreeSpecies.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \struct _fofemSpecies
    \brief Structure to hold FOFEM species names and equation indices.
 */

//------------------------------------------------------------------------------
/*! \typedef FofemSpeciesStruct
    \brief Typedef of structure to hold FOFEM species names and equation indices.
 */

typedef struct _fofemSpecies
{
    char *abbrev;       //!< Genus-species abbreviation
    int   mortEq;       //!< Index to mortality equation (base 1)
    int   barkEq;       //!< Index to single bark thickness equation (base 1)
    char *regions;      //!< Region list (any combination of 1, 2, 3, and/or 4)
    char *scientific;   //!< Scientific name
    char *common;       //!< Common name
} FofemSpeciesStruct;

//------------------------------------------------------------------------------
/*! \var FofemSpeciesTable
    \brief Structure of FOFEM tree species names and equation indices.
    These are used in the bark thickness and tree mortality functions.
    Note: Region 1=Interior West, 2=Pacific West, 3=NorthEast, 4=SouthEast.
 */

static FofemSpeciesStruct FofemSpeciesTable[] =
{
/* 000 */ { "ABIAMA",  1, 26,    "2", "Abies amabilis",               "Pacific silver fir" },
/* 001 */ { "ABIBAL",  1, 10,  "134", "Abies balsamea",               "Balsam fir" },
/* 002 */ { "ABICON",  1, 27,   "12", "Abies concolor",               "White fir" },
/* 003 */ { "ABIGRA",  1, 25,   "12", "Abies grandis",                "Grand fir" },
/* 004 */ { "ABILAS",  1, 20,   "12", "Abies lasiocarpa",             "Subalpine fir" },
/* 005 */ { "ABIMAG",  1, 18,   "12", "Abies magnifica",              "Red fir" },
/* 006 */ { "ABIPRO",  1, 24,    "2", "Abies procera",                "Noble fir" },
/* 007 */ { "ABISPP",  1, 30,   "34", "Abies species",                "Firs" },
/* 008 */ { "ACEBAR",  1,  8,    "4", "Acer barbatum",                "Florida maple" },
/* 009 */ { "ACELEU",  1,  8,    "4", "Acer leucoderme",              "Chalk maple" },
/* 010 */ { "ACEMAC",  1,  3,    "2", "Acer macrophyllum",            "Bigleaf maple" },
/* 011 */ { "ACENEG",  1, 13,   "34", "Acer negundo",                 "Boxelder" },
/* 012 */ { "ACENIG",  1, 14,   "34", "Acer nigrum",                  "Black maple" },
/* 013 */ { "ACEPEN",  1, 24,   "34", "Acer pensylvanicum",           "Striped maple" },
/* 014 */ { "ACERUB",  1,  7,   "34", "Acer rubrum",                  "Red maple" },
/* 015 */ { "ACESACI", 1, 10,   "34", "Acer saccharinum",             "Silver maple" },
/* 016 */ { "ACESACU", 1, 12,   "34", "Acer saccharum",               "Sugar maple" },
/* 017 */ { "ACESPI",  1, 19,    "3", "Acer spicatum",                "Mountain maple" },
/* 018 */ { "ACESPP",  1,  8,   "34", "Acer species",                 "Maples" },
/* 019 */ { "AESGLA",  1, 15,   "34", "Aesculus glabra",              "Ohio buckeye" },
/* 020 */ { "AESOCT",  1, 29,   "34", "Aesculus octandra",            "Yellow buckeye" },
/* 021 */ { "AILALT",  1, 29,   "34", "Ailanthus altissima",          "Ailanthus" },
/* 022 */ { "ALNRHO",  1, 35,    "2", "Alnus rhombifolia",            "White alder" },
/* 023 */ { "ALNRUB",  1,  5,    "2", "Alnus rubra",                  "Red alder" },
/* 024 */ { "AMEARB",  1, 29,   "34", "Amelanchier arborea",          "Serviceberry" },
/* 025 */ { "ARBMEN",  1, 34,    "2", "Arbutus menziesii",            "Pacific madrone" },
/* 026 */ { "BETALL",  1, 10,   "34", "Betula alleghaniensis",        "Yellow birch" },
/* 027 */ { "BETLEN",  1,  9,    "4", "Betula lenta",                 "Sweet birch" },
/* 028 */ { "BETNIG",  1,  8,   "34", "Betula nigra",                 "River birch" },
/* 029 */ { "BETOCC",  1, 29,   "34", "Betula occidentalis",          "Water birch" },
/* 030 */ { "BETPAP",  1,  6,  "234", "Betula papyrifera",            "Paper birch" },
/* 031 */ { "BETSPP",  1, 12,  "234", "Betula species ",              "Birches" },
/* 032 */ { "CELOCC",  1, 14,   "34", "Celtis occidentalis",          "Hackberry" },
/* 033 */ { "CARAQU",  1, 19,   "34", "Carya aquatica",               "Water hickory" },
/* 034 */ { "CARCAR",  1,  9,   "34", "Carpinus caroliniana",         "American hornbeam" },
/* 035 */ { "CARCOR",  1, 16,   "34", "Carya cordiformis",            "Bitternut hickory" },
/* 036 */ { "CARGLA",  1, 16,   "34", "Carya glabra",                 "Pignut hickory" },
/* 037 */ { "CARILL",  1, 15,   "34", "Carya illinoensis",            "Pecan" },
/* 038 */ { "CARLAC",  1, 22,   "34", "Carya laciniosa",              "Shellbark hickory" },
/* 039 */ { "CAROVA",  1, 19,   "34", "Carya ovata",                  "Shagbark hickory" },
/* 040 */ { "CARSPP",  1, 23,   "34", "Carya species",                "Hickories" },
/* 041 */ { "CARTEX",  1, 19,    "4", "Carya texana",                 "Black hickory" },
/* 042 */ { "CARTOM",  1, 22,   "34", "Carya tomentosa",              "Mockernut hickory" },
/* 043 */ { "CASCHR",  1, 24,    "2", "Castanopsis chrysophylla",     "Golden chinkapin" },
/* 044 */ { "CASDEN",  1, 19,    "3", "Castanea dentata",             "American chestnut" },
/* 045 */ { "CATSPP",  1, 16,    "4", "Catalpa species",              "Catalpas" },
/* 046 */ { "CELLAE",  1, 15,   "34", "Celtis laevigata",             "Sugarberry" },
/* 047 */ { "CERCAN",  1, 14,   "34", "Cercis canadensis",            "Eastern redbud" },
/* 048 */ { "CHALAW",  1, 39,    "2", "Chamaecyparis lawsoniana",     "Port Orford cedar" },
/* 049 */ { "CHANOO",  1,  2,    "2", "Chamaecyparis nootkatenis",    "Alaska cedar" },
/* 050 */ { "CHATHY",  1,  4,   "34", "Chamaecyparis thyoides",       "Atlantic white cedar" },
/* 051 */ { "CORFLO",  1, 20,   "34", "Cornus florida",               "Flowering dogwood" },
/* 052 */ { "CORNUT",  1, 35,    "2", "Cornus nuttallii",             "Pacific dogwood" },
/* 053 */ { "CORSPP",  1, 10,   "34", "Cornus species",               "Dogwoods" },
/* 054 */ { "CRADOU",  1, 17,    "4", "Crataegus douglasii",          "Black hawthorn" },
/* 055 */ { "CRASPPW", 1, 35,    "2", "Crataegus species (western)",  "Hawthorns (western)" },
/* 056 */ { "CRASPPE", 1, 17,   "34", "Crataegus species (eastern)",  "Hawthorns (eastern)" },
/* 057 */ { "DIOVIR",  1, 20,   "34", "Diospyros virginiana",         "Persimmon" },
/* 058 */ { "FAGGRA",  1,  4,   "34", "Fagus grandifolia",            "American beech" },
/* 059 */ { "FRAAMA",  1, 21,   "34", "Fraxinus americana",           "White ash" },
/* 060 */ { "FRANIG",  1, 14,   "34", "Fraxinus nigra",               "Black ash" },
/* 061 */ { "FRAPEN",  1, 18,   "34", "Fraxinus pennsylvanica",       "Green ash" },
/* 062 */ { "FRAPRO",  1, 16,   "34", "Fraxinus profunda",            "Pumpkin ash" },
/* 063 */ { "FRAQUA",  1,  9,   "34", "Fraxinus quadrangulata",       "Blue ash" },
/* 064 */ { "FRASPP",  1, 21,   "34", "Fraxinus species",             "Ashes" },
/* 065 */ { "GLETRI",  1, 17,   "34", "Gleditsia triacanthos",        "Honeylocust" },
/* 066 */ { "GORLAS",  1, 17,    "4", "Gordonia lasianthus",          "Loblolly bay" },
/* 067 */ { "GYMDIO",  1, 10,   "34", "Gymnocladus dioicus",          "Kentucky coffeetree" },
/* 068 */ { "HALSPP",  1, 17,    "4", "Halesia species",              "Silverbells" },
/* 069 */ { "ILEOPA",  1, 21,   "34", "Ilex opaca",                   "American holly" },
/* 070 */ { "JUGCIN",  1, 20,   "34", "Juglans cinerea",              "Butternut" },
/* 071 */ { "JUGNIG",  1, 20,   "34", "Juglans nigra",                "Black walnut" },
/* 072 */ { "JUNOCC",  1,  4,    "2", "Juniperus occidentalis",       "Western juniper" },
/* 073 */ { "JUNSPP",  1, 12,   "34", "Juniperus species",            "Junipers/Redcedars" },
/* 074 */ { "JUNVIR",  1, 17,   "34", "Juniperus virginiana",         "Eastern redcedar" },
/* 075 */ { "LARLAR",  1, 10,   "34", "Larix laricina",               "Tamarack" },
/* 076 */ { "LARLYA",  1, 29,    "2", "Larix lyallii",                "Subalpine larch" },
/* 077 */ { "LAROCC",  1, 36,   "12", "Larix occidentalis",           "Western larch" },
/* 078 */ { "LIBDEC",  1, 34,    "2", "Libocedrus decurrens",         "Incense cedar" },
/* 079 */ { "LIQSTY",  1, 15,   "34", "Liquidambar styraciflua",      "Sweetgum" },
/* 080 */ { "LIRTUL",  1, 20,   "34", "Liriodendron tulipifera",      "Yellow poplar" },
/* 081 */ { "LITDEN",  1, 30,    "2", "Lithocarpus densiflorus",      "Tanoak" },
/* 082 */ { "MACPOM",  1, 16,    "4", "Maclura pomifera",             "Osage orange" },
/* 083 */ { "MAGACU",  1, 15,   "34", "Magnolia acuminata",           "Cucumbertree" },
/* 084 */ { "MAGGRA",  1, 12,    "4", "Magnolia grandiflora",         "Southern magnolia" },
/* 085 */ { "MAGMAC",  1, 12,    "4", "Magnolia macrophylla",         "Bigleaf magnolia" },
/* 086 */ { "MAGSPP",  1, 18,   "34", "Magnolia species",             "Magnolias" },
/* 087 */ { "MAGVIR",  1, 19,   "34", "Magnolia virginiana",          "Sweetbay" },
/* 088 */ { "MALPRU",  1, 17,    "4", "Malus/Prunus species",         "Apples/Cherries" },
/* 089 */ { "MALSPP",  1, 22,   "34", "Malus species",                "Apples" },
/* 090 */ { "MORALB",  1, 17,    "4", "Morus alba",                   "White mulberry" },
/* 091 */ { "MORRUB",  1, 17,    "4", "Morus rubra",                  "Red mulberry" },
/* 092 */ { "MORSPP",  1, 12,   "34", "Morus species",                "Mulberries" },
/* 093 */ { "NYSAQU",  1,  9,    "4", "Nyssa aquatica",               "Water tupelo" },
/* 094 */ { "NYSOGE",  1, 17,    "4", "Nyssa ogache",                 "Ogeechee tupelo" },
/* 095 */ { "NYSSPP",  1,  4,   "34", "Nyssa species",                "Tupelos" },
/* 096 */ { "NYSSYL",  1, 18,   "34", "Nyssa sylvatica",              "Black tupelo" },
/* 097 */ { "NYSSYLB", 1, 16,    "4", "Nyssa sylvatica var. biflora", "Swamp tupelo" },
/* 098 */ { "OSTVIR",  1, 16,   "34", "Ostrya virginiana",            "Eastern hophornbeam" },
/* 099 */ { "OXYARB",  1, 15,   "34", "Oxydendrum arboreum",          "Sourwood" },
/* 100 */ { "PAUTOM",  1, 29,   "34", "Paulownia tomentosa",          "Paulownia" },
/* 101 */ { "PERBOR",  1, 17,    "4", "Persea borbonia",              "Redbay" },
/* 102 */ { "PICABI",  1,  8,   "34", "Picea abies",                  "Norway spruce" },
/* 103 */ { "PICENG",  3, 15,   "12", "Picea engelmannii",            "Engelmann spruce" },
/* 104 */ { "PICGLA",  3,  4,  "123", "Picea glauca",                 "White spruce" },
/* 105 */ { "PICMAR",  3, 11,  "234", "Picea mariana",                "Black spruce" },
/* 106 */ { "PICPUN",  3, 10,    "1", "Picea pungens",                "Blue spruce" },
/* 107 */ { "PICRUB",  3, 13,   "34", "Picea rubens",                 "Red spruce" },
/* 108 */ { "PICSIT",  3,  6,    "2", "Picea sitchensis",             "Sitka spruce" },
/* 109 */ { "PICSPP",  3, 13,   "34", "Picea species",                "Spruces" },
/* 110 */ { "PINALB",  1,  9,   "12", "Pinus albicaulis",             "Whitebark pine" },
/* 111 */ { "PINATT",  1,  9,    "2", "Pinus attenuata",              "Knobcone pine" },
/* 112 */ { "PINBAN",  1, 19,    "3", "Pinus banksiana",              "Jack pine" },
/* 113 */ { "PINCLA",  1, 14,    "4", "Pinus clausa",                 "Sand pine" },
/* 114 */ { "PINCON",  1,  7,   "12", "Pinus contorta",               "Lodgepole pine" },
/* 115 */ { "PINECH",  1, 16,   "34", "Pinus echinata",               "Shortleaf pine" },
/* 116 */ { "PINELL",  1, 31,    "4", "Pinus elliottii",              "Slash pine" },
/* 117 */ { "PINFLE",  1,  9,    "1", "Pinus flexilis",               "Limber pine" },
/* 118 */ { "PINGLA",  1, 14,    "4", "Pinus glabra",                 "Spruce pine" },
/* 119 */ { "PINJEF",  1, 37,   "12", "Pinus jeffreyi",               "Jeffrey pine" },
/* 120 */ { "PINLAM",  1, 38,   "12", "Pinus lambertiana",            "Sugar pine" },
/* 121 */ { "PINMON",  1, 14,   "12", "Pinus monticola",              "Western white pine" },
/* 122 */ { "PINPAL",  1, 28,    "4", "Pinus palustrus",              "Longleaf pine" },
/* 123 */ { "PINPON",  1, 36,   "12", "Pinus ponderosa",              "Ponderosa pine" },
/* 124 */ { "PINPUN",  1, 19,   "34", "Pinus pungens",                "Table mountain pine" },
/* 125 */ { "PINRES",  1, 22,   "34", "Pinus resinosa",               "Red pine" },
/* 126 */ { "PINRIG",  1, 24,   "34", "Pinus rigida",                 "Pitch pine" },
/* 127 */ { "PINSAB",  1, 12,    "2", "Pinus sabiniana",              "Digger pine" },
/* 128 */ { "PINSER",  1, 35,   "34", "Pinus serotina",               "Pond pine" },
/* 129 */ { "PINSPP",  1,  9,   "34", "Pinus species",                "Pines" },
/* 130 */ { "PINSTR",  1, 24,   "34", "Pinus strobus",                "Eastern white pine" },
/* 131 */ { "PINSYL",  1,  9,   "34", "Pinus sylvestris",             "Scotch pine" },
/* 132 */ { "PINTAE",  1, 30,   "34", "Pinus taeda",                  "Loblolly pine" },
/* 133 */ { "PINVIR",  1, 12,   "34", "Pinus virginiana",             "Virginia pine" },
/* 134 */ { "PLAOCC",  1, 12,   "34", "Plantus occidentalis",         "American sycamore" },
/* 135 */ { "POPBAL",  1, 19,   "34", "Populus balsamifera",          "Balsam poplar" },
/* 136 */ { "POPDEL",  1, 19,   "34", "Populus deltoides",            "Eastern cottonwood" },
/* 137 */ { "POPGRA",  1, 18,   "34", "Populus grandidentata",        "Bigtooth aspen" },
/* 138 */ { "POPHET",  1, 29,   "34", "Populus heterophylla",         "Swamp cottonwood" },
/* 139 */ { "POPSPP",  1, 17,   "34", "Populus species",              "Poplars" },
/* 140 */ { "POPTRI",  1, 23,    "2", "Populus trichocarpa",          "Black cottonwood" },
/* 141 */ { "PRUAME",  1, 19,    "3", "Prunus americana",             "American plum" },
/* 142 */ { "PRUEMA",  1, 35,    "2", "Prunus emarginata",            "Bitter cherry" },
/* 143 */ { "PRUDEN",  1, 24,   "34", "Prunus pensylvanica",          "Pin cherry" },
/* 144 */ { "PRUSER",  1,  9,   "34", "Prunus serotina",              "Black cherry" },
/* 145 */ { "PRUSPP",  1, 29,   "34", "Prunus species",               "Cherries" },
/* 146 */ { "PRUVIR",  1, 19,    "3", "Prunus virginiana",            "Chokecherry" },
/* 147 */ { "PSEMEN",  1, 36,   "12", "Pseudotsuga menziesii",        "Douglas-fir" },
/* 148 */ { "QUEAGR",  1, 29,    "2", "Quercus agrifolia",            "Coast live oak" },
/* 149 */ { "QUEALB",  1, 19,   "34", "Quercus alba",                 "White oak" },
/* 150 */ { "QUEBIC",  1, 24,   "34", "Quercus bicolor",              "Swamp white oak" },
/* 151 */ { "QUECHR",  1,  3,    "2", "Quercus chrysolepis",          "Canyon live oak" },
/* 152 */ { "QUEOCC",  1, 19,   "34", "Quercus coccinea",             "Scarlet oak" },
/* 153 */ { "QUEDOU",  1, 12,    "2", "Quercus douglasii",            "Blue oak" },
/* 154 */ { "QUEELL",  1, 17,   "34", "Quercus ellipsoidalis",        "Northern pin oak" },
/* 155 */ { "QUEENG",  1, 33,    "2", "Quercus engelmannii",          "Engelmann oak" },
/* 156 */ { "QUEFAL",  1, 23,   "34", "Quercus falcata",              "Southern red oak" },
/* 157 */ { "QUEGAR",  1,  8,    "2", "Quercus garryana",             "Oregon white oak" },
/* 158 */ { "QUEIMB",  1, 20,   "34", "Quercus imbricaria",           "Shingle oak" },
/* 159 */ { "QUEINC",  1, 17,    "4", "Quercus incana",               "Bluejack oak" },
/* 160 */ { "QUEKEL",  1,  9,    "2", "Quercus kellogii",             "Califonia black oak" },
/* 161 */ { "QUELAE",  1, 16,    "4", "Quercus laevis",               "Turkey oak" },
/* 162 */ { "QUELAU",  1, 15,    "4", "Quercus laurifolia",           "Laurel oak" },
/* 163 */ { "QUELOB",  1, 22,    "2", "Quercus lobata",               "California white oak" },
/* 164 */ { "QUELYR",  1, 18,   "34", "Quercus lyrata",               "Overcup oak" },
/* 165 */ { "QUEMAC",  1, 21,   "34", "Quercus macrocarpa",           "Bur oak" },
/* 166 */ { "QUEMAR",  1, 16,   "34", "Quercus marilandica",          "Blackjack oak" },
/* 167 */ { "QUEMIC",  1, 25,   "34", "Quercus michauxii",            "Swamp chestnut oak" },
/* 168 */ { "QUEMUE",  1, 21,   "34", "Quercus muehlenbergii",        "Chinkapin oak" },
/* 169 */ { "QUENIG",  1, 15,   "34", "Quercus nigra",                "Water oak" },
/* 170 */ { "QUENUT",  1,  9,    "4", "Quercus nuttallii",            "Nuttall oak" },
/* 171 */ { "QUEPAL",  1, 20,   "34", "Quercus palustris",            "Pin oak" },
/* 172 */ { "QUEPHE",  1, 20,   "34", "Quercus phellos",              "Willow oak" },
/* 173 */ { "QUEPRI",  1, 28,   "34", "Quercus prinus",               "Chestnut oak" },
/* 174 */ { "QUERUB",  1, 21,   "34", "Quercus rubra",                "Northern red oak" },
/* 175 */ { "QUESHU",  1, 16,   "34", "Quercus shumardii",            "Shumard oak" },
/* 176 */ { "QUESPP",  1, 24,   "34", "Quercus species",              "Oaks" },
/* 177 */ { "QUESTE",  1, 23,   "34", "Quercus stellata",             "Post oak" },
/* 178 */ { "QUEVEL",  1, 24,   "34", "Quercus velutina",             "Black oak" },
/* 179 */ { "QUEVIR",  1, 22,    "4", "Quercus virginiana",           "Live oak" },
/* 180 */ { "QUEWIS",  1, 13,    "2", "Quercus wislizenii",           "Interior live oak" },
/* 181 */ { "ROBPSE",  1, 28,   "34", "Robinia pseudoacacia",         "Black locust" },
/* 182 */ { "SALDIA",  1, 19,    "3", "Salix bebbiana",               "Diamond willow" },
/* 183 */ { "SALNIG",  1, 19,   "34", "Salix nigra",                  "Black willow" },
/* 184 */ { "SALSPP",  1, 20,  "234", "Salix species",                "Willows" },
/* 185 */ { "SASALB",  1, 14,   "34", "Sassafras albidum",            "Sassafras" },
/* 186 */ { "SEQGIG",  1, 39,    "2", "Sequoiadendron giganteum",     "Giant sequoia" },
/* 187 */ { "SEQSEM",  1, 39,    "2", "Sequoia sempervirens",         "Redwood" },
/* 188 */ { "SORAME",  1, 19,    "3", "Sorbus americana",             "American mountain ash" },
/* 189 */ { "TAXBRE",  1,  4,   "12", "Taxus brevifolia",             "Pacific yew" },
/* 190 */ { "TAXDIS",  1,  4,   "34", "Taxodium distichum",           "Baldcypress" },
/* 191 */ { "TAXDISN", 1, 21,    "4", "Taxodium distictum var. nutans", "Pondcypress" },
/* 192 */ { "THUOCC",  1,  4,   "34", "Thuja occidentalis",           "Northern white cedar" },
/* 193 */ { "THUPLI",  1, 14,   "12", "Thuja plicata",                "Western redcedar" },
/* 194 */ { "THUSPP",  1, 12,   "34", "Thuju species",                "Arborvitae" },
/* 195 */ { "TILAME",  1, 17,   "34", "Tilia americana",              "American basswood" },
/* 196 */ { "TILHET",  1, 29,   "34", "Tilia heterophylla",           "White basswood" },
/* 197 */ { "TSUCAN",  1, 18,   "34", "Tsuga canadensis",             "Eastern hemlock" },
/* 198 */ { "TSUHET",  1, 19,   "12", "Tsuga heterophylla",           "Western hemlock" },
/* 199 */ { "TSUMER",  1, 19,   "12", "Tsuga mertensiana",            "Mountain hemlock" },
/* 200 */ { "ULMALA",  1, 10,   "34", "Ulmus alata",                  "Winged elm" },
/* 201 */ { "ULMAME",  1, 10,   "34", "Ulmus americana",              "American elm" },
/* 202 */ { "ULMPUM",  1, 17,   "34", "Ulmus pumila",                 "Siberian elm" },
/* 203 */ { "ULMRUB",  1, 11,   "34", "Ulmus rubra",                  "Slippery elm" },
/* 204 */ { "ULMSPP",  1, 18,   "34", "Ulmus species",                "Elms" },
/* 205 */ { "ULMTHO",  1, 12,   "34", "Ulmus thomasii",               "Rock elm" },
/* 206 */ { "UMBCAL",  1,  5,    "2", "Umbellularia californica",     "California laurel" },
/* 207 */ {        0,  0,  0,      0, 0,                              0 }
};

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species bark thickness equation index.

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \return Index into another table containing bark thickness estimation
    parameters.
 */
int Sem::FofemTreeSpecies::barkEquationIndex( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].barkEq );
}

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species common name

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \note This returns a pointer to static storage, so don't try to alter it!

    \return Pointer to static storage containing the species common name.
 */
const char* Sem::FofemTreeSpecies::commonName( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].common );
}

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species genus-species code.

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \note This returns a pointer to static storage, so don't try to alter it!

    \return Pointer to static storage containing the species genus=species code.
 */
const char* Sem::FofemTreeSpecies::genusSpeciesCode( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].abbrev );
}

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species mortality equation index.

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \return Index into another table containing mortality estimation
    parameters.
 */
int Sem::FofemTreeSpecies::mortalityEquationIndex( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].mortEq );
}

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species regions of occurrence.

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \note This returns a pointer to static storage, so don't try to alter it!

    \return Pointer to static storage containing a list of region codes
    where the species occurs:
        - 1 = Interior West,
        - 2 = Pacific West,
        - 3 = NorthEast, and
        - 4 = SouthEast.
 */
const char* Sem::FofemTreeSpecies::regions( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].regions );
}

//------------------------------------------------------------------------------
/*! \brief Access to FOFEM species scientific name.

    \param[in] species Sem:FofemSpecies enumeration (0-206).

    \note This returns a pointer to static storage, so don't try to alter it!

    \return Pointer to static storage containing the species scientific name.
 */
const char* Sem::FofemTreeSpecies::scientificName( FofemSpecies species )
{
    return( FofemSpeciesTable[ species ].scientific );
}
    
//------------------------------------------------------------------------------
//  End of FofemSpecies.cpp
//------------------------------------------------------------------------------

