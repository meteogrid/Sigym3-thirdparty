//------------------------------------------------------------------------------
/*! \file WeatherAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All weather algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

// Custom header files
#include "WeatherAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Calculates the dew point temperature.
  
    \param[in] dryBulb  Dry bulb air temperature (oF).
    \param[in] wetBulb  Wet bulb air temperature (oF).
    \param[in] elev     Elevation above mean sea level (ft).
  
    \return Dew point temperature (oF).
 */

double Sem::WeatherAlgorithm::dewPointTemperature(
        double dryBulb, double wetBulb, double elev )
{
    double dbulbc = ( dryBulb - 32. ) * 5. / 9.;
    double wbulbc = ( wetBulb - 32. ) * 5. / 9.;
    double dewpoint = dryBulb;
    if ( wbulbc < dbulbc )
    {
        // double e1 = 6.1121 * exp( 17.502 * dbulbc / (240.97 + dbulbc) );
        double e2 = 6.1121 * exp( 17.502 * wbulbc / (240.97 + wbulbc) );
        if ( wbulbc < 0. )
        {
            e2 = 6.1115 * exp( 22.452 * wbulbc / ( 272.55 + wbulbc) );
        }
        double p = 1013. * exp( -0.0000375 * elev );
        double d = 0.66 * ( 1. + 0.00115 * wbulbc) * (dbulbc - wbulbc);
        double e3 = e2 - d * p / 1000.;
        if ( e3 < 0.001 )
        {
            e3 = 0.001;
        }
        double t3 = -240.97 /  ( 1.- 17.502 / log(e3 / 6.1121) );
        if ( ( dewpoint = t3 * 9. / 5. + 32. ) < -40. )
        {
            dewpoint = -40.;
        }
    }
    return( dewpoint );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the heat index using the algorithm from
    http://www.usatoday.com/weather/whumcalc.htm and
    http://www.srh.noaa.gov/elp/wxcalc/heatindexsc.html
  
    \param[in] at Air temperature (oF).
    \param[in] rh Air relative humidity (%).
  
    \return Heat index.
 */

double Sem::WeatherAlgorithm::heatIndex1( double at, double rh )
{
    return( -42.379
        + 2.04901523 * at
        + 10.14333127 * rh
        - 0.22475541 * at * rh
        - 6.83783e-03 * at * at
        - 5.481717e-02 * rh * rh
        + 1.22874e-03 * at * at * rh
        + 8.5282e-04 * at * rh * rh
        - 1.99e-06 * at * at * rh * rh );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the heat index using the algorithm from
    http://www.wvec.com/knowledge/heatindex.htm
  
    \param[in] at Air temperature (oF).
    \param[in] rh Air relative humidity (%).
  
    \return Heat index.
 */

double Sem::WeatherAlgorithm::heatIndex2( double at, double rh )
{
    return( 16.923
        + 0.185212e+00 * at
        + 0.537941e+01 * rh
        - 0.100254e+00 * at * rh
        + 0.941695e-02 * at * at
        + 0.728898e-02 * rh * rh
        + 0.345372e-03 * at * at * rh
        - 0.814970e-03 * at * rh * rh
        + 0.102102e-04 * at * at * rh * rh
        - 0.386460e-04 * at * at * at
        + 0.291583e-04 * rh * rh * rh
        + 0.142721e-05 * at * at * at * rh
        + 0.197483e-06 * at * rh * rh * rh
        - 0.218429e-07 * at * at * at * rh * rh
        + 0.843296e-09 * at * at * rh * rh * rh
        - 0.481975e-10 * at * at * at * rh * rh * rh );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the relative humidity.
  
    \param[in] dryBulb  Air temperature (oF).
    \param[in] dewPt    Dew point temperature (oF).
  
    \return Relative humidity (fraction).
 */

double Sem::WeatherAlgorithm::relativeHumidity( double dryBulb, double dewPt )
{
    return( ( dewPt >= dryBulb )
          ? ( 1.0 )
          : ( exp( -7469. / ( dewPt+398.0 ) + 7469. / ( dryBulb+398.0 ) ) ) );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the summer simmer index using the algorithm from
    http://www.usatoday.com/weather/whumcalc.htm.
  
    \param[in] at Air temperature (oF).
    \param[in] rh Relative humidity(%).
  
    \return Summer simmer index (dl).
 */

double Sem::WeatherAlgorithm::summerSimmerIndex( double at, double rh )
{
    return( 1.98 * ( at - ( 0.55 - 0.0055*rh ) * ( at - 58. ) ) - 56.83 );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the fuel temperature using the BEHAVE FIRE2 subroutine
    CAIGN() algorithm.
  
    \param[in] airTemperature Air temperature (oF).
    \param[in] sunShade       Fraction of sun shaded from the fuel.
  
    \return Fuel temperature (oF).
 */

double Sem::WeatherAlgorithm::surfaceFuelTemperature(
        double airTemperature, double sunShade )
{
    // FIRE2 SUBROUTINE CAIGN() restricts air temp to 5-degree intervals
    int iAirTemp = (int) ( airTemperature / 10. );
    double airTemp = 5. + ( 10. * iAirTemp );

    // But we are going to use the continuum
    airTemp= airTemperature;

    // Temperature differential depends upon shading
#ifdef __DEPRECATED__
    double xincr = 5.;
    if ( sunShade <= 0.10 )
    {
        xincr = 25.;
    }
    else if ( sunShade <= 0.50 )
    {
        xincr = 19.;
    }
    else if ( sunShade <= 0.90 )
    {
        xincr = 12.;
    }
    else
    {
        xincr = 5.;
    }
#endif
    // This could be approximated by xinc = 25. - sunShade * 20.;
    double xincr = 25. - 20. * sunShade;
    return( airTemp + xincr );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the wind chill temperature.
  
    This uses the most recently (Nov 1, 2001) adopted formula
    used by the US NOAA and Canadian MSC and is now part of AWIPS.
    A new version in 2002 may add solar radiation effects.
  
    \param[in] airTemperature   Air temperature (oF).
    \param[in] windSpeed        Wind speed (mi/h).
  
    \return Wind chill temperature (oF).
 */

double Sem::WeatherAlgorithm::windChillTemperature(
        double airTemperature, double windSpeed )
{
    double v = 0.;
    if ( windSpeed > 0.0 )
    {
        v = pow( windSpeed, 0.16 );
    }
    double t = airTemperature;
    return( 35.74 + 0.6215 * t - 35.75 * v + 0.4275 * t * v );
    // Old method
    //return( 0.0817 * ( 5.81 + 3.71 * pow( windSpeed, 0.5 ) - 0.25 * windSpeed )
    //    * ( airTemperature - 91.4 ) + 91.4 );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the wind speed at 20 ft from the wind speed at 10 m.
 *
 *  \param windSpeedAt10M Wind speed at 10 meter (mi/h).
 *
 *  \return Wind speed at 20 ft (mi/h).
 */

double Sem::WeatherAlgorithm::windSpeedAt20Ft( double windSpeedAt10M )
{
    return( windSpeedAt10M / 1.15 );
}

//------------------------------------------------------------------------------
//  End of WeatherAlgorithm.cpp
//------------------------------------------------------------------------------

