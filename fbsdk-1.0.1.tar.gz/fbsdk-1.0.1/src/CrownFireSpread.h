//------------------------------------------------------------------------------
/*! \file CrownFireSpread.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Implements \ref rothermel1991 crown fire spread with additional
    support for transition to crown fire from surface fire.
 */

#ifndef _CROWNFIRESPREAD_H_INCLUDED_
#define _CROWNFIRESPREAD_H_INCLUDED_

// Custom header files
#include "Signal.h"
#include "CrownFireAlgorithm.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class CrownFireSpread CrownFireSpread.h
    \brief Implements \ref rothermel1991 crown fire spread with additional
    support for transition to crown fire from surface fire.
 */

class CrownFireSpread : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int crownFireSpreadVersion = 1;    //!< Class version
// Property ranges
    static const double canopyBaseHeightMin;    //!< Minimum valid canopy base height (ft)
    static const double canopyBaseHeightMax;    //!< Maximum valid canopy base height (ft)
    static const double canopyBulkDensityMin;   //!< Minimum valid canopy bulk density (lb/ft3)
    static const double canopyBulkDensityMax;   //!< Maximum valid canopy bulk density (;b/ft3)
    static const double dead1hMin;              //!< Minimum valid dead 1-h moisture (lb/lb)
    static const double dead1hMax;              //!< Maximum valid dead 1-h moisture (lb/lb)
    static const double dead10hMin;             //!< Minimum valid dead 10-h moisture (lb/lb) 
    static const double dead10hMax;             //!< Maximum valid dead 10-h moisture (lb/lb) 
    static const double dead100hMin;            //!< Minimum valid dead 100-h moisture (lb/lb) 
    static const double dead100hMax;            //!< Maximum valid dead 100-h moisture (lb/lb) 
    static const double flameLengthMin;         //!< Minimum valid flame length (ft)
    static const double flameLengthMax;         //!< Maximum valid flame length (ft)
    static const double foliarMoistureMin;      //!< Minimum valid foliar moisture (lb/lb) 
    static const double foliarMoistureMax;      //!< Maximum valid foliar moisture (lb/lb) 
    static const double liveWoodMin;            //!< Minimum valid live wood moisture (lb/lb) 
    static const double liveWoodMax;            //!< Maximum valid live wood moisture (lb/lb) 
    static const double windSpeedAt20FtMin;     //!< Minimum valid wind speed at 20 ft (mi/h)
    static const double windSpeedAt20FtMax;     //!< Maximum valid wind speed at 20 ft (mi/h)

// Public interface
public:
    // Default constructor
    CrownFireSpread( void ) ;
    // Custom constructors
    CrownFireSpread(
        double canopyBaseHeight,
        double canopyBulkDensity,
        double dead1h,
        double dead10h,
        double dead100h,
        double liveWood,
        double foliarMoisture,
        double windSpeedAt20Ft,
        double flameLength );
    // Virtual destructor
    virtual ~CrownFireSpread( void ) ;
    // Copy constructor
    CrownFireSpread( const CrownFireSpread &rhs ) ;
    // Assignment operator
    const CrownFireSpread &operator=( const CrownFireSpread &rhs ) ;

    // Property access methods
    const char *className( void ) const ;
    int classVersion( void ) const ;
    double canopyBaseHeight( void ) const;
    double canopyBulkDensity( void ) const;
    double dead1h( void ) const;
    double dead10h( void ) const;
    double dead100h( void ) const;
    double flameLength( void ) const;
    double foliarMoisture( void ) const;
    double liveWood( void ) const;
    double windSpeedAt20Ft( void ) const;

    // Intermediates access methods
    bool   activeCrownFire( void ) const;
    double activeRatio( void ) const;
    double criticalCrownFireSpreadRate( void ) const;
    double criticalSurfaceFirelineIntensity( void ) const;
    double criticalSurfaceFlameLength( void ) const;
    double crownFireSpreadRate( void ) const;
    Sem::CrownFireAlgorithm::FireStatus fireStatus( void ) const;
    double surfaceFirelineIntensity( void ) const;
    double transitionRatio( void ) const;
    bool   transitionToCrown( void ) const;

    // Property update methods
    void setCanopyBaseHeight( double canopyBaseHeight ) ;
    void setCanopyBulkDensity( double canopyBulkDensity ) ;
    void setDead1h( double dead1h ) ;
    void setDead10h( double dead10h ) ;
    void setDead100h( double dead100h ) ;
    void setFlameLength( double flameLength ) ;
    void setFoliarMoisture( double foliarMoisture );
    void setLiveWood( double liveWood ) ;
    void setWindSpeedAt20Ft( double windSpeed ) ;

// Must be re-implemented by derived classes
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;

// Protected properties
protected:
    double m_canopyBaseHeight;      //!< Canopy base height (3-100 ft).
    double m_canopyBulkDensity;     //!< Canopy bulk density (0.000625 - 0.0625 lb/ft3).
    double m_dead1h;                //!< Canopy dead 1-h time lag moisture (0.01-0.60 lb water/lb fuel).
    double m_dead10h;               //!< Canopy dead 10-h time lag moisture (0.01-0.60 lb water/lb fuel).
    double m_dead100h;              //!< Canopy dead 100-h time lag moisture (0.01-0.60 lb water/lb fuel).
    double m_flameLength;           //!< Surface fire flame length (0 -200 ft).
    double m_foliarMoisture;        //!< Canopy foliar moisture (0.30-3.00 lb water/lb fuel).
    double m_liveWood;              //!< Canopy live wood moisture (0.30-3.00 lb water/lb fuel).
    double m_windSpeedAt20Ft;       //!< Wind speed at 20ft (0-99 mi/h)

    mutable bool   m_activeCrownFire;   //!< TRUE if current state is an active crown fire
    mutable double m_activeRatio;       //!< Crown fire active ratio (dl)
    mutable double m_criticalCrownFireSpreadRate;   //!< Critical crown fire spread rate (ft/min)
    mutable double m_criticalSurfaceFirelineIntensity;  //!< Critical surface fireline intensity (Btu/ft/s)
    mutable double m_criticalSurfaceFlameLength;    //!< Critical surface fire flame length (ft)
    mutable double m_crownFireSpreadRate;   //!< Crown fire spread rate (ft/min)
    mutable Sem::CrownFireAlgorithm::FireStatus m_fireStatus;    //!< Current state is surface, torching, or crown fire
    mutable double m_surfaceFirelineIntensity;  //!< Surface fire fireline intensity (Btu/ft/s)
    mutable double m_transitionRatio;   //!< Crown fire transition ratio (dl)
    mutable bool   m_transitionToCrown; //!< TRUE if current state permits surface fire transition to crown fire
};

// Non-member equality operators
bool operator ==( const CrownFireSpread & a, const CrownFireSpread & b ) ;
bool operator !=( const CrownFireSpread & a, const CrownFireSpread & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of CrownFireSpread.h
//------------------------------------------------------------------------------

