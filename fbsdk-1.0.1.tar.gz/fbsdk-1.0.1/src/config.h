//------------------------------------------------------------------------------
/*! \file config.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Various constants and defines used by multiple classes.
 */

#ifndef _CONFIG_H_INCLUDED_
#define _CONFIG_H_INCLUDED_

// Namespaces
namespace std
{
    // Until ::boost gets incorporated into tr1
    //namespace tr1 = ::boost;
}

namespace Sem
{
//------------------------------------------------------------------------------
/*! \var Smidgen
    \brief Anything less than this is treated as zero.
 */

static const double Smidgen = 0.0000001;
}

/*! \def M_PI
    \brief A well rounded number
 */
#ifndef M_PI
#define M_PI 3.141592654
#endif

#endif

//------------------------------------------------------------------------------
//  End of config.h
//------------------------------------------------------------------------------

