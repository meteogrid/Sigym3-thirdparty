/****************************************************************************
** Meta object code from reading C++ file 'SurfaceFireFuelInterface.h'
**
** Created: Tue May 23 12:33:34 2006
**      by: The Qt Meta Object Compiler version 59 (Qt 4.1.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "SurfaceFireFuelInterface.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SurfaceFireFuelInterface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.1.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_Sem__SurfaceFireFuelInterface[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets

       0        // eod
};

static const char qt_meta_stringdata_Sem__SurfaceFireFuelInterface[] = {
    "Sem::SurfaceFireFuelInterface\0"
};

const QMetaObject Sem::SurfaceFireFuelInterface::staticMetaObject = {
    { &Signal::staticMetaObject, qt_meta_stringdata_Sem__SurfaceFireFuelInterface,
      qt_meta_data_Sem__SurfaceFireFuelInterface, 0 }
};

const QMetaObject *Sem::SurfaceFireFuelInterface::metaObject() const
{
    return &staticMetaObject;
}

void *Sem::SurfaceFireFuelInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Sem__SurfaceFireFuelInterface))
	return static_cast<void*>(const_cast<SurfaceFireFuelInterface*>(this));
    return Signal::qt_metacast(_clname);
}

int Sem::SurfaceFireFuelInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Signal::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
