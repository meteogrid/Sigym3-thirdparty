//------------------------------------------------------------------------------
/*! \file SurfaceFireTerrain.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireTerrainInterface for
    accessing and updating terrain aspect and steepness information at a
    specific point.
 */

#ifndef _SURFACEFIRETERRAIN_H_INCLUDED_
#define _SURFACEFIRETERRAIN_H_INCLUDED_

// Custom header files
#include "SurfaceFireTerrainInterface.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireTerrain SurfaceFireTerrain.h
    \brief A simple implementation of the SurfaceFireTerrainInterface for
    accessing and updating terrain aspect and steepness information at a
    specific point.

    This is a bare bones implementation of the SurfaceFireTerrainInterface.
 */

class SurfaceFireTerrain : public SurfaceFireTerrainInterface
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireTerrainVersion = 1; //!< Class version
// Property ranges
    static const double slopeFractionMin;   //!< Minimum slope fraction (rise/reach)
    static const double slopeFractionMax;   //!< Maximum slope fraction (rise/reach)
    static const double slopeDegreesMin;    //!< Minimum slope degrees
    static const double slopeDegreesMax;    //!< Maximum slope degrees

// Public interface
public:
    // Default constructor
    SurfaceFireTerrain( void ) ;
    // Custom constructors
    SurfaceFireTerrain( double midflameSpeedMph, double sourceDegreesClockwiseFromNorth ) ;
    // Virtual destructor
    virtual ~SurfaceFireTerrain( void ) ;
    // Copy constructor
    SurfaceFireTerrain( const SurfaceFireTerrain &rhs ) ;
    // Assignment operator
    const SurfaceFireTerrain &operator=( const SurfaceFireTerrain &rhs ) ;

    // Property access methods
    double aspectCompass( void ) const ;
    const char *className( void ) const ;
    int classVersion( void ) const ;
    double downslopeCompass( void ) const ;
    double upslopeCompass( void ) const ;
    double slopeDegrees( void ) const ;
    double slopeFraction( void ) const ;
    double slopePercent( void ) const ;

    // Property update methods
    void setAspectCompass( double sourceDegreesClockwiseFromNorth );
    void setDownslopeCompass( double bearingDegreesClockwiseFromNorth );
    void setUpslopeCompass( double bearingDegreesClockwiseFromNorth );
    void setSlopeDegrees( double slopeDegrees ) ;
    void setSlopeFraction( double slopeFraction ) ;
    void setSlopePercent( double slopePercent ) ;

// Protected interface
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;

// Protected properties
protected:
    double m_aspect;    //!< Terrain aspect (down-slope degrees clockwise from north).
    double m_slope;     //!< Terrain slope steepness (fraction rise/reach).
};

// Non-member equality operators
bool operator ==( const SurfaceFireTerrain & a, const SurfaceFireTerrain & b ) ;
bool operator !=( const SurfaceFireTerrain & a, const SurfaceFireTerrain & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of SurfaceFireTerrain.h
//------------------------------------------------------------------------------

