//------------------------------------------------------------------------------
/*! \file Compass.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief Quantifies a global compass direction in terms of degrees
    clockwise from north.
    \license This code is released under the GNU Public License 2.
 */

// Custom header files
#include "CompassAlgorithm.h"
#include "Compass.h"
#include "Logger.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Compass default constructor.
 */

Sem::Compass::Compass( void ) :
    m_degrees( 0. )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief Compass custom constructor.
    \param[in] degreesClockwiseFromNorth Just what it says.
 */

Sem::Compass::Compass( double degreesClockwiseFromNorth ) :
    m_degrees( 0. )
{
    m_degrees = Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::Compass::~Compass( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief Compass copy constructor.
    \param[in] right Reference to the Compass from which to copy.
    \return Reference to the newly allocated Compass.
 */

Sem::Compass::Compass( const Compass &right ) :
    Signal(),
    m_degrees( 0. )
{
    m_degrees = right.m_degrees;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Compass assignment operator.
    \param[in] right Reference to the Compass from which to assign.
    \return Reference to the newly assigned Compass.
 */

const Sem::Compass& Sem::Compass::operator=( const Compass &right )
{
    if ( this != &right )
    {
        m_degrees = right.m_degrees;
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Compass assignment operator.
    \param[in] degreesClockwiseFromNorth Just what it says.
    \return Reference to the newly assigned Compass.
 */

const Sem::Compass& Sem::Compass::operator=( double degreesClockwiseFromNorth )
{
    m_degrees = Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth );
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::Compass::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::Compass::classVersion( void ) const
{
    return( compassVersion );
}

//------------------------------------------------------------------------------
/*! \brief Compass access method.
    \return Degrees clockwise from north in range [0..360].
 */

double Sem::Compass::degreesClockwiseFromNorth( void ) const
{
    return( m_degrees );
}

//------------------------------------------------------------------------------
/*! \brief Compass access method.
    \return Degrees deviation from north in range [-180..180].
 */

double Sem::Compass::degreesDeviationFromNorth( void ) const
{
    return( Sem::CompassAlgorithm::deviation( m_degrees ) );
}

//------------------------------------------------------------------------------
/*! \brief Convenience method to get compass deviation [-180..180].
    \return Degrees constrained to range [-180..180].
 */

double Sem::Compass::deviation( void ) const
{
    return( Sem::CompassAlgorithm::deviation( m_degrees ) );
}

//------------------------------------------------------------------------------
/*! \brief Convenience method to return opposite direction in range [0..360].
    \return Opposite direction in degrees clockwise from north
    constrained to range [0..360].
 */

double Sem::Compass::opposite( void ) const
{
    return( Sem::CompassAlgorithm::opposite( m_degrees ) );
}

//------------------------------------------------------------------------------
/*! \brief Compass update method.
    \param[in] degreesClockwiseFromNorth Just what it says.
 */

void Sem::Compass::setDegreesClockwiseFromNorth(
    double degreesClockwiseFromNorth )
{
    m_degrees = Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object properties up to date.

    \note Make sure NOT to call any member update methods on properties,
    such as "property()", as these then call checkUpdate(), resulting in an
    infinite loop!  Access member properties directly, as in "m_property".
 */

void Sem::Compass::update( void ) const
{
    // Do whatever is necessary to update the object state
    return;
}

//------------------------------------------------------------------------------
/*! \brief Compass addition assignment operator.
    \param[in] rhs Right-hand-side Compass object.
 */

Sem::Compass& Sem::Compass::operator +=( const Sem::Compass &rhs )
{
    m_degrees = Sem::CompassAlgorithm::constrain( m_degrees + rhs.m_degrees );
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Compass addition assignment operator.
    \param[in] degrees Compass degrees to be added.
 */

Sem::Compass& Sem::Compass::operator +=( double degrees )
{
    m_degrees = Sem::CompassAlgorithm::constrain( m_degrees + degrees );
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Compass subtraction assignment operator.
    \param[in] rhs Right-hand-side Compass object.
 */

Sem::Compass& Sem::Compass::operator -=( const Sem::Compass &rhs )
{
    m_degrees = Sem::CompassAlgorithm::constrain( m_degrees - rhs.m_degrees );
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Compass subtraction assignment operator.
    \param[in] degrees Compass degrees to be suntracted.
 */

Sem::Compass& Sem::Compass::operator -=( double degrees )
{
    m_degrees = Sem::CompassAlgorithm::constrain( m_degrees - degrees );
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator ==( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( fabs( lhs.degreesClockwiseFromNorth() - rhs.degreesClockwiseFromNorth() )
    < 0.00001 );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator ==( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( fabs( lhs.degreesClockwiseFromNorth() - degreesClockwiseFromNorth )
    < 0.00001 );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between a double value and a Compass object.
    \param[in] degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator ==( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( fabs( degreesClockwiseFromNorth - rhs.degreesClockwiseFromNorth() )
    < 0.00001 );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator !=( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
/*! \brief Inequality operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator !=( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( !( lhs == degreesClockwiseFromNorth ) );
}

//------------------------------------------------------------------------------
/*! \brief Equality operator between a double value and a Compass object.
    \param degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator !=( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( !( degreesClockwiseFromNorth == rhs ) );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator >( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( lhs.degreesClockwiseFromNorth() > rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator >( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( lhs.degreesClockwiseFromNorth() > degreesClockwiseFromNorth );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than operator between a double value and a Compass object.
    \param degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator >( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( degreesClockwiseFromNorth > rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than-or-equal operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator >=( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( lhs.degreesClockwiseFromNorth() >= rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than-or-equal operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator >=( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( lhs.degreesClockwiseFromNorth() >= degreesClockwiseFromNorth );
}

//------------------------------------------------------------------------------
/*! \brief Greater-than-or-equal operator between a double value and a Compass object.
    \param degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator >=( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( degreesClockwiseFromNorth > rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Less-than operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator <( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( lhs.degreesClockwiseFromNorth() < rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Less-than operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator <( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( lhs.degreesClockwiseFromNorth() < degreesClockwiseFromNorth );
}

//------------------------------------------------------------------------------
/*! \brief Less-than operator between a double value and a Compass object.
    \param degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator <( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( degreesClockwiseFromNorth < rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Less-than-or-equal operator between two Compass objects.
    \param[in] lhs Left-hand-side Compass object.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator <=( const Sem::Compass &lhs, const Sem::Compass &rhs )
{ 
  return( lhs.degreesClockwiseFromNorth() <= rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Less-than-or-equal operator between a Compass object and a double value.
    \param[in] lhs Left-hand-side Compass object.
    \param degreesClockwiseFromNorth Just what it says.
 */
bool Sem::operator <=( const Sem::Compass &lhs, double degreesClockwiseFromNorth )
{ 
  return( lhs.degreesClockwiseFromNorth() <= degreesClockwiseFromNorth );
}

//------------------------------------------------------------------------------
/*! \brief Less-than-or-equal operator between a double value and a Compass object.
    \param degreesClockwiseFromNorth Just what it says.
    \param[in] rhs Right-hand-side Compass object.
 */
bool Sem::operator <=( double degreesClockwiseFromNorth, const Sem::Compass &rhs )
{ 
  return( degreesClockwiseFromNorth <= rhs.degreesClockwiseFromNorth() );
}

//------------------------------------------------------------------------------
/*! \brief Text stream output operator.

    \param[in] output Reference to the output stream.
    \param[in] rhs Reference to the Compass to output.

    \return Reference to the output ostream.
 */

std::ostream &Sem::operator<<( std::ostream &output, const Sem::Compass &rhs )
{
    rhs.writeHeader( output );
    output << rhs.degreesClockwiseFromNorth();
    // Always return a reference to the stream
    return( output );
}

//------------------------------------------------------------------------------
/*! \brief Binary stream output operator.
    
    \param[in] output Reference to the output QDataStream.
    \param[in] rhs Reference to the Compass to output.

    \return Reference to the output QDataStream.
 */

QDataStream &Sem::operator<<( QDataStream &output, const Sem::Compass &rhs )
{
    rhs.writeHeader( output );
    output << rhs.degreesClockwiseFromNorth();
    // Always return a reference to the stream
    return( output );
}

//------------------------------------------------------------------------------
/*! \brief Text stream input operator>>.
    \param input Reference to the input stream.
    \param rhs Reference to the Compass to hold the input.
    \return Reference to the input istream.
 */

std::istream &Sem::operator>>( std::istream &input, Sem::Compass &rhs )
{
    // Read the header data
    if ( rhs.readHeader( input ) )
    {
        // Read class specific according to class version
        if ( rhs.m_classVersion == 1 )
        {
            input >> rhs.m_degrees;
        }
        else
        {
            Sem::Logger::Instance().send( 3,
                QString( "Class '%1' version '%2' is unsupported for text input." )
                .arg( rhs.className() ).arg( rhs.m_classVersion ) );
        }
    }
    // Always return a reference to the stream
    return( input );
}

//------------------------------------------------------------------------------
/*! \brief Binary stream input operator>>.
    \param input Reference to the input QDataStream.
    \param rhs Reference to the Compass to hold the input.
    \return Reference to the input QDataStream.
 */

QDataStream &Sem::operator>>( QDataStream &input, Sem::Compass &rhs )
{
    // Read the header data
    if ( rhs.readHeader( input ) )
    {
        // Read class specific according to class version
        if ( rhs.m_classVersion == 1 )
        {
            input >> rhs.m_degrees;
        }
        else
        {
            Sem::Logger::Instance().send( 3,
                QString( "Class '%1' version '%2' is unsupported for text input." )
                .arg( rhs.className() ).arg( rhs.m_classVersion ) );
        }
    }
    // Always return a reference to the stream
    return( input );
}

//------------------------------------------------------------------------------
//  End of Compass.cpp
//------------------------------------------------------------------------------

