/****************************************************************************
** Meta object code from reading C++ file 'SurfaceFireSpread.h'
**
** Created: Tue May 23 12:33:52 2006
**      by: The Qt Meta Object Compiler version 59 (Qt 4.1.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "SurfaceFireSpread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SurfaceFireSpread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.1.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_Sem__SurfaceFireSpread[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      24,   23,   23,   23, 0x0a,
      44,   23,   23,   23, 0x0a,
      61,   23,   23,   23, 0x0a,
      78,   23,   23,   23, 0x0a,
      92,   23,   23,   23, 0x0a,
     108,   23,   23,   23, 0x0a,
     125,   23,   23,   23, 0x0a,
     144,   23,   23,   23, 0x0a,
     158,   23,   23,   23, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Sem__SurfaceFireSpread[] = {
    "Sem::SurfaceFireSpread\0\0disconnectTerrain()\0disconnectFuel()\0"
    "disconnectWind()\0fuelChanged()\0fuelDestroyed()\0terrainChanged()\0"
    "terrainDestroyed()\0windChanged()\0windDestroyed()\0"
};

const QMetaObject Sem::SurfaceFireSpread::staticMetaObject = {
    { &Signal::staticMetaObject, qt_meta_stringdata_Sem__SurfaceFireSpread,
      qt_meta_data_Sem__SurfaceFireSpread, 0 }
};

const QMetaObject *Sem::SurfaceFireSpread::metaObject() const
{
    return &staticMetaObject;
}

void *Sem::SurfaceFireSpread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Sem__SurfaceFireSpread))
	return static_cast<void*>(const_cast<SurfaceFireSpread*>(this));
    return Signal::qt_metacast(_clname);
}

int Sem::SurfaceFireSpread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Signal::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: disconnectTerrain(); break;
        case 1: disconnectFuel(); break;
        case 2: disconnectWind(); break;
        case 3: fuelChanged(); break;
        case 4: fuelDestroyed(); break;
        case 5: terrainChanged(); break;
        case 6: terrainDestroyed(); break;
        case 7: windChanged(); break;
        case 8: windDestroyed(); break;
        }
        _id -= 9;
    }
    return _id;
}
