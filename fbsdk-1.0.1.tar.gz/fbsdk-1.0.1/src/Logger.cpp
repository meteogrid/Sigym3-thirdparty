//------------------------------------------------------------------------------
/*! \file Logger.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Application-wide Singleton destination for error messages,
    which can be observed/subscribed to by client reporters.
 */

// Custom include files
#include "Logger.h"

//------------------------------------------------------------------------------
/*  \brief Default constructor.
 */

Sem::LoggerBase::LoggerBase( void ) :
    m_code(0),
    m_file(0),
    m_line(0),
    m_msg("")
{
    return;
}

//------------------------------------------------------------------------------
/*  \brief Virtual destructor.
 */

Sem::LoggerBase::~LoggerBase( void )
{
    return;
}

//------------------------------------------------------------------------------
/*  \brief Access to the current message code.
    \return Current message code.
 */

int Sem::LoggerBase::code( void ) const
{
    return( m_code );
}

//------------------------------------------------------------------------------
/*  \brief Access to the send() file name.
    \return Static pointer to the file name from which the send() was sent.
 */

const char* Sem::LoggerBase::file( void ) const
{
    return( m_file );
}

//------------------------------------------------------------------------------
/*  \brief Access to the send() file line number.
    \return File line number from which the send() was sent.
 */

int Sem::LoggerBase::line( void ) const
{
    return( m_line );
}

//------------------------------------------------------------------------------
/*  \brief Access to the current message string.
    \return Copy of the current message string.
 */

QString Sem::LoggerBase::message( void ) const
{
    return( m_msg );
}

//------------------------------------------------------------------------------
/*  \brief Receives messages from clients.

    \param[in] code Application-specific error or severity code
    \param[in] msg  Message text
    \param[in] file File from which send() was invoked.
    \param[in] line Line number from which send() was invoked.
 */

void Sem::LoggerBase::send( int code, const QString& msg, const char* file,
    const int line )
{
    m_code = code;
    m_msg  = msg;
    m_file = file;
    m_line = line;
    emit messageReceived();
    return;
}

//------------------------------------------------------------------------------
//  End of Logger.cpp
//------------------------------------------------------------------------------

