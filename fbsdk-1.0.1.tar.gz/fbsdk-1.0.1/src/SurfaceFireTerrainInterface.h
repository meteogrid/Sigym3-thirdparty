//------------------------------------------------------------------------------
/*! \file SurfaceFireTerrainInterface.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An abstract base class defining an interface to provide terrain
    aspect and steepness information.
 */

#ifndef _SURFACEFIRETERRAININTERFACE_H_INCLUDED_
#define _SURFACEFIRETERRAININTERFACE_H_INCLUDED_

// Custom headers
#include "Signal.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireTerrainInterface SurfaceFireTerrainInterface.h
    \brief An abstract base class defining an interface to provide terrain
    aspect and steepness information.
 */

class SurfaceFireTerrainInterface : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireTerrainInterfaceVersion = 1; //!< Class version

// Public interface
public:
    /*! \brief Virtual destructor implemented here
     */
    virtual ~SurfaceFireTerrainInterface( void ) {}

    // Property access methods
    const char* className( void ) const { return( metaObject()->className() ); }
    int classVersion( void ) const { return ( surfaceFireTerrainInterfaceVersion ); }

    /*! \fn virtual double aspectCompass( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain aspect (down-slope) compass direction (degrees clockwise from north).
    */
    virtual double aspectCompass( void ) const = 0;

    /*! \fn virtual double downslopeCompass( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain down-slope (aspect) compass direction (degrees clockwise from north).
    */
    virtual double downslopeCompass( void ) const = 0;

    /*! \fn virtual double slopeDegrees( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain slope steepness in degrees.
    */
    virtual double slopeDegrees( void ) const = 0;

    /*! \fn virtual double slopeFraction( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain slope steepness fraction (rise/reach).
    */
    virtual double slopeFraction( void ) const = 0;

    /*! \fn virtual double slopePercent( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain slope steepness percent (100. rise/reach).
    */
    virtual double slopePercent( void ) const = 0;

    /*! \fn virtual double upslopeCompass( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Terrain up-slope compass direction (degrees clockwise from north).
    */
    virtual double upslopeCompass( void ) const = 0;
};

}   // End of namespace Sem

#endif  // _SURFACEFIRETERRAININTERFACE_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireTerrainInterface.h
//------------------------------------------------------------------------------

