//------------------------------------------------------------------------------
/*! \file SurfaceFireSpread.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Determines elliptical surface fire spread rate and fireline
    intensity from SurfaceFireFuelInterface, SurfaceFireTerrainInterface, and
    SurfaceFireWindInterface instances.
 */                               

#ifndef _SURFACEFIRESPREAD_H_INCLUDED_
#define _SURFACEFIRESPREAD_H_INCLUDED_

// Configuration
#include "Signal.h"
#include "SurfaceFireFuelInterface.h"
#include "SurfaceFireTerrainInterface.h"
#include "SurfaceFireWindInterface.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireSpread SurfaceFireSpread.h
    \brief Determines elliptical surface fire spread rate and fireline
    intensity from SurfaceFireFuelInterface, SurfaceFireTerrainInterface, and
    SurfaceFireWindInterface instances.

    Each SurfaceFireSpread instance is connected to specific instances of a
    - SurfaceFireFuelInterface (aka 'fuel'),
    - SurfaceFireTerrainInterface (aka 'terrain'), and
    - SurfaceFireWindInterface (aka 'wind').

    These provide all the input state information required by the elliptical
    surface fire spread and intensity algorithms.  They may be assigned
    during SurfaceFireSpread() construction, or assigned and re-assigned via the
    connectFuel(), connectTerrain(), and connectWind() methods.

    SurfaceFireSpread is fairly light weight in that it only maintains pointers
    to its fuel bed, terrain, and wind objects plus a few fire behavior
    variables.
    
    Depending on the application, many SurfaceFireSpread instances can connect
    to (or share) a relatively few number of fuel, terrain, and wind objects.
    For example, a landscape level fire simulation may require just a single
    wind object, a couple different fuel bed objects, and many terrain objects
    to describe the entire landscape.

    A SurfaceFireSpread instance is "connected" to a SurfaceFireTerrainInterface,
    SurfaceFireFuelInterface, and SurfaceFireWindInterface instance in the sense
    that anytime a property is updated in one of them via their set<Property>()
    methods, a valueChanged() signal is emitted and its dirty flag is set.
    Furthermore, the SurfaceFireSpread catches the signal and sets its own dirty
    flag.  The next time a property is requested from the SurfaceFireSpread,
    all the required updates are first automatically performed.

    This means the programmer never has to know or keep track of when to
    update the intermediate and final properties of any of these objects;
    just change one or more properties of any of these objects, and the next
    time the program accesses any of the dependent properties, the object state
    is automatically updated before the property value is return.
    It also means that objects use lazy updating; the program may make many
    calls to set<Property>() methods, but no updating actually occurs until
    a property is accessed via one of the access methods.

    The nominal program flow follows:
    \code
    // Step 1: create a simple fuel moisture observation station 
    Sem::SurfaceFireMoistureTimeLag* moisture = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );

    // Step 2: create a standard fire behavior 'Fuel Model 1'
    // and have it get its fuel moisture from moisture station 'mosture'
    Sem::SurfaceFireFuelModel* fuel = Sem::createFuelModel( 1, moisture );

    // Step 3: create a terrain instance with 100% slope and south aspect
    Sem::SurfaceFireTerrain* terrain = new Sem::SurfaceFireTerrain( 100., 180. );

    // Step 4: create a wind observation station
    // and initialize it to 5 mph wind blowing from the south.
    Sem::SurfaceFireWind* wind = new Sem::SurfaceFireWind( 5., 180. );

    // Step 5: create a surface fire that uses these fuel (and associated
    // moisture), terrain, and wind instances
    Sem::SurfaceFireSpread* fire = new Sem::SurfaceFireSpread( fuel, terrain, wind );

    // Step 6: get the maximum spread rate and direction
    double maxRos = f->spreadRateAtHead();
    double maxDir = f->spreadDirectionAtHead();

    // Step 7: change the 'wind' direction and see that its effects are
    // automatically propagated to 'fire' (and, indeed, is propagated to all
    // fires that reference 'wind')
    wind->setBearing( 90. );
    maxRos = f->spreadRateAtHead();
    maxDir = f->spreadDirectionAtHead();
    \endcode
 */

class SurfaceFireSpread : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireSpreadVersion = 1;  //!< Class version

// Public interface
public:
    // Default constructor
    SurfaceFireSpread( void ) ;
    // Custom constructors
    SurfaceFireSpread(
        SurfaceFireFuelInterface* fuel,
        SurfaceFireTerrainInterface* terrain,
        SurfaceFireWindInterface* wind );
    // Virtual destructor
    virtual ~SurfaceFireSpread( void ) ;
    // Copy constructor
    SurfaceFireSpread( const SurfaceFireSpread & ) ;
    // Assignment operator
    const SurfaceFireSpread &operator=( const SurfaceFireSpread &rhs ) ;

    // Property access methods
    const char *className( void ) const ;
    int classVersion( void ) const ;
    SurfaceFireFuelInterface* connectedFuel( void ) const ;
    SurfaceFireTerrainInterface* connectedTerrain( void ) const ;
    SurfaceFireWindInterface* connectedWind( void ) const ;
    double distanceAtBack( double elapsedMinutes=0.0 ) const ;
    double distanceAtCompass( double elapsedMinutes=0.0 ) const ;
    double distanceAtHead( double elapsedMinutes=0.0 ) const ;
    double eccentricity( void ) const ;
    double effectiveWindSpeed( void ) const ;
    double fireAcres( double elapsedMinutes=0.0 ) const ;
    double fireArea( double elapsedMinutes=0.0 ) const ;
    double fireLength( double elapsedMinutes=0.0 ) const ;
    double firelineIntAtBack( void ) const ;
    double firelineIntAtCompass( void ) const ;
    double firelineIntAtCompass( double degreesClockwiseFromNorth ) const ;
    double firelineIntAtHead( void ) const ;
    double firePerimeter( double elapsedMinutes=0.0 ) const ;
    double fireWidth( double elapsedMinutes=0.0 ) const ;
    double flameLengthAtBack( void ) const ;
    double flameLengthAtCompass( void ) const ;
    double flameLengthAtCompass( double degreesClockwiseFromNorth ) const ;
    double flameLengthAtHead( void ) const ;
    double lengthToWidthRatio( void ) const ;
    double phiEffectiveWind( void ) const ;
    double phiSlope( void ) const ;
    double phiWind( void ) const ;
    double scorchHeightAtBack( void ) const ;
    double scorchHeightAtCompass( void ) const ;
    double scorchHeightAtCompass( double degreesClockwiseFromNorth ) const ;
    double scorchHeightAtHead( void ) const ;
    double slopeK( void ) const ;
    double spreadDirectionAtBack( void ) const ;
    double spreadDirectionAtCompass( void ) const ;
    double spreadDirectionAtCompass( double degreesClockwiseFromNorth ) const ;
    double spreadDirectionAtHead( void ) const ;
    double spreadRateAtBack( void ) const ;
    double spreadRateAtCompass( void ) const ;
    double spreadRateAtCompass( double degreesClockwiseFromNorth ) const ;
    double spreadRateAtHead( void ) const ;
    bool   windLimitExceeded( void ) const ;

    // Property update methods
    void connectFuel( Sem::SurfaceFireFuelInterface* fuel ) ;
    void connectTerrain( Sem::SurfaceFireTerrainInterface* terrain ) ;
    void connectWind( Sem::SurfaceFireWindInterface* wind ) ;

public slots:
    void disconnectTerrain( void );
    void disconnectFuel( void );
    void disconnectWind( void );
    void fuelChanged( void );
    void fuelDestroyed( void );
    void terrainChanged( void );
    void terrainDestroyed( void );
    void windChanged( void );
    void windDestroyed( void );

// Protected interface
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;
    virtual void updateCompassDirection( double degreesClockwiseFromNorth,
        bool force=false ) const ;

// Private implementation
protected:
    Sem::SurfaceFireFuelInterface* m_fuel;          //!< Surface fuel bed and moisture
    Sem::SurfaceFireTerrainInterface* m_terrain;    //!< Surface fire terrain
    Sem::SurfaceFireWindInterface* m_wind;          //!< Surface fire midflame wind
    mutable double m_eccentricity;          //!< Surface fire ellipse eccentricity (dl).
    mutable double m_elapsedMinutes;        //!< Surface fire elapsed time since ignition (min).
    mutable double m_effWindSpeed;          //!< Surface fire spread rate wind+slope effective wind speed (ft.min).
    mutable double m_firelineIntAtBack;     //!< Surface fire fireline intensity in backing direction (Btu/ft/s).
    mutable double m_firelineIntAtCompass;  //!< Surface fire fireline intensity in compass direction (Btu/ft/s).
    mutable double m_firelineIntAtHead;     //!< Surface fire fireline intensity in heading (Btu/ft/s).
    mutable double m_flameLengthAtBack;     //!< Surface fire flame length in heading direction (ft).
    mutable double m_flameLengthAtCompass;  //!< Surface fire flame length in compass direction (ft).
    mutable double m_flameLengthAtHead;     //!< Surface fire flame length in backing direction(ft).
    mutable double m_lengthToWidthRatio;    //!< Surface fire ellipse length-to-width ratio (dl).
    mutable double m_phiEffWind;            //!< Surface fire spread rate effective wind (wind+slope) factor (dl).
    mutable double m_phiSlope;              //!< Surface fire spread rate slope factor (dl).
    mutable double m_phiWind;               //!< Surface fire spread rate wind coefficient (dl).
    mutable double m_scorchHeightAtBack;    //!< Surface fire scorch height in backing direction (ft)
    mutable double m_scorchHeightAtCompass; //!< Surface fire scorch height in compass direction cache (ft)
    mutable double m_scorchHeightAtHead;    //!< Surface fire scorch height in heading direction (ft)
    mutable double m_slopeK;                //!< Surface fire bed intermediate slope term [derived].
    mutable double m_spreadDirAtBack;       //!< Surface fire backing direction (degrees clockwise from north).
    mutable double m_spreadDirAtCompass;    //!< Surface fire compass direction cache (degrees clockwise from north).
    mutable double m_spreadDirAtHead;       //!< Surface fire heading direction (degrees clockwise from north).
    mutable double m_spreadRateAtBack;      //!< Surface fire spread rate in backing direction (ft/min)
    mutable double m_spreadRateAtCompass;   //!< Surface fire spread rate in compass direction cache (ft/min)
    mutable double m_spreadRateAtHead;      //!< Surface fire spread rate in heading direction (ft/min)
    mutable bool   m_windLimitExceeded;     //!< TRUE if the maximum reliable wind speed is reached
    mutable double m_windB;                 //!< Surface fire bed intermediate wind parameter "b" (0.02526*pow(m_sigma,0.54)) [derived].
    mutable double m_windC;                 //!< Surface fire bed intermediate wind parameter "c" (7.47*exp(-0.133*pow( m_sigma,0.55)) [derived].
    mutable double m_windE;                 //!< Surface fire bed intermediate wind parameter "e" (0.715*exp(-0.000359*m_sigma)) [derived].
    mutable double m_windK;                 //!< Surface fire bed intermediate wind term (m_windC * pow(m_betaRatio,-m_windE)) [derived].
};

// Non-member equality operators
bool operator ==( const SurfaceFireSpread& a, const SurfaceFireSpread& b ) ;
bool operator !=( const SurfaceFireSpread& a, const SurfaceFireSpread& b ) ;

}   // End of namespace Sem

#endif  // _SURFACEFIRESPREAD_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFire.h
//------------------------------------------------------------------------------

