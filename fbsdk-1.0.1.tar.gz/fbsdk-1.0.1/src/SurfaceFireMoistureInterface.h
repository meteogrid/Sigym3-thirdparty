//------------------------------------------------------------------------------
/*! \file SurfaceFireMoistureInterface.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An abstract base class defining an interface to provide surface fire
    fuel particle moisture content information.
 */

#ifndef _SURFACEFIREMOISTUREINTERFACE_H_INCLUDED_
#define _SURFACEFIREMOISTUREINTERFACE_H_INCLUDED_

// Qt include files
#include "Signal.h"
#include "SurfaceFireFuelAlgorithm.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireMoistureInterface SurfaceFireMoistureInterface.h
    \brief An abstract base class defining an interface to provide surface fire
    fuel particle moisture content information.

    The SurfaceFireMoistureInterface defines a just a few methods to access
    the various surface fire fuel moisture values.  How these moisture
    values get set is up to the implementation.

    SurfaceFireMoistureInterface inherits from Signal, so derived classes
    must implement the virtual update() method.

    Any class derived from SurfaceFireMoistureInterface can be connected to a
    SurfaceFireFuelModel class for dynamic moisture updating.

    At least two implementations of this interface exist:
    - The SurfaceFireMoistureTimeLag class is a simple get/set implementation
    that merely sets and gets the 6 moisture values.
    - The SurfaceFireMoistureStick class implements Nelson's physical
    processes model to update dead fuel moisture based upon local temperature,
    humidity, solar radiation, and rainfall.
 */

class SurfaceFireMoistureInterface : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireMoistureInterfaceVersion = 1;   //!< Class version

// Public interface
public:
    /*! \brief Virtual destructor implemented here
     */
    virtual ~SurfaceFireMoistureInterface( void ) {}

    // Property access methods
    const char* className( void ) const { return( metaObject()->className() ); }
    int classVersion( void ) const { return ( surfaceFireMoistureInterfaceVersion ); }

    /*! \fn virtual double dead1h( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Dead 1-h time lag fuel moisture content (fraction oven-dry weight).
    */
    virtual double dead1h( void ) const = 0 ;

    /*! \fn virtual double dead10h( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Dead 10-h time lag fuel moisture content (fraction oven-dry weight).
    */
    virtual double dead10h( void ) const = 0 ;

    /*! \fn virtual double dead100h( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Dead 100-h time lag fuel moisture content (fraction oven-dry weight).
    */
    virtual double dead100h( void ) const = 0 ;

    /*! \fn virtual double dead1000h( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Dead 1000-h time lag fuel moisture content (fraction oven-dry weight).
    */
    virtual double dead1000h( void ) const = 0 ;

    /*! \fn virtual double liveHerb( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
    */
    virtual double liveHerb( void ) const = 0 ;

    /*! \fn virtual double liveWood( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Live herbaceous fuel moisture content (fraction oven-dry weight).
    */
    virtual double liveWood( void ) const = 0 ;

    /*! \fn virtual double moisture( Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass type ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Live woody fuel moisture content (fraction oven-dry weight).
    */
    virtual double moisture(
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass type ) const = 0;
};

}   // End of namespace Sem

#endif  // _SURFACEFIREMOISTUREINTERFACE_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireMoistureInterface.h
//------------------------------------------------------------------------------

