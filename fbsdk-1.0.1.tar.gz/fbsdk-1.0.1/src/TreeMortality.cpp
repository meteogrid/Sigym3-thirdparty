//------------------------------------------------------------------------------
/*! \file TreeMortality.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of the FOFEM tree mortality model.
 */

// Custom header files
#include "Logger.h"
#include "TreeMortality.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::TreeMortality::treeCrownRatioMin = 0.0;
const double Sem::TreeMortality::treeCrownRatioMax = 1.0;
const double Sem::TreeMortality::treeDbhMin = 5.0;
const double Sem::TreeMortality::treeDbhMax = 40.0;
const double Sem::TreeMortality::treeHeightMin = 10.0;
const double Sem::TreeMortality::treeHeightMax = 300.0;
const double Sem::TreeMortality::scorchHeightMin = 0.0;
const double Sem::TreeMortality::scorchHeightMax = 300.0;

//------------------------------------------------------------------------------
/*! \brief TreeMortality default constructor.
 */

Sem::TreeMortality::TreeMortality( void ) :
    Signal(),
    m_scorchHeight(scorchHeightMin),
    m_treeCrownRatio(treeCrownRatioMin),
    m_treeDbh(treeDbhMin),
    m_treeHeight(treeHeightMin),
    m_species(Sem::FofemTreeSpecies::FofemSpeciesPINPON),
    m_barkThickness(0.0),
    m_crownLengthScorched(0.0),
    m_crownVolumeScorched(0.0),
    m_mortalityProbability(0.0)
{
    init();
    m_classVersion = treeMortalityVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief TreeMortality custom constructor.

    \param[in] species Sem::FofemSpecies enumeration index.
    \param[in] treeHeight Total tree height (10-300 ft).
    \param[in] treeCrownRatio Tree crown length-to-bole length ratio (ft/ft).
    \param[in] treeDbh Tree diameter-at-breast-height 95-40 in).
    \param[in] scorchHeight Scorch height on tree (ft).
 */

Sem::TreeMortality::TreeMortality(
            Sem::FofemTreeSpecies::FofemSpecies species,
            double treeHeight,
            double treeCrownRatio,
            double treeDbh,
            double scorchHeight ) :
    Signal(),
    m_scorchHeight(scorchHeight),
    m_treeCrownRatio(treeCrownRatio),
    m_treeDbh(treeDbh),
    m_treeHeight(treeHeight),
    m_species(species),
    m_barkThickness(0.0),
    m_crownLengthScorched(0.0),
    m_crownVolumeScorched(0.0),
    m_mortalityProbability(0.0)
{
    assert( m_scorchHeight   >= scorchHeightMin
         && m_scorchHeight   <= scorchHeightMax );
    assert( m_treeCrownRatio >= treeCrownRatioMin
         && m_treeCrownRatio <= treeCrownRatioMax );
    assert( m_treeDbh        >= treeDbhMin
         && m_treeDbh        <= treeDbhMax );
    assert( m_treeHeight     >= treeHeightMin
         && m_treeHeight     <= treeHeightMax );
    init();
    m_classVersion = treeMortalityVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::TreeMortality::~TreeMortality( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief TreeMortality copy constructor.
    \param[in] right Reference to the TreeMortality from which to copy.
    \return Reference to the newly allocated TreeMortality.
 */

Sem::TreeMortality::TreeMortality( const TreeMortality &right ) :
    Signal()
{
    init();
    m_classVersion         = right.m_classVersion;
    m_scorchHeight         = right.m_scorchHeight;
    m_treeCrownRatio       = right.m_treeCrownRatio;
    m_treeDbh              = right.m_treeDbh;
    m_treeHeight           = right.m_treeHeight;
    m_species              = right.m_species;
    m_barkThickness        = right.m_barkThickness;
    m_crownLengthScorched  = right.m_crownLengthScorched;
    m_crownVolumeScorched  = right.m_crownVolumeScorched;
    m_mortalityProbability = right.m_mortalityProbability;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief TreeMortality assignment operator.
    \param[in] right Reference to the TreeMortality from which to assign.
    \return Reference to the newly assigned TreeMortality.
 */

const Sem::TreeMortality& Sem::TreeMortality::operator=(
        const TreeMortality &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion         = right.m_classVersion;
        m_scorchHeight         = right.m_scorchHeight;
        m_treeCrownRatio       = right.m_treeCrownRatio;
        m_treeDbh              = right.m_treeDbh;
        m_treeHeight           = right.m_treeHeight;
        m_species              = right.m_species;
        m_barkThickness        = right.m_barkThickness;
        m_crownLengthScorched  = right.m_crownLengthScorched;
        m_crownVolumeScorched  = right.m_crownVolumeScorched;
        m_mortalityProbability = right.m_mortalityProbability;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the derived tree bark thickness.

    \return Tree bark thickness (in).
 */

double Sem::TreeMortality::barkThickness( void ) const
{
    checkUpdate();
    return( m_barkThickness );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::TreeMortality::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::TreeMortality::classVersion( void ) const
{
    return( treeMortalityVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the derived tree crown length scorched.

    \return Tree crown length scorched (ft).
 */

double Sem::TreeMortality::crownLengthScorched( void ) const
{
    checkUpdate();
    return( m_crownLengthScorched );
}

//------------------------------------------------------------------------------
/*! \brief Access to the derived tree crown volume scorched.

    \return Tree crown volume scorched (scorch volume/crown volume).
 */

double Sem::TreeMortality::crownVolumeScorched( void ) const
{
    checkUpdate();
    return( m_crownVolumeScorched );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::TreeMortality::init( void ) const
{
    m_barkThickness        = 0.0;
    m_crownLengthScorched  = 0.0;
    m_crownVolumeScorched  = 0.0;
    m_mortalityProbability = 0.0;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the derived tree mortality probability.

    \return Tree mortality probability (fraction).
 */

double Sem::TreeMortality::mortalityProbability( void ) const
{
    checkUpdate();
    return( m_mortalityProbability );
}

//------------------------------------------------------------------------------
/*! \brief Access to the scorch height.

    \return Scorch height (ft).
 */

double Sem::TreeMortality::scorchHeight( void ) const
{
    return( m_scorchHeight );
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean scorch height.

    \param[in] scorchHeight Scorch height on tree (ft).
 */

void Sem::TreeMortality::setScorchHeight( double scorchHeight )
{
    assert( scorchHeight >= scorchHeightMin
         && scorchHeight <= scorchHeightMax );
    if ( scorchHeight != m_scorchHeight )
    {
        m_scorchHeight = scorchHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the tree's Sem::FofemSpecies enumeration index.

    \param[in] species Sem::FofemSpecies enumeration index.
 */

void Sem::TreeMortality::setSpecies( Sem::FofemTreeSpecies::FofemSpecies species )
{
    if ( species != m_species )
    {
        m_species = species;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the tree crown ratio.

    \param[in] treeCrownRatio Tree crown length-to-bole length ratio (ft/ft).
 */

void Sem::TreeMortality::setTreeCrownRatio( double treeCrownRatio )
{
    assert( treeCrownRatio >= treeCrownRatioMin
         && treeCrownRatio <= treeCrownRatioMax );
    if ( treeCrownRatio != m_treeCrownRatio )
    {
        m_treeCrownRatio = treeCrownRatio;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the tree diameter-at-breast height.

    \param[in] treeDbh Tree diameter-at-breast-height 95-40 in).
 */

void Sem::TreeMortality::setTreeDbh( double treeDbh )
{
    assert( treeDbh >= treeDbhMin
         && treeDbh <= treeDbhMax );
    if ( treeDbh != m_treeDbh )
    {
        m_treeDbh = treeDbh;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the total tree height.

    \param[in] treeHeight Tree height (ft).
 */

void Sem::TreeMortality::setTreeHeight( double treeHeight )
{
    assert( treeHeight >= treeHeightMin
         && treeHeight <= treeHeightMax );
    if ( treeHeight != m_treeHeight )
    {
        m_treeHeight = treeHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the tree's Sem::FofemSpecies enumeration index.

    \return Tree's Sem::FofemSpecies enumeration index.
 */

Sem::FofemTreeSpecies::FofemSpecies Sem::TreeMortality::species( void ) const
{
    return( m_species );
}

//------------------------------------------------------------------------------
/*! \brief Access to the tree crown ratio.

    \return Tree crown ratio (ft crown / ft tree).
 */

double Sem::TreeMortality::treeCrownRatio( void ) const
{
    return( m_treeCrownRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the tree dbh.

    \return Tree diameter-at-breast height (in).
 */

double Sem::TreeMortality::treeDbh( void ) const
{
    return( m_treeDbh );
}

//------------------------------------------------------------------------------
/*! \brief Access to the tree height.

    \return Total tree height (ft).
 */

double Sem::TreeMortality::treeHeight( void ) const
{
    return( m_treeHeight );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access METHODS to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::TreeMortality::update( void ) const
{
    // Initialize all mutables
    init();

    // Bark thickness
    m_barkThickness = Sem::TreeMortalityAlgorithm::treeBarkThicknessFofem(
        m_species, m_treeDbh );

    // Crown length and volume scorched
    double crownLengthFractionScorched;
    m_crownVolumeScorched = Sem::TreeMortalityAlgorithm::treeCrownScorch(
        m_treeHeight, m_treeCrownRatio, m_scorchHeight,
        &m_crownLengthScorched, &crownLengthFractionScorched );

    // Determine if this is a Picea species
    const char* name = Sem::FofemTreeSpecies::scientificName( m_species );
    bool isPicea = ( strncmp( name, "Picea", 5 ) == 0 );

    // Mortality probability
    m_mortalityProbability = Sem::TreeMortalityAlgorithm::treeMortalityFofem(
        m_barkThickness, m_crownVolumeScorched, isPicea );

    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two TreeMortality objects.

    \param[in] lhs Left-hand-side TreeMortality object.
    \param[in] rhs Right-hand-side TreeMortality object.
 */
bool Sem::operator ==( const Sem::TreeMortality &lhs,
                       const Sem::TreeMortality &rhs )
{ 
  return( lhs.species() == rhs.species()
       && fabs( lhs.scorchHeight() - rhs.scorchHeight() ) < Smidgen
       && fabs( lhs.treeCrownRatio() - rhs.treeCrownRatio() ) < Smidgen
       && fabs( lhs.treeDbh() - rhs.treeDbh() ) < Smidgen
       && fabs( lhs.treeHeight() - rhs.treeHeight() ) < Smidgen );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two TreeMortality objects.

    \param[in] lhs Left-hand-side TreeMortality object.
    \param[in] rhs Right-hand-side TreeMortality object.
 */
bool Sem::operator !=( const Sem::TreeMortality &lhs,
                       const Sem::TreeMortality &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of TreeMortality.cpp
//------------------------------------------------------------------------------

