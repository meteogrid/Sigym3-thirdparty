//------------------------------------------------------------------------------
/*! \file CrownFireSpread.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Implements \ref rothermel1991 crown fire spread with additional
    support for transition to crown fire from surface fire.
 */

// Custom header files
#include "Logger.h"
#include "CrownFireAlgorithm.h"
#include "CrownFireSpread.h"
#include "SurfaceFireSpreadAlgorithm.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::CrownFireSpread::canopyBaseHeightMin  = 3.0;
const double Sem::CrownFireSpread::canopyBaseHeightMax  = 300.0;
const double Sem::CrownFireSpread::canopyBulkDensityMin = 0.000625;
const double Sem::CrownFireSpread::canopyBulkDensityMax = 0.0625;
const double Sem::CrownFireSpread::dead1hMin = 0.01;
const double Sem::CrownFireSpread::dead1hMax = 0.60;
const double Sem::CrownFireSpread::dead10hMin = 0.01;
const double Sem::CrownFireSpread::dead10hMax = 0.60;
const double Sem::CrownFireSpread::dead100hMin = 0.01;
const double Sem::CrownFireSpread::dead100hMax = 0.60;
const double Sem::CrownFireSpread::flameLengthMin = 0.0;
const double Sem::CrownFireSpread::flameLengthMax = 200.0;
const double Sem::CrownFireSpread::foliarMoistureMin = 0.30;
const double Sem::CrownFireSpread::foliarMoistureMax = 3.00;
const double Sem::CrownFireSpread::liveWoodMin = 0.30;
const double Sem::CrownFireSpread::liveWoodMax = 3.00;
const double Sem::CrownFireSpread::windSpeedAt20FtMin = 0.0;
const double Sem::CrownFireSpread::windSpeedAt20FtMax = 99.0;

//------------------------------------------------------------------------------
/*! \brief CrownFireSpread default constructor.
 */

Sem::CrownFireSpread::CrownFireSpread( void ) :
    Signal(),
    m_canopyBaseHeight( canopyBaseHeightMin ),
    m_canopyBulkDensity( canopyBulkDensityMin ),
    m_dead1h( dead1hMax ),
    m_dead10h( dead10hMax ),
    m_dead100h( dead100hMax ),
    m_flameLength( flameLengthMin ),
    m_foliarMoisture( foliarMoistureMax ),
    m_liveWood( liveWoodMax ),
    m_windSpeedAt20Ft( windSpeedAt20FtMin ),
    m_activeCrownFire( false ),
    m_activeRatio( 0.0 ),
    m_criticalCrownFireSpreadRate( 0.0 ),
    m_criticalSurfaceFirelineIntensity( 0.0 ),
    m_criticalSurfaceFlameLength( 0.0 ),
    m_crownFireSpreadRate( 0.0 ),
    m_fireStatus( Sem::CrownFireAlgorithm::FireStatusSurface ),
    m_surfaceFirelineIntensity( 0.0 ),
    m_transitionRatio( 0.0 ),
    m_transitionToCrown( false )
{
    init();
    m_classVersion = crownFireSpreadVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief CrownFireSpread custom constructor.

    \param[in] canopyBaseHeight Height of the crown fuel canopy above the ground (3-300 ft).
    \param[in] canopyBulkDensity Bulk density of the crown fuel canopy (0.000625 - 0.0625 lb/ft<sup>3</sup>).
    \param[in] dead1h Crown fuel canopy dead 1-h time lag fuel moisture content (0.01 - 0.60 lb water/lb fuel).
    \param[in] dead10h Crown fuel canopy dead 1-h time lag fuel moisture content (0.01 - 0.60 lb water/lb fuel).
    \param[in] dead100h Crown fuel canopy dead 1-h time lag fuel moisture content (0.01 - 0.60 lb water/lb fuel).
    \param[in] liveWood Crown fuel canopy live wood fuel moisture content (0.30 - 3.00 lb water/lb fuel).
    \param[in] foliarMoisture Crown fuel canopy foliar moisture content (0.30 - 3.00 lb water/lb fuel).
    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
    \param[in] flameLength Surface fire flame length (0-200 ft).
 */

Sem::CrownFireSpread::CrownFireSpread(
        double canopyBaseHeight,
        double canopyBulkDensity,
        double dead1h,
        double dead10h,
        double dead100h,
        double liveWood,
        double foliarMoisture,
        double windSpeedAt20Ft,
        double flameLength ) :
    Signal(),
    m_canopyBaseHeight( canopyBaseHeight ),
    m_canopyBulkDensity( canopyBulkDensity ),
    m_dead1h( dead1h ),
    m_dead10h( dead10h ),
    m_dead100h( dead100h ),
    m_flameLength( flameLength ),
    m_foliarMoisture( foliarMoisture ),
    m_liveWood( liveWood ),
    m_windSpeedAt20Ft( windSpeedAt20Ft ),
    m_activeCrownFire( false ),
    m_activeRatio( 0.0 ),
    m_criticalCrownFireSpreadRate( 0.0 ),
    m_criticalSurfaceFirelineIntensity( 0.0 ),
    m_criticalSurfaceFlameLength( 0.0 ),
    m_crownFireSpreadRate( 0.0 ),
    m_fireStatus( Sem::CrownFireAlgorithm::FireStatusSurface ),
    m_surfaceFirelineIntensity( 0.0 ),
    m_transitionRatio( 0.0 ),
    m_transitionToCrown( false )
{
    assert( m_canopyBaseHeight  >= canopyBaseHeightMin
         && m_canopyBaseHeight  <= canopyBaseHeightMax );
    assert( m_canopyBulkDensity >= canopyBulkDensityMin
         && m_canopyBulkDensity <= canopyBulkDensityMax );
    assert( m_dead1h            >= dead1hMin
         && m_dead1h            <= dead1hMax );
    assert( m_dead10h           >= dead10hMin
         && m_dead10h           <= dead10hMax );
    assert( m_dead100h          >= dead100hMin
         && m_dead100h          <= dead100hMax );
    assert( m_flameLength       >= flameLengthMin
         && m_flameLength       <= flameLengthMax );
    assert( m_foliarMoisture    >= foliarMoistureMin
         && m_foliarMoisture    <= foliarMoistureMax );
    assert( m_liveWood          >= liveWoodMin
         && m_liveWood          <= liveWoodMax );
    assert( m_windSpeedAt20Ft   >= windSpeedAt20FtMin
         && m_windSpeedAt20Ft   <= windSpeedAt20FtMax );
    init();
    m_classVersion = crownFireSpreadVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::CrownFireSpread::~CrownFireSpread( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief CrownFireSpread copy constructor.
    \param[in] right Reference to the CrownFireSpread from which to copy.
    \return Reference to the newly allocated CrownFireSpread.
 */

Sem::CrownFireSpread::CrownFireSpread( const CrownFireSpread &right ) :
    Signal()
{
    init();
    m_classVersion      = right.m_classVersion;
    m_canopyBaseHeight  = right.m_canopyBaseHeight;
    m_canopyBulkDensity = right.m_canopyBulkDensity;
    m_dead1h            = right.m_dead1h;
    m_dead10h           = right.m_dead10h;
    m_dead100h          = right.m_dead100h;
    m_flameLength       = right.m_flameLength;
    m_foliarMoisture    = right.m_foliarMoisture;
    m_liveWood          = right.m_liveWood;
    m_windSpeedAt20Ft   = right.m_windSpeedAt20Ft;
    m_activeCrownFire   = right.m_activeCrownFire;
    m_activeRatio       = right.m_activeRatio;
    m_criticalCrownFireSpreadRate = right.m_criticalCrownFireSpreadRate;
    m_criticalSurfaceFirelineIntensity = right.m_criticalSurfaceFirelineIntensity;
    m_criticalSurfaceFlameLength = right.m_criticalSurfaceFlameLength;
    m_crownFireSpreadRate = right.m_crownFireSpreadRate;
    m_fireStatus        = right.m_fireStatus;
    m_surfaceFirelineIntensity = right.m_surfaceFirelineIntensity;
    m_transitionRatio   = right.m_transitionRatio;
    m_transitionToCrown = right.m_transitionToCrown;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief CrownFireSpread assignment operator.
    \param[in] right Reference to the CrownFireSpread from which to assign.
    \return Reference to the newly assigned CrownFireSpread.
 */

const Sem::CrownFireSpread& Sem::CrownFireSpread::operator=(
        const CrownFireSpread &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion    = right.m_classVersion;
        m_canopyBaseHeight  = right.m_canopyBaseHeight;
        m_canopyBulkDensity = right.m_canopyBulkDensity;
        m_dead1h            = right.m_dead1h;
        m_dead10h           = right.m_dead10h;
        m_dead100h          = right.m_dead100h;
        m_flameLength       = right.m_flameLength;
        m_foliarMoisture    = right.m_foliarMoisture;
        m_liveWood          = right.m_liveWood;
        m_windSpeedAt20Ft   = right.m_windSpeedAt20Ft;
        m_activeCrownFire   = right.m_activeCrownFire;
        m_activeRatio       = right.m_activeRatio;
        m_criticalCrownFireSpreadRate = right.m_criticalCrownFireSpreadRate;
        m_criticalSurfaceFirelineIntensity = right.m_criticalSurfaceFirelineIntensity;
        m_criticalSurfaceFlameLength = right.m_criticalSurfaceFlameLength;
        m_crownFireSpreadRate = right.m_crownFireSpreadRate;
        m_fireStatus        = right.m_fireStatus;
        m_surfaceFirelineIntensity = right.m_surfaceFirelineIntensity;
        m_transitionRatio   = right.m_transitionRatio;
        m_transitionToCrown = right.m_transitionToCrown;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the active crown fire status flag.

    \return TRUE if active crown fire, FALSE if not.
 */

bool Sem::CrownFireSpread::activeCrownFire( void ) const
{
    checkUpdate();
    return( m_activeCrownFire );
}

//------------------------------------------------------------------------------
/*! \brief Access to the active ratio.

    The 'active' ratio is the ratio of the crown fire spread rate to the
    'critical' crown fire spread rate (the rate a crown fire must spread
    to maintain itself \ref vanwagner1977).

    \return Ratio of crown fire spread rate to the critical crown fire
    spread rate.
 */

double Sem::CrownFireSpread::activeRatio( void ) const
{
    checkUpdate();
    return( m_activeRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel canopy base height.

    \return Mean crown fuel canopy base height.
 */

double Sem::CrownFireSpread::canopyBaseHeight( void ) const
{
    return( m_canopyBaseHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel canopy bulk density.

    \return Mean crown fuel canopy bulk density.
 */

double Sem::CrownFireSpread::canopyBulkDensity( void ) const
{
    return( m_canopyBulkDensity );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::CrownFireSpread::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::CrownFireSpread::classVersion( void ) const
{
    return( crownFireSpreadVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the critical crown fire spread rate.

    The 'critical' crown fire spread rate is the minimum rate a crown fire
    must spread to maintain itself \ref vanwagner1977).

    \return Critical crown fire spread rate (ft/min).
 */

double Sem::CrownFireSpread::criticalCrownFireSpreadRate( void ) const
{
    checkUpdate();
    return( m_criticalCrownFireSpreadRate );
}

//------------------------------------------------------------------------------
/*! \brief Access to the critical surface fire fireline intensity.

    The 'critical' surface fire fireline intensity is the minimum fireline
    intensity required to affect a transition from surface fire to crown fire.

    \return Critical surface fire fireline intensity (Btu/ft<sup>2</sup>/s).
 */

double Sem::CrownFireSpread::criticalSurfaceFirelineIntensity( void ) const
{
    checkUpdate();
    return( m_criticalSurfaceFirelineIntensity );
}

//------------------------------------------------------------------------------
/*! \brief Access to the critical surface fire flame length.

    The 'critical' surface fire flame length is the minimum fireline
    intensity required to affect a transition from surface fire to crown fire.

    \return Critical surface fire flame length (ft).
 */

double Sem::CrownFireSpread::criticalSurfaceFlameLength( void ) const
{
    checkUpdate();
    return( m_criticalSurfaceFlameLength );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fire spread rate.

    \return Crown fire spread rate (ft/min).
 */

double Sem::CrownFireSpread::crownFireSpreadRate( void ) const
{
    checkUpdate();
    return( m_crownFireSpreadRate );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel dead 1-h time lag fuel moisture content.

    \return Aerial fuel dead 1-h time lag fuel moisture content.
 */

double Sem::CrownFireSpread::dead1h( void ) const
{
    return( m_dead1h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel dead 10-h time lag fuel moisture content.

    \return Aerial fuel dead 10-h time lag fuel moisture content.
 */

double Sem::CrownFireSpread::dead10h( void ) const
{
    return( m_dead10h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel dead 100-h time lag fuel moisture content.

    \return Aerial fuel dead 100-h time lag fuel moisture content.
 */

double Sem::CrownFireSpread::dead100h( void ) const
{
    return( m_dead100h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the Sem::FireStatus.

    \return SEM::FireStatus for the fire:
        - FireStatusSurface  = 0,
        - FireStatusTorching = 1,
        - FireStatusCrowning = 2.
 */

Sem::CrownFireAlgorithm::FireStatus Sem::CrownFireSpread::fireStatus( void ) const
{
    checkUpdate();
    return( m_fireStatus );
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel foliar moisture content.

    \return Aerial fuel foliar moisture content.
 */

double Sem::CrownFireSpread::foliarMoisture( void ) const
{
    return( m_foliarMoisture );
}

//------------------------------------------------------------------------------
/*! \brief Access to the steady flame length from a burning pile.

    \return Steady flame length from a burning pile (ft).
 */

double Sem::CrownFireSpread::flameLength( void ) const
{
    return( m_flameLength );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::CrownFireSpread::init( void ) const
{
    m_activeCrownFire     = false;
    m_activeRatio         = 0.0;
    m_criticalCrownFireSpreadRate = 0.0;
    m_criticalSurfaceFirelineIntensity = 0.0;
    m_criticalSurfaceFlameLength = 0.0;
    m_crownFireSpreadRate = 0.0;
    m_fireStatus          = Sem::CrownFireAlgorithm::FireStatusSurface;
    m_surfaceFirelineIntensity = 0.0;
    m_transitionRatio     = 0.0;
    m_transitionToCrown   = false;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the crown fuel live wood moisture content.

    \return Aerial fuel live wood moisture content.
 */

double Sem::CrownFireSpread::liveWood( void ) const
{
    return( m_liveWood );
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean crown canopy base height.

    \param[in] canopyBaseHeight Height of the crown fuel canopy above the
    ground (3-300 ft).
 */

void Sem::CrownFireSpread::setCanopyBaseHeight( double canopyBaseHeight )
{
    assert( canopyBaseHeight >= canopyBaseHeightMin
         && canopyBaseHeight <= canopyBaseHeightMax );
    if ( canopyBaseHeight != m_canopyBaseHeight )
    {
        m_canopyBaseHeight = canopyBaseHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean crown canopy bulk density.

    \param[in] canopyBulkDensity Bulk density of the crown fuel canopy
    (0.000625 - 0.0625 lb/ft<sup>3</sup>).
 */

void Sem::CrownFireSpread::setCanopyBulkDensity( double canopyBulkDensity )
{
    assert( canopyBulkDensity >= canopyBulkDensityMin
         && canopyBulkDensity <= canopyBulkDensityMax );
    if ( canopyBulkDensity != m_canopyBulkDensity )
    {
        m_canopyBulkDensity = canopyBulkDensity;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the crown fuel dead 1-h time lag moisture content.

    \param[in] dead1h Crown fuel canopy dead 1-h time lag fuel moisture
    content (0.01 - 0.60 lb water/lb fuel).
 */

void Sem::CrownFireSpread::setDead1h( double dead1h )
{
    assert( dead1h >= dead1hMin
         && dead1h <= dead1hMax );
    if ( dead1h != m_dead1h )
    {
        m_dead1h = dead1h;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the crown fuel dead 10-h time lag moisture content.

    \param[in] dead10h Crown fuel canopy dead 10-h time lag fuel moisture
    content (0.01 - 0.60 lb water/lb fuel).
 */

void Sem::CrownFireSpread::setDead10h( double dead10h )
{
    assert( dead10h >= dead10hMin
         && dead10h <= dead10hMax );
    if ( dead10h != m_dead10h )
    {
        m_dead10h = dead10h;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the crown fuel dead 100-h time lag moisture content.

    \param[in] dead100h Crown fuel canopy dead 100-h time lag fuel moisture
    content (0.01 - 0.60 lb water/lb fuel).
 */

void Sem::CrownFireSpread::setDead100h( double dead100h )
{
    assert( dead100h >= dead100hMin
         && dead100h <= dead100hMax );
    if ( dead100h != m_dead100h )
    {
        m_dead100h = dead100h;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fire flame length.

    \param[in] flameLength Surface fire flame length (0-200 ft).
 */

void Sem::CrownFireSpread::setFlameLength( double flameLength )
{
    assert( flameLength >= flameLengthMin
         && flameLength <= flameLengthMax );
    if ( flameLength != m_flameLength )
    {
        m_flameLength = flameLength;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the crown fuel foliar moisture content.

    \param[in] foliarMoisture Crown fuel canopy foliar moisture content
    (0.30 - 3.00 lb water/lb fuel).
 */

void Sem::CrownFireSpread::setFoliarMoisture( double foliarMoisture )
{
    assert( foliarMoisture >= foliarMoistureMin
         && foliarMoisture <= foliarMoistureMax );
    if ( foliarMoisture != m_foliarMoisture )
    {
        m_foliarMoisture = foliarMoisture;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the crown fuel live wood moisture content.

    \param[in] liveWood Crown fuel canopy live wood moisture content
    (0.30 - 3.00 lb water/lb fuel).
 */

void Sem::CrownFireSpread::setLiveWood( double liveWood )
{
    assert( liveWood >= liveWoodMin
         && liveWood <= liveWoodMax );
    if ( liveWood != m_liveWood )
    {
        m_liveWood = liveWood;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind speed at 20 ft.

    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
 */

void Sem::CrownFireSpread::setWindSpeedAt20Ft( double windSpeedAt20Ft )
{
    assert( windSpeedAt20Ft >= windSpeedAt20FtMin
         && windSpeedAt20Ft <= windSpeedAt20FtMax );
    if ( windSpeedAt20Ft != m_windSpeedAt20Ft )
    {
        m_windSpeedAt20Ft = windSpeedAt20Ft;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fireline intensity.

    \return Surface fire fireline intensity (Btu/ft<sup>2</sup>/s).
 */

double Sem::CrownFireSpread::surfaceFirelineIntensity( void ) const
{
    checkUpdate();
    return( m_surfaceFirelineIntensity );
}

//------------------------------------------------------------------------------
/*! \brief Access to the transition ratio.

    The 'transition' ratio is the ratio of the surface fire fireline intensity
    to the 'critical' surface fire fireline intensity required to affect a
    transition from surface fire to crown fire.

    \return Ratio of crown fire spread rate to the critical crown fire
    spread rate.
 */

double Sem::CrownFireSpread::transitionRatio( void ) const
{
    checkUpdate();
    return( m_transitionRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the transition-to-crown status flag.

    \return TRUE if the surface fire can transition to crown, FALSE if not.
 */

bool Sem::CrownFireSpread::transitionToCrown( void ) const
{
    checkUpdate();
    return( m_transitionToCrown );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access METHODS to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::CrownFireSpread::update( void ) const
{
    // Initialize all mutables
    init();

    // Surface-to-crown transition
    m_surfaceFirelineIntensity =
        Sem::SurfaceFireSpreadAlgorithm::firelineIntensity( m_flameLength );

    m_criticalSurfaceFirelineIntensity =
        Sem::CrownFireAlgorithm::criticalSurfaceFirelineIntensity(
            m_foliarMoisture, m_canopyBaseHeight );

    m_criticalSurfaceFlameLength =
        Sem::CrownFireAlgorithm::criticalSurfaceFlameLength(
            m_criticalSurfaceFirelineIntensity );

    m_transitionRatio = Sem::CrownFireAlgorithm::transitionRatio(
        m_surfaceFirelineIntensity, m_criticalSurfaceFirelineIntensity );

    m_transitionToCrown = ( m_transitionRatio >= 1.0 );

    // Active crown fire
    m_crownFireSpreadRate = Sem::CrownFireAlgorithm::crownFireSpreadRate(
        m_windSpeedAt20Ft, m_dead1h, m_dead10h, m_dead100h, m_liveWood );

    m_criticalCrownFireSpreadRate =
        Sem::CrownFireAlgorithm::criticalCrownFireSpreadRate(
            m_canopyBulkDensity );

    m_activeRatio = Sem::CrownFireAlgorithm::activeRatio(
        m_crownFireSpreadRate, m_criticalCrownFireSpreadRate );

    m_activeCrownFire = ( m_activeRatio >= 1.0 );

    // Fire status
    m_fireStatus = Sem::CrownFireAlgorithm::FireStatusSurface;
    if ( m_transitionToCrown )
    {
        m_fireStatus = ( m_activeCrownFire )
                     ? Sem::CrownFireAlgorithm::FireStatusCrowning
                     : Sem::CrownFireAlgorithm::FireStatusTorching;
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at 20 ft.

    \return Wind speed at 20 ft (mi/h).
 */

double Sem::CrownFireSpread::windSpeedAt20Ft( void ) const
{
    return( m_windSpeedAt20Ft );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two CrownFireSpread objects.

    \param[in] lhs Left-hand-side CrownFireSpread object.
    \param[in] rhs Right-hand-side CrownFireSpread object.
 */
bool Sem::operator ==( const Sem::CrownFireSpread &lhs,
                       const Sem::CrownFireSpread &rhs )
{ 
  return( fabs( lhs.canopyBaseHeight() - rhs.canopyBaseHeight() ) < Smidgen
       && fabs( lhs.canopyBulkDensity() - rhs.canopyBulkDensity() ) < Smidgen
       && fabs( lhs.dead1h() - rhs.dead1h() ) < Smidgen
       && fabs( lhs.dead10h() - rhs.dead10h() ) < Smidgen
       && fabs( lhs.dead100h() - rhs.dead100h() ) < Smidgen
       && fabs( lhs.flameLength() - rhs.flameLength() ) < Smidgen
       && fabs( lhs.foliarMoisture() - rhs.foliarMoisture() ) < Smidgen
       && fabs( lhs.liveWood() - rhs.liveWood() ) < Smidgen
       && fabs( lhs.windSpeedAt20Ft() - rhs.windSpeedAt20Ft() ) < Smidgen );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two CrownFireSpread objects.

    \param[in] lhs Left-hand-side CrownFireSpread object.
    \param[in] rhs Right-hand-side CrownFireSpread object.
 */
bool Sem::operator !=( const Sem::CrownFireSpread &lhs,
                       const Sem::CrownFireSpread &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of CrownFireSpread.cpp
//------------------------------------------------------------------------------

