//------------------------------------------------------------------------------
/*! \file SpotSurfaceFire.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of Albini's \ref albini1979 model for
    predicting maximum spotting distance from a group of burning trees.
 */

// Custom header files
#include "Logger.h"
#include "SpotSurfaceFire.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::SpotSurfaceFire::coverHeightMin = 0.0;
const double Sem::SpotSurfaceFire::coverHeightMax = 300.0;
const double Sem::SpotSurfaceFire::flameLengthMin = 0.0;
const double Sem::SpotSurfaceFire::flameLengthMax = 100.0;
const double Sem::SpotSurfaceFire::ridgetopToValleyDistanceMin = 0.0;
const double Sem::SpotSurfaceFire::ridgetopToValleyDistanceMax = 4.0;
const double Sem::SpotSurfaceFire::ridgetopToValleyElevationMin = 0.0;
const double Sem::SpotSurfaceFire::ridgetopToValleyElevationMax = 4000.0;
const double Sem::SpotSurfaceFire::windSpeedAt20FtMin = 0.0;
const double Sem::SpotSurfaceFire::windSpeedAt20FtMax = 99.0;

//------------------------------------------------------------------------------
/*! \brief SpotSurfaceFire default constructor.
 */

Sem::SpotSurfaceFire::SpotSurfaceFire( void ) :
    Signal(),
    m_coverHeight(0.0),
    m_distance(0.0),
    m_elevation(0.0),
    m_flameLength(0.0),
    m_source(Sem::SpotAlgorithm::SpotSourceValleyBottom),
    m_windSpeedAt20Ft(0.0),
    m_firebrandHeight(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    init();
    m_classVersion = spotSurfaceFireVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotSurfaceFire custom constructor.

    \param[in] source Tsurface fireing tree spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
    \param[in] ridgetopToValleyDistance Ridgetop-to-valley horizontal distance (0-4 mi).
    \param[in] ridgetopToValleyElevation Ridgetop-to-valley elevation difference (0-4000 ft).
    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
    \param[in] flameLength Steady flame height from the surface fire (0-100 ft).
 */

Sem::SpotSurfaceFire::SpotSurfaceFire(
            Sem::SpotAlgorithm::SpotSource source,
            double ridgetopToValleyDistance,
            double ridgetopToValleyElevation,
            double coverHeight,
            double windSpeedAt20Ft,
            double flameLength ) :
    Signal(),
    m_coverHeight( coverHeight ),
    m_distance( ridgetopToValleyDistance ),
    m_elevation( ridgetopToValleyElevation ),
    m_flameLength( flameLength ),
    m_source( source ),
    m_windSpeedAt20Ft( windSpeedAt20Ft ),
    m_firebrandHeight(0.0),
    m_flatSpottingDistance(0.0),
    m_mtnSpottingDistance(0.0)
{
    assert( m_coverHeight     >= coverHeightMin
         && m_coverHeight     <= coverHeightMax );
    assert( m_distance        >= ridgetopToValleyDistanceMin
         && m_distance        <= ridgetopToValleyDistanceMax );
    assert( m_elevation       >= ridgetopToValleyElevationMin
         && m_elevation       <= ridgetopToValleyElevationMax );
    assert( m_flameLength     >= flameLengthMin
         && m_flameLength     <= flameLengthMax );
    assert( m_windSpeedAt20Ft >= windSpeedAt20FtMin
         && m_windSpeedAt20Ft <= windSpeedAt20FtMax );
    init();
    m_classVersion = spotSurfaceFireVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SpotSurfaceFire::~SpotSurfaceFire( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotSurfaceFire copy constructor.
    \param[in] right Reference to the SpotSurfaceFire from which to copy.
    \return Reference to the newly allocated SpotSurfaceFire.
 */

Sem::SpotSurfaceFire::SpotSurfaceFire( const SpotSurfaceFire &right ) :
    Signal()
{
    init();
    m_classVersion    = right.m_classVersion;
    m_coverHeight     = right.m_coverHeight;
    m_distance        = right.m_distance;
    m_elevation       = right.m_elevation;
    m_flameLength     = right.m_flameLength;
    m_source          = right.m_source;
    m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
    m_firebrandHeight = right.m_firebrandHeight;
    m_flatSpottingDistance = right.m_flatSpottingDistance;
    m_mtnSpottingDistance  = right.m_mtnSpottingDistance;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SpotSurfaceFire assignment operator.
    \param[in] right Reference to the SpotSurfaceFire from which to assign.
    \return Reference to the newly assigned SpotSurfaceFire.
 */

const Sem::SpotSurfaceFire& Sem::SpotSurfaceFire::operator=(
        const SpotSurfaceFire &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion    = right.m_classVersion;
        m_coverHeight     = right.m_coverHeight;
        m_distance        = right.m_distance;
        m_elevation       = right.m_elevation;
        m_flameLength     = right.m_flameLength;
        m_source          = right.m_source;
        m_windSpeedAt20Ft = right.m_windSpeedAt20Ft;
        m_firebrandHeight = right.m_firebrandHeight;
        m_flatSpottingDistance = right.m_flatSpottingDistance;
        m_mtnSpottingDistance  = right.m_mtnSpottingDistance;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SpotSurfaceFire::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SpotSurfaceFire::classVersion( void ) const
{
    return( spotSurfaceFireVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the mean treetop/vegetation cover height
    along the firebrand path.

    \return Mean treetop/vegetation cover height along the firebrand path (ft).
 */

double Sem::SpotSurfaceFire::coverHeight( void ) const
{
    return( m_coverHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to lofted firebrand height.

    \return Lofted firebrand height (ft).
 */

double Sem::SpotSurfaceFire::firebrandHeight( void ) const
{
    checkUpdate();
    return( m_firebrandHeight );
}

//------------------------------------------------------------------------------
/*! \brief Access to the steady flame height from a surface fire.

    \return Steady flame height from a surface fire (ft).
 */

double Sem::SpotSurfaceFire::flameLength( void ) const
{
    return( m_flameLength );
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum flat terrain spotting distance (mi).

    \return Maximum flat terrain spotting distance (mi).
 */

double Sem::SpotSurfaceFire::flatTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_flatSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SpotSurfaceFire::init( void ) const
{
    m_firebrandHeight      = 0.0;
    m_flatSpottingDistance = 0.0;
    m_mtnSpottingDistance  = 0.0;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to maximum mountainous terrain spotting distance (mi).

    \return Maximum mountainous terrain spotting distance (mi).
 */

double Sem::SpotSurfaceFire::mountainTerrainSpottingDistance( void ) const
{
    checkUpdate();
    return( m_mtnSpottingDistance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley horizontal distance (mi).

    \return Ridgetop-to-valley horizontal distance (mi).
 */

double Sem::SpotSurfaceFire::ridgetopToValleyDistance( void ) const
{
    return( m_distance );
}

//------------------------------------------------------------------------------
/*! \brief Access to the ridgetop-to-valley elevation difference (ft).

    \return Ridgetop-to-valley elevation difference (ft).
 */

double Sem::SpotSurfaceFire::ridgetopToValleyElevation( void ) const
{
    return( m_elevation );
}

//------------------------------------------------------------------------------
/*! \brief Updates the mean treetop/vegetation cover height
    along the firebrand path.

    \param[in] coverHeight Mean treetop/vegetation cover height
                along the firebrand path (0-300 ft).
 */

void Sem::SpotSurfaceFire::setCoverHeight( double coverHeight )
{
    assert( coverHeight >= coverHeightMin
         && coverHeight <= coverHeightMax );
    if ( coverHeight != m_coverHeight )
    {
        m_coverHeight = coverHeight;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fire steady flame height.

    \param[in] flameLength Surface fire steady flame height (0-100 ft).
 */

void Sem::SpotSurfaceFire::setFlameLength( double flameLength )
{
    assert( flameLength >= flameLengthMin
         && flameLength <= flameLengthMax );
    if ( flameLength != m_flameLength )
    {
        m_flameLength = flameLength;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fire spotting source Sem::SpotSource.

    \param[in] source Surface fire spotting source Sem::Source.
        - SpotSourceMidslopeWindard
        - SpotSourceValleyBottom
        - SpotSourceMidslopeLeeward
        - SpotSourceRidgetop
 */

void Sem::SpotSurfaceFire::setSource( Sem::SpotAlgorithm::SpotSource source )
{
    if ( source != m_source )
    {
        m_source = source;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley horizontal distance.

    \param[in] distance Ridgetop-to-valley horizontal distance (0-4 mi).
 */

void Sem::SpotSurfaceFire::setRidgetopToValleyDistance( double distance )
{
    assert( distance >= ridgetopToValleyDistanceMin
         && distance <= ridgetopToValleyDistanceMax );
    if ( distance != m_distance )
    {
        m_distance = distance;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the ridgetop-to-valley elevation difference.

    \param[in] elevation Ridgetop-to-valley elevation difference (0-4000 ft).
 */

void Sem::SpotSurfaceFire::setRidgetopToValleyElevation( double elevation )
{
    assert( elevation >= ridgetopToValleyElevationMin
         && elevation <= ridgetopToValleyElevationMax );
    if ( elevation != m_elevation )
    {
        m_elevation = elevation;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind speed at 20 ft.

    \param[in] windSpeedAt20Ft Wind speed at 20 ft (0-99 mi/h).
 */

void Sem::SpotSurfaceFire::setWindSpeedAt20Ft( double windSpeedAt20Ft )
{
    assert( windSpeedAt20Ft >= windSpeedAt20FtMin
         && windSpeedAt20Ft <= windSpeedAt20FtMax );
    if ( windSpeedAt20Ft != m_windSpeedAt20Ft )
    {
        m_windSpeedAt20Ft = windSpeedAt20Ft;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fires Sem::SpotSource location.

    \return Surface fire spotting source Sem::SpotSource location.
 */

Sem::SpotAlgorithm::SpotSource Sem::SpotSurfaceFire::source( void ) const
{
    return( m_source );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access METHODS to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SpotSurfaceFire::update( void ) const
{
    // Initialize all mutables
    init();

    m_firebrandHeight = Sem::SpotAlgorithm::firebrandHeightFromSurfaceFire(
        m_flameLength, m_windSpeedAt20Ft );

    m_flatSpottingDistance = 
        Sem::SpotAlgorithm::flatTerrainSpotDistanceFromSurfaceFire(
            m_firebrandHeight, m_windSpeedAt20Ft, m_coverHeight );

    m_mtnSpottingDistance = Sem::SpotAlgorithm::mountainTerrainSpotDistance(
        m_flatSpottingDistance, m_source, m_distance, m_elevation );

    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at 20 ft.

    \return Wind speed at 20 ft (mi/h).
 */

double Sem::SpotSurfaceFire::windSpeedAt20Ft( void ) const
{
    return( m_windSpeedAt20Ft );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SpotSurfaceFire objects.

    \param[in] lhs Left-hand-side SpotSurfaceFire object.
    \param[in] rhs Right-hand-side SpotSurfaceFire object.
 */
bool Sem::operator ==( const Sem::SpotSurfaceFire &lhs,
                       const Sem::SpotSurfaceFire &rhs )
{ 
  return( fabs( lhs.coverHeight() - rhs.coverHeight() ) < Smidgen
       && fabs( lhs.ridgetopToValleyDistance() - rhs.ridgetopToValleyDistance() ) < Smidgen
       && fabs( lhs.ridgetopToValleyElevation() - rhs.ridgetopToValleyElevation() ) < Smidgen
       && fabs( lhs.flameLength() - rhs.flameLength() ) < Smidgen
       && lhs.source() == rhs.source()
       && fabs( lhs.windSpeedAt20Ft() - rhs.windSpeedAt20Ft() ) < Smidgen );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SpotSurfaceFire objects.

    \param[in] lhs Left-hand-side SpotSurfaceFire object.
    \param[in] rhs Right-hand-side SpotSurfaceFire object.
 */
bool Sem::operator !=( const Sem::SpotSurfaceFire &lhs,
                       const Sem::SpotSurfaceFire &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SpotSurfaceFire.cpp
//------------------------------------------------------------------------------

