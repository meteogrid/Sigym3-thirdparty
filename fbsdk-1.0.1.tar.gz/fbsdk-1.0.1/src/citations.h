//------------------------------------------------------------------------------
/*! \file citations.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Contains all citations referenced by the code and documentation.
 */

//-----------------------------------------------------------------------------
/*! \page citations Cited Documents

    \section anderson1972 Anderson, Hal E.  1982.
    Aids to determining fuel models for estimating fire behavior.
    USDA Forest Service General Technical Report INT-122, 22p.
    Intermountain Forest & Range Experiment Station, Ogen, UT 84401.

    \section albini1973 Albini, Frank A. 1973.
    Potential spotting distance from wind-driven surface fires.
    Research Paper INT-309. Ogden, UT: U.S. Department of Agriculture,
    Forest Service, Intermountain Forest and Range Experiment Station; 1983.
    27p.

    \section albini1976a Albini, Frank A. 1976.
    Computer-based models of wildland fire behavior: a user's manual.
    USDA Forest Service General Technical Report INT-, 68 p.
    Intermountain Forest & Range Experiment Station, Ogen, UT 84401.

    \section albini1976b Albini, Frank A. 1976.
    Estimating wildland fire behavior and effects.  USDA Forest Service
    General Technical Report INT-30, 92 p.
    Intermountain Forest & Range Experiment Station, Ogen, UT 84401.

    \section albini1979 Albini, Frank A. 1979.
    Spot distance from burning trees - a predictive model.
    USDA Forest Service General Technical Report INT-56, 73 p.
    Intermountain Forest and Range Experiment Station, Ogden, UT 84401.

    \section albini1983 Albini, Frank A. 1983.
    Potential spotting distance from wind-driven surface fires.
    Research Paper INT-309. Ogden, UT: U.S. Department of Agriculture,
    Forest Service, Intermountain Forest and Range Experiment Station; 1983.
    27p.
          
    \section bevins2004 Bevins, Collin D. 2004.
    Adapting Nelson's dead fuel moisture model for wildland fire modeling.
  
    \section carlson2003 Carlson, J. D. 2003.
    Evaluation of a new dead fuel moisture model in a near-real-time data
    assimilation and forecast environment.  Progress report on file at USDA
    Forest Service Intermountain Research Station, Fire Sciences Laboratory,
    Missoula, MT.  September 15, 2003.
  
    \section carlson2004a Carlson, J. D. 2004a.
    Evaluation of a new dead fuel moisture model in a near-real-time data
    assimilation and forecast environment.  Progress report on file at USDA
    Forest Service Intermountain Research Station, Fire Sciences Laboratory,
    Missoula, MT.  February 10, 2004.
  
    \section carlson2004b Carlson, J. D. 2004b.
    Evaluation of a new dead fuel moisture model in a near-real-time data
    assimilation and forecast environment.  Progress report on file at USDA
    Forest Service Intermountain Research Station, Fire Sciences Laboratory,
    Missoula, MT.  July 13, 2004.

    \section friedfried1995 Fried, Jeremy S; Fried, Burton D. 1995.
    Simulating wildfire containment with realistic tactics.
    Forest Science 42(3):267-281.
      
    \section meeus1982 Meeus, Jean. 1982.
    Astronomical formulae for calculators.  Fourth Ed. Willman-Bell, Inc. 218p.
  
    \section nelson2000 Nelson, Ralph M. Jr. 2000.
    Prediction of diurnal change in 1-h fuel stick moisture content.
    <i>Can. J. For. Res.</i> <b>30</b>: 1071-1087. (2000).

    \section reinhardtkeanebrown1997 Reinhardt, Elizabeth D.; Keane, Robert E.; Brown, James K. 1997.
    First Order Fire effects Model: FOFEM 4.0, user's guide.
    Ogden, UT: U.S. Department of Agriculture, Forest Service,
    Intermountain Research Station.  65p.

    \section rothermel1972 Rothermel, Richard C. 1972.
    A mathematical model for predicting fire spread in wildland fuels.
    USDA Forest Service Research Paper INT-115, 40 p.
    Intermountain Forest & Range Experiment Station, Ogen, UT 84401.

    \section rothermel1991 Rothermel, Richard C. 1991.
    Predicting behavior and size of crown fires in the Northern Rocky Mountains.
    Research Paper INT-438.  Ogden, UT: U.S. Department of Agriculture,
    Forest service, Intermountain Research Station. 46p.

    \section scottburgan2005 Scott, Joseph H.; Burgan, Robert E. 2005.

    \section vanwagner1973 VanWagner, Charles E. 1973.
    Height of crown scorch in forest fires.  Canadian Journal of Forest
    Research 3(3):373-378.

    \section vanwagner1977 VanWagner,C.E> 1977.
    Conditions for the start and spread of crown fire.
    Canadian Journal of Forest Research 7:23-34.
 */

//------------------------------------------------------------------------------
//  End of citations.h
//------------------------------------------------------------------------------

