//------------------------------------------------------------------------------
/*! \file SafetyAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire safety zone algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _SAFETYALGORITHM_H_INCLUDED_
#define _SAFETYALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SafetyAlgorithm SafetyAlgorithm.h
    \brief All fire safety zone algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all fire safety zone equations and
    algorithms.  These can be used to estimate fire safety zone size from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
 */

class SafetyAlgorithm
{
public:

    static double safetyZoneRadius(
            double seperationDistance,
            double numberOfPeople,
            double areaPerPerson,
            double numberOfEquipment,
            double areaPerEquipment ) ;

    static double safetyZoneSeparationDistance( double flameHeight ) ;

};

}   // End of namespace Sem

#endif  // _SAFETYALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SafetyAlgorithm.h
//------------------------------------------------------------------------------

