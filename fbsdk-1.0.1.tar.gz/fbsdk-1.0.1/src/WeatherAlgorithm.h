//------------------------------------------------------------------------------
/*! \file WeatherAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief All weather algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

#ifndef _WEATHERALGORITHM_H_INCLUDED_
#define _WEATHERALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class WeatherAlgorithm WeatherAlgorithm.h
    \brief All weather algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

class WeatherAlgorithm
{
public:
    static double dewPointTemperature(
            double dryBulb,
            double wetBulb,
            double elev ) ;

    static double heatIndex1(
            double at,
            double rh ) ;

    static double heatIndex2(
            double at,
            double rh ) ;

    static double relativeHumidity(
            double dryBulb,
            double dewPt ) ;

    static double summerSimmerIndex(
            double at,
            double rh ) ;

    static double surfaceFuelTemperature(
            double airTemperature,
            double sunShade ) ;

    static double windChillTemperature(
            double airTemperature,
            double windSpeed ) ;

    static double windSpeedAt20Ft( double windSpeedAt10M ) ;
};

}   // End of namespace Sem

#endif  // _WEATHERALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of WeatherAlgorithm.h
//------------------------------------------------------------------------------

