/****************************************************************************
** Meta object code from reading C++ file 'Handler.h'
**
** Created: Tue May 23 12:33:40 2006
**      by: The Qt Meta Object Compiler version 59 (Qt 4.1.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Handler.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Handler.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.1.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_Sem__HandlerDemo[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Sem__HandlerDemo[] = {
    "Sem::HandlerDemo\0\0messageHandler()\0"
};

const QMetaObject Sem::HandlerDemo::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Sem__HandlerDemo,
      qt_meta_data_Sem__HandlerDemo, 0 }
};

const QMetaObject *Sem::HandlerDemo::metaObject() const
{
    return &staticMetaObject;
}

void *Sem::HandlerDemo::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Sem__HandlerDemo))
	return static_cast<void*>(const_cast<HandlerDemo*>(this));
    return QObject::qt_metacast(_clname);
}

int Sem::HandlerDemo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: messageHandler(); break;
        }
        _id -= 1;
    }
    return _id;
}
