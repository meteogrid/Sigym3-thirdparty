//------------------------------------------------------------------------------
/*! \file SurfaceFireWind.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireWindInterface for
    accessing and updating surface fire <i>midflame</i> wind speed and direction
    at a specific location and time.
 */

#ifndef _SURFACEFIREWIND_H_INCLUDED_
#define _SURFACEFIREWIND_H_INCLUDED_

// Custom header files
#include "SurfaceFireWindInterface.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireWind SurfaceFireWind.h
    \brief A simple implementation of the SurfaceFireWindInterface for
    accessing and updating surface fire <i>midflame</i> wind speed and direction
    at a specific location and time.

    This is a bare bones implementation of the SurfaceFireWindInterface,
    mostly to ensure that a <i>midflame</i> wind speed is being used.
 */

class SurfaceFireWind : public SurfaceFireWindInterface
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireWindVersion = 1;    //!< Class version
// Property ranges
    static const double speedMphMin;    //!< Minimum valid wind speed (mi/h)
    static const double speedMphMax;    //!< Maximum valid wind speed (mi/h)

// Public interface
public:
    // Default constructor
    SurfaceFireWind( void ) ;
    // Custom constructors
    SurfaceFireWind( double midflameSpeedMph,
        double sourceDegreesClockwiseFromNorth ) ;
    // Virtual destructor
    virtual ~SurfaceFireWind( void ) ;
    // Copy constructor
    SurfaceFireWind( const SurfaceFireWind &rhs ) ;
    // Assignment operator
    const SurfaceFireWind &operator=( const SurfaceFireWind &rhs ) ;

    // Property access methods
    double bearing( void ) const;
    const char *className( void ) const ;
    int classVersion( void ) const ;
    double source( void ) const;
    double fpm( void ) const;
    double mph( void ) const;

    // Property update methods
    void setBearing( double bearingDegreesClockwiseFromNorth );
    void setSource( double sourceDegreesClockwiseFromNorth );
    void setFpm( double midflameSpeedFpm ) ;
    void setMph( double midflameSpeedMph ) ;

// Must be re-implemented by derived classes
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;

// Protected properties
protected:
    double m_source;    //!< Wind source (degrees clockwise from north).
    double m_speed;     //!< Midflame wind speed (mi/h).
};

// Non-member equality operators
bool operator ==( const SurfaceFireWind & a, const SurfaceFireWind & b ) ;
bool operator !=( const SurfaceFireWind & a, const SurfaceFireWind & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of SurfaceFireWind.h
//------------------------------------------------------------------------------

