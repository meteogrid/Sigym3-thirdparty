//------------------------------------------------------------------------------
/*! \file Logger.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Logger message class interface and declarations.
 */

#ifndef _LOGGER_H_INCLUDED_
#define _LOGGER_H_INCLUDED_

// Qt include files
#include <QObject>
#include <QString>

// Loki include files
#include "Singleton.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class LoggerBase Logger.h
    \brief Application-wide Singleton destination for error messages,
    which can be observed/subscribed to by client reporters.

    Clients send messages to the Logger Singleton via the
    Logger::Instance().send( int code, const QString& msg ) method.
    The \a code is application specific, and may be a status code or a
    severity level.

    When Logger receives a message, it emits the messageReceived() signal.
    Error handlers wishing to process messages need to connect to the SIGNAL:
    connect( Logger::Instance(), SIGNAL(messageReceived()),
             this, SLOT(handleMessage());

    The client error handler can then request the code and message via
    -- Logger::Instance().code()
    -- Logger::Instance().message()

    Each application is free to establish its own error code protocol,
    and to cache, display, report, or log messages as needed.
 */

class LoggerBase : public QObject
{
// Enable signals and slots
    Q_OBJECT
public:
friend class Loki::CreateUsingNew<LoggerBase>;

private:
    /*  \fn Sem::LoggerBase::LoggerBase( void )
        \brief Private constructor since this is a Singleton.
     */
    LoggerBase( void ) ;
public:
    /*  \fn virtual Sem::LoggerBase::~LoggerBase( void )
        \brief Virtual destructor.
     */
    virtual ~LoggerBase( void ) ;
    /*  \fn int Sem::LoggerBase::code( void ) const
        \brief Access to the current message code.
        \return Current message code.
     */
    int code( void ) const ;
    /*  \fn const char* Sem::LoggerBase::file( void ) const
        \brief Access to the send() file name.
        \return Static pointer to the file name from which the send() was sent.
     */
    const char* file( void ) const ;
    /*  \fn int Sem::LoggerBase::line( void ) const
        \brief Access to the send() file line number.
        \return File line number from which the send() was sent.
     */
    int line( void ) const ;
    /*  \fn QString Sem::LoggerBase::message( void ) const
        \brief Access to the current message string.
        \return Copy of the current message string.
     */
    QString message( void ) const ;
    /*! \fn void Sem::LoggerBase::send( int code, const QString& msg, const char* file=0, int line=0 )
     \brief Sends the error message to the handler.
        \param[in] code Application-specific error or severity code
        \param[in] msg  Message text
        \param[in] file File from which send() was invoked.
        \param[in] line Line number from which send() was invoked.
     */
    void send( int code, const QString& msg, const char* file=0, int line=0 ) ;

signals:
    /*! \fn void Sem::LoggerBase::messageReceived( void )
        \brief Qt signal.
    */
    void messageReceived( void );

// Private data
protected:
    int     m_code;     //!< Application specific error or severity code.
    const char* m_file; //!< __FILE__ where send() was invoked
    int     m_line;     //!< __LINE__ where send() was invoked
    QString m_msg;      //!< Message text
};  // End of class LoggerBase

//------------------------------------------------------------------------------
/*! \typedef Logger
    \brief The Logger class Singleton typedef and policies.
 */

    typedef Loki::SingletonHolder<LoggerBase, Loki::CreateUsingNew> Logger;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of Logger.h
//------------------------------------------------------------------------------

