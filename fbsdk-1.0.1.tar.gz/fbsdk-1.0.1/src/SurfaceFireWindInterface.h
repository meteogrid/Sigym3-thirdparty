//------------------------------------------------------------------------------
/*! \file SurfaceFireWindInterface.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An abstract base class defining an interface to provide wind speed
    and bearing information.
 */

#ifndef _SURFACEFIREWINDINTERFACE_H_INCLUDED_
#define _SURFACEFIREWINDINTERFACE_H_INCLUDED_

// Custom headers
#include "Signal.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireWindInterface SurfaceFireWindInterface.h
    \brief An abstract base class defining an interface to provide wind speed
    and bearing information.
 */

class SurfaceFireWindInterface : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireWindInterfaceVersion = 1;   //!< Class version

// Public interface
public:
    /*! \brief Virtual destructor implemented here
     */
    virtual ~SurfaceFireWindInterface( void ) {}

    // Property access methods
    const char* className( void ) const { return( metaObject()->className() ); }
    int classVersion( void ) const { return ( surfaceFireWindInterfaceVersion ); }

    /*! \fn virtual double bearing( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Wind bearing (degrees clockwise from north).
    */
    virtual double bearing( void ) const = 0;

    /*! \fn virtual double fpm( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Wind speed at midflame height (ft/min).
    */
    virtual double fpm( void ) const = 0;

    /*! \fn virtual double mph( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Wind speed at midflame height (mi/h).
    */
    virtual double mph( void ) const = 0;

    /*! \fn virtual double source( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Wind source (degrees clockwise from north).
    */
    virtual double source( void ) const = 0;
};

}   // End of namespace Sem

#endif  // _SURFACEFIREWINDINTERFACE_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireWindInterface.h
//------------------------------------------------------------------------------

