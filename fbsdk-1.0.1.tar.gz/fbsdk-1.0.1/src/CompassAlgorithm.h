//------------------------------------------------------------------------------
/*! \file CompassAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief All compass algorithms are encapsulated in this static class
    of <i>pure functions</i>.
    \license This code is released under the GNU Public License 2.
 */

#ifndef _COMPASSALGORITHM_H_INCLUDED_
#define _COMPASSALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class CompassAlgorithm CompassAlgorithm.h
    \brief All compass algorithms are encapsulated in this static class
    of <i>pure functions</i>.
 */

class CompassAlgorithm
{
public:
    static double constrain( double degreesClockwiseFromNorth ) ;    
    static double deviation( double degreesClockwiseFromNorth ) ;    
    static double opposite( double degreesClockwiseFromNorth ) ; 
};

}   // End of namespace Sem

#endif  // _COMPASSALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of CompassAlgorithm.h
//------------------------------------------------------------------------------

