//------------------------------------------------------------------------------
/*! \file SurfaceFireParticle.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of the SurfaceFireParticleInterface that follows
    the implementations of Rothermel, Albini, BEHAVE, BehavePlus, etc.
 */

// Custom header files
#include "Logger.h"
#include "SurfaceFireMoistureInterface.h"
#include "SurfaceFireParticle.h"

// Standard headers
#include <cmath>
#include <iostream>

// Non-integral static data members must be initialized outside the class
const double Sem::SurfaceFireParticle::condMin     = 4.0e-6;    // Btu/s/ft/oF
const double Sem::SurfaceFireParticle::condMax     = 4.0e-5;    // Btu/s/ft/oF
const double Sem::SurfaceFireParticle::densityMin  = 10.;       // lb/ft3
const double Sem::SurfaceFireParticle::densityMax  = 70.;       // lb/ft3
const double Sem::SurfaceFireParticle::endtMin     = 481.73;    // oF
const double Sem::SurfaceFireParticle::endtMax     = 931.73;    // oF
const double Sem::SurfaceFireParticle::hcapMin     = .238662;   // Btu/lb/oF
const double Sem::SurfaceFireParticle::hcapMax     = .715985;   // Btu/lb/oF
const double Sem::SurfaceFireParticle::heatMin     = 1000.;     // Btu/lb
const double Sem::SurfaceFireParticle::heatMax     = 16000.;    // Btu/lb
const double Sem::SurfaceFireParticle::heightMin   = 0.01;      // ft
const double Sem::SurfaceFireParticle::heightMax   = 6.00;      // ft
const double Sem::SurfaceFireParticle::igntMin     = 391.73;    // oF
const double Sem::SurfaceFireParticle::igntMax     = 751.73;    // oF
const double Sem::SurfaceFireParticle::loadDeadMin = 0.00;      // lb/ft2
const double Sem::SurfaceFireParticle::loadDeadMax = 5.00;      // lb/ft2
const double Sem::SurfaceFireParticle::loadLiveMin = 0.00;      // lb/ft2
const double Sem::SurfaceFireParticle::loadLiveMax = 5.00;      // lb/ft2
const double Sem::SurfaceFireParticle::moisDeadMin = 0.01;      // lb/lb
const double Sem::SurfaceFireParticle::moisDeadMax = 1.00;      // lb/lb
const double Sem::SurfaceFireParticle::moisLiveMin = 0.30;      // lb/lb
const double Sem::SurfaceFireParticle::moisLiveMax = 5.00;      // lb/lb
const double Sem::SurfaceFireParticle::savrMin     = 1.;        // ft2/ft3
const double Sem::SurfaceFireParticle::savrMax     = 4000.;     // ft2/ft3
const double Sem::SurfaceFireParticle::seffMin     = 0.001;     // lb/lb
const double Sem::SurfaceFireParticle::seffMax     = 0.200;     // lb/lb
const double Sem::SurfaceFireParticle::stotMin     = 0.001;     // lb/lb
const double Sem::SurfaceFireParticle::stotMax     = 0.200;     // lb/lb

//------------------------------------------------------------------------------
/*! \brief Default constructor.
 */

Sem::SurfaceFireParticle::SurfaceFireParticle( void ) :
    SurfaceFireParticleInterface(),
    m_cond( 0.0 ),
    m_cureAlgorithm( Sem::SurfaceFireFuelAlgorithm::CureNone ),
    m_dens( 32.0 ),
    m_endt( 0.0 ),
    m_hcap( 0.0 ),
    m_heat( 8000. ),
    m_height( 1.0 ),
    m_ignt( 0.0 ),
    m_loadDead( 0.0 ),
    m_loadLive( 0.0 ),
    m_moistureClass( Sem::SurfaceFireFuelAlgorithm::MoistureDead1h ),
    m_moisDead( 0.3 ),
    m_moisLive( 3.0 ),
    m_savr( 1000. ),
    m_seff( 0.010 ),
    m_stot( 0.0555 )
{
    init();
    m_classVersion = surfaceFireParticleVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Custom constructor.

    \param[in] moistureClass SurfaceFuelMoistureClass used to get the correct
                moisture content for this fuel particle.
    \param[in] cureAlgorithm ParticleCureAlgorithm used to determine
                if and how live fuel load is transferred to dead load.
    \param[in] surfaceAreaToVolumeRatio Fuel particle surface area-to-volume
                ratio (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] height Maximum height above the surface (ft).
    \param[in] loadDead Dead fuel load (lb/ft<sup>2</sup>).
    \param[in] loadLive Live fuel load (lb/ft<sup>2</sup>).
    \param[in] moisDead Dead fuel moisture content (fraction oven-dry weight).
    \param[in] moisLive Live fuel moisture content (fraction oven-dry weight).
    \param[in] heat Low heat of combustion (BTU/lb).
    \param[in] density Fuel particle density (lb/ft<sup>3</sup>).
    \param[in] siTotal Total silica content (fraction oven-dry weight).
    \param[in] siEffective Effective silica content (fraction oven-dry weight).
    \param[in] capacity Fuel particle heat capacity used by BurnUp (Btu/lb/oF).
    \param[in] conductance Fuel particle thermal conductance used by BurnUp (Btu/s/ft/oF).
    \param[in] ignitionTemp Fuel particle ignition temperature used by Burnup (oF).
    \param[in] endPyrolisisTemp Fuel particle char end pyrolisis temperature used by Burnup (oF).
 */

Sem::SurfaceFireParticle::SurfaceFireParticle(
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClass,
        Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm cureAlgorithm,
        double surfaceAreaToVolumeRatio,
        double height,
        double loadDead,
        double loadLive,
        double moisDead,
        double moisLive,
        double heat,
        double density,
        double siTotal,
        double siEffective,
        double capacity,
        double conductance,
        double ignitionTemp,
        double endPyrolisisTemp )
    :
    SurfaceFireParticleInterface(),
    m_cond( conductance ),
    m_cureAlgorithm( cureAlgorithm ),
    m_dens( density ),
    m_endt( endPyrolisisTemp ),
    m_hcap( capacity ),
    m_heat( heat ),
    m_height( height ),
    m_ignt( ignitionTemp ),
    m_loadDead( loadDead ),
    m_loadLive( loadLive ),
    m_moistureClass( moistureClass ),
    m_moisDead( moisDead ),
    m_moisLive( moisLive ),
    m_savr( surfaceAreaToVolumeRatio ),
    m_seff( siEffective ),
    m_stot( siTotal )
{
    assert( m_dens >= densityMin && m_dens <= densityMax );
    assert( m_heat >= heatMin && m_heat <= heatMax );
    assert( m_height >= heightMin && m_height <= heightMax );
    assert( m_loadDead >= loadDeadMin && m_loadDead <= loadDeadMax );
    assert( m_loadLive >= loadLiveMin && m_loadLive <= loadLiveMax );
    assert( m_moisDead >= moisDeadMin && m_moisDead <= moisDeadMax );
    assert( m_moisLive >= moisDeadMax && m_moisLive <= moisLiveMax );
    assert( m_savr >= savrMin && m_savr <= savrMax );
    assert( m_seff >= seffMin && m_seff <= seffMax );
    assert( m_stot >= stotMin && m_stot <= stotMax );
    init();
    m_classVersion = surfaceFireParticleVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
    Because this is a QObject, the destroyed() signal always gets sent out.
 */

Sem::SurfaceFireParticle::~SurfaceFireParticle( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireParticle copy constructor.

    \param[in] right Reference to the SurfaceFireParticle from which to copy.

    \return Reference to the newly allocated SurfaceFireParticle.
 */

Sem::SurfaceFireParticle::SurfaceFireParticle( const SurfaceFireParticle &right )
    : SurfaceFireParticleInterface()
{
    init();
    m_cond          = right.m_cond;
    m_classVersion  = right.m_classVersion;
    m_cureAlgorithm = right.m_cureAlgorithm;
    m_dens          = right.m_dens;
    m_endt          = right.m_endt;
    m_hcap          = right.m_hcap;
    m_heat          = right.m_heat;
    m_height        = right.m_height;
    m_ignt          = right.m_ignt;
    m_loadDead      = right.m_loadDead;
    m_loadLive      = right.m_loadLive;
    m_moistureClass = right.m_moistureClass;
    m_moisDead      = right.m_moisDead;
    m_moisLive      = right.m_moisLive;
    m_savr          = right.m_savr;
    m_seff          = right.m_seff;
    m_stot          = right.m_stot;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireParticle assignment operator.

    \param[in] right Reference to the SurfaceFireParticle from which to assign.

    \return Reference to the newly assigned SurfaceFireParticle.
 */

const Sem::SurfaceFireParticle& Sem::SurfaceFireParticle::operator=( const SurfaceFireParticle &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion  = right.m_classVersion;
        m_cond          = right.m_cond;
        m_cureAlgorithm = right.m_cureAlgorithm;
        m_dens          = right.m_dens;
        m_endt          = right.m_endt;
        m_hcap          = right.m_hcap;
        m_heat          = right.m_heat;
        m_height        = right.m_height;
        m_ignt          = right.m_ignt;
        m_loadDead      = right.m_loadDead;
        m_loadLive      = right.m_loadLive;
        m_moistureClass = right.m_moistureClass;
        m_moisDead      = right.m_moisDead;
        m_moisLive      = right.m_moisLive;
        m_savr          = right.m_savr;
        m_seff          = right.m_seff;
        m_stot          = right.m_stot;
        setDirty();
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    
    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireParticle::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    
    \return Current class version.
 */

int Sem::SurfaceFireParticle::classVersion( void ) const
{
    return( surfaceFireParticleVersion );
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireParticle clone (virtual) constructor.
    
    \return Pointer to the newly allocated SurfaceFireParticle.
 */

Sem::SurfaceFireParticle* Sem::SurfaceFireParticle::clone( void ) const
{
    Sem::SurfaceFireParticle* ptr = new Sem::SurfaceFireParticle(
        m_moistureClass, m_cureAlgorithm, m_savr, m_height, m_loadDead,
        m_loadLive, m_moisDead, m_moisLive, m_heat, m_dens, m_stot, m_seff );
    Q_ASSERT_X( (ptr != 0 ), "Sem::SurfaceFireParticle::clone()",
        "SurfaceFireParticle allocation failure." );
    //ptr->setDirty();  Should get called by the new constructor
    return( ptr );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle live fuel cure algorithm.

    \return Surface fuel particle live fuel cure algorithm as a
    ParticleCureAlgorithm enum value.
 */

Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm Sem::SurfaceFireParticle::cureAlgorithm( void ) const
{
    checkUpdate();
    return( m_cureAlgorithm );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle live fuel fraction cured.

    \return Surface fuel particle live fuel fraction cured [0..1].
 */

double Sem::SurfaceFireParticle::cured( void ) const
{
    checkUpdate();
    if ( m_cureAlgorithm == Sem::SurfaceFireFuelAlgorithm::CureHerb1 )
    {
       return( Sem::SurfaceFireFuelAlgorithm::cureHerb1( m_moisLive ) );
    }
    return( 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle density.

    \return Surface fuel particle density (lb/ft<sup>3</sup>).
    (Multiply by 16.0185 to convert to kg/m3).
 */

double Sem::SurfaceFireParticle::density( void ) const
{
    checkUpdate();
    return( m_dens );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle char end pyrolisis temperature.

    \return Surface fuel particle char end pyrolisis temperature (oF).
    (oK = 273 + 5(oF-32)/9).
 */

double Sem::SurfaceFireParticle::endPyrolisisTemperature( void ) const
{
    checkUpdate();
    return( m_endt );
}

//------------------------------------------------------------------------------
/*! \brief Access to whether surface fuel particle has live herb fuel.

    \return TRUE if the surface fuel particle has live herb fuel.
 */

bool Sem::SurfaceFireParticle::hasLiveHerb( void ) const
{
    checkUpdate();
    return( m_moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb );
}

//------------------------------------------------------------------------------
/*! \brief Access to whether surface fuel particle has live wood fuel.

    \return TRUE if the surface fuel particle has live wood fuel.
 */

bool Sem::SurfaceFireParticle::hasLiveWood( void ) const
{
    checkUpdate();
    return( m_moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle low heat of combustion.

    \return Surface fuel particle low heat of combustion (Btu/lb).
    (Multiply by 2327.79 to convert to J/kg.)
 */

double Sem::SurfaceFireParticle::heatOfCombustion( void ) const
{
    checkUpdate();
    return( m_heat );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle char end pyrolisis temperature.

    \return Surface fuel particle heat capacity (Btu/lb/oF).
    (Multiply by 4190.03 to convert to J/kg/oK.)
 */

double Sem::SurfaceFireParticle::heatCapacity( void ) const
{
    checkUpdate();
    return( m_hcap );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle maximum height above the surface.

    \return Surface fuel particle maximum height above the surface (ft).
 */

double Sem::SurfaceFireParticle::height( void ) const
{
    checkUpdate();
    return( m_height );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle ignition temperature.

    \return Surface fuel particle ignition temperature (oF).
    (oK = 273 + 5(oF-32)/9).
 */

double Sem::SurfaceFireParticle::ignitionTemperature( void ) const
{
    checkUpdate();
    return( m_ignt );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SurfaceFireParticle::init( void ) const
{
    // There are no intermediates to initialize for this class
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle dead fuel load.

    \return Surface fuel particle dead fuel load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireParticle::loadDead( void ) const
{
    checkUpdate();
    return( m_loadDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle live fuel load.

    \return Surface fuel particle live fuel load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireParticle::loadLive( void ) const
{
    checkUpdate();
    return( m_loadLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel particle
    moisture class as assigned during construction.

    \return SurfaceFuelMoistureClass for the surface fuel particle
    as assigned during construction.
 */

Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass
        Sem::SurfaceFireParticle::moistureClass( void ) const
{
    checkUpdate();
    return( m_moistureClass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel particle
    dead component fuel moisture class.

    \return SurfaceFireMoistureClass for the surface fuel particle dead load
    component based upon the surface fuel particle surface area to volume ratio.
 */

Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass
        Sem::SurfaceFireParticle::moistureClassDead( void ) const
{
    checkUpdate();
    return( Sem::SurfaceFireFuelAlgorithm::deadTimeLagClass( m_savr ) );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel particle
    live component fuel moisture class.

    \return SurfaceFireMoistureClass for the surface fuel particle live load
    component based upon the surface fuel particle surface area to volume ratio.
 */

Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass
        Sem::SurfaceFireParticle::moistureClassLive( void ) const
{
    checkUpdate();
    return( ( m_moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb )
        ? Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb
        : Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle dead fuel moisture content.

    \return Surface fuel particle dead fuel moisture content
    (fraction oven-dry weight).
 */

double Sem::SurfaceFireParticle::moistureDead( void ) const
{
    checkUpdate();
    return( m_moisDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle live fuel moisture content.

    \return Surface fuel particle live fuel moisture content
    (fraction oven-dry weight).
 */

double Sem::SurfaceFireParticle::moistureLive( void ) const
{
    checkUpdate();
    return( m_moisLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle surface area to volume ratio.

    \return Surface fuel particle surface area to volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
 */

double Sem::SurfaceFireParticle::savr( void ) const
{
    checkUpdate();
    return( m_savr );
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle density.

    \param[in] density Surface fuel particle density (lb/ft<sup>3</sup>.
    (Divide by 16.0185 to convert from kg/m3).
 */

void Sem::SurfaceFireParticle::setDensity( double density )
{
    if ( m_dens != density )
    {
        assert( density >= densityMin && density <= densityMax );
        m_dens = density;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle density.

    \param[in] endt Surface fuel particle char end pyrolisis temperature (oF).
    (oF = 32 + 9*C/5), and (oC = oK-273).
 */

void Sem::SurfaceFireParticle::setEndPyrolisisTemperature( double endt )
{
    if ( m_endt != endt )
    {
        assert( endt >= endtMin && endt <= endtMax );
        m_dens = endt;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel heat capacity.

    \param[in] hcap Surface fuel particle heat capacity (Btu/lb/oF).
    (Divide by 4190.03 to convert from J/kg/oK.)
 */

void Sem::SurfaceFireParticle::setHeatCapacity( double hcap )
{
    if ( m_hcap != hcap )
    {
        assert( hcap >= hcapMin && hcap <= hcapMax );
        m_dens = hcap;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle low heat of combustion.

    \param[in] heat Surface fuel particle low heat of combustion (Btu/lb).
    (Divide by 2327.79 to convert from J/kg.)
 */

void Sem::SurfaceFireParticle::setHeatOfCombustion( double heat )
{
    if ( m_heat != heat )
    {
        assert( heat >= heatMin && heat <= heatMax );
        m_heat = heat;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle ignition temperature.

    \param[in] ignt Surface fuel particle ignition temperature (oF).
    (oF = 32 + 9*C/5), and (oC = oK-273).
 */

void Sem::SurfaceFireParticle::setIgnitionTemperature( double ignt )
{
    if ( m_ignt != ignt )
    {
        assert( ignt >= igntMin && ignt <= igntMax );
        m_dens = ignt;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle moisture contents
    from a SurfaceFireMoistureInterface object.

    \param[in] sfm Reference to a SurfaceFireMoistureInterface object.
 */

void Sem::SurfaceFireParticle::setMoisture(
        const SurfaceFireMoistureInterface& sfm )
{
    setMoistureDead( sfm.moisture( moistureClassDead() ) );
    setMoistureLive( sfm.moisture( moistureClassLive() ) );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle moisture contents
    from a SurfaceFuelMoisture object.

    \param[in] sfm Pointer to a SurfaceFuelMoistureInterface object.
 */

void Sem::SurfaceFireParticle::setMoisture(
        const SurfaceFireMoistureInterface* sfm )
{
    setMoistureDead( sfm->moisture( moistureClassDead() ) );
    setMoistureLive( sfm->moisture( moistureClassLive() ) );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle dead fuel moisture content.

    \param[in] fractionOdw Dead fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireParticle::setMoistureDead( double fractionOdw )
{
    if ( m_moisDead != fractionOdw )
    {
        assert( fractionOdw > moisDeadMin && fractionOdw < moisDeadMax );
        m_moisDead = fractionOdw;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle live fuel moisture content.

    \param[in] fractionOdw Live fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireParticle::setMoistureLive( double fractionOdw )
{
    if ( m_moisLive != fractionOdw )
    {
        assert( fractionOdw > moisLiveMin && fractionOdw < moisLiveMax );
        m_moisLive = fractionOdw;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle surface area to volume ratio.

    \param[in] savr Fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    (Divide by 3.28084 to convert from m<sup>2</sup>/m<sup>3</sup>).
 */

void Sem::SurfaceFireParticle::setSurfaceAreaToVolumeRatio( double savr )
{
    if ( m_savr != savr )
    {
        assert( savr >= savrMin && savr <= savrMax );
        m_savr = savr;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle thermal condutivity.

    \param[in] cond Surface fuel particle thermal conductivity (Btu/s/ft/oF).
    (Divide by 6235.45 to convert from W/m/oK.)
 */

void Sem::SurfaceFireParticle::setThermalConductance( double cond )
{
    if ( m_cond != cond )
    {
        assert( cond >= condMin && cond <= condMax );
        m_dens = cond;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle effective silica content.

    \return Surface fuel particle effective silica content
    (fraction oven-dry weight).
 */

double Sem::SurfaceFireParticle::siEffective( void ) const
{
    checkUpdate();
    return( m_seff );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle total silica content.

    \return Surface fuel particle total silica content (fraction oven-dry weight).
 */

double Sem::SurfaceFireParticle::siTotal( void ) const
{
    checkUpdate();
    return( m_stot );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel particle thermal conductance.

    \return Surface fuel particle thermal conductance (Btu/s/ft/0F).
    (Multiply by 6235.45 to convert to W/m/oK.)
 */

double Sem::SurfaceFireParticle::thermalConductance( void ) const
{
    checkUpdate();
    return( m_cond );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access methods to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SurfaceFireParticle::update( void ) const
{
    // Do whatever here to bring object properties current
    updateLoad();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel particle dead and live fuel load components
    depending upon the fuel particle type and load transfer function.

    \note Make sure NOT to call any member access methods to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SurfaceFireParticle::updateLoad( void ) const
{
    if ( m_moistureClass == Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb )
    {
        if ( m_cureAlgorithm == Sem::SurfaceFireFuelAlgorithm::CureHerb1 )
        {
            double cured = Sem::SurfaceFireFuelAlgorithm::cureHerb1( m_moisLive );
            double load = m_loadDead + m_loadLive;
            m_loadDead = cured * load;
            m_loadLive = load - m_loadDead;
        }
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireParticle objects.

    \param[in] lhs Left-hand-side SurfaceFireParticle object.
    \param[in] rhs Right-hand-side SurfaceFireParticle object.

    \note Note that the area and size weighting values are ignored,
    since they are really SurfaceFuelBed properties.

    \return TRUE if equal, FALSE if not equal.
 */

bool Sem::operator ==( const Sem::SurfaceFireParticle &lhs, const Sem::SurfaceFireParticle &rhs )
{ 
    return( ( fabs( lhs.savr() - rhs.savr() ) < Smidgen )
         && ( fabs( lhs.height() - rhs.height() ) < Smidgen )
         && ( fabs( lhs.loadDead() - rhs.loadDead() ) < Smidgen )
         && ( fabs( lhs.loadLive() - rhs.loadLive() ) < Smidgen )
         && ( fabs( lhs.moistureDead() - rhs.moistureDead() ) < Smidgen )
         && ( fabs( lhs.moistureLive() - rhs.moistureLive() ) < Smidgen )
         && ( lhs.moistureClass() == rhs.moistureClass() )
         && ( lhs.cureAlgorithm() == rhs.cureAlgorithm() )
         && ( fabs( lhs.heatOfCombustion() - rhs.heatOfCombustion() ) < Smidgen )
         && ( fabs( lhs.density() - rhs.density() ) < Smidgen )
         && ( fabs( lhs.siEffective() - rhs.siEffective() ) < Smidgen )
         && ( fabs( lhs.siTotal() - rhs.siTotal() ) < Smidgen )
         && ( fabs( lhs.heatCapacity() - rhs.heatCapacity() ) < Smidgen )
         && ( fabs( lhs.thermalConductance() - rhs.thermalConductance() ) < Smidgen )
         && ( fabs( lhs.endPyrolisisTemperature() - rhs.endPyrolisisTemperature() ) < Smidgen )
         && ( fabs( lhs.ignitionTemperature() - rhs.ignitionTemperature() ) < Smidgen )
    );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireParticle objects.

    \param[in] lhs Left-hand-side SurfaceFireParticle object.
    \param[in] rhs Right-hand-side SurfaceFireParticle object.

    \return TRUE if not equal, FALSE if equal.
 */

bool Sem::operator !=( const Sem::SurfaceFireParticle &lhs, const Sem::SurfaceFireParticle &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireParticle.cpp
//------------------------------------------------------------------------------

