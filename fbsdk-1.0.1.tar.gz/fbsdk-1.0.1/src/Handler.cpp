//------------------------------------------------------------------------------
/*! \file Handler.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Simple demo of an application-wide Singleton message handler that
    manages messages emitted by the Singleton Logger instance.
 */

// Custom include files
#include "Logger.h"
#include "Handler.h"

// Qt headers
#include <QString>

// Standard headers
#include <iostream>

//------------------------------------------------------------------------------
/*  \brief Default constructor.
 */

Sem::HandlerDemo::HandlerDemo( void ) :
    m_dumpMessage( true ),
    m_msg()
{
    connect( &Sem::Logger::Instance(), SIGNAL(messageReceived()),
             this, SLOT(messageHandler()));

    if ( Sem::Logger::Instance().message() != "" )
    {
        messageHandler();
    }
    return;
}

//------------------------------------------------------------------------------
/*  \brief Virtual destructor.
 */

Sem::HandlerDemo::~HandlerDemo( void )
{
    disconnect( &Sem::Logger::Instance(), SIGNAL(messageReceived()),
                this, SLOT(messageHandler()));
    return;
}

//------------------------------------------------------------------------------
/*  \brief Default message display handler.

    \note This default implementation uses the following message code protocol:
    <table>
    <tr><td>code</td><td>Enum</td><td>Meaning</td></tr>
    <tr><td>0</td><td>Info</td><td>Informational or debugging</td></tr>
    <tr><td>1</td><td>Warning</td><td>Notice or warning</td></tr>
    <tr><td>2</td><td>User</td><td>User level error such as bad input</td></tr>
    <tr><td>3</td><td>Program</td><td>Program level error such as index out of bounds or value out of range</td></tr>
    <tr><td>4</td><td>System</td><td>System level error, usually resource inavailability such as memory allocation</td></tr>
    </table>

    This is just a demo of how messages can be handled; each client application
    will likely re-implement their own handler and code protocol.
 */

void Sem::HandlerDemo::displayMessage( void )
{
    m_msg = "UNKNOWN";
    int code = Sem::Logger::Instance().code();
    if ( code == Sem::HandlerDemo::Info )
    {
        m_msg = "INFO";
    }
    else if ( code == Sem::HandlerDemo::Warning )
    {
        m_msg = "WARNING";
    }
    else if ( code == Sem::HandlerDemo::User )
    {
        m_msg = "USER";
    }
    else if ( code == Sem::HandlerDemo::Program )
    {
        m_msg = "PROGRAM";
    }
    else if ( code == Sem::HandlerDemo::System )
    {
        m_msg = "SYSTEM";
    }

    m_msg.append( " message" );
    const char* file = Sem::Logger::Instance().file();
    if ( file )
    {
        m_msg.append( QString(" from %1").arg( file ) );
        int line = Sem::Logger::Instance().line();
        if ( line )
        {
            m_msg.append( QString(":(%1)").arg( line ) );
        }
    }
    m_msg.append( " - " );
    m_msg.append( Sem::Logger::Instance().message() );

    if ( m_dumpMessage || code >= 3 )
    {
        std::cerr << std::endl << m_msg.toLatin1().constData() << std::endl;
    }
    if ( code >= 3 )
    {
        abort();
    }
    return;
}

//------------------------------------------------------------------------------
/*  \brief Access to the last full message.
    \return Copy of the last full message.
 */

QString Sem::HandlerDemo::message( void ) const
{
    return( m_msg );
}

//------------------------------------------------------------------------------
/*  \brief Callback slot that handles Logger messages.
    \note This method simply delegates to displayMessage(), which is most
    likely re-implemented by each client application.
 */

void Sem::HandlerDemo::messageHandler( void )
{
    displayMessage();
    return;
}

//------------------------------------------------------------------------------
/*  \brief Sets whether or not the final message is dumped to std::cerr.
    \param[in] TRUE if the final message is dumped to std::cerr, FALSE if not.
 */

void Sem::HandlerDemo::setDumpMessage( bool dumpMessage )
{
    m_dumpMessage = dumpMessage;
}

//------------------------------------------------------------------------------
//  End of handler.cpp
//------------------------------------------------------------------------------

