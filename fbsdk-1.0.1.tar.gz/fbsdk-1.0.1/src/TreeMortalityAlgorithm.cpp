//------------------------------------------------------------------------------
/*! \file TreeMortalityAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

// Custom header files
#include "TreeMortalityAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Calculates tree bark thickness using the old BEHAVE equations.
  
    \param[in] behaveBarkSpecies BehaveBarkSpecies, which is one of
        - BehaveBarkDouglasFir
        - BehaveBarkWesternLarch
        - BehaveBarkWesternHemlock
        - BehaveBarkEngelmannSpruce
        - BehaveBarkWesternRedCedar
        - BehaveBarkSubalpineFir
        - BehaveBarkLodgepolePine
    \param[in] treeDbh Tree diameter at breast height (in).
  
    \return Tree bark thickness (in).
 */

double Sem::TreeMortalityAlgorithm::treeBarkThicknessBehave(
        Sem::TreeMortalityAlgorithm::BehaveBarkSpecies behaveBarkSpecies,
        double treeDbh )
{
    static double BehaveBark[][2] =
    {
        { 0.000, 0.0665 },  // 0 Douglas-fir (BEHAVE code 1)
        { 0.000, 0.0650 },  // 1 western larch (BEHAVE code 1)
        { 0.056, 0.0430 },  // 2 western hemlock (BEHAVE code 2)
        { 0.189, 0.0220 },  // 3 Engelmann spruce (BEHAVE code 3)
        { 0.189, 0.0220 },  // 4 western red cedar (BEHAVE code 3)
        { 0.000, 0.0150 },  // 5 subalpine fir (BEHAVE code 4)
        { 0.000, 0.0150 }   // 6 lodgepole pine (BEHAVE code 4)
    } ;
    int species = (int) behaveBarkSpecies;
    return( ( BehaveBark[ species ][0]
            + BehaveBark[ species ][1] * 2.54 * treeDbh ) / 2.54 );
}

//------------------------------------------------------------------------------
/*! \brief Calculates tree bark thickness using the FOFEM 5.0 equations.
  
    \param[in] species Sem:FofemSpecies enumeration (0-206).
    \param[in] dbh Tree diameter at breast height (in).
  
    \return Tree bark thickness (in).
 */

double Sem::TreeMortalityAlgorithm::treeBarkThicknessFofem(
        Sem::FofemTreeSpecies::FofemSpecies species,
        double dbh )
{
    // Fofem factors for determining Single Bark Thickness.
    // Each FOFEM species has a SBT equation index "barkEq" [1-39]
    // into this array.
    static double Fofem_Sbt[] =
    {
        /* 00 */    0.000,      // Not used
        /* 01 */    0.019,      // Not used
        /* 02 */    0.022,
        /* 03 */    0.024,
        /* 04 */    0.025,
        /* 05 */    0.026,
        /* 06 */    0.027,
        /* 07 */    0.028,
        /* 08 */    0.029,
        /* 09 */    0.030,
        /* 10 */    0.031,
        /* 11 */    0.032,
        /* 12 */    0.033,
        /* 13 */    0.034,
        /* 14 */    0.035,
        /* 15 */    0.036,
        /* 16 */    0.037,
        /* 17 */    0.038,
        /* 18 */    0.039,
        /* 19 */    0.040,
        /* 20 */    0.041,
        /* 21 */    0.042,
        /* 22 */    0.043,
        /* 23 */    0.044,
        /* 24 */    0.045,
        /* 25 */    0.046,
        /* 26 */    0.047,
        /* 27 */    0.048,
        /* 28 */    0.049,
        /* 29 */    0.050,
        /* 30 */    0.052,
        /* 31 */    0.055,
        /* 32 */    0.057,      // Not used
        /* 33 */    0.059,
        /* 34 */    0.060,
        /* 35 */    0.062,
        /* 36 */    0.065,
        /* 37 */    0.068,
        /* 38 */    0.072,
        /* 39 */    0.081
    };

    int i = Sem::FofemTreeSpecies::barkEquationIndex( species );
    return( Fofem_Sbt[i] * dbh );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the tree crown base height.
  
    \param crownRatio Tree crown ratio (crown length / tree height).
    \param treeHt     Tree height (ft ).
  
    \return Tree's crown base height (ft).
 */

double Sem::TreeMortalityAlgorithm::treeCrownBaseHeight(
        double crownRatio,
        double treeHt )
{
    return( treeHt * ( 1. - crownRatio ) );
}

//------------------------------------------------------------------------------
/*! \brief Calculates tree crown volume scorched, tree length scorched,
    and tree crown length fraction scorched.
  
    \param[in] treeHt Tree height (ft).
    \param[in] crownRatio Tree crown ratio (ft/ft).
    \param[in] scorchHt Crown scorch height (ft).
    \param[out] crownLengthScorched Address where the calculated crown length (ft)
    is stored.  If NULL or 0, no value is returned.
    \param[out] crownLengthFractionScorched Address where the calculated crown
    length fraction (ft/ft) is stored.  If NULL or 0, no value is returned.
  
    \return Fraction of the crown volume that is scorched (ft3/ft3).
 */

double Sem::TreeMortalityAlgorithm::treeCrownScorch(
        double treeHt,
        double crownRatio,
        double scorchHt,
        double *crownLengthScorched,
        double *crownLengthFractionScorched )
{
    double scorchFrac, scorchVol;
    // Tree crown length (ft) and base height (ft)
    double crownLeng = treeHt * crownRatio;
    double baseHt    = treeHt - crownLeng;
    // Tree crown length scorched (ft)
    double scorchLeng = ( scorchHt <= baseHt )
                        ? ( 0.0 )
                        : ( scorchHt - baseHt );
    scorchLeng = ( scorchLeng > crownLeng )
                 ? ( crownLeng )
                 : ( scorchLeng );
    // Fraction of the crown length scorched (ft/ft)
    if ( crownLeng < Smidgen )
    {
        scorchFrac = ( scorchLeng > 0. ) ? ( 1.0 ) : ( 0.0 );
    }
    else
    {
        scorchFrac = scorchLeng / crownLeng;
    }
    // Fraction of the crown volume scorched (ft3/ft3)
    scorchVol = ( crownLeng < Smidgen )
                ? ( 0.0 )
                : ( scorchLeng * ( 2. * crownLeng - scorchLeng )
                    / ( crownLeng * crownLeng ) );
    // Store results in parameter adresses
    if ( crownLengthScorched )
    {
        *crownLengthScorched = scorchLeng;
    }
    if ( crownLengthFractionScorched )
    {
        *crownLengthFractionScorched = scorchFrac;
    }
    return( scorchVol );
}

//------------------------------------------------------------------------------
/*! \brief Calculates probability of tree mortality using the BEHAVE equations.
  
    \param[in] barkThickness Tree bark thickness (in).
    \param[in] crownVolScorched Fraction of the crown volume that is scorched
    (ft<sup>3</sup>/ft<sup>3</sup>).
  
    Note that if scorch height is zero, mortality is zero.  But once scorch
    height exceeds 0.0001 ft, some fire induced mortality will result as
    determined by bark thickness and crown volume scorched.
  
    \return Tree mortality probability [0..1].
 */

double Sem::TreeMortalityAlgorithm::treeMortalityBehave(
        double barkThickness,
        double crownVolScorched )
{
    // Compute the bark constant bk
    double bk = 1.466 - 4.862 * barkThickness
              + 1.156 * barkThickness * barkThickness;
    // Determine mortality rate
    double mr = 1. / (1. + exp( -( bk + 5.35 * crownVolScorched * crownVolScorched ) ) );
    // Constrain the result to the range [0..1]
    mr = ( mr < 0. ) ? ( 0. ) : ( mr );
    mr = ( mr > 1. ) ? ( 1. ) : ( mr );
    return( mr );
}

//------------------------------------------------------------------------------
/*! \brief Calculates probability of tree mortality using the FOFEM 5.0
    equations for trees with dbh >= 1.
  
    This is only a partial implementation of the FOFEM mortality algorithm.
    Specifically, it only implements those cases where the tree dbh >= 1".
    It also excludes the FOFEM special case of \e Populus \e tremuloides,
    which requires additional inputs (namely, flame height and fire severity).
  
    \param[in] barkThickness Tree bark thickness (in).
    \param[in] crownVolScorched Fraction of the crown volume that is scorched
    (ft<sup>3</sup>/ft<sup>3</sup>).
    \param[in] isPicea TRUE if this is a Picea species, FALSE if not.
      
    \return Tree mortality probability [0..1].
 */

double Sem::TreeMortalityAlgorithm::treeMortalityFofem(
        double barkThickness,
        double crownVolScorched,
        bool   isPicea )
{
    // FOFEM equation 1 for dbh > 1"
    double mr = -1.941
              + 6.316 * ( 1.0 - exp( -barkThickness ) )
              - 5.35 * crownVolScorched * crownVolScorched;
    mr = 1.0 / ( 1.0 + exp( mr ) );
    // Adjustment for Picea (FOFEM equation 3).
    if ( isPicea && mr < 0.8 )
    {
        mr = 0.8;
    }
    // Constrain the result to the range [0..1]
    mr = ( mr < 0. ) ? ( 0. ) : ( mr );
    mr = ( mr > 1. ) ? ( 1. ) : ( mr );
    return( mr );
}

//------------------------------------------------------------------------------
//  End of TreeMortalityAlgorithm.cpp
//------------------------------------------------------------------------------

