//------------------------------------------------------------------------------
/*! \file Handler.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Simple demo of an application-wide Singleton message handler that
    manages messages emitted by the Singleton Logger instance.
 */

#ifndef _HANDLER_H_INCLUDED_
#define _HANDLER_H_INCLUDED_

// Loki include files
#include "Singleton.h"

// Qt include files
#include <QObject>
#include <QString>

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class HandlerDemo Handler.h
    \brief Simple demo of an application-wide Singleton message handler that
    manages messages emitted by the Singleton Logger instance.

    Demo implementation of an error handler class to work with Logger.
    It simply writes all messages to std::cerr.

    Most applications will use this as a template to create their own
    message handler to implement caching, logging, gui display, etc.
 */

class HandlerDemo : public QObject
{
// Enable signals and slots
    Q_OBJECT
//------------------------------------------------------------------------------
/*! \enum Code
    \brief Default set of message codes.
 */
enum Code
{
    Info=0,         //!< Informational or debugging
    Warning=1,      //!< Notice or warning
    User=2,         //!< User level error such as bad input
    Program=3,      //!< Program level error such as index out of bounds or value out of range
    System=4        //!< System level error, usually resource inavailability such as memory allocation
};

// Enable signals and slots
public:
friend class Loki::CreateUsingNew<HandlerDemo>;
private:
    /*  \fn HandlerDemo( void ) ;
        \brief Private constructor since this is implemented as a Singleton.
     */
    HandlerDemo( void ) ;
public:
    /*  \fn virtual ~HandlerDemo( void ) ;
        \brief Virtual destructor.
     */
    virtual ~HandlerDemo( void ) ;
    /*  \fn QString message( void ) const ;
        \brief Access to the last full message.
        \return Copy of the last full message.
     */
    QString message( void ) const ;
    /*  \fn void setDumpMessage( bool dumpMessage ) ;
        \brief Sets whether or not the final message is dumped to std::cerr.
        \param[in] TRUE if the final message is dumped to std::cerr, FALSE if not.
     */
    void setDumpMessage( bool dumpMessage ) ;

// Public slots
public slots:
    /*  \fn void messageHandler( void );
        \brief Callback slot that handles Logger messages.
        \note This method simply delegates to displayMessage(), which is most
        likely re-implemented by each client application.
     */
    void messageHandler( void );

protected:
    /*  \fn virtual void displayMessage( void ) ;
        \brief Default message display handler.

        \note This default implementation uses the following message code protocol:
        <table>
        <tr><td>code</td><td>Enum</td><td>Meaning</td></tr>
        <tr><td>0</td><td>Info</td><td>Informational or debugging</td></tr>
        <tr><td>1</td><td>Warning</td><td>Notice or warning</td></tr>
        <tr><td>2</td><td>User</td><td>User level error such as bad input</td></tr>
        <tr><td>3</td><td>Program</td><td>Program level error such as index out of bounds or value out of range</td></tr>
        <tr><td>4</td><td>System</td><td>System level error, usually resource inavailability such as memory allocation</td></tr>
        </table>

        This is just a demo of how messages can be handled; each client application
        will likely re-implement their own handler and code protocol.
     */
    virtual void displayMessage( void ) ;

// Protected data
protected:
    bool m_dumpMessage; //!< If TRUE, the final message is dumped to std::cerr.
    QString m_msg;      //!< Final message ready for display to some device
};  // End of class HandlerDemo

//------------------------------------------------------------------------------
/*! \typedef Handler
    \brief The Handler class Singleton typedef and policies.
 */

    typedef Loki::SingletonHolder<HandlerDemo, Loki::CreateUsingNew> Handler;

}   // End of namespace SEM

#endif

//------------------------------------------------------------------------------
//  End of Handler.h
//------------------------------------------------------------------------------

