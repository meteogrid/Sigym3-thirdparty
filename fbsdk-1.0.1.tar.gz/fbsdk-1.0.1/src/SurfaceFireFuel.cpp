//------------------------------------------------------------------------------
/*! \file SurfaceFireFuel.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief An implementation of the SurfaceFireFuelInterface applying the
    classic Rothermel/Albini (BEHAVE/BehavePlus) algorithms.
    \par License
    This is released under the GNU Public License 2.
 */

// Custom include files
#include "SurfaceFireFuel.h"
#include "SurfaceFireFuelAlgorithm.h"

// Standard headers
#include <cassert>
#include <cmath>
#include <iostream>

// Non-integral static data members must be initialized outside the class
const double Sem::SurfaceFireFuel::mextDeadMin = 0.10;
const double Sem::SurfaceFireFuel::mextDeadMax = 1.00;

//------------------------------------------------------------------------------
/*! \brief Default constructor.
 */

Sem::SurfaceFireFuel::SurfaceFireFuel( void ) :
    SurfaceFireFuelInterface(),
    m_fuel(),
    m_mextDead( 0.30 ),
    m_moisture( 0 ),
    m_sizeWtgDead( Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClasses, 0.0 ),
    m_sizeWtgLive( Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClasses, 0.0 )
{
    init();
    m_classVersion = surfaceFireFuelVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Custom constructor.

    \param[in] mextDead Surface fuel bed dead fuel extinction moisture content.
    \param[in] moisture Pointer to a SurfaceFireMoistureInterface object
    to connect to this fuel bed for automatic moisture updates.
 */

Sem::SurfaceFireFuel::SurfaceFireFuel( double mextDead,
        Sem::SurfaceFireMoistureInterface* moisture ) :
    SurfaceFireFuelInterface(),
    m_fuel(),
    m_mextDead( mextDead ),
    m_moisture( 0 ),
    m_sizeWtgDead( Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClasses, 0.0 ),
    m_sizeWtgLive( Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClasses, 0.0 )
{
    assert( m_mextDead >= mextDeadMin && m_mextDead <= mextDeadMax );
    init();
    m_classVersion = surfaceFireFuelVersion;
    connectMoisture( moisture );
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SurfaceFireFuel::~SurfaceFireFuel( void )
{
    clearFuel();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireFuel copy constructor.

    \param[in] right Reference to the SurfaceFireFuel from which to copy.

    Note that this results in a deep copy of rhs; the lhs has its own
    set of SurfaceFireParticleInterface objects.

    \return Reference to the newly allocated SurfaceFireFuel.
 */

Sem::SurfaceFireFuel::SurfaceFireFuel( const SurfaceFireFuel &right ) :
    SurfaceFireFuelInterface()
{
    init();
    clearFuel();
    m_classVersion = right.m_classVersion;
    m_mextDead     = right.m_mextDead;
    m_moisture     = right.m_moisture;
    foreach( SurfaceFireParticleInterface* ptr, right.m_fuel )
    {
        addSurfaceFireParticle( ptr->clone() );
    }       
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireFuel assignment operator.

    \param[in] right Reference to the SurfaceFireFuel from which to assign.

    Note that this results in a deep copy of rhs; the lhs has its own
    set of SurfaceFireParticleInterface objects.

    \return Reference to the newly assigned SurfaceFireFuel.
 */

const Sem::SurfaceFireFuel& Sem::SurfaceFireFuel::operator=(
        const SurfaceFireFuel &right )
{
    if ( this != &right )
    {
        init();
        clearFuel();
        m_classVersion = right.m_classVersion;
        m_mextDead     = right.m_mextDead;
        m_moisture     = right.m_moisture;
        foreach( SurfaceFireParticleInterface* ptr, right.m_fuel )
        {
            addSurfaceFireParticle( ptr->clone() );
        }
        setDirty();
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Adds a new SurfaceFireParticleInterface object to the SurfaceFireFuel.

    \param[in] surfaceFireFuelPtr Pointer to a newly allocated or cloned
    SurfaceFireParticleInterface object.  This SurfaceFireParticle takes
    ownership of the new SurfaceFireParticleInterface object
    and handles its destruction.
 */

void Sem::SurfaceFireFuel::addSurfaceFireParticle(
        Sem::SurfaceFireParticleInterface* surfaceFireFuelPtr )
{
    // Add it to the collection
    m_fuel.push_back( surfaceFireFuelPtr );

    // Get notified anytime the SurfaceFireParticleInterface object is changed
    connect( surfaceFireFuelPtr, SIGNAL(valueChanged()),
             this,               SLOT(particleChanged()) );
    connect( surfaceFireFuelPtr, SIGNAL(destroyed(QObject*)),
             this,               SLOT(particleDestroyed(QObject*)) );
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed bulk density.

    \return Surface fuel bed mean bulk density (lb/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuel::bulkDensity( void ) const
{
    checkUpdate();
    return( m_bulkDensity );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    
    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireFuel::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    
    \return Current class version.
 */

int Sem::SurfaceFireFuel::classVersion( void ) const
{
    return( surfaceFireFuelVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed depth.

    \return Surface fuel bed depth (ft).
 */

double Sem::SurfaceFireFuel::depth( void ) const
{
    checkUpdate();
    return( m_depth );
}

//------------------------------------------------------------------------------
/*! \brief Removes all the surface fire bed SurfaceFireParticleInterface objects.
 */

void Sem::SurfaceFireFuel::clearFuel( void )
{
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        if ( ptr )
        {
            delete ptr;
        }
    }
    m_fuel.clear();
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the currently connected SurfaceFireMoistureInterface
    object address.

    \return Address of the currently connected SurfaceFireMoistureInterface object,
    or 0 if there is no attached object.
 */

Sem::SurfaceFireMoistureInterface* Sem::SurfaceFireFuel::connectedMoisture( void ) const
{
    // Do not checkUpdate()!
    return( m_moisture );
}

//------------------------------------------------------------------------------
/*! \brief Connects a SurfaceFireMoistureInterface object's valueChanged()
    signal to the moistureChanged() callback slot.
 */

void Sem::SurfaceFireFuel::connectMoisture(
        Sem::SurfaceFireMoistureInterface* moisture )
{
    if ( m_moisture != moisture )
    {
        disconnectMoisture();
        if ( moisture )
        {
            connect( moisture, SIGNAL(valueChanged()),
                     this,     SLOT(moistureChanged()) );
            connect( moisture, SIGNAL(destroyed()),
                     this,     SLOT(moistureDestroyed()) );
        }
        m_moisture = moisture;
        setDirty();     // emits valueChanged()
    }
    // Because this affects downstream SurfaceFireParticle objects,
    // we need to update them immediately
    updateParticleMoistures();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Disconnects any currently connected SurfaceFireMoistureInterface
    object.

    \note This is also a callback slot connected to the currently attached
    SurfaceFireMoistureInterface::destroyed() signals.
 */

void Sem::SurfaceFireFuel::disconnectMoisture( void )
{
    if ( m_moisture )
    {
        disconnect( m_moisture, SIGNAL(valueChanged()),
                    this,       SLOT(moistureChanged()) );
        disconnect( m_moisture, SIGNAL(destroyed()),
                    this,       SLOT(moistureDestroyed()) );
        m_moisture = 0;
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed weighted moisture content of the
    dead fuel that must be heated to ignition.

    \return Surface fuel bed weighted moisture content of the dead fuel
    must be heated to ignition (g water / g oven-dry fuel).
 */

double Sem::SurfaceFireFuel::fineDeadMoisture( void ) const
{
    checkUpdate();
    return( m_fineFuelDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed dead fuel load
    that must be heated to ignition.

    \return Surface fuel bed dead fuel load that must be heated to ignition
    (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::fineFuelDead( void ) const
{
    checkUpdate();
    return( m_fineFuelDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed live fuel load
    that must be heated to ignition.

    \return Surface fuel bed live fuel load that must be heated to ignition
    (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::fineFuelLive( void ) const
{
    checkUpdate();
    return( m_fineFuelLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the dead fuel surface area weighting factor of
    a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return SurfaceFireParticleInterface object's dead fuel area weighting factor (dl).
 */

double Sem::SurfaceFireFuel::fuelAreaWtgDead( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuelAwtgDead[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the live fuel surface area weighting factor of
    a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return SurfaceFireParticleInterface object's live fuel area weighting factor (dl).
 */

double Sem::SurfaceFireFuel::fuelAreaWtgLive( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuelAwtgLive[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the effective heating number of
    a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return SurfaceFireParticleInterface object's effective heating number.
 */

double Sem::SurfaceFireFuel::fuelEffectiveHeatingNumber( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuelEhn[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the fraction of dead fuel that must be heated to ignition
    for a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return SurfaceFireParticleInterface object's fraction of dead fuel that must
    be heated to ignition (dl).
 */

double Sem::SurfaceFireFuel::fuelFineDead( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuelFineDead[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the fraction of live fuel that must be heated to ignition
    for a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return SurfaceFireParticleInterface object's fraction of live fuel that must
    be heated to ignition (dl).
 */

double Sem::SurfaceFireFuel::fuelFineLive( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuelFineLive[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the address of
    a specific SurfaceFireParticleInterface object connected to the SurfaceFireFuel.

    \param[in] id Index of the SurfaceFireParticleInterface object in the collection.

    \return Pointer to the SurfaceFireParticleInterface object.
 */

Sem::SurfaceFireParticleInterface* Sem::SurfaceFireFuel::fuelPtr( int id ) const
{
    checkUpdate();
    assert( id >= 0 && id <= m_fuel.count() );
    if ( id >= 0 && id <= m_fuel.count() )
    {
        return( m_fuel[id] );
    }
    return( 0 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the number of surface fuel particles in the fuel bed.

    \return Number of surface fuel particles in the fuel bed.
 */

int Sem::SurfaceFireFuel::fuels( void ) const
{
    checkUpdate();
    return( m_fuel.count() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic
    dead fuel heat of combustion.

    \return Surface fuel bed characteristic dead fuel heat of combustion
    (Btu/lb).
 */

double Sem::SurfaceFireFuel::heatOfCombustionDead( void ) const
{
    checkUpdate();
    return( m_heatDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic
    live fuel heat of combustion.

    \return Surface fuel bed characteristic live fuel heat of combustion
    (Btu/lb).
 */

double Sem::SurfaceFireFuel::heatOfCombustionLive( void ) const
{
    checkUpdate();
    return( m_heatLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed heat per unit area.

    \return Surface fuel bed heat per unit area (Btu/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::heatPerUnitArea( void ) const
{
    checkUpdate();
    return( m_hpua );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed heat sink.

    \return Surface fuel bed heat sink (Btu/lb).
 */

double Sem::SurfaceFireFuel::heatSink( void ) const
{
    checkUpdate();
    return( m_heatSink );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all mutable derived properties.

    Note this does NOT initialize m_mextDead or reset the SurfaceFireParticlePtrs.
 */

void Sem::SurfaceFireFuel::init( void ) const
{
    m_area = 0.0;               //!< Surface fuel bed total fuel surface area (ft2/ft2) [derived].
    m_areaDead = 0.0;           //!< Surface fuel bed dead fuel surface area (ft2/ft2) [derived].
    m_areaLive = 0.0;           //!< Surface fuel bed live fuel surface area (ft2/ft2) [derived].
    m_areaWtgDead = 1.0;        //!< Surface fuel bed dead fuel area weighting factor (dl) [derived].
    m_areaWtgLive = 0.0;        //!< Surface fuel bed live fuel area weighting factor (dl) [derived].
    m_betaRatio = 0.0;          //!< Surface fuel bed packingRatio / optPackingRatio ratio (dl) [derived].
    m_bulkDensity = 0.0;        //!< Surface fuel bed bulk density (lb/ft3) [derived].
    m_etasDead = 0.0 ;          //!< Surface fuel bed dead fuel mineral damping coefficient (dl) [derived].
    m_etasLive = 0.0 ;          //!< Surface fuel bed live fuel mineral damping coefficient (dl) [derived].
    m_depth = 0.0 ;             //!< Surface fuel bed depth (ft) [derived].
    m_fineDeadMoisture = 0.0 ;  //!< Surface fuel bed weighted fine dead fuel moisture content.
    m_fineFuelDead = 0.0 ;      //!< Surface fuel bed fine dead fuel load that must be raised to ignition (lb/ft2).
    m_fineFuelLive = 0.0 ;      //!< Surface fuel bed fine live fuel load that must be raised to ignition (lb/ft2).
    m_fuelAwtgDead.clear();     //!< Vector of SurfaceFireParticleInterface object dead area weighting factors (dl).
    m_fuelAwtgLive.clear();     //!< Vector of SurfaceFireParticleInterface object live area weighting factors (dl).
    m_fuelEhn.clear();          //!< Vector of SurfaceFireParticleInterface object effective heating numbewrs (dl ).
    m_fuelFineDead.clear();     //!< Vector of SurfaceFireParticleInterface object dead fuel fraction that must be heated to ignition (dl).
    m_fuelFineLive.clear();     //!< Vector of SurfaceFireParticleInterface object live fuel fraction that must be heated to ignition (dl).
    m_gammaMax = 0.0 ;          //!< Surface fuel bed maximum reaction velocity (1/min) [derived].
    m_gammaOpt = 0.0 ;          //!< Surface fuel bed optimum reaction velocity (1/min) [derived].
    m_heatDead = 0.0 ;          //!< Surface fuel bed dead fuel low heat of combustion (Btu/lb) [derived].
    m_heatLive = 0.0 ;          //!< Surface fuel bed live fuel low heat of combustion (Btu/lb) [derived].
    m_heatSink = 0.0 ;          //!< Surface fuel bed heat sink (Btu/ft<SUP>3</SUP>).
    m_hpua = 0.0 ;              //!< Surface fuel bed hHeat per unit area (Btu/ft<SUP>2</SUP>).
    m_load = 0.0 ;              //!< Surface fuel bed net total fuel load (lb/ft2) [derived].
    m_loadDead = 0.0 ;          //!< Surface fuel bed net dead fuel load (lb/ft2) [derived].
    m_loadLive = 0.0 ;          //!< Surface fuel bed net live fuel load (lb/ft2) [derived].
    m_mextLive = 0.0 ;          //!< Surface fuel bed live fuel moisture of extinction factor (lb water/lb fuel) [derived].
    m_moistureDead = 0.0 ;      //!< Surface fuel bed weighted dead fuel moisture content (g/g).
    m_moistureLive = 0.0 ;      //!< Surface fuel bed weighted live fuel moisture content (g/g).
    m_netLoadDead = 0.0 ;       //!< Surface fuel bed net dead fuel load (lb/ft2) [derived].
    m_netLoadLive = 0.0 ;       //!< Surface fuel bed net live fuel load (lb/ft2) [derived].
    m_optPackingRatio = 0.0 ;   //!< Surface fuel bed optimum packing ratio (dl) [derived].
    m_packingRatio = 0.0 ;      //!< Surface fuel bed packing ratio (dl) [derived].
    m_propFluxRatio = 0.0 ;     //!< Surface fuel bed propagating flux ratio (dl) [derived].
    m_q_ig = 0.0 ;              //!< Surface fuel bed weighted effective heat of pre-ignition (Btu/lb).
    m_residenceTime = 0.0 ;     //!< Surface fuel bed fire residence time (min) [derived].
    m_ros = 0.0 ;               //!< Surface fuel bed no-wind no-slope spread rate (ft/min).
    m_rxDead = 0.0 ;            //!< Surface fuel bed dead fuel reaction intensity (Btu/ft2/min) [derived].
    m_rxLive = 0.0 ;            //!< Surface fuel bed live fuel reaction intensity (Btu/ft2/min) [derived].
    m_rxInt = 0.0 ;             //!< Surface fuel bed reaction intensity (Btu/ft<SUP>2</SUP>-min).
    m_savrDead = 0.0 ;          //!< Surface fuel bed dead fuel characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    m_savrLive = 0.0 ;          //!< Surface fuel bed live fuel characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    m_seffDead = 0.0 ;          //!< Surface fuel bed dead fuel effective (silica-free) mineral content (lb mineral/lb fuel) [derived].
    m_seffLive = 0.0 ;          //!< Surface fuel bed dead fuel effective (silica-free) mineral content (lb mineral/lb fuel) [derived].
    m_sigma = 0.0 ;             //!< Surface fuel bed characteristic surface area-to-volume ratio (ft2/ft3) [derived].
    m_sigma15 = 0.0 ;           //!< Surface fuel bed intermediate factor (pow(sigma, 1.5)) [derived].
    m_sigmaA = 0.0 ;            //!< Surface fuel bed intermediate factor (133. / (pow(sigma, 0.7913)) ) [derived].
    m_sizeWtgDead.fill( 0.0 );  //!< Vector of SurfaceFireParticleInterface object dead area weighting factors accumulated by size category (dl).
    m_sizeWtgLive.fill( 0.0 );  //!< Vector of SurfaceFireParticleInterface object live area weighting factors accumulated by size category (dl).
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total dead fuel load.

    \return Surface fuel bed total dead net load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::loadDead( void ) const
{
    checkUpdate();
    return( m_loadDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total live fuel load.

    \return Surface fuel bed total live fuel load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::loadLive( void ) const
{
    checkUpdate();
    return( m_loadLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total fuel load.

    \return Surface fuel bed total fuel load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::loadTotal( void ) const
{
    checkUpdate();
    return( m_loadDead + m_loadLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed maximum reaction velocity.

    \return Surface fuel bed maximum reaction velocity (1/min).
 */

double Sem::SurfaceFireFuel::maximumReactionVelocity( void ) const
{
    checkUpdate();
    return( m_gammaMax );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed dead extinction moisture content.

    \return Surface fuel bed dead extinction moisture content
    (g water / g oven-dry fuel).
 */

double Sem::SurfaceFireFuel::mextDead( void ) const
{
    checkUpdate();
    return( m_mextDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed live extinction moisture content.

    \return Surface fuel bed live extinction moisture content
    (g water / g oven-dry fuel).
 */

double Sem::SurfaceFireFuel::mextLive( void ) const
{
    checkUpdate();
    return( m_mextLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed dead fuel mineral damping
    coefficient.

    \return Surface fuel bed dead fuel mineral damping coefficient (dl).
 */

double Sem::SurfaceFireFuel::mineralDampingCoefficientDead( void ) const
{
    checkUpdate();
    return( m_etasDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed live fuel mineral damping
    coefficient.

    \return Surface fuel bed live fuel mineral damping coefficient (dl).
 */

double Sem::SurfaceFireFuel::mineralDampingCoefficientLive( void ) const
{
    checkUpdate();
    return( m_etasLive );
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireMoistureInterface::valueChanged()
    signals.

    Called whenever a SurfaceFuelMoistureTimeLag gets changed, this method simply
    calls setDirty() which emits the SurfaceFireFuel::valueChanged() signal.
 */

void Sem::SurfaceFireFuel::moistureChanged( void )
{
    // Because this affects downstream SurfaceFireParticle objects,
    // we need to update them immediately
    updateParticleMoistures();
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireMoistureInterface::destroyed()
    signals.

    Note that the signal-slot connection is automatically disconnected
    when either the receiver or sender is destroyed, so we don't need to
    call disconnectMoisture() here; merely set m_moisture to 0.
 */

void Sem::SurfaceFireFuel::moistureDestroyed( void )
{
    m_moisture = 0;
    //setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total dead net load
    (adjusted for total silica content).

    \return Surface fuel bed total dead net load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::netLoadDead( void ) const
{
    checkUpdate();
    return( m_netLoadDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total live net load
    (adjusted for total silica content).

    \return Surface fuel bed total live net load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::netLoadLive( void ) const
{
    checkUpdate();
    return( m_netLoadLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total net fuel load
    (adjusted for total silica content).

    \return Surface fuel bed total live net load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::netLoadTotal( void ) const
{
    checkUpdate();
    return( m_netLoadDead + m_netLoadLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed optimum packing ratio.

    \return Surface fuel bed optimum packing ratio (dl).
 */

double Sem::SurfaceFireFuel::optimumPackingRatio( void ) const
{
    checkUpdate();
    return( m_optPackingRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed optimum reaction velocity.

    \return Surface fuel bed optimum reaction velocity (1/min).
 */

double Sem::SurfaceFireFuel::optimumReactionVelocity( void ) const
{
    checkUpdate();
    return( m_gammaOpt );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed packing ratio.

    \return Surface fuel bed packing ratio (dl).
 */

double Sem::SurfaceFireFuel::packingRatio( void ) const
{
    checkUpdate();
    return( m_packingRatio );
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireParticleInterface::valueChanged()
    signals.

    Called whenever a SurfaceFuelParticle gets changed, this method simply
    calls setDirty() which emits the SurfaceFireFuel::valueChanged() signal.
 */

void Sem::SurfaceFireFuel::particleChanged( void )
{
//std::cerr << "SurfaceFireFuel::particleChanged()" << std::endl;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireParticleInterface::destroyed()
    signals.
 */

void Sem::SurfaceFireFuel::particleDestroyed( QObject* ptr )
{
    int id = m_fuel.indexOf( static_cast<SurfaceFireParticleInterface*>( ptr ) );
    if ( id >= 0 )
    {
        m_fuel.remove( id );
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed propagating flux ratio.

    \return Surface fuel bed propagating flux ratio (dl).
 */

double Sem::SurfaceFireFuel::propagatingFluxRatio( void ) const
{
    checkUpdate();
    return( m_propFluxRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed reaction intensity.

    \return Surface fuel bed reaction intensity (Btu/ft<sup>2</sup>/min).
 */

double Sem::SurfaceFireFuel::reactionIntensity( void ) const
{
    checkUpdate();
    return( m_rxInt );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed fire residence time.

    \return Surface fuel bed fire residence time (min).
 */

double Sem::SurfaceFireFuel::residenceTime( void ) const
{
    checkUpdate();
    return( m_residenceTime );
}

//------------------------------------------------------------------------------
/*! \brief Updates the surface fuel bed dead extinction moisture content.

    \param[in] mextDead Surface fuel bed dead extinction moisture content
    (g water / g oven-dry fuel).
 */

void Sem::SurfaceFireFuel::setMextDead( double mextDead )
{
    if ( m_mextDead != mextDead )
    {
        assert( mextDead >= mextDeadMin && mextDead <= mextDeadMax );
        m_mextDead = mextDead;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic
    dead fuel effective silica content.

    \return Surface fuel bed characteristic dead fuel effective silica content
    (g silica / g oven-dry fuel).
 */

double Sem::SurfaceFireFuel::siEffectiveDead( void ) const
{
    checkUpdate();
    return( m_seffDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic
    live fuel effective silica content.

    \return Surface fuel bed characteristic live fuel effective silica content
    (g silica / g oven-dry fuel).
 */

double Sem::SurfaceFireFuel::siEffectiveLive( void ) const
{
    checkUpdate();
    return( m_seffLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic surface area to
    volume ratio.

    \return Surface fuel bed characteristic surface area to volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuel::sigma( void ) const
{
    checkUpdate();
    return( m_sigma );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic dead fuel
    surface area to volume ratio.

    \return Surface fuel bed characteristic dead fuel surface area to volume
    ratio (ft<sup>2</sup>/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuel::sigmaDead( void ) const
{
    checkUpdate();
    return( m_savrDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed characteristic live fuel
    surface area to volume ratio.

    \return Surface fuel bed characteristic live fuel surface area to volume
    ratio (ft<sup>2</sup>/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuel::sigmaLive( void ) const
{
    checkUpdate();
    return( m_savrLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed no-wind, no-slope fire spread rate.

    \return Surface fuel bed no-wind, no-slope fire spread rate (ft/min).
 */

double Sem::SurfaceFireFuel::spreadRate( void ) const
{
    checkUpdate();
    return( m_ros );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total dead plus live fuel surface area.

    \return Surface fuel bed total dead plus live fuel surface area (ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::surfaceArea( void ) const
{
    checkUpdate();
    return( m_area );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total dead fuel surface area.

    \return Surface fuel bed total dead fuel surface area (ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::surfaceAreaDead( void ) const
{
    checkUpdate();
    return( m_areaDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed total live fuel surface area.

    \return Surface fuel bed total live fuel surface area (ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuel::surfaceAreaLive( void ) const
{
    checkUpdate();
    return( m_areaLive );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed dead fuel surface area weighting factor.

    \return Surface fuel bed dead fuel surface area weighting factor (dl).
 */

double Sem::SurfaceFireFuel::surfaceAreaWtgDead( void ) const
{
    checkUpdate();
    return( m_areaWtgDead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fuel bed live fuel surface area weighting factor.

    \return Surface fuel bed live fuel surface area weighting factor (dl).
 */

double Sem::SurfaceFireFuel::surfaceAreaWtgLive( void ) const
{
    checkUpdate();
    return( m_areaWtgLive );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object properties up to date.

    \note Make sure NOT to call any member update methods on properties,
    such as "property()", as these then call checkUpdate(), resulting in an
    infinite loop!  Access member properties directly, as in "m_property".
 */

void Sem::SurfaceFireFuel::update( void ) const
{
//std::cerr << std::endl << "SurfaceFireFuel::update()" << std::endl;
    init();

    //--------------------------------------------------------------------------
    // 0: Update fuel moisture
    //--------------------------------------------------------------------------

    updateParticleMoistures();
    
    //--------------------------------------------------------------------------
    // 1: Update fuel bed depth
    //--------------------------------------------------------------------------

//std::cerr << "----- Fuel Weights -----" << std::endl;
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        double depth = ptr->height();
        m_depth = ( depth > m_depth ) ? depth : m_depth;
    }
//std::cerr << "m_depth=" << m_depth << std::endl;
    //--------------------------------------------------------------------------
    // 2: Update surface areas
    //--------------------------------------------------------------------------

    // Accumulate surface area by dead and live class
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        // Rothermel (1972) equation 54 (p 30)
        m_areaDead += Sem::SurfaceFireFuelAlgorithm::surfaceArea(
            ptr->savr(), ptr->loadDead(), ptr->density() );
        m_areaLive += Sem::SurfaceFireFuelAlgorithm::surfaceArea(
            ptr->savr(), ptr->loadLive(), ptr->density() );
    }
    // Mean total surface area of fuel per unit fuel cell
    // Rothermel (1972) equation 55 (p 30)
    m_area = m_areaDead + m_areaLive;
//std::cerr << "m_areaDead=" << m_areaDead << std::endl;
//std::cerr << "m_areaLive=" << m_areaLive << std::endl;
//std::cerr << "m_area=" << m_area << std::endl;

    //--------------------------------------------------------------------------
    // 3: Update particle and bed weighting factors
    //--------------------------------------------------------------------------

    // Rothermel (1972) equation 57 (p 30)
    m_areaWtgLive = ( m_area > Smidgen ) ? ( m_areaLive / m_area ) : 0.0 ;
    m_areaWtgDead = 1.0 - m_areaWtgLive;
//std::cerr << "m_areaWtgDead=" << m_areaWtgDead << std::endl;
//std::cerr << "m_areaWtgLive=" << m_areaWtgLive << std::endl;

    // Assign individual FuelParticle surface area weighting factors
    // and accumulate size class weighting factors while we're at it
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        // Determine surface fuel particle weighting size class
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClass size =
            Sem::SurfaceFireFuelAlgorithm::surfaceAreaWtgSizeClass( ptr->savr() );

        // Dead fuel area weighting
        // Rothermel (1972) equation 56 (p 30)
        double areaDead = Sem::SurfaceFireFuelAlgorithm::surfaceArea(
            ptr->savr(), ptr->loadDead(), ptr->density() );
        double awtgDead = ( m_areaDead > Smidgen ) ? ( areaDead / m_areaDead ) : 0. ;
        m_sizeWtgDead[size] += awtgDead;
        m_fuelAwtgDead.append( awtgDead );

        // Live fuel area weighting
        // Rothermel (1972) equation 56 (p 30)
        double areaLive = Sem::SurfaceFireFuelAlgorithm::surfaceArea(
            ptr->savr(), ptr->loadLive(), ptr->density() );
        double awtgLive = ( m_areaLive > Smidgen ) ? ( areaLive / m_areaLive ) : 0. ;
        m_sizeWtgLive[size] += awtgLive;
        m_fuelAwtgLive.append( awtgLive );
    }

    //--------------------------------------------------------------------------
    // 4: Update weighted fuel particle and fuel bed parameters
    //--------------------------------------------------------------------------

//std::cerr << "----- Fuel Particles -----" << std::endl;
    int id=0;
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        double density  = ptr->density();
        double heat     = ptr->heatOfCombustion();
        double savr     = ptr->savr();
        double seff     = ptr->siEffective();
        double stot     = ptr->siTotal();
        double loadDead = ptr->loadDead();
        double loadLive = ptr->loadLive();
        // Determine surface fuel particle weighting size class
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClass size =
            Sem::SurfaceFireFuelAlgorithm::surfaceAreaWtgSizeClass( savr );
        
        // Dead fuel component
        // Rothermel (1972) equation 61 (p 31)
        m_heatDead += m_fuelAwtgDead[id] * heat;
        // Dead fuel load
        m_loadDead += loadDead;
        // Rothermel (1972) equations 59 and 60 (p 31) as later modified
        // NOTE THAT THIS USES SIZE CLASS WTG, *NOT* SURFACE AREA WTG
        m_netLoadDead += m_sizeWtgDead[size] * loadDead * ( 1. - stot );
        // Rothermel (1972) equation 72 (p 32)
        m_savrDead += m_fuelAwtgDead[id] * savr;
        // Rothermel (1972) equation 63 (p 31)
        m_seffDead += m_fuelAwtgDead[id] * seff;

        // Live fuel component
        // Rothermel (1972) equation 61 (p 31)
        m_heatLive += m_fuelAwtgLive[id] * heat;
        // Live fuel load
        m_loadLive += loadLive;
        // Rothermel (1972) equations 59 and 60 (p 31) as later modified
        // NOTE THAT THIS USES SIZE CLASS WTG, *NOT* SURFACE AREA WTG
        m_netLoadLive += m_sizeWtgLive[size] * loadLive * ( 1. - stot );
        // Rothermel (1972) equation 72 (p 32)
        m_savrLive += m_fuelAwtgLive[id] * savr;
        // Rothermel (1972) equation 63 (p 31)
        m_seffLive += m_fuelAwtgLive[id] * seff;

//std::cerr << "density[" << id << "]=" << density << std::endl;
//std::cerr << "heat[" << id << "]=" << heat << std::endl;
//std::cerr << "savr[" << id << "]=" << savr << std::endl;
//std::cerr << "seff[" << id << "]=" << seff << std::endl;
//std::cerr << "stot[" << id << "]=" << stot << std::endl;
//std::cerr << "loadDead[" << id << "]=" << loadDead << std::endl;
//std::cerr << "loadLive[" << id << "]=" << loadLive << std::endl;
        double load = loadDead + loadLive;
        m_load += load;
        m_packingRatio += ( density > Smidgen ) ? ( load / density ) : 0.0;
        id++;
    }
//std::cerr << "----- Fuel Bed -----" << std::endl;
//std::cerr << "m_heatDead=" << m_heatDead << std::endl;
//std::cerr << "m_heatLive=" << m_heatLive << std::endl;
//std::cerr << "m_loadDead=" << m_loadDead << std::endl;
//std::cerr << "m_loadLive=" << m_loadLive << std::endl;
//std::cerr << "m_netLoadDead=" << m_netLoadDead << std::endl;
//std::cerr << "m_netLoadLive=" << m_netLoadLive << std::endl;
//std::cerr << "m_savrDead=" << m_savrDead << std::endl;
//std::cerr << "m_savrLive=" << m_savrLive << std::endl;
//std::cerr << "m_seffDead=" << m_seffDead << std::endl;
//std::cerr << "m_seffLive=" << m_seffLive << std::endl;
//std::cerr << "m_load=" << m_load << std::endl;

    //--------------------------------------------------------------------------
    // 5: Update fuel bed characteristics
    //--------------------------------------------------------------------------

    // Packing ratio
    // Rothermel (1972) equations 31 and 73 (p 32)
    m_packingRatio = ( m_depth > Smidgen ) ? ( m_packingRatio / m_depth ) : 0. ;
//std::cerr << "m_packingRatio=" << m_packingRatio << std::endl;

    // Bulk density
    // Rothermel (1972) equations 40 and 74 (p 32)
    m_bulkDensity = Sem::SurfaceFireFuelAlgorithm::bulkDensity( m_load, m_depth ) ;
//std::cerr << "m_bulkDensity=" << m_bulkDensity << std::endl;

    // Weighted average surface area-to-volume ratio (ft2/ft3)
    // Rothermel (1972) equation 71 (p 32)
    m_sigma = m_areaWtgDead * m_savrDead + m_areaWtgLive * m_savrLive;
//std::cerr << "m_sigma=" << m_sigma << std::endl;

    // Optimum packing ratio
    // Rothermel (1972) equations 37 and 69 (p 32)
    m_optPackingRatio =
        Sem::SurfaceFireFuelAlgorithm::optimumPackingRatio( m_sigma ) ;
//std::cerr << "m_optPackingRatio=" << m_optPackingRatio << std::endl;

    // Ratio of pacl=king ratio to the optimum packing ratio
    m_betaRatio = ( m_optPackingRatio > Smidgen )
                ? ( m_packingRatio / m_optPackingRatio ) : 0.0 ;
//std::cerr << "m_betaRatio=" << m_betaRatio << std::endl;

    // Maximum reaction velocity (1/min)
    // Rothermel (1972) equations 36 and 68 (p 32)
    m_sigma15  = pow( m_sigma, 1.5 );
    m_gammaMax =
        Sem::SurfaceFireFuelAlgorithm::maximumReactionVelocity( m_sigma );
//std::cerr << "m_gammaMax=" << m_gammaMax << std::endl;

    // Rothermel's "A" goodness-of-fit factor
    // Rothermel (1972) equations 39 and 70 (p 32) later modified
    m_sigmaA = ( m_sigma > Smidgen ) ? ( 133. / pow( m_sigma, 0.7913 ) ) : 0.0 ;

    // Optimum reaction velocity (1/min)
    // Rothermel (1972) equations 38 and 67 (p 31)
    m_gammaOpt = Sem::SurfaceFireFuelAlgorithm::optimumReactionVelocity(
        m_gammaMax, m_sigma, m_packingRatio, m_optPackingRatio );
//std::cerr << "m_gammaOpt=" << m_gammaOpt << std::endl;

    // Fire residence time (min) also depends only upon sigma
    m_residenceTime = Sem::SurfaceFireFuelAlgorithm::residenceTime( m_sigma );
//std::cerr << "m_residenceTime=" << m_residenceTime << std::endl;

    // Propagating flux ratio
    // Rothermel (1972) equations 42 and 76 (p 32)
    m_propFluxRatio = Sem::SurfaceFireFuelAlgorithm::propagatingFluxRatio(
        m_sigma, m_packingRatio );
//std::cerr << "m_propFluxRatio=" << m_propFluxRatio << std::endl;

    // Mineral damping coefficients
    // Rothermel (1972) equations 30 and 62 (p 31)
    m_etasDead =
        Sem::SurfaceFireFuelAlgorithm::mineralDampingCoefficient( m_seffDead );
    m_etasLive =
        Sem::SurfaceFireFuelAlgorithm::mineralDampingCoefficient( m_seffLive );
//std::cerr << "m_etasDead=" << m_etasDead << std::endl;
//std::cerr << "m_etasLive=" << m_etasLive << std::endl;

//std::cerr << "----- Fine Fuels -----" << std::endl;
    //  Fine dead and live fuel loads and fine dead moisture content
    id = 0;
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        double ehn =
            Sem::SurfaceFireFuelAlgorithm::effectiveHeatingNumber( ptr->savr() );
        m_fuelEhn.append( ehn );
        double fineDead =
            Sem::SurfaceFireFuelAlgorithm::fineFuelDead( ptr->loadDead(), ehn );
        m_fuelFineDead.append( fineDead );
        double fineLive =
            Sem::SurfaceFireFuelAlgorithm::fineFuelLive( ptr->loadLive(), ptr->savr() );
        m_fuelFineLive.append( fineLive );

        m_fineFuelDead     += fineDead;
        m_fineFuelLive     += fineLive;
        m_fineDeadMoisture += ptr->moistureDead() * fineDead;
        m_moistureDead     += m_fuelAwtgDead[id] * ptr->moistureDead();
        m_moistureLive     += m_fuelAwtgLive[id] * ptr->moistureLive();
//std::cerr << "ptr->moistureDead()[" << id << "]=" << ptr->moistureDead() << std::endl;
//std::cerr << "ptr->moistureLive()[" << id << "]=" << ptr->moistureLive() << std::endl;
//std::cerr << "m_fuelEhn[" << id << "]=" << ehn << std::endl;
//std::cerr << "m_fuelFineDead[" << id << "]=" << fineDead << std::endl;
//std::cerr << "m_fuelFineLive[" << id << "]=" << fineLive << std::endl;
        id++;
    }
//std::cerr << "m_moistureDead=" << m_moistureDead << std::endl;
//std::cerr << "m_moistureLive=" << m_moistureLive << std::endl;
//std::cerr << "m_fineFuelDead=" << m_fineFuelDead << std::endl;
//std::cerr << "m_fineFuelLive=" << m_fineFuelLive << std::endl;
//std::cerr << "m_fineDeadMoisture=" << m_fineDeadMoisture << std::endl;

    // Live fuel extinction moisture factor
    m_mextLive = Sem::SurfaceFireFuelAlgorithm::liveFuelExtinctionMoisture(
        m_fineFuelDead, m_fineFuelLive, m_fineDeadMoisture, m_mextDead );
//std::cerr << "m_mextLive=" << m_mextLive << std::endl;
//std::cerr << "----- Heat Sink -----" << std::endl;
    // Fuel bed heat sink
    id = 0;
    foreach( SurfaceFireParticleInterface* ptr, m_fuel )
    {
        // Accumulate total effective q_ig for all fuel particles
        double hpiDead = Sem::SurfaceFireFuelAlgorithm::heatOfPreIgnition( ptr->moistureDead() );
        m_q_ig += m_fuelEhn[id] * m_fuelAwtgDead[id] * m_areaWtgDead * hpiDead;
        double hpiLive = Sem::SurfaceFireFuelAlgorithm::heatOfPreIgnition( ptr->moistureLive() );
        m_q_ig += m_fuelEhn[id] * m_fuelAwtgLive[id] * m_areaWtgLive * hpiLive;
//std::cerr << "m_fuelEhn[" << id << "]=" << m_fuelEhn[id] << std::endl;
//std::cerr << "m_fuelAwtgDead[" << id << "]=" << m_fuelAwtgDead[id] << std::endl;
//std::cerr << "m_areaWtgDead[" << id << "]=" << m_areaWtgDead << std::endl;
//std::cerr << "hpiDead[" << id << "]=" << hpiDead << std::endl;
//std::cerr << "m_fuelAwtgLive[" << id << "]=" << m_fuelAwtgLive[id] << std::endl;
//std::cerr << "m_areaWtgLive[" << id << "]=" << m_areaWtgLive << std::endl;
//std::cerr << "hpiLive[" << id << "]=" << hpiLive << std::endl;
        id++;
    }
//std::cerr << "m_q_ig=" << m_q_ig << std::endl;
    m_heatSink = Sem::SurfaceFireFuelAlgorithm::heatSink( m_q_ig, m_bulkDensity );
//std::cerr << "m_heatSink=" << m_heatSink << std::endl;

    // Dead and live moisture damping coefficients
    m_etamDead = Sem::SurfaceFireFuelAlgorithm::moistureDampingCoefficient(
        m_moistureDead, m_mextDead );
    m_etamLive = Sem::SurfaceFireFuelAlgorithm::moistureDampingCoefficient(
        m_moistureLive, m_mextLive );
//std::cerr << "m_mextDead=" << m_mextDead << std::endl;
//std::cerr << "m_etamDead=" << m_etamDead << std::endl;
//std::cerr << "m_mextLive=" << m_mextLive << std::endl;
//std::cerr << "m_etamLive=" << m_etamLive << std::endl;

//std::cerr << "----- Fire Behavior -----" << std::endl;
    // Reaction intensity (Btu/ft2/min)
    // Rothermel (1972) equations 27 and 58 (p 31)
    m_rxDead = m_gammaOpt * m_netLoadDead * m_heatDead * m_etasDead * m_etamDead;
    m_rxLive = m_gammaOpt * m_netLoadLive * m_heatLive * m_etasLive * m_etamLive;
    m_rxInt = m_rxDead + m_rxLive;
//std::cerr << "m_rxDead=" << m_rxDead << std::endl;
//std::cerr << "m_rxLive=" << m_rxLive << std::endl;
//std::cerr << "m_rxInt=" << m_rxInt << std::endl;

    // Heat per unit area (Btu/ft2) from rx intensity and residence time.
    m_hpua = Sem::SurfaceFireFuelAlgorithm::heatPerUnitArea(
        m_rxInt, m_residenceTime );
//std::cerr << "m_hpua=" << m_hpua << std::endl;

    // No-wind, no-slope spread rate.
    m_ros = Sem::SurfaceFireFuelAlgorithm::noWindNoSlopeSpreadRate(
        m_rxInt, m_propFluxRatio, m_heatSink ) ;
//std::cerr << "m_ros=" << m_ros << std::endl;

    //--------------------------------------------------------------------------
    // The following were moved to the SurfaceFireSpread interface
    //--------------------------------------------------------------------------
#ifdef OMIT
    // Wind and slope factors
    // Rothermel (1972) equation 80 (p 33) first two terms
    m_slopeK = Sem::SurfaceFireFuelAlgorithm::slopeParameterK( m_packingRatio );

    // Rothermel (1972) equation 82 (p 33)
    m_windC = Sem::SurfaceFireFuelAlgorithm::windParameterC( m_sigma );

    // Rothermel (1972) equation 83 (p 33)
    m_windB = Sem::SurfaceFireFuelAlgorithm::windParameterB( m_sigma );

    // Rothermel (1972) equation 84 (p 33)
    m_windE = Sem::SurfaceFireFuelAlgorithm::windParameterE( m_sigma );

    // Rothermel (1972) equation 79 (p 33) first and third terms
    // Since we already have C and E, its more effeicient NOT to call
    // Sem::SurfaceFireFuelAlgorithm::windParameterK(), which recalculates them.
    m_windK = m_windC * pow( m_betaRatio, -m_windE );

    // Inverse of Rothermel (1972) equation 79 (p 33) first and third terms
    // Since we already have C and E, its more effeicient NOT to call
    // Sem::SurfaceFireFuelAlgorithm::windParameterX(), which recalculates them.
    m_windI = ( m_betaRatio > Smidgen && m_windC > Smidgen )
            ? ( pow( m_betaRatio, m_windE ) / m_windC )
            : 0.0 ;
#endif
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates all surface fire particle moisture contents from the
    current moisture object.
 */

void Sem::SurfaceFireFuel::updateParticleMoistures( void ) const
{
    if ( m_moisture )
    {
        foreach( SurfaceFireParticleInterface* ptr, m_fuel )
        {
            ptr->setMoisture( m_moisture );
        }
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireFuel objects.

    \param[in] lhs Left-hand-side SurfaceFireFuel object.
    \param[in] rhs Right-hand-side SurfaceFireFuel object.


    \note Note that the SurfaceFireParticleInterface objects contents are
    compared between the lhs and rhs.

    \return TRUE if equal, FALSE if not equal.
 */

bool Sem::operator ==( const Sem::SurfaceFireFuel &lhs, const Sem::SurfaceFireFuel &rhs )
{ 
    if ( fabs( lhs.mextDead() - rhs.mextDead() ) > Smidgen
        || lhs.fuels() != rhs.fuels() )
    {
        return( false );
    }
    for ( int i=0; i<lhs.fuels(); i++ )
    {
        if ( *lhs.fuelPtr( i ) != *rhs.fuelPtr( i ) )
        {
            return( false );
        }
    }
    return( true );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireFuel objects.

    \param[in] lhs Left-hand-side SurfaceFireFuel object.
    \param[in] rhs Right-hand-side SurfaceFireFuel object.

    \return TRUE if not equal, FALSE if equal.
 */

bool Sem::operator !=( const Sem::SurfaceFireFuel &lhs, const Sem::SurfaceFireFuel &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireFuel.cpp
//------------------------------------------------------------------------------

