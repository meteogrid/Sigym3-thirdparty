//------------------------------------------------------------------------------
/*! \file IgnitionAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _IGNITIONALGORITHM_H_INCLUDED_
#define _IGNITIONALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class IgnitionAlgorithm IgnitionAlgorithm.h
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all fire ignition equations and
    algorithms.  These can be used to estimate ignition probabilities from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
 */

class IgnitionAlgorithm
{

//------------------------------------------------------------------------------
/*! \enum LightningCharge
    \brief Indicates the type of lightning charge.
 */

enum LightningCharge
{
    LightningChargeNegative = 0,
    LightningChargePositive = 1,
    LightningChargeUnknown  = 2
};
const static int LightningCharges = 3;  //!< Number of LightningCharge enums

//------------------------------------------------------------------------------
/*! \enum LightningFuel  
    \brief Indicates the ground fuel receiving the lightning strike.
 */

enum LightningFuel
{
    LightningFuelPonderosaPineLitter   = 0, //!< Ponderosa Pine Litter
    LightningFuelPunkyWood             = 1, //!< Punky wood, rotten, chunky
    LightningFuelDeepPunkWoodPowder    = 2, //!< Punky wood powder, deep (4.8 cm)
    LightningFuelShallowPunkWoodPowder = 3, //!< Punk wood powder, shallow (2.4 cm)
    LightningFuelLodgepolePineDuff     = 4, //!< Lodgepole pine duff
    LightningFuelDouglasFirDuff        = 5, //!< Douglas-fir duff
    LightningFuelHighAltitudeMixed     = 6, //!< High altitude mixed (mainly Engelmann spruce)
    LightningFuelPeatMoss              = 7  //!< Peat moss (commercial)
};
const static int LightningFuels = 8;    //!< Number of LightningFuel enums

// Public interface
public:

    static double firebrandIgnitionProbability(
            double fuelTemperature,
            double fuelMoisture ) ;

    static double lightningIgnitionProbability(
            LightningFuel fuelType,
            double fuelDepth,
            double fuelMoisture,
            LightningCharge charge ) ;

};

}   // End of namespace Sem

#endif  // _IGNITIONALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of IgnitionAlgorithm.h
//------------------------------------------------------------------------------

