//------------------------------------------------------------------------------
/*! \file CompassAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief All compass algorithms are encapsulated in this static class
    of <i>pure functions</i>.
    \license This code is released under the GNU Public License 2.
 */

// Custom header files
#include "CompassAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Static convenience method to ensure degrees are in range [0..360].
    \param[in] degrees Compass degrees clockwise from north,
    \return Degrees wrapped within the range >= zero and < 360.
 */

double Sem::CompassAlgorithm::constrain( double degrees )
{
    while ( degrees >= 360.0 )
    {
        degrees -= 360.;
    }
    while ( degrees < 0.0 )
    {
        degrees += 360.;
    }
    return( degrees );
}

//------------------------------------------------------------------------------
/*! \brief Static convenience method to ensure degrees are in range [0..180].
    \param[in] degreesClockwiseFromNorth Just what it says.
    \return Degrees constrained to range [-180..180].
 */

double Sem::CompassAlgorithm::deviation( double degreesClockwiseFromNorth )
{
    double degrees = Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth );
    return( degrees <= 180.0 ? degrees : degrees - 360.0 );
}

//------------------------------------------------------------------------------
/*! \brief Static convenience method to return opposite direction in range [0..360].
    \param[in] degreesClockwiseFromNorth Just what it says.
    \return Opposite direction in degrees clockwise from north
    constrained to range >=0 and < 360.
 */

double Sem::CompassAlgorithm::opposite( double degreesClockwiseFromNorth )
{
    return( Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth - 180. ) );
}

//------------------------------------------------------------------------------
//  End of CompassAlgorithm.cpp
//------------------------------------------------------------------------------

