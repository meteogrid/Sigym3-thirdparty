//------------------------------------------------------------------------------
/*! \file SurfaceFireTerrain.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireTerrainInterface for
    accessing and updating terrain aspect and steepness information at a
    specific point.
 */

// Custom header files
#include "CompassAlgorithm.h"
#include "Logger.h"
#include "SurfaceFireTerrain.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::SurfaceFireTerrain::slopeFractionMin = 0.0;
const double Sem::SurfaceFireTerrain::slopeFractionMax = 5728.996164;
const double Sem::SurfaceFireTerrain::slopeDegreesMin = 0.0;
const double Sem::SurfaceFireTerrain::slopeDegreesMax = 89.0;

//------------------------------------------------------------------------------
/*! \brief SurfaceFireTerrain default constructor.
 */

Sem::SurfaceFireTerrain::SurfaceFireTerrain( void ) :
    SurfaceFireTerrainInterface(),
    m_aspect( 0.0 ),
    m_slope( 0.0 )
{
    init();
    m_classVersion = surfaceFireTerrainVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireTerrain custom constructor.

    \param[in] slopePercent Slope steepness percent (100 * rise/reach).
    \param[in] aspectDegreesClockwiseFromNorth Just what it says.
 */

Sem::SurfaceFireTerrain::SurfaceFireTerrain( double slopePercent,
        double aspectDegreesClockwiseFromNorth ) :
    SurfaceFireTerrainInterface(),
    m_aspect( aspectDegreesClockwiseFromNorth ),
    m_slope( 0.01 * slopePercent )
{
    assert( m_slope >= slopeFractionMin && m_slope <= slopeFractionMax );
    init();
    m_classVersion = surfaceFireTerrainVersion;
    m_aspect = Sem::CompassAlgorithm::constrain( m_aspect );
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SurfaceFireTerrain::~SurfaceFireTerrain( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireTerrain copy constructor.
    \param[in] right Reference to the SurfaceFireTerrain from which to copy.
    \return Reference to the newly allocated SurfaceFireTerrain.
 */

Sem::SurfaceFireTerrain::SurfaceFireTerrain( const SurfaceFireTerrain &right ) :
    SurfaceFireTerrainInterface()
{
    init();
    m_classVersion = right.m_classVersion;
    m_aspect       = right.m_aspect;
    m_slope        = right.m_slope;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireTerrain assignment operator.
    \param[in] right Reference to the SurfaceFireTerrain from which to assign.
    \return Reference to the newly assigned SurfaceFireTerrain.
 */

const Sem::SurfaceFireTerrain& Sem::SurfaceFireTerrain::operator=(
        const SurfaceFireTerrain &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion = right.m_classVersion;
        m_aspect       = right.m_aspect;
        m_slope        = right.m_slope;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the terrain aspect (down-slope) compass direction.

    \return Terrain aspect (down-slope) compass direction (degrees clockwise from north).
 */

double Sem::SurfaceFireTerrain::aspectCompass( void ) const
{
    checkUpdate();
    return( m_aspect );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireTerrain::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SurfaceFireTerrain::classVersion( void ) const
{
    return( surfaceFireTerrainVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the terrain down-slope (aspect) compass direction.

    \return Terrain down-slope (aspect) compass direction (degrees clockwise from north).
 */

double Sem::SurfaceFireTerrain::downslopeCompass( void ) const
{
    checkUpdate();
    return( m_aspect );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SurfaceFireTerrain::init( void ) const
{
    // There are no intermediates to initialize for this class
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain aspect (down-slope) compass direction.

    \param[in] aspectDegreesClockwiseFromNorth Just what it says.
 */

void Sem::SurfaceFireTerrain::setAspectCompass(
        double aspectDegreesClockwiseFromNorth )
{
    double aspect =
        Sem::CompassAlgorithm::constrain( aspectDegreesClockwiseFromNorth );
    if ( aspect != m_aspect )
    {
        m_aspect = aspect;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain down-slope (aspect) compass direction.

    \param[in] downslopeDegreesClockwiseFromNorth Just what it says.
 */

void Sem::SurfaceFireTerrain::setDownslopeCompass(
        double downslopeDegreesClockwiseFromNorth )
{
    setAspectCompass( downslopeDegreesClockwiseFromNorth );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain up-slope compass direction.

    \param[in] upslopeDegreesClockwiseFromNorth Just what it says.
 */

void Sem::SurfaceFireTerrain::setUpslopeCompass(
        double upslopeDegreesClockwiseFromNorth )
{
    setAspectCompass(
        Sem::CompassAlgorithm::opposite( upslopeDegreesClockwiseFromNorth ) );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain slope steepness.

    \param[in] slopeDegrees Slope steepness in degrees.
 */

void Sem::SurfaceFireTerrain::setSlopeDegrees( double slopeDegrees )
{
    setSlopeFraction( tan( slopeDegrees * 0.017453293 ) );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain slope steepness.

    \param[in] slopePercent Slope steepness percent (100 * rise/reach).
 */

void Sem::SurfaceFireTerrain::setSlopePercent( double slopePercent )
{
    setSlopeFraction( 0.01 * slopePercent );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the terrain slope steepness.

    \param[in] slopeFraction Slope steepness fraction (rise/reach).
 */

void Sem::SurfaceFireTerrain::setSlopeFraction( double slopeFraction )
{
    assert( slopeFraction >= slopeFractionMin && slopeFraction <= slopeFractionMax );
    if ( slopeFraction != m_slope )
    {
        m_slope = slopeFraction;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to terrain slope steepness.

    \return Terrain slope steepness in degrees.
 */

double Sem::SurfaceFireTerrain::slopeDegrees( void ) const
{
    checkUpdate();
    return( atan( m_slope ) / 0.017453293 );
}

//------------------------------------------------------------------------------
/*! \brief Access to the terrain slope steepness.

    \return Terrain slope steepness fraction (rise/reach).
 */

double Sem::SurfaceFireTerrain::slopeFraction( void ) const
{
    checkUpdate();
    return( m_slope );
}

//------------------------------------------------------------------------------
/*! \brief Access to the terrain slope steepness.

    \return Terrain slope steepness percent (100. rise/reach).
 */

double Sem::SurfaceFireTerrain::slopePercent( void ) const
{
    checkUpdate();
    return( 100. * m_slope );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access methods to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SurfaceFireTerrain::update( void ) const
{
    // Do whatever here to bring object properties current
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the terrain up-slope compass direction.

    \return Terrain up-slope compass direction (degrees clockwise from north).
 */

double Sem::SurfaceFireTerrain::upslopeCompass( void ) const
{
    checkUpdate();
    return( Sem::CompassAlgorithm::opposite( m_aspect ) );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireTerrain objects.

    \param[in] lhs Left-hand-side SurfaceFireTerrain object.
    \param[in] rhs Right-hand-side SurfaceFireTerrain object.
 */
bool Sem::operator ==( const Sem::SurfaceFireTerrain &lhs,
                       const Sem::SurfaceFireTerrain &rhs )
{ 
  return( ( fabs( lhs.slopeFraction() - rhs.slopeFraction() )  < Smidgen )
       && ( fabs( lhs.aspectCompass() - rhs.aspectCompass() ) < Smidgen )
    );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireTerrain objects.

    \param[in] lhs Left-hand-side SurfaceFireTerrain object.
    \param[in] rhs Right-hand-side SurfaceFireTerrain object.
 */
bool Sem::operator !=( const Sem::SurfaceFireTerrain &lhs,
                       const Sem::SurfaceFireTerrain &rhs )
{ 
  return( ! ( lhs == rhs ) );
}


//------------------------------------------------------------------------------
//  End of SurfaceFireTerrain.cpp
//------------------------------------------------------------------------------

