//------------------------------------------------------------------------------
/*! \file SpotBurningPile.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief An implementation of Albini's \ref albini1979 model for
    predicting maximum spotting distance from a group of burning trees.
 */

#ifndef _SPOTBURNINGPILE_H_INCLUDED_
#define _SPOTBURNINGPILE_H_INCLUDED_

// Custom header files
#include "Signal.h"
#include "SpotAlgorithm.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SpotBurningPile SpotBurningPile.h
    \brief An implementation of Albini's \ref albini1979 model for
    predicting maximum spotting distance from a group of burning trees.

    SpotBurningPile uses the flame height property to determine the height
    of lofted firebrands.
    
    The distance a firebrand can travel over flat terrain is determined by
    its lofted height, the 20-ft wind speed, and the mean treetop/vegetation
    cover height along the trajectory path.

    In mountainous terrain, this distance is adjusted for the firebrand's
    source location in a sinusiodal terrain described by the ridgetop-to-valley
    horizontal distance and elevational difference.

    The default constructor SpotBurningPile() creates an uninteresting state
    that can be manipulated be setting independent properties:
        - void setCoverHeight( double coverHeight ) ;
        - void setFlameHeight( double treeHeight ) ;
        - void setRidgetopToValleyDistance( double distance ) ;
        - void setRidgetopToValleyElevation( double elevation ) ;
        - void setSource( SpotSource source ) ;
        - void setWindSpeedAt20Ft( double windSpeed ) ;

    After setting any one or more of these properties, you can query any of
    the dependent property results:
        - double firebrandHeight( void ) const;
        - double flatTerrainSpottingDistance( void ) const;
        - double mountainTerrainSpottingDistance( void ) const;

    Whenever an independent property is updated, a dirty flag is set.
    Whenever a dependent property is accessed, the dirty flag is check,
    and all necessary updates are performed before the dependent value is
    returned.  The alleviates programmers from having to remember to invoke
    update routines at appropriate times, and enables 'lazy updating' of
    dependent properties; they only get updated when they are requested.
 */

class SpotBurningPile : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int spotBurningPileVersion = 1;    //!< Class version
// Property ranges
    static const double coverHeightMin;                 //!< Minimum valid cover height (ft) 
    static const double coverHeightMax;                 //!< Maximum valid cover height (ft) 
    static const double flameHeightMin;                 //!< Minimum valid flame height (ft)
    static const double flameHeightMax;                 //!< Maximum valid flame height (ft)
    static const double ridgetopToValleyDistanceMin;    //!< Minimum valid ridgetop-to-valley distance (mi)  
    static const double ridgetopToValleyDistanceMax;    //!< Maximum valid ridgetop-to-valley distance (mi)  
    static const double ridgetopToValleyElevationMin;   //!< Minimum valid valley-to-ridgetop elevation (ft) 
    static const double ridgetopToValleyElevationMax;   //!< Maximum valid valley-to-ridgetop elevation (ft) 
    static const double windSpeedAt20FtMin;             //!< Minimum valid wind speed at 20 ft (mi/h)
    static const double windSpeedAt20FtMax;             //!< Maximum valid wind speed at 20 ft (mi/h)

// Public interface
public:
    // Default constructor
    SpotBurningPile( void ) ;
    // Custom constructors
    SpotBurningPile(
            Sem::SpotAlgorithm::SpotSource source,
            double ridgetopToValleyDistance,
            double ridgetopToValleyElevation,
            double coverHeight,
            double windSpeedAt20Ft,
            double flameHeight );
    // Virtual destructor
    virtual ~SpotBurningPile( void ) ;
    // Copy constructor
    SpotBurningPile( const SpotBurningPile &rhs ) ;
    // Assignment operator
    const SpotBurningPile &operator=( const SpotBurningPile &rhs ) ;

    // Property access methods
    const char *className( void ) const ;
    int classVersion( void ) const ;
    double coverHeight( void ) const;
    double flameHeight( void ) const;
    double ridgetopToValleyDistance( void ) const;
    double ridgetopToValleyElevation( void ) const;
    Sem::SpotAlgorithm::SpotSource source( void ) const ;
    double windSpeedAt20Ft( void ) const;

    // Intermediates access methods
    double firebrandHeight( void ) const;
    double flatTerrainSpottingDistance( void ) const;
    double mountainTerrainSpottingDistance( void ) const;

    // Property update methods
    void setCoverHeight( double coverHeight ) ;
    void setFlameHeight( double flameHeight ) ;
    void setRidgetopToValleyDistance( double distance ) ;
    void setRidgetopToValleyElevation( double elevation ) ;
    void setSource( Sem::SpotAlgorithm::SpotSource source ) ;
    void setWindSpeedAt20Ft( double windSpeed ) ;

// Must be re-implemented by derived classes
protected:
    virtual void init( void ) const ;
    virtual void update( void ) const ;

// Protected properties
protected:
    double m_coverHeight;       //!< Mean treetop/vegetation height along the firebrand path (0-300 ft).
    double m_distance;          //!< Horizontal distance from ridgetop to valley bottom (0-4 mi).
    double m_elevation;         //!< Vertical distance from ridgetop to valley bottom (0-4000 ft).
    double m_flameHeight;       //!< Steady flame height from burning pile (0-100 ft).
    Sem::SpotAlgorithm::SpotSource m_source;   //!< Source location of the burning pile.
    double m_windSpeedAt20Ft;   //!< Wind speed at 20ft (0-99 mi/h)

    mutable double m_firebrandHeight;       //!< Lofted firebrand height from toching trees (ft).
    mutable double m_flatSpottingDistance;  //!< Maximum spotting distance on flat terrain (mi).
    mutable double m_mtnSpottingDistance;   //!< Maximum spotting distance in mountainous terrain (mi).
};

// Non-member equality operators
bool operator ==( const SpotBurningPile & a, const SpotBurningPile & b ) ;
bool operator !=( const SpotBurningPile & a, const SpotBurningPile & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of SpotBurningPile.h
//------------------------------------------------------------------------------

