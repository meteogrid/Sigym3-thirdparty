//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All surface fuel algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

// Custom header files
#include "SurfaceFireFuelAlgorithm.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed mean bulk density (lb/ft<sup>3</sup>).
 
    \param[in] load Surface fuel bed total load (lb/ft<sup>2</sup>).
    \param[in] depth Surface fuel bed depth (ft).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 40 and Equation 74:
    \f[\rho_{b} = \frac {\omega_o}{\delta}\f]
    where
    - \f$\rho_{b}\f$ is the oven-dry bulk density (lb/ft<sup>3</sup>),
   - \f$\omega_o\f$ is the oven-dry fuel load (lb/ft<sup>2</sup>), and
    - \f$\delta\f$ is the fuel bed depth (ft).
  
    \return Surface fuel bed mean bulk density (lb/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::bulkDensity( double load, double depth )
{
    return( ( depth > Sem::Smidgen ) ? ( load / depth ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle fraction of total herbaceous
    fuel load that is cured based upon the herbaceous fuel moisture content.

    \param[in] herbMc Surface fuel live herbaceous fuel moisture content
    (lb water/lb fuel).

    \return Fraction [0..1] of total herbaceous fuel load that is cured.
 */

double Sem::SurfaceFireFuelAlgorithm::cureHerb1( double herbMc )
{
    double cured = 1.333 - 1.11 * herbMc;
    cured = ( cured < 0.0 ) ? 0.0 : cured;
    cured = ( cured > 1.0 ) ? 1.0 : cured;
    return( cured );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle dead fuel time lag class.

    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    BEHAVE code.
  
    Dead fuel time lag class is deteremined from the particle diameter:
    <table>
    <tr><td>Time Lag<br>Class</td><td>SA/Vol<br>(ft<sup>2</sup>/ft<sup>3</sup>)</td><td>Diameter<br>(in)</td></tr>
    <tr><td>1</td><td>>= 192</td><td><= 0.25</td></tr>
    <tr><td>10</td><td>>= 48</td><td><= 1.00</td></tr>
    <tr><td>100</td><td>>= 16</td><td><= 3.00</td></tr>
    <tr><td>1000</td><td>< 16</td><td>> 3.00</td></tr>
    </table>
  
    \return Fuel particle's dead fuel moisture time lag class
    as a SurfaceFuelMoistureClass enum value.
 */

Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass
        Sem::SurfaceFireFuelAlgorithm::deadTimeLagClass( double savr )
{
    if ( savr >= 192. )             // 0.0 - 0.25 inches diameter
    {
        return( MoistureDead1h );
    }
    else if ( savr >= 48. )         // 0.50 - 1.00 inches diameter
    {
        return( MoistureDead10h );
    }
    else if ( savr >= 16. )         // 1.00 - 3.00 inches diameter
    {
        return( MoistureDead100h );
    }
    return( MoistureDead1000h );    // > 3.00 inches diameter
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle diameter
    from its surface area-to-volume ratio.
 
    \param[in] savr Surface fuel particle surface area-to-volume ratio.
    (ft<sup>2</sup>/ft<sup>3</sup>).
 
    \par Reference:
    The fuel particle diameter is determined by:
    \f[ d = \frac {48}{\sigma} \f]
    where
    - \f$ d \f$ is the fuel particle diameter (in) and
    - \f$\sigma\f$ is the fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
 
    This table shows some commonly used values.
    <table>
    <tr><td>Diameter<br>(inches)</td><td>SA/Vol<br>(ft<sup>2</sup>/ft<sup>3</sup>)</td><td>Notes</td></tr>
    <tr><td>3.00</td><td>16</td><td></td></tr>
    <tr><td>1.60</td><td>30</td><td>All standard fuel model dead 100h</td></tr>
    <tr><td>1.00</td><td>48</td><td></td></tr>
    <tr><td>0.50</td><td>96</td><td></td></tr>
    <tr><td>0.44</td><td>109</td><td>All standard fuel model dead 10h</tr>
    <tr><td>0.25</td><td>192</td><td></td></tr>
    <tr><td>0.04</td><td>1200</td><td></td></tr>
    <tr><td>0.0320</td><td>1500</td><td>Models 3, 11, 12, & 13 dead 1h<br>Models 2, 4, 5, & 7 live</td></tr>
    <tr><td>0.0274</td><td>1750</td><td>Models 6 & 7 dead 1h</td></tr>
    <tr><td>0.0240</td><td>2000</td><td>Models 4, 5, 8, & 10 dead 1h</td></tr>
    <tr><td>0.0192</td><td>2500</td><td>Model 9 dead 1h</td></tr>
    <tr><td>0.0160</td><td>3000</td><td>Model 2 dead 1h</td></tr>
    <tr><td>0.0137</td><td>3500</td><td>Model 1 dead 1h</td></tr>
    </table>
 
   \return The fuel particle diameter (in).
 */

double Sem::SurfaceFireFuelAlgorithm::diameter( double savr )
{
    return( ( savr > Sem::Smidgen ) ? ( 48. / savr ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle effective heating number.
  
    The effective heating number is the fraction of the particle that must
    be heated to ignition temperature for the particle to ignite.
  
    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 14 and Equation 77:
    \f[\epsilon = e^{\left( -138 / \sigma \right)} \f]
    where
    - \f$\epsilon\f$ is the fuel particle effective heating number and
    - \f$\sigma\f$ is the fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Fuel particle effective heating number (dimensionless).
 */

double Sem::SurfaceFireFuelAlgorithm::effectiveHeatingNumber( double savr )
{
    return( ( savr > Sem::Smidgen ) ? ( exp( -138. / savr ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines amount of surface fuel particle dead load
    that must be heated to ignition.
  
    \param[in] load Surface fuel particle dead load (lb/ft<sup>2</sup>).
    \param[in] ehn Surface fuel particle effective heating number (dimensionless).
  
    \return Dead fuel particle effective heating load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::fineFuelDead( double load, double ehn )
{
    return( load * ehn );
}

//------------------------------------------------------------------------------
/*! \brief Determines amount of surface fuel particle live load
    that must be heated to ignition.
  
    \param[in] load Surface fuel particle live load (lb/ft<sup>2</sup>).
    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Live fuel particle effective heating load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::fineFuelLive( double load, double savr )
{
    return( ( savr > Sem::Smidgen ) ? ( load * exp( -500. / savr ) ) : 0.0 );
}

//  Doxygen stops here

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel particle heat of pre-ignition
    based upon its moisture content.
  
    \param[in] moisture Surface fuel particle moisture content
    (lb water/lb oven-dry fuel).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 12 and Equation 78:
    \f[Q_{ig} = 250 + 116 M_f\f]
    where
    - \f$ Q_{ig} \f$ is the heat of pre-ignition (Btu/lb) and
    - \f$ M_f \f$ is the fuel particle moisture content
        (lb water/lb oven-dry fuel).
  
    \return Fuel particle heat of pre-ignition (Btu/lb).
 */

double Sem::SurfaceFireFuelAlgorithm::heatOfPreIgnition( double moisture )
{
    return( 250. + 1116.0 * moisture );
}

//------------------------------------------------------------------------------
/*! \brief Determines the heat per unit area (Btu/ft<SUP>2</SUP>).
  
    \param[in] rxInt Fire reaction intensity (Btu/ft<SUP>2</SUP>-min).
    \param[in] tauR Fire residence time (min).
  
    \par Reference:
    \f[H = I_{R} \cdot \tau_{r}\f]
    where
    - \f$ H \f$ is the heat per unit area (Btu/ft<SUP>2</SUP>),
    - \f$ I_{R} \f$ is the fire reaction intensity (Btu/ft<SUP>2</SUP>-min), and
    - \f$ \tau_{r} \f$ is the fire residence time (min).
  
    \return Fire heat per unit area (Btu/ft<SUP>2</SUP>).
 */

double Sem::SurfaceFireFuelAlgorithm::heatPerUnitArea( double rxInt,
        double tauR )
{
    return( rxInt * tauR );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed heat sink.
  
    \param[in] q_ig Fuel bed weighted heat of pre-ignition (Btu/lb).
    \param[in] bulkDensity Surface fuel bed mean bulk density (lb/ft<sup>3</sup>).
  
    \return Surface fuel bed heat sink (Btu/lb).
 */

double Sem::SurfaceFireFuelAlgorithm::heatSink( double q_ig, double bulkDensity )
{
    return( q_ig * bulkDensity );
}

//------------------------------------------------------------------------------
/*! \brief Determines the fuel bed live fuel moisture content of extinction.
  
    \param deadEffLoad Dead fuel effective load (lb/ft<SUP>2</SUP>).  This is
    the amount of the dead fuel load that must be raised to ignition point.
  
    \param liveEffLoad Live fuel effective load (lb/ft<SUP>2</SUP>).  This is
    the amount of the live fuel load that must be raised to ignition point.
  
    \param fineDeadMois Weighted fuel moisture content of the dead fuel load
    that must be raised to ignition (lb water/lb oven-dry fuel).
  
    \param deadMext Dead fuel moisture content of extinction
    (lb water/lb oven-dry fuel).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 88:
  
    \return Fuel bed maximum reaction velocity (min<SUP>-1</SUP>).
 */

double Sem::SurfaceFireFuelAlgorithm::liveFuelExtinctionMoisture(
        double deadEffLoad, double liveEffLoad,
        double fineDeadMois, double deadMext )
{
    double liveMext = deadMext;
    if ( liveEffLoad > Sem::Smidgen
      && deadEffLoad > Sem::Smidgen
      && deadMext    > Sem::Smidgen )
    {
        liveMext = 2.9 * ( deadEffLoad / liveEffLoad )
                 * ( 1.0 - fineDeadMois / deadEffLoad / deadMext )
                 - 0.226;
    }
    if ( liveMext < deadMext )
    {
        liveMext = deadMext;
    }
    return( liveMext );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed maximum reaction velocity.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 36 and Equation 68:
    \f[\Gamma_{max}^{`} = \sigma^{1.5} (495 + 0.0594 \sigma^{1.5})^{-1}\f]
    where
    - \f$\Gamma_{max}^{`}\f$ is the fuel bed maximum reaction velocity
        (min<sup>-1</sup>) and
    - \f$\sigma\f$ is the fuel bed surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed maximum reaction velocity (min<sup>-1</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::maximumReactionVelocity( double sigma )
{
    double gammaMax = 0.;
    if ( sigma > 1.0 )
    {
        double sig15 = pow( sigma, 1.5 );
        // Rothermel (1972) equation 36
        gammaMax = sig15 / ( 495.0 + 0.0594 * sig15 );
    }
    return( gammaMax );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed mineral damping coefficient.
  
    \param[in] seff Effective silica content of the surface fuel (lb Si/lb fuel).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 30 and Equation 62:
    \f[\eta_s = 0.174 S_e^{-.19}\f]
    where
    - \f$\eta_s\f$ is the mineral damping coefficient (dimensionless) and
    - \f$S_e\f$ is the effective silica content of the fuel (lb Si/lb fuel).
  
    \return Surface fuel bed mineral damping coefficient (dimensionless).
 */

double Sem::SurfaceFireFuelAlgorithm::mineralDampingCoefficient( double seff )
{
    double etaS = 1.0;
    if ( seff > Sem::Smidgen )
    {
        if ( ( etaS = 0.174 * pow( seff, -0.19 ) ) > 1.0 )
        {
            etaS = 1.0;
        }
    }
    return( etaS );
}

//------------------------------------------------------------------------------
/*! \brief Determines the fuel bed moisture damping coefficient.
  
    \param[in] mois Fuel moisture content (lb water/lb oven-dry fuel).
    \param[in] mext Fuel moisture content of extinction (lb water/lb oven-dry fuel).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 29 and Equation 64:
    \f[\eta_M = 1.00 - 2.59 r_M + 5.11 r_M^2 - 3.52 r_M^3\f]
    where
    - \f$\eta_M\f$ is the moisture damping coefficient (dimensionless) and
    - \f$r_M\f$ is the fuel moisture content-to-fuel moisture content of
        extinction ratio (dimensionless) as derived below.
  
    \ref rothermel1972 "Rothermel (1972)" Equation 65:
    \f[r_m = \frac {M_f}{M_{ext}}\f]
    where
    - \f$r_m\f$ is the fuel moisture ratio (dimensionless),
    - \f$M_f\f$ is the fuel moisture content (lb water/lb oven-dry fuel), and
    - \f$M_{ext}\f$ is the fuel moisture content of extinction (lb water/lb
        oven-dry fuel).
  
    \return Fuel bed moisture damping coefficient (dimensionless).
 */

double Sem::SurfaceFireFuelAlgorithm::moistureDampingCoefficient(
        double mois, double mext )
{
    double etaM = 0.0;
    if ( mext > Sem::Smidgen
      && mois <= mext )
    {
        double ratio = mois / mext;
        etaM = 1.0 - 2.59 * ratio + 5.11 * ratio * ratio
             - 3.52 * ratio * ratio * ratio;
        if ( etaM > 1.0 )
        {
            etaM = 1.0;
        }
    }
    if ( etaM < 0.0 )
    {
        etaM = 0.0;
    }
    return( etaM );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle net fuel load
    from the oven-dry fuel load and total silica content (lb/ft<sup>2</sup>).
  
    This uses Albini's correction to Rothermel's Equation 24.
  
    \param[in] load Surface fuel particle oven-dry load (lb/ft<sup>2</sup>).
    \param[in] totalSi Total silica content of the fuel particle
                (lb silica/lb oven-dry fuel).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 24 was:
    \f[\omega_n = \frac {\omega_o}{1 + S_T}\f]
    where
    - \f$\omega_n\f$ is the net fuel load (lb/ft<sup>2</sup>),
    - \f$\omega_o\f$ is the oven-dry fuel load (lb/ft<sup>2</sup>), and
    - \f$S_T\f$ is the total silica content (lb silica/lb oven-dry fuel).
  
    Albini corrected the equation to:
    \f[\omega_n = \omega_o \left(1. - S_T\right) \f]
  
    \return Surface fuel particle net load (lb/ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::netLoad( double load, double totalSi )
{
    return( load * ( 1. - totalSi ) );
}

//------------------------------------------------------------------------------
/*! \brief Determines the no-wind, no-slope spread rate (ft/min).
  
    \param rxInt Fuel bed reaction intensity (Btu/ft<SUP>2</SUP>-min).
    \param propFlux Propagating flux ratio (dimensionless).
    \param heatSink Heat sink term (Btu/ft<SUP>3</SUP>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 27 and Equation 58:
    \f[R = \frac {I_R \cdot \xi}{\rho_b \cdot \epsilon \cdot Q_{ig} }\f]
    where
    - \f$ R \f$ is the no-wind, no-slope spread rate (ft/min),
    - \f$ I_R \f$ is the reaction intensity (Btu/ft<SUP>2</SUP>),
    - \f$ \xi \f$ is the propagating flux ratio (dimensionless), and
    - \f$ \rho_b \cdot \epsilon \cdot Q_{ig}\f$ is the heat sink term (Btu/ft<SUP>3</SUP>)
    where
    - \f$\rho_b\f$ is the fuel bed bulk density (lb/ft<SUP>3</SUP>),
    - \f$\epsilon\f$ is the effective heating number (dimensionless),
    - \f$Q_{ig}\f$ is the heat of pre-ignition (Btu/lb).
  
    \return No-wind, no-slope spread rate (ft/min).
 */

double Sem::SurfaceFireFuelAlgorithm::noWindNoSlopeSpreadRate( double rxInt,
        double propFlux, double heatSink )
{
    return( ( heatSink > Smidgen ) ? ( rxInt * propFlux / heatSink ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed optimum packing ratio
    (volume of fuel-to-volume of fuel bed).
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 37 and Equation 69:
    \f[\beta_{op} = 3.348 \sigma^{-.8189}\f]
    where
    - \f$\beta_{op}\f$ is the fuel bed optimum packing ratio and
    - \f$\sigma\f$ is the fuel bed surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed optimum packing ratio
    (ft<sup>3</sup> fuel/ft<sup>3</sup> fuel bed).
 */

double Sem::SurfaceFireFuelAlgorithm::optimumPackingRatio( double sigma )
{
    return( ( sigma > 1.0 ) ? ( 3.348 * pow( sigma, -0.8189 ) ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed optimum reaction velocity.
  
    \param[in] gammaMax Surface fuel bed maximum reaction velocity (min<sup>-1</sup>).
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] beta Surface fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
    \param[in] betaOpt Surface fuel bed optimum packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 38 and Equation 67:
    \f[\Gamma^{`} = \Gamma_{max}^{`}
                    \left(\frac{\beta}{\beta_{op}}\right)^A
                    e^{\left[A\left(1-\frac{\beta}{\beta_{op}}\right)\right]}\f]
    where
    - \f$\Gamma^{`}\f$ is the fuel bed optimum reaction velocity (min<sup>-1</sup>),
    - \f$\Gamma_{max}^{`}\f$ is the fuel bed maximum reaction velocity
        (min<sup>-1</sup>),
    - \f$\beta\f$ is the fuel bed packing ratio,
    - \f$\beta_{op}\f$ is the fuel bed optimum packing ratio, and
    - A is Rothermel's "arbitrary variable" shown below.
  
    \ref rothermel1972 "Rothermel (1972)" Equation 39 and Equation 70:
    \f[ A = \left(4.774 \sigma^{0.1} - 7.27\right)^{-1} \f]
    where
    - \f$\sigma\f$ is the fuel bed surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>)
    <I>however</I>, BEHAVE uses the following:
    \f[ A = \frac {133}{\sigma^{0.7913}} \f]
  
    \return Surface fuel bed optimum reaction velocity (min<sup>-1</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::optimumReactionVelocity(
        double gammaMax, double sigma, double beta, double betaOpt )
{
    double gammaOpt = 0.;
    if ( betaOpt > Sem::Smidgen && sigma > 1. )
    {
        double ratio = beta / betaOpt;
        // Rothermel (1972) equation 39 is:
        // double a = 1. / ( 4.774 * pow( sigma, 0.1 ) - 7.27 );
        // But BEHAVE 4 uses this:
        double a = 133. / ( pow( sigma, 0.7913 ) );
        // Rothermel (1972) equation 38
        gammaOpt = gammaMax * pow( ratio, a ) * exp( a * ( 1. - ratio ) );
    }
    return( gammaOpt );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed propagating flux ratio.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] beta Surface fuel bed packing ratio
    (lb per ft<sup>3</sup> fuel bed/lb per ft<sup>3</sup> fuel particles).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 42 and Equation 76:
    \f[\xi = \left( 192 + 0.2595 \sigma\right)^{-1}
                  e^{\left[\left(0.792 + 0.681 \sigma^{0.5}\right)
                  \left( \beta + 0.1 \right) \right]} \f]
    where
    - \f$ \xi \f$ is the propagating flux ratio (dimensionless),
    - \f$ \beta \f$ is the fuel bed packing ratio, and
    - \f$ \sigma \f$ is the fuel bed surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Propagating flux ratio (dimensionless).
 */

double Sem::SurfaceFireFuelAlgorithm::propagatingFluxRatio(
        double sigma, double beta )
{
    return( ( sigma > Smidgen )
          ? ( exp( ( 0.792 + 0.681 * sqrt( sigma ) ) * ( beta + 0.1 ) )
            / ( 192. + 0.2595 * sigma ) )
          : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines the surface fuel bed fire residence time.
  
    \param[in] sigma Surface fuel bed characteristic surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    \ref anderson1972 "Anderson (?)" Equation ?:
    \f[\tau = \frac {384}{\sigma}\f]
    where
    - \f$\tau\f$ is the fire residence time (min) and
    - \f$\sigma\f$ is the fuel bed surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \return Surface fuel bed fire residence time (min).
 */

double Sem::SurfaceFireFuelAlgorithm::residenceTime( double sigma )
{
    return( ( sigma > Sem::Smidgen ) ? ( 384. / sigma ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle surface area.
  
    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] load Surface fuel particle load (lb/ft<sup>2</sup>).
    \param[in] rho Surface fuel particle density (lb/ft<sup>3</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 53:
    \f[ \alpha = \frac {\sigma \omega_o}{\rho_p} \f]
    where
    - \f$ \alpha \f$ is the fuel particle surface area (ft2),
    - \f$ \sigma \f$ is the fuel particle surface area-to-volume ratio
        (ft<sup>2</sup>/ft<sup>3</sup>),
    - \f$ \omega_o \f$ is the fuel particle oven-dry load
        (lb/ft<sup>2</sup>), and
    - \f$ \rho_p \f$ is the fuel particle density (lb/ft<sup>3</sup>).
  
    \return Surface fuel particle surface area (ft<sup>2</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::surfaceArea( double savr, double load,
        double rho )
{
    return( ( rho > Sem::Smidgen ) ? ( ( savr * load ) / rho ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle surface area-to-volume ratio
    from its diameter.

    \param[in] diameter Surface fuel particle diameter (in).
      
    \par Reference:
    The surface area-to-volume ratio (ft<sup>2</sup>/ft<sup>3</sup>)
    is determined by:
    \f[ \sigma = \frac {48}{d} \f]
    where
    - \f$ \sigma \f$ is the fuel particle surface area-to-volume ratio
        (ft<sup>2</sup>/ft<sup>3</sup>) and
    - \f$ d \f$ is the fuel particle diameter (in).
  
    This table shows some commonly used values:
    <table>
    <tr><td>Diameter<br>(inches)</td><td>SA/Vol<br>(ft<sup>2</sup>/ft<sup>3</sup>)</td><td>Notes</td></tr>
    <tr><td>3.00</td><td>16</td><td></td></tr>
    <tr><td>1.60</td><td>30</td><td>All standard fuel model dead 100h</td></tr>
    <tr><td>1.00</td><td>48</td><td></td></tr>
    <tr><td>0.50</td><td>96</td><td></td></tr>
    <tr><td>0.44</td><td>109</td><td>All standard fuel model dead 10h</tr>
    <tr><td>0.25</td><td>192</td><td></td></tr>
    <tr><td>0.04</td><td>1200</td><td></td></tr>
    <tr><td>0.0320</td><td>1500</td><td>Models 3, 11, 12, & 13 dead 1h<br>Models 2, 4, 5, & 7 live</td></tr>
    <tr><td>0.0274</td><td>1750</td><td>Models 6 & 7 dead 1h</td></tr>
    <tr><td>0.0240</td><td>2000</td><td>Models 4, 5, 8, & 10 dead 1h</td></tr>
    <tr><td>0.0192</td><td>2500</td><td>Model 9 dead 1h</td></tr>
    <tr><td>0.0160</td><td>3000</td><td>Model 2 dead 1h</td></tr>
    <tr><td>0.0137</td><td>3500</td><td>Model 1 dead 1h</td></tr>
    </table>
  
    \return The fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::surfaceAreaToVolumeRatio( double diameter )
{
    return( ( diameter > Sem::Smidgen ) ? ( 48. / diameter ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle surface area weighting factor
    for either its dead or live load component.
  
    \param[in] particleArea Surface fuel particle dead or live surface area
    (ft<sup>2</sup>).
    \param[in] lifeArea Corresponding fuel bed total dead or live surface area
    (ft<sup>2</sup>).
  
    \par Reference:
    \ref rothermel1972 "Rothermel (1972)" Equation 56 and Equation 57:
    \f[ f = \frac {\alpha_p}{\alpha_c} \f]
    where
    - \f$ f \f$ is the surface area weighting factor (dimensionless),
    - \f$ \alpha_p \f$ is the fuel particle surface area (ft<sup>2</sup>), and
    - \f$ \alpha_c \f$ is the fuel life category surface area (ft<sup>2</sup>).
  
    \return Ratio of \a particleArea to \a categoryArea.
 */

double Sem::SurfaceFireFuelAlgorithm::surfaceAreaWtgFactor(
        double particleArea, double lifeArea )
{
    return( ( lifeArea > Sem::Smidgen ) ? ( particleArea / lifeArea ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle surface area weighting size class
    from its surface area-to-volume ratio.

    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
  
    \par Reference:
    BEHAVE code.
  
    Surface area weighting size class is determined from the following table:
    <table>
    <tr><td>Wtg<br>Class</td><td>SA/Vol<br>(ft<sup>2</sup>/ft<sup>3</sup>)</td><td>Diameter<br>(in)</td></tr>
    <tr><td>0</td><td>>= 1200</td><td></td><= 0.04</tr>
    <tr><td>1</td><td>>= 192</td><td><= 0.25</td></tr>
    <tr><td>2</td><td>>= 98</td><td><= 0.50</td></tr>
    <tr><td>3</td><td>>= 48</td><td><= 1.00</td></tr>
    <tr><td>4</td><td>>= 16</td><td><= 3.00</td></tr>
    <tr><td>5</td><td>>= 0</td><td>> 3.00</td></tr>
    </table>
  
    \return Fuel particle's surface area weighting size class
    as a SurfaceFuelAreaWtgClass enum value.
 */

Sem::SurfaceFireFuelAlgorithm::SurfaceFireAreaWtgClass
        Sem::SurfaceFireFuelAlgorithm::surfaceAreaWtgSizeClass( double savr )
{
    if ( savr >= 1200. )            // 0.00 - 0.04 inches diameter
    {
        return( AreaWtgClass1200Plus );
    }
    else if ( savr >=  192. )       // 0.04 - 0.25 inches diameter
    {
        return( AreaWtgClass192_1200 );
    }
    else if ( savr >=   96. )       // 0.25 - 0.50 inches diameter
    {
        return( AreaWtgClass96_192 );
    }
    else if ( savr >=   48. )       // 0.50 - 1.00 inches diameter
    {
        return( AreaWtgClass48_96 );
    }
    else if ( savr >= 16. )         // 1.00 - 3.00 inches diameter
    {
        return( AreaWtgClass16_48 );
    }
    return( AreaWtgClass0_16 );     // > 3.00 inches diameter
}

//------------------------------------------------------------------------------
/*! \brief Determines surface fuel particle volume for round branchwood.
    
    \param[in] savr Surface fuel particle surface area-to-volume ratio
    (ft<sup>2</sup>/ft<sup>3</sup>).
    \param[in] area Surface fuel particle surface area (ft<sup>2</sup>).

   \return Surface fuel particle volume for round branchwood (ft<sup>3</sup>).
 */

double Sem::SurfaceFireFuelAlgorithm::volume( double savr, double area )
{
    return( ( savr > Smidgen ) ? ( area / savr ) : 0.0 );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the wind adjustment factor for scaling wind speed from
    20-ft to midflame height.
  
    For sheltered conditions under a canopy, Albini and Baughman (1979)
    equation 21 (page 9) is used for the wind adjustment factor.
  
    For unsheltered conditions, applies the same basic equation using
    fuel bed depth as the canopy height.
  
    \param[in] canopyCover  Canopy cover projected onto ground [0..1].
    \param[in] canopyHt     Tree canopy height from the ground (ft).
    \param[in] crownRatio   Tree crown length-to-tree height ratio [0..1].
    \param[in] fuelDepth    Fuel bed depth (ft).
  
    \return Wind adjustment factor [0..1].
 */

double Sem::SurfaceFireFuelAlgorithm::windAdjustmentFactor(
        double canopyCover, double canopyHt,
        double crownRatio, double fuelDepth )
{
    double waf  = 1.0;
    crownRatio  = ( crownRatio < 0.0 )  ? 0.0 : crownRatio;
    crownRatio  = ( crownRatio > 1.0 )  ? 1.0 : crownRatio;
    canopyCover = ( canopyCover < 0.0 ) ? 0.0 : canopyCover;
    canopyCover = ( canopyCover > 1.0 ) ? 1.0 : canopyCover;
    canopyHt    = ( canopyHt < 10.0 ) ? 10.0 : canopyHt;

    // f == fraction of the volume under the canopy top that is filled with
    // tree crowns (division by 3 assumes conical crown shapes).
    double f = crownRatio * canopyCover / 3.;

    // Unsheltered
    if ( canopyCover < Smidgen || f < 0.05 )
    {
        if ( fuelDepth > Smidgen )
        {
            waf = 1.83 / log( (20. + 0.36 * fuelDepth) / (0.13 * fuelDepth) );
        }
    }
    // Sheltered
    else
    {
        waf = 0.555 / ( sqrt( f * canopyHt ) * log( ( 20 + 0.36 * canopyHt )
            / ( 0.13 * canopyHt ) ) );
    }
    // Constrain the result
    waf = ( waf > 1.0 ) ? 1.0 : waf;
    waf = ( waf < 0.0 ) ? 0.0 : waf;
    return( waf );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelAlgorithm.cpp
//------------------------------------------------------------------------------

