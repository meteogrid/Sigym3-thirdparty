//------------------------------------------------------------------------------
/*! \file Compass.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief Quantifies a global compass direction in terms of degrees
    clockwise from north.
    \license This code is released under the GNU Public License 2.
 */

#ifndef _COMPASS_H_INCLUDED_
#define _COMPASS_H_INCLUDED_

// Configuration
#include "config.h"
#include "Signal.h"

// Qt include files
#include <QDataStream>

// Standard header files
#include <iomanip>
#include <iostream>

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class Compass Compass.h
    \brief Quantifies a global compass direction in terms of degrees
    clockwise from north.
 
    Objects of type Compass are first class objects that behave like
    internal types with full construction, destruction, copy, assignment,
    serialization, and attribute access and update semantics.
 
    Compass is used to define wind and fire spread directions in the
    Fire Behavior Library. Because it is a full fledged type, strict
    typing gets enforced when passed as a parameter.
 */

class Compass : public Signal
{
// Valid property ranges
public:
    static const int compassVersion = 1;    //!< Class version

// Enable signals and slots
    Q_OBJECT
// Public interface
public:
    // Default constructor
    Compass( void ) ;
    // Custom constructor
    Compass( double degreesClockwiseFromNorth ) ;
    // Virtual destructor
    virtual ~Compass( void ) ;
    // Copy constructor
    Compass( const Compass & ) ;
    // Assignment operators
    const Compass &operator=( const Compass &rhs ) ;
    const Compass &operator=( double degreesClockwiseFromNorth ) ;
    // Addition and subtraction assignment operator
    Compass& operator +=( const Compass &rhs ) ;
    Compass& operator +=( double degrees ) ;
    Compass& operator -=( const Compass &rhs ) ;
    Compass& operator -=( double degrees ) ;
    // Introspection
    virtual const char *className( void ) const ;
    virtual int classVersion( void ) const ;
    // I/o and serialization
    friend std::istream &operator>>( std::istream &input, Compass &rhs ) ;
    friend std::ostream &operator<<( std::ostream &output, const Compass &rhs ) ;
    friend QDataStream &operator>>( QDataStream &input, Compass &rhs ) ;
    friend QDataStream &operator<<( QDataStream &output, const Compass &rhs ) ;
    // Public access
    double degreesClockwiseFromNorth( void ) const ;
    double degreesDeviationFromNorth( void ) const ;
    // Public update
    void setDegreesClockwiseFromNorth( double degreesClockwiseFromNorth ) ;
    // Public helper static methods
    double deviation( void ) const ;
    double opposite( void ) const ;

// Must be re-implemented by derived classes
protected:
    virtual void update( void ) const ;

// Private implementation
private:
    double m_degrees;       //!< Degrees clockwise from north
};


// Non-member equality operators
bool operator ==( const Compass & a, const Compass & b ) ;
bool operator ==( const Compass & a, double b ) ;
bool operator ==( double, const Compass & b ) ;

bool operator !=( const Compass & a, const Compass & b ) ;
bool operator !=( const Compass & a, double b ) ;
bool operator !=( double, const Compass & b ) ;

bool operator >( const Compass & a, const Compass & b ) ;
bool operator >( const Compass & a, double b ) ;
bool operator >( double, const Compass & b ) ;

bool operator >=( const Compass & a, const Compass & b ) ;
bool operator >=( const Compass & a, double b ) ;
bool operator >=( double, const Compass & b ) ;

bool operator <( const Compass & a, const Compass & b ) ;
bool operator <( const Compass & a, double b ) ;
bool operator <( double, const Compass & b ) ;

bool operator <=( const Compass & a, const Compass & b ) ;
bool operator <=( const Compass & a, double b ) ;
bool operator <=( double, const Compass & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of Compass.h
//------------------------------------------------------------------------------

