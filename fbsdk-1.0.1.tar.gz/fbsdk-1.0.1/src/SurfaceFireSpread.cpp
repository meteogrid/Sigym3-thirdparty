//------------------------------------------------------------------------------
/*! \file SurfaceFireSpread.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Quantifies a surface fire instance.
 */

// Custom header files
#include "CompassAlgorithm.h"
#include "Logger.h"
#include "SurfaceFireSpread.h"
#include "SurfaceFireSpreadAlgorithm.h"

// Standard headers
#include <cmath>
#include <iostream>
#include <iomanip>

//------------------------------------------------------------------------------
/*! \brief SurfaceFireSpread default constructor.
 */

Sem::SurfaceFireSpread::SurfaceFireSpread( void ) :
    Signal(),
    m_fuel( 0 ),
    m_terrain( 0 ),
    m_wind( 0 )
{
    init();
    m_classVersion = surfaceFireSpreadVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireSpread custom constructor.

    \param[in] fuel Pointer to the SurfaceFireFuelInterface to monitor.
    \param[in] terrain Pointer to the SurfaceFireTerrainInterface to monitor.
    \param[in] wind Pointer to the SurfaceFireWindInterface to monitor.
 */

Sem::SurfaceFireSpread::SurfaceFireSpread(
        Sem::SurfaceFireFuelInterface* fuel,
        Sem::SurfaceFireTerrainInterface* terrain,
        Sem::SurfaceFireWindInterface* wind ) :
    Signal(),
    m_fuel( 0 ),
    m_terrain( 0 ),
    m_wind( 0 )
{
    init();
    m_classVersion = surfaceFireSpreadVersion;
    connectFuel( fuel );
    connectTerrain( terrain );
    connectWind( wind );
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SurfaceFireSpread::~SurfaceFireSpread( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireSpread copy constructor.

    \param[in] right Reference to the SurfaceFireSpread from which to copy.

    \return Reference to the newly allocated SurfaceFireSpread.
 */

Sem::SurfaceFireSpread::SurfaceFireSpread( const SurfaceFireSpread &right )
    : Signal()
{
    init();
    m_classVersion = surfaceFireSpreadVersion;
    m_fuel         = right.m_fuel;
    m_terrain      = right.m_terrain;
    m_wind         = right.m_wind;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireSpread assignment operator.

    \param[in] right Reference to the SurfaceFireSpread from which to assign.

    \return Reference to the newly assigned SurfaceFireSpread.
 */

const Sem::SurfaceFireSpread& Sem::SurfaceFireSpread::operator=(
        const SurfaceFireSpread &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion = surfaceFireSpreadVersion;
        m_fuel         = right.m_fuel;
        m_terrain      = right.m_terrain;
        m_wind         = right.m_wind;
        setDirty();
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireSpread::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SurfaceFireSpread::classVersion( void ) const
{
    return( surfaceFireSpreadVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the currently connected SurfaceFireFuelInterface
    object address.

    \return Address of the currently connected SurfaceFireFuelInterface object,
    or 0 if there is no attached object.
 */

Sem::SurfaceFireFuelInterface* Sem::SurfaceFireSpread::connectedFuel( void ) const
{
    // Do not checkUpdate()!
    return( m_fuel );
}

//------------------------------------------------------------------------------
/*! \brief Access to the currently connected SurfaceFireTerrainInterface
    object address.

    \return Address of the currently connected SurfaceFireTerrainInterface
    object, or 0 if there is no attached object.
 */

Sem::SurfaceFireTerrainInterface* Sem::SurfaceFireSpread::connectedTerrain( void ) const
{
    // Do not checkUpdate()!
    return( m_terrain );
}

//------------------------------------------------------------------------------
/*! \brief Access to the currently connected SurfaceFireWindInterface
    object address.

    \return Address of the currently connected SurfaceFireWindInterface object,
    or 0 if there is no attached object.
 */

Sem::SurfaceFireWindInterface* Sem::SurfaceFireSpread::connectedWind( void ) const
{
    // Do not checkUpdate()!
    return( m_wind );
}

//------------------------------------------------------------------------------
/*! \brief Connects a SurfaceFireFuelInterface object's valueChanged() signal
    to the fuelChanged() callback slot.
 */

void Sem::SurfaceFireSpread::connectFuel( Sem::SurfaceFireFuelInterface* fuel )
{
    if ( m_fuel != fuel )
    {
        disconnectFuel();
        if ( fuel )
        {
            connect( fuel, SIGNAL(valueChanged()),
                     this, SLOT(fuelChanged()) );
            connect( fuel, SIGNAL(destroyed()),
                     this, SLOT(fuelDestroyed()) );
        }
        m_fuel = fuel;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Connects a SurfaceFireTerrainInterface object's valueChanged() signal
    to the terrainChanged() callback slot.
 */

void Sem::SurfaceFireSpread::connectTerrain(
        Sem::SurfaceFireTerrainInterface* terrain )
{
    if ( m_terrain != terrain )
    {
        disconnectTerrain();
        if ( terrain )
        {
            connect( terrain, SIGNAL(valueChanged()),
                     this,    SLOT(terrainChanged()) );
            connect( terrain, SIGNAL(destroyed()),
                     this,    SLOT(terrainDestroyed()) );
        }
        m_terrain = terrain;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Connects a SurfaceFireWindInterface object's valueChanged() signal
    to the windChanged() callback slot.
 */

void Sem::SurfaceFireSpread::connectWind( Sem::SurfaceFireWindInterface* wind )
{
    if ( m_wind != wind )
    {
        disconnectWind();
        if ( wind )
        {
            connect( wind, SIGNAL(valueChanged()),
                     this, SLOT(windChanged()) );
            connect( wind, SIGNAL(destroyed()),
                     this, SLOT(windDestroyed()) );
        }
        m_wind = wind;
        setDirty();
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Disconnects any currently connected SurfaceFireFuelInterface object.

    \note This is also a callback slot connected to the currently attached
    SurfaceFireFuelInterface::destroyed() signals.
 */

void Sem::SurfaceFireSpread::disconnectFuel( void )
{
    if ( m_fuel )
    {
        disconnect( m_fuel, SIGNAL(valueChanged()),
                    this,   SLOT(fuelChanged()) );
        disconnect( m_fuel, SIGNAL(destroyed()),
                    this,   SLOT(fuelDestroyed()) );
        m_fuel = 0;
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Disconnects any currently connected SurfaceFireTerrainInterface object.

    \note This is also a callback slot connected to the currently attached
    SurfaceFireTerrainInterface::destroyed() signals.
 */

void Sem::SurfaceFireSpread::disconnectTerrain( void )
{
    if ( m_terrain )
    {
        disconnect( m_terrain, SIGNAL(valueChanged()),
                    this,      SLOT(terrainChanged()) );
        disconnect( m_terrain, SIGNAL(destroyed()),
                    this,      SLOT(terrainDestroyed()) );
        m_terrain = 0;
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Disconnects any currently connected SurfaceFireWindInterface object.

    \note This is also a slot callback connected to the currently attached
    SurfaceFireWindInterface::destroyed() signals.
 */

void Sem::SurfaceFireSpread::disconnectWind( void )
{
    if ( m_wind )
    {
        disconnect( m_wind, SIGNAL(valueChanged()),
                    this,   SLOT(windChanged()) );
        disconnect( m_wind, SIGNAL(destroyed()),
                    this,   SLOT(windDestroyed()) );
        m_wind = 0;
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire ellipse eccentricity.

    \return Surface fire ellipse eccentricity (dl).
 */

double Sem::SurfaceFireSpread::eccentricity( void ) const
{
    checkUpdate();
    return( m_eccentricity );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate effective wind speed
    (wind speed comparable to the actual combined wind and slope factors).

    \return Surface fire spread rate effective wind speed (ft/min).
 */

double Sem::SurfaceFireSpread::effectiveWindSpeed( void ) const
{
    checkUpdate();
    return( m_effWindSpeed );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread distance at the fire back
    at the specified or current elapsed time.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire spread distance at the back of the fire (ft).
 */

double Sem::SurfaceFireSpread::distanceAtBack( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( m_spreadRateAtBack * m_elapsedMinutes );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread distance
    at the current m_spreadDirectionAtCompass
    at the specified or current elapsed time.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire spread distance at the back of the fire (ft).
 */

double Sem::SurfaceFireSpread::distanceAtCompass( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( m_spreadRateAtCompass * m_elapsedMinutes );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread distance at the fire head
    at the specified or current elapsed time.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.
    \return Surface fire spread distance at the head of the fire (ft).
 */

double Sem::SurfaceFireSpread::distanceAtHead( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( m_spreadRateAtHead * m_elapsedMinutes );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire total area at the specified elapsed
    time since ignition.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire total area after the elapsed time (ac).
 */

double Sem::SurfaceFireSpread::fireAcres( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( Sem::SurfaceFireSpreadAlgorithm::fireAcres(
        fireLength(), fireWidth() ) );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire total area at the specified elapsed
    time since ignition.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire total area after the elapsed time (ft2).
 */

double Sem::SurfaceFireSpread::fireArea( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( Sem::SurfaceFireSpreadAlgorithm::fireArea(
        fireLength(), fireWidth() ) );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire total length at the specified elapsed
    time since ignition.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire total length after the elapsed time (ft).
 */

double Sem::SurfaceFireSpread::fireLength( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( ( m_spreadRateAtHead + m_spreadRateAtBack ) * m_elapsedMinutes );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fireline (Byram's) intensity
    at the fire back.

    \return Surface fire fireline intensity at the fire back (Btu/ft/s).
 */

double Sem::SurfaceFireSpread::firelineIntAtBack( void ) const
{
    checkUpdate();
    return( m_firelineIntAtBack );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fireline (Byram's) intensity
    at the current m_spreadDirectionAtCompass.

    \return Surface fire fireline intensity at the current compass direction
    (Btu/ft/s).
 */

double Sem::SurfaceFireSpread::firelineIntAtCompass( void ) const
{
    checkUpdate();
    return( m_firelineIntAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fireline (Byram's) intensity
    at the specified compass direction.

    \param[in] degreesClockwiseFromNorth Just what it says.

    \note This also updates the current m_spreadDirectionAtCompass.

    \return Surface fire fireline intensity at the current compass direction
    (Btu/ft/s).
 */

double Sem::SurfaceFireSpread::firelineIntAtCompass(
        double degreesClockwiseFromNorth ) const
{
    checkUpdate();
    updateCompassDirection( degreesClockwiseFromNorth );
    return( m_firelineIntAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fireline (Byram's) intensity
    at the fire head.

    \return Surface fire fireline intensity at the fire head (Btu/ft/s).
 */

double Sem::SurfaceFireSpread::firelineIntAtHead( void ) const
{
    checkUpdate();
    return( m_firelineIntAtHead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire perimeter total length
    at the specified elapsed time since ignition.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire perimeter total length after the elapsed time (ft).
 */

double Sem::SurfaceFireSpread::firePerimeter( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( Sem::SurfaceFireSpreadAlgorithm::firePerimeter(
        fireLength(), fireWidth() ) );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire ellipse maximum width
    at the specified elapsed time since ignition.

    \param[in] elapsedMinutes If greater than zero, the elapsed minutes since
        the fire ignition.
        If zero or omitted, then the last elapsed minutes is applied.

    \note If elapsedMinutes > 0, this also updates the current m_elapsedMinutes.

    \return Surface fire ellipse maximum width after the elapsed time (ft).
 */

double Sem::SurfaceFireSpread::fireWidth( double elapsedMinutes ) const
{
    checkUpdate();
    if ( elapsedMinutes > Smidgen )
    {
        m_elapsedMinutes = elapsedMinutes;
    }
    return( fireLength() / m_lengthToWidthRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire flame length at the fire back.

    \return Surface fire flame length at the fire back (ft).
 */

double Sem::SurfaceFireSpread::flameLengthAtBack( void ) const
{
    checkUpdate();
    return( m_flameLengthAtBack );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire flame length at the current
    m_spreadDirectionAtCompass.

    \return Surface fire flame length at the current compass direction (ft).
 */

double Sem::SurfaceFireSpread::flameLengthAtCompass( void ) const
{
    checkUpdate();
    return( m_flameLengthAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire flame length at the specified compass
    direction.

    \param[in] degreesClockwiseFromNorth Just what it says.

    \note This also updates the current m_spreadDirectionAtCompass.

    \return Surface fire flame length at the current compass direction (ft).
 */

double Sem::SurfaceFireSpread::flameLengthAtCompass(
        double degreesClockwiseFromNorth ) const
{
    checkUpdate();
    updateCompassDirection( degreesClockwiseFromNorth );
    return( m_flameLengthAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire flame length at the fire head.

    \return Surface fire flame length at the fire head (ft).
 */

double Sem::SurfaceFireSpread::flameLengthAtHead( void ) const
{
    checkUpdate();
    return( m_flameLengthAtHead );
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to
    SurfaceFireFuelInterface::valueChanged() signals.

    This is called anytime the currently connected SurfaceFireFuelInterface
    object emits a valueChanged() signal.
 */

void Sem::SurfaceFireSpread::fuelChanged( void )
{
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireFuelInterface::destroyed()
    signals.

    Note that the signal-slot connection is automatically disconnected
    when either the receiver or sender is destroyed, so we don't need to
    call disconnectFuel() here; merely set m_fuel to 0.
 */

void Sem::SurfaceFireSpread::fuelDestroyed( void )
{
    m_fuel = 0;
    //setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Initializes all mutable derived properties.
 */

void Sem::SurfaceFireSpread::init( void ) const
{
//std::cerr << "**** SurfaceFireSpread::init() called ***" << std::endl;
    m_eccentricity          = 0.0;
    m_effWindSpeed          = 0.0;
    m_elapsedMinutes        = 0.0;
    m_firelineIntAtBack     = 0.0;
    m_firelineIntAtCompass  = 0.0;
    m_firelineIntAtHead     = 0.0;
    m_flameLengthAtBack     = 0.0;
    m_flameLengthAtCompass  = 0.0;
    m_flameLengthAtHead     = 0.0;
    m_lengthToWidthRatio    = 1.0;
    m_phiEffWind            = 0.0;
    m_phiSlope              = 0.0;
    m_phiWind               = 0.0;
    m_scorchHeightAtBack    = 0.0;
    m_scorchHeightAtCompass = 0.0;
    m_scorchHeightAtHead    = 0.0;
    m_slopeK                = 0.0;
    m_spreadDirAtBack       = 180.;
    //m_spreadDirAtCompass    = 180.;  // Allow this to stay unchanged
    m_spreadDirAtHead       = 0.0;
    m_spreadRateAtBack      = 0.0;
    m_spreadRateAtCompass   = 0.0;
    m_spreadRateAtHead      = 0.0;
    m_windLimitExceeded     = false;
    m_windB                 = 0.0;
    m_windC                 = 0.0;
    m_windE                 = 0.0;
    m_windK                 = 0.0;
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire ellipse length-to-width ratio.

    \return Surface fire ellipse length-to-width ratio (dl).
 */

double Sem::SurfaceFireSpread::lengthToWidthRatio( void ) const
{
    checkUpdate();
    return( m_lengthToWidthRatio );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate effective wind factor
    (combined wind and slope factors).

    \return Surface fire spread rate effective wind speed factor (dl).
 */

double Sem::SurfaceFireSpread::phiEffectiveWind( void ) const
{
    checkUpdate();
    return( m_phiEffWind );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate slope factor.

    \return Surface fire spread rate slope factor (dl).
 */

double Sem::SurfaceFireSpread::phiSlope( void ) const
{
    checkUpdate();
    return( m_phiSlope );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate wind factor.

    \return Surface fire spread rate wind factor (dl).
 */

double Sem::SurfaceFireSpread::phiWind( void ) const
{
    checkUpdate();
    return( m_phiWind );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire scorch height at the fire back.

    \return Surface fire scorch height at the fire back (ft).
 */

double Sem::SurfaceFireSpread::scorchHeightAtBack( void ) const
{
    checkUpdate();
    return( m_scorchHeightAtBack );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire scorch height at the current
    m_spreadDirnAtCompass.

    \return Surface fire scorch height at the current compass direction (ft).
 */

double Sem::SurfaceFireSpread::scorchHeightAtCompass( void ) const
{
    checkUpdate();
    return( m_scorchHeightAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire scorch height at the specified compass
    direction.

    \param[in] degreesClockwiseFromNorth Just what it says.

    \note This also updates the current m_spreadDirnAtCompass.

    \return Surface fire scorch height at the current compass direction (ft).
 */

double Sem::SurfaceFireSpread::scorchHeightAtCompass(
        double degreesClockwiseFromNorth ) const
{
    checkUpdate();
    updateCompassDirection( degreesClockwiseFromNorth );
    return( m_scorchHeightAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire scorch height at the fire head.

    \return Surface fire scorch height at the fire head (ft).
 */

double Sem::SurfaceFireSpread::scorchHeightAtHead( void ) const
{
    checkUpdate();
    return( m_scorchHeightAtHead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire fuel bed slope parameter K.

    \return Surface fire fuel bed slope parameter K.
 */

double Sem::SurfaceFireSpread::slopeK( void ) const
{
    checkUpdate();
    return( m_slopeK );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread direction at the fire back.

    \return Surface fire spread direction at the fire back
    (degrees clockwise from north).
 */

double Sem::SurfaceFireSpread::spreadDirectionAtBack( void ) const
{
    checkUpdate();
    return( m_spreadDirAtBack );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current surface fire spread compass direction.

    \return Surface fire spread compass direction
    (degrees clockwise from north).
 */

double Sem::SurfaceFireSpread::spreadDirectionAtCompass( void ) const
{
    checkUpdate();
    return( m_spreadDirAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Updates the current surface fire spread compass direction.

    \param[in] degreesClockwiseFromNorth Just what it says.

    \return Surface fire spread compass direction
    (degrees clockwise from north).
 */

double Sem::SurfaceFireSpread::spreadDirectionAtCompass( 
        double degreesClockwiseFromNorth ) const
{
    checkUpdate();
    updateCompassDirection( degreesClockwiseFromNorth );
    return( m_spreadDirAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread direction at the fire head.

    \return Surface fire spread direction at the fire head
    (degrees clockwise from north).
 */

double Sem::SurfaceFireSpread::spreadDirectionAtHead( void ) const
{
    checkUpdate();
    return( m_spreadDirAtHead );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate at the current
    m_spreadDirAtCompass.

    \return Surface fire spread rate at the current compass direction (ft/min).
 */

double Sem::SurfaceFireSpread::spreadRateAtCompass( void ) const
{
    checkUpdate();
    return( m_spreadRateAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate at the specified compass
    direction.

    \param[in] degreesClockwiseFromNorth Just what it says.

    \note This also updates the current m_spreadDirAtCompass.

    \return Surface fire spread rate at the current compass direction (ft/min).
 */

double Sem::SurfaceFireSpread::spreadRateAtCompass(
        double degreesClockwiseFromNorth ) const
{
    checkUpdate();
    updateCompassDirection( degreesClockwiseFromNorth );
    return( m_spreadRateAtCompass );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate at the fire back.

    \return Surface fire spread rate at the fire back (ft/min).
 */

double Sem::SurfaceFireSpread::spreadRateAtBack( void ) const
{
    checkUpdate();
    return( m_spreadRateAtBack );
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire spread rate at the fire head.

    \return Surface fire spread rate at the fire head (ft/min).
 */

double Sem::SurfaceFireSpread::spreadRateAtHead( void ) const
{
    checkUpdate();
    return( m_spreadRateAtHead );
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireTerrain::valueChanged() signals.

    This is called anytime the currently connected SurfaceFireTerrain
    object emits a valueChanged() signal.
 */

void Sem::SurfaceFireSpread::terrainChanged( void )
{
//std::cerr << "SurfaceFireSpread::terrainChanged()\n";
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireTerrainInterface::destroyed()
    signals.

    Note that the signal-slot connection is automatically disconnected
    when either the receiver or sender is destroyed, so we don't need to
    call disconnectTerrain() here; merely set m_terrain to 0.
 */

void Sem::SurfaceFireSpread::terrainDestroyed( void )
{
    m_terrain = 0;
    //setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object properties up to date.

    \note Make sure NOT to call any member update methods on properties,
    such as "property()", as these then call checkUpdate(), resulting in an
    infinite loop!  Access member properties directly, as in "m_property".
 */

void Sem::SurfaceFireSpread::update( void ) const
{
//std::cerr << "SurfaceFireSpread::update()" << std::setprecision(15) << std::endl;
    if ( ! m_fuel )
    {
        Sem::Logger::Instance().send( 3,
            "Sem::SurfaceFireSpread::update() - no Sem::SurfaceFuelBed connected." );
        return;
    }
    if ( ! m_terrain )
    {
        Sem::Logger::Instance().send( 3,
            "Sem::SurfaceFireSpread::update() - no Sem::SurfaceFireTerrain connected." );
        return;
    }
    if ( ! m_wind )
    {
        Sem::Logger::Instance().send( 3,
            "Sem::SurfaceFireSpread::update() - no Sem::SurfaceFireWind connected." );
        return;
    }
    
    // Initialize all mutables
    init();

    // Ratio of actual to optimum fuel bed packing ratios
    double betaRatio = m_fuel->optimumPackingRatio() > Smidgen
                     ? m_fuel->packingRatio() / m_fuel->optimumPackingRatio()
                     : 0.0;
    double sigma = m_fuel->sigma();

    // Slope parameter K
    // Rothermel (1972) equation 80 (p 33) first two terms
    m_slopeK = Sem::SurfaceFireSpreadAlgorithm::slopeParameterK(
        m_fuel->packingRatio() );
//std::cerr << "m_slopeK=" << m_slopeK << std::endl;
    // Slope factor
    // Rothermel (1972) equation 47 and 79.
    m_phiSlope = Sem::SurfaceFireSpreadAlgorithm::slopeFactor(
        m_terrain->slopeFraction(), m_slopeK );
//std::cerr << "m_phiSlope=" << m_phiSlope << std::endl;
    // Wind parameter C
    // Rothermel (1972) equation 82 (p 33)
    m_windC = Sem::SurfaceFireSpreadAlgorithm::windParameterC( sigma );

    // Wind parameter B
    // Rothermel (1972) equation 83 (p 33)
    m_windB = Sem::SurfaceFireSpreadAlgorithm::windParameterB( sigma );

    // Wind parameter E
    // Rothermel (1972) equation 84 (p 33)
    m_windE = Sem::SurfaceFireSpreadAlgorithm::windParameterE( sigma );

    // Rothermel (1972) equation 79 (p 33) first and third terms
    // Since we already have C and E, its more efficient NOT to call
    // Sem::SurfaceFireSpreadAlgorithm::windParameterK(), which recalculates them.
    m_windK = m_windC * pow( betaRatio, -m_windE );

    // Wind coefficient
    // Rothermel (1972) equation 51 and 80.
    m_phiWind = Sem::SurfaceFireSpreadAlgorithm::windCoefficient(
        m_wind->fpm(), m_windB, m_windK );

    // Effective wind coefficient is the total of wind and slope coefficients
    m_phiEffWind = m_phiSlope + m_phiWind;

    // Determine fire head spread rate and direction
    // based on the following situations
    bool doEffWind, checkWindLimit;
    double ros0    = m_fuel->spreadRate();
//std::cerr << "ros0=" << m_fuel->spreadRate() << std::endl;
    double rxInt   = m_fuel->reactionIntensity();
    double upslope = m_terrain->upslopeCompass();
    double upwind  = m_wind->bearing();
    // Situation 1: no base fire spread
    if ( ros0 < Smidgen )
    {
        // Initialized values are fine (but we'll reset them here for clarity)
        m_spreadRateAtHead = 0.;
        m_spreadDirAtHead  = 0.;
        // There COULD BE an effective wind even if there is no fire.
        doEffWind          = true;
        // But since BEHAVE doesn't calculate effective wind speed when
        // there is no spread rate, we won't either.
        doEffWind          = false;
        // No spread, so no need to check the wind limit
        checkWindLimit     = false;
    }
    // Situation 2: no wind and no slope.
    else if ( ( m_phiSlope + m_phiWind ) < Smidgen )
    {
        m_spreadRateAtHead = ros0;
        m_spreadDirAtHead  = 0.;
        // No wind or slope, so no effective wind
        doEffWind          = false;
        // No wind or slope, so no need to check the wind limit
        checkWindLimit     = false;
    }
    // Situation 3: wind with no slope.
    else if ( m_phiSlope < Smidgen )
    { 
        m_spreadRateAtHead =
            Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( ros0, m_phiEffWind );
        m_spreadDirAtHead  = upwind;
        // No slope, so we already know what the effective wind speed
        m_effWindSpeed     = m_wind->fpm();
        doEffWind          = false;
        // Since there is an effective wind we must check its upper limit
        checkWindLimit     = true;
    }
    // Situation 4: slope with no wind.
    else if ( m_phiWind < Smidgen )
    {
        m_spreadRateAtHead = Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( ros0, m_phiEffWind );
        m_spreadDirAtHead  = upslope;
        // Since there is a slope so must calculate its effective wind
        doEffWind          = true;
        // Since there is an effective wind we must test its upper limit
        checkWindLimit     = true;
    }
    // Situation 5: wind blows upslope.
    else if ( fabs( upslope - upwind ) < Smidgen )
    {
        m_spreadRateAtHead =
            Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( ros0, m_phiEffWind );
        m_spreadDirAtHead  = upslope;
        // Since there is a slope, we must calculate its effective wind
        doEffWind          = true;
        // Since there is an effective wind we must test its upper limit
        checkWindLimit     = true;
    }
    // Situation 6: wind blows cross slope (this is the tough one)
    else
    {
        // Recalculate spread rate in the optimal direction
        m_spreadRateAtHead =
            Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum( ros0,
            upwind, upslope, m_phiWind, m_phiSlope, &m_spreadDirAtHead );
        // Recalculate effective wind coefficient in the optimal direction
        m_phiEffWind   = Sem::SurfaceFireSpreadAlgorithm::effectiveWindFactor(
            ros0, m_spreadRateAtHead );
        doEffWind      = ( m_phiEffWind > Smidgen ) ? true : false;
        checkWindLimit = true;
    }
    // If required, calculate effective wind speed based upon phiEffWind
    if ( doEffWind )
    {
        // Inverse of Rothermel (1972) equation 79 (p 33) first and third terms
        // Since we already have C and E, its more efficient NOT to call
        // Sem::SurfaceFireSpreadAlgorithm::windParameterX(),
        // which recalculates them.
        double windI = ( betaRatio > Smidgen && m_windC > Smidgen )
                     ? ( pow( betaRatio, m_windE ) / m_windC ) : 0.0 ;
        m_effWindSpeed = Sem::SurfaceFireSpreadAlgorithm::effectiveWindSpeed(
            m_phiEffWind, m_windB, windI );
    }
    // If effective wind exceeds maximum wind, scale back spread & phiEw.
    if ( checkWindLimit )
    {
        double maxWind =
            Sem::SurfaceFireSpreadAlgorithm::maximumReliableWindSpeed( rxInt );
        if ( m_effWindSpeed > maxWind )
        {
            m_phiEffWind = Sem::SurfaceFireSpreadAlgorithm::windCoefficient(
                maxWind, m_windB, m_windK );
            m_spreadRateAtHead =
                Sem::SurfaceFireSpreadAlgorithm::spreadRateMaximum(
                    ros0, m_phiEffWind );
            m_effWindSpeed      = maxWind;
            m_windLimitExceeded = true;
        }
    }
    // Determine fire ellipse parameters from the effective wind speed.
    m_lengthToWidthRatio =
        Sem::SurfaceFireSpreadAlgorithm::fireLengthToWidthRatio( m_effWindSpeed );
    m_eccentricity =
        Sem::SurfaceFireSpreadAlgorithm::eccentricity( m_lengthToWidthRatio );

    // Backing spread rate and direction.
    m_spreadRateAtBack = Sem::SurfaceFireSpreadAlgorithm::spreadRateAtBack(
        m_spreadRateAtHead, m_eccentricity );
    m_spreadDirAtBack = Sem::CompassAlgorithm::opposite( m_spreadDirAtHead );

    // Fireline intensity at head and back
    m_firelineIntAtBack = Sem::SurfaceFireSpreadAlgorithm::firelineIntensity(
        m_spreadRateAtBack, rxInt, m_fuel->residenceTime() );
    m_firelineIntAtHead = Sem::SurfaceFireSpreadAlgorithm::firelineIntensity(
        m_spreadRateAtHead, rxInt, m_fuel->residenceTime() );

    // Flame length at head and back
    m_flameLengthAtHead =
        Sem::SurfaceFireSpreadAlgorithm::flameLength( m_firelineIntAtHead );
    m_flameLengthAtBack =
        Sem::SurfaceFireSpreadAlgorithm::flameLength( m_firelineIntAtBack );

    // Scorch height at head and back
    m_scorchHeightAtHead = Sem::SurfaceFireSpreadAlgorithm::scorchHeight(
        m_firelineIntAtHead, m_wind->fpm() );
    m_scorchHeightAtBack = Sem::SurfaceFireSpreadAlgorithm::scorchHeight(
        m_firelineIntAtBack, m_wind->fpm() );

    // Fire behavior at arbitrary compass direction (0 degrees for now)
    updateCompassDirection( 0., true );
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the fire behavior in the specific compass direction held
    by m_spreadDirAtCompas().

    \note Make sure NOT to call any member update methods on properties,
    such as "property()", as these then call checkUpdate(), resulting in an
    infinite loop!  Access member properties directly, as in "m_property".
 */

void Sem::SurfaceFireSpread::updateCompassDirection(
        double degreesClockwiseFromNorth, bool force ) const
{
    double dir = Sem::CompassAlgorithm::constrain( degreesClockwiseFromNorth );
    if ( force || dir != m_spreadDirAtCompass )
    {
        m_spreadDirAtCompass = dir;

        m_spreadRateAtCompass =
            Sem::SurfaceFireSpreadAlgorithm::spreadRateAtCompass(
                degreesClockwiseFromNorth,
                m_spreadRateAtHead,
                m_spreadDirAtHead,
                m_eccentricity );

        m_firelineIntAtCompass =
            Sem::SurfaceFireSpreadAlgorithm::firelineIntensity(
                m_spreadRateAtCompass,
                m_fuel->reactionIntensity(),
                m_fuel->residenceTime() );

        m_flameLengthAtCompass =
            Sem::SurfaceFireSpreadAlgorithm::flameLength(
                m_firelineIntAtCompass );

        m_scorchHeightAtCompass =
            Sem::SurfaceFireSpreadAlgorithm::scorchHeight(
                m_firelineIntAtCompass,
                m_wind->fpm() );
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireWind::valueChanged() signals.

    This is called anytime the currently connected SurfaceFireWind
    object emits a valueChanged() signal.
 */

void Sem::SurfaceFireSpread::windChanged( void )
{
//std::cerr << "SurfaceFireSpread::windChanged()\n";
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Slot callback connected to SurfaceFireWindInterface::destroyed()
    signals.

    Note that the signal-slot connection is automatically disconnected
    when either the receiver or sender is destroyed, so we don't need to
    call disconnectWind() here; merely set m_wind to 0.
 */

void Sem::SurfaceFireSpread::windDestroyed( void )
{
    m_wind = 0;
    //setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the surface fire wind limit exceeded flag.

    \return TRUE if the surface fire maximum reliable wind limit is exceeded.
 */

bool Sem::SurfaceFireSpread::windLimitExceeded( void ) const
{
    checkUpdate();
    return( m_windLimitExceeded );
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireSpread objects.

    \param[in] lhs Left-hand-side SurfaceFireSpread object.
    \param[in] rhs Right-hand-side SurfaceFireSpread object.

    \return TRUE if equal, FALSE if not equal.
 */

bool Sem::operator ==( const Sem::SurfaceFireSpread &lhs,
        const Sem::SurfaceFireSpread &rhs )
{ 
    // If both have the exact same components, then they are equal
    if ( lhs.connectedFuel()    == rhs.connectedFuel()
      && lhs.connectedTerrain() == rhs.connectedTerrain()
      && lhs.connectedWind()    == rhs.connectedWind() )
    {
        return( true );
    }
    // If any component is missing, then they are not equal
    if ( (   lhs.connectedFuel()    && ! rhs.connectedFuel() )
      || ( ! lhs.connectedFuel()    &&   rhs.connectedFuel() )
      || (   lhs.connectedTerrain() && ! rhs.connectedTerrain() )
      || ( ! lhs.connectedTerrain() &&   rhs.connectedTerrain() )
      || (   lhs.connectedWind()    && ! rhs.connectedWind() )
      || ( ! lhs.connectedWind()    &&   rhs.connectedWind() ) )
    {
        return( false );
    }
    // Otherwise compare each non-zero component
    return( *(lhs.connectedFuel()) == *(rhs.connectedFuel())
         && *(lhs.connectedTerrain()) == *(rhs.connectedTerrain())
         && *(lhs.connectedWind()) == *(rhs.connectedWind()) );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireSpread objects.

    \param[in] lhs Left-hand-side SurfaceFireSpread object.
    \param[in] rhs Right-hand-side SurfaceFireSpread object.

    \return TRUE if not equal, FALSE if equal.
 */

bool Sem::operator !=( const Sem::SurfaceFireSpread &lhs,
        const Sem::SurfaceFireSpread &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireSpread.cpp
//------------------------------------------------------------------------------

