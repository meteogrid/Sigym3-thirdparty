//------------------------------------------------------------------------------
/*! \file Signal.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief Base class for implementing SEM object signal/slot and
    meta class communication.
    \par License
    This is released under the GNU Public License 2.
 */

#ifndef _SEMSIGNAL_H_INCLUDED_
#define _SEMSIGNAL_H_INCLUDED_

// Configuration
#include "config.h"

// Qt include files
#include <QDataStream>
#include <QObject>

// Standard header files

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class Signal Signal.h
    \brief Base class for implementing SEM object signal/slot and
    meta class communication.
 
    All objects that wish to emit or receive valueChanged() must
    inherit from this base class.
 */

class Signal : public QObject
{
// Enable signals, slots, and introspection
    Q_OBJECT

// Public interface
public:
    // Default constructor
    Signal( void ) ;
    // Custom constructor
    Signal( int classVersion ) ;
    // Copy constructor
    Signal( const Signal &right ) ;
    // Assignment operator
    const Signal& operator=( const Signal &right ) ;
    // Virtual destructor
    virtual ~Signal( void ) ;
    // Property access methods
    virtual const char *className( void ) const ;
    virtual int classVersion( void ) const ;

// Signals
signals:
    /*! \fn void valueChanged( void ) ;
        \brief Qt signal.
    */
    void valueChanged( void ) ;

// Protected interface
protected:
    // Referenced by all derived classes
    void checkUpdate( void ) const ;
    void setDirty( void ) ;
    void updateObject( void ) const ;

    // Serialization helpers
    bool readHeader( QDataStream& input ) ;
    bool readHeader( std::istream& input ) ;
    void writeHeader( std::ostream &output ) const ;
    void writeHeader( QDataStream& output ) const ;

    // Must be re-implemented by derived classes
    /*! \fn virtual void update( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
     */
    virtual void update( void ) const = 0;

// Protected properties
protected:
    int m_classVersion;     //!< Derived class version number
    mutable bool m_dirty;   //!< Signal input dirty flag.
};

// Equality operators
bool operator ==( const Signal & a, const Signal & b ) ;
bool operator !=( const Signal & a, const Signal & b ) ;

}   // End of namespace Sem

#endif

//------------------------------------------------------------------------------
//  End of Signal.h
//------------------------------------------------------------------------------

