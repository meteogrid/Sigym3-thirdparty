//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief All surface fuel algorithms are encapsulated in this static
    class of <i>pure functions</i>.
 */

#ifndef _SURFACEFIREFUELALGORITHM_H_INCLUDED_
#define _SURFACEFIREFUELALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireFuelAlgorithm SurfaceFireFuelAlgorithm.h
    \brief All surface fuel algorithms are encapsulated in this static
    class of <i>pure functions</i>.

    These functions are dependent only on fuel properties, and not on any
    environmental or terrain conditions.

    ANSI standard C89 implementation of all surface fuel equations and
    algorithms.  These can be used to create surface fire simulations from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
    
    Additional structure, state, and framework is provided by the
    SurfaceFireSpread, SurfaceFireFuelInterface, and SurfaceFireFuelModel
    classes, which require the QtCore library for signals/slots,
    multithreading, etc.
 */

class SurfaceFireFuelAlgorithm
{
// Public enums
public:

//------------------------------------------------------------------------------
/*! \enum ParticleCureAlgorithm
    \brief Indicates which curing algorithm is used to transfer fuel load
    between dead and live classes for a SurfaceFuelParticle.
 */

enum ParticleCureAlgorithm
{
    CureNone  = 0,  //!< No live-to-dead fuel load transfer
    CureHerb1 = 1   //!< Simple herb live-to-dead load transfer based on live herb moisture content
};

//------------------------------------------------------------------------------
/*! \enum SurfaceFireAreaWtgClass
    \brief Surface fire fuel particle surface area weighting class

    Surface area weighting size class is determined from the following table:
    <table>
    <tr><td>Wtg<br>Class</td><td>SAVR<br>(ft<sup>2</sup>/ft<sup>3</sup>)</td><td>Diameter<br>(in)</td></tr>
    <tr><td>0</td><td>>= 1200</td><td></td><= 0.04</tr>
    <tr><td>1</td><td>>= 192</td><td><= 0.25</td></tr>
    <tr><td>2</td><td>>= 98</td><td><= 0.50</td></tr>
    <tr><td>3</td><td>>= 48</td><td><= 1.00</td></tr>
    <tr><td>4</td><td>>= 16</td><td><= 3.00</td></tr>
    <tr><td>5</td><td>>= 0</td><td>Over 3.00</td></tr>
    </table>
 */
enum SurfaceFireAreaWtgClass
{
    AreaWtgClass1200Plus = 0,
    AreaWtgClass192_1200 = 1,
    AreaWtgClass96_192   = 2,
    AreaWtgClass48_96    = 3,
    AreaWtgClass16_48    = 4,
    AreaWtgClass0_16     = 5
};
static const int SurfaceFireAreaWtgClasses = 6; //!< Number of SurfaceFireAreaWTgCLass enums

//------------------------------------------------------------------------------
/*! \enum SurfaceFireMoistureClass
    \brief Surface fire fuel moisture classes.
 */
enum SurfaceFireMoistureClass
{
    MoistureDead1h    = 0,
    MoistureDead10h   = 1,
    MoistureDead100h  = 2,
    MoistureDead1000h = 3,
    MoistureLiveHerb  = 4,
    MoistureLiveWood  = 5
};
static const int SurfaceFireMoistureClasses = 6;    //!< Number of SurfaceFireMoistureClass enums

// Public interface
public:
    static double bulkDensity( double load, double depth ) ;
    static double cureHerb1( double herbMc ) ;
    static SurfaceFireMoistureClass deadTimeLagClass( double savr ) ;
    static double diameter( double savr ) ;
    static double effectiveHeatingNumber( double savr ) ;
    static double fineFuelDead( double load, double ehn ) ;
    static double fineFuelLive( double load, double savr ) ;
    static double heatOfPreIgnition( double moisture ) ;
    static double heatPerUnitArea( double rxInt, double tauR ) ;
    static double heatSink( double q_ig, double bulkDensity ) ;
    static double liveFuelExtinctionMoisture( double deadEffLoad,
                    double liveEffLoad, double fineDeadMois, double deadMext ) ;
    static double maximumReactionVelocity( double sigma ) ;
    static double mineralDampingCoefficient( double seff ) ;
    static double moistureDampingCoefficient( double mois, double mext ) ;
    static double netLoad( double load, double totalSi ) ;
    static double noWindNoSlopeSpreadRate( double rxInt, double propFlux,
                    double heatSink ) ;
    static double optimumPackingRatio( double sigma ) ;
    static double optimumReactionVelocity( double gammaMax, double sigma,
                    double beta, double betaOpt ) ;
    static double propagatingFluxRatio( double sigma, double beta ) ;
    static double residenceTime( double sigma ) ;
    static double surfaceArea( double savr, double load, double rho ) ;
    static double surfaceAreaToVolumeRatio( double diam ) ;
    static double surfaceAreaWtgFactor( double particleArea, double lifeArea ) ;
    static SurfaceFireAreaWtgClass surfaceAreaWtgSizeClass( double savr ) ;
    static double volume( double savr, double area ) ;
    static double windAdjustmentFactor( double canopyCover, double canopyHt,
        double crownRatio, double fuelDepth ) ;
};

}   // End of namespace Sem

#endif  // _SURFACEFIREFUELALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelAlgorithm.h
//------------------------------------------------------------------------------

