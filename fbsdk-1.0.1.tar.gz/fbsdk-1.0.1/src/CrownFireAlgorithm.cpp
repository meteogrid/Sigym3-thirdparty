//------------------------------------------------------------------------------
/*! \file CrownFireAlgorithm.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All crown fire algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

// Custom header files
#include "CrownFireAlgorithm.h"
#include "SurfaceFireFuelModelFactory.h"
#include "SurfaceFireMoistureTimeLag.h"
#include "SurfaceFireSpread.h"
#include "SurfaceFireSpreadAlgorithm.h"
#include "SurfaceFireTerrain.h"
#include "SurfaceFireWind.h"

// Standard headers
#include <cmath>

//------------------------------------------------------------------------------
/*! \brief Calculates the crown fire active ratio.
  
    \param crownSpreadRate      Crown fire spread rate (ft/min).
    \param criticalSpreadRate   Critical crown fire spread rate (ft/min).
  
    \return Crown fire active ratio.
 */

double Sem::CrownFireAlgorithm::activeRatio(
        double crownSpreadRate,
        double criticalSpreadRate )
{
    return( ( criticalSpreadRate < Smidgen )
          ? ( 0.00 )
          : ( crownSpreadRate / criticalSpreadRate ) );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the critical crown fire spread rate to achieve active
    crowning.
  
    \param canopyBulkDensity    Canopy crown bulk density (lb/ft3).
  
    \return Critical crown fire spread rate (ft/min).
 */

double Sem::CrownFireAlgorithm::criticalCrownFireSpreadRate(
        double canopyBulkDensity )
{
    double cbd = 16.0185 * canopyBulkDensity;       // Convert to Kg/m3
    double ros = ( cbd < Smidgen ) ? 0.00 : ( 3.0 / cbd );
    return( 3.28084 * ros );                        // Convert to ft/min
}

//------------------------------------------------------------------------------
/*! \brief Calculates the critical surface fireline intensity
    for a surface fire to transition to a crown fire.
  
    \param foliarMoisture   Tree foliar moisture content (lb water/lb foliage).
    \param crownBaseHt      Tree crown base height (ft).
  
    \return Critical surface fireline intensity (Btu/ft/s).
 */

double Sem::CrownFireAlgorithm::criticalSurfaceFirelineIntensity(
        double foliarMoisture,
        double crownBaseHt )
{
    // Convert foliar moisture content to percent and constrain lower limit
    double fmc = 100. * foliarMoisture;
    fmc = ( fmc < 30.0 ) ? 30. : fmc;
    // Convert crown base ht to meters and constrain lower limit
    double cbh = 0.3048 * crownBaseHt;
    cbh = ( cbh < 0.1 ) ? 0.1 : cbh;
    // Critical surface fireline intensity (kW/m)
    double csfi =pow( (0.010 * cbh * ( 450. + 25.9 * fmc ) ), 1.5 );
    // Return as Btu/ft/s
    return ( 0.288672 * csfi );
}

//------------------------------------------------------------------------------
/*! \brief Reverse calculates the critical surface fire intensity for a
    surface fire to transition to a crown fire given the critical flame length.
  
    \param criticalFlameLength Critical surface fire flame length (ft).
  
    \return Critical surface fire intensity (Btu/ft/s).
 */

double Sem::CrownFireAlgorithm::criticalSurfaceFireIntensity(
        double criticalFlameLength )
{
    return( Sem::SurfaceFireSpreadAlgorithm::firelineIntensity(
        criticalFlameLength ) );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the critical surface fire flame length for a surface fire
   to transition to a crown fire given the critical fireline intensity.
 
   \param criticalFireInt Critical surface fireline intensity (Btu/ft/s).
 
   \return Critical surface fire flame length (ft).
 */

double Sem::CrownFireAlgorithm::criticalSurfaceFlameLength(
        double criticalFireInt )
{
    return( Sem::SurfaceFireSpreadAlgorithm::flameLength( criticalFireInt ) );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the crown fire spread rate.
  
    This uses \ref rothermel1991 crown fire correlation.
  
    \param windSpeedAt20Ft   Wind speed at 20 ft above the canopy (mi/h).
    \param dead1h       Dead 1-h fuel moisture content (lb water/lb fuel).
    \param dead10h      Dead 10-h fuel moisture content (lb water/lb fuel).
    \param dead100h     Dead 100-h fuel moisture content (lb water/lb fuel).
    \param liveWood     Live wood fuel moisture content (lb water/lb fuel).
  
    \return Crown fire average spread rate (ft/min).
 */

double Sem::CrownFireAlgorithm::crownFireSpreadRate(
        double windSpeedAt20Ft,
        double dead1h,
        double dead10h,
        double dead100h,
        double liveWood )
{
    // Adjust the wind speed
    double windSpeedAtMidflame = 0.4 * windSpeedAt20Ft;

    // Create fuel model 10 with the supplied moisture contents and wind
    Sem::SurfaceFireMoistureTimeLag* moisture =
        new Sem::SurfaceFireMoistureTimeLag( dead1h, dead10h, dead100h,
            dead100h, liveWood, liveWood );
    Sem::SurfaceFireFuelModel* fuel = Sem::createFuelModel( 10, moisture );
    Sem::SurfaceFireWind* wind = new Sem::SurfaceFireWind( windSpeedAtMidflame, 0. );
    Sem::SurfaceFireTerrain* terrain = new Sem::SurfaceFireTerrain( 0., 0. );
    Sem::SurfaceFireSpread* fire = new Sem::SurfaceFireSpread(
        fuel, terrain, wind );

    // Determine spread rate per \ref rothermel1991
    double crownRos = 3.34 * fire->spreadRateAtHead();

    // Release resource and return crown spread rate
    delete fire;
    delete fuel;
    delete wind;
    delete terrain;
    delete moisture;
    return( crownRos );
}

//------------------------------------------------------------------------------
/*! \brief Calculates the crown fire transition ratio.
  
    \param surfaceFireInt   Surface fireline intensity (Btu/ft/s).
    \param criticalFireInt  Critical crown fire fireline intensity (Btu/ft/s).
  
    \return Transition ratio.
 */

double Sem::CrownFireAlgorithm::transitionRatio(
        double surfaceFireInt,
        double criticalFireInt )
{
    return( ( criticalFireInt < Smidgen )
          ? ( 0.00 )
          : ( surfaceFireInt / criticalFireInt ) );
}

//------------------------------------------------------------------------------
//  End of CrownFireAlgorithm.cpp
//------------------------------------------------------------------------------

