//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelModelFactory.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Factory for the 13 original standard fire behavior fuel models
    as defined by Albini (1976) and 40 extended fuel models defined by
    Scott and Burgan (2005).
 */

#ifndef _SURFACEFIREFUELMODELFACTORY_H_INCLUDED_
#define _SURFACEFIREFUELMODELFACTORY_H_INCLUDED_

// Custom headers
#include "config.h"
#include "SurfaceFireFuelModel.h"

// Qt include files
#include <QString>

namespace Sem
{
    // Forward class declarations
    class SurfaceFireFuelModel;
    class SurfaceFireMoistureInterface;

    // These the two main factory methods
    Sem::SurfaceFireFuelModel* createFuelModel(
        int id, SurfaceFireMoistureInterface* moisture=0 ) ;
    Sem::SurfaceFireFuelModel* createFuelModel(
        const QString& name, SurfaceFireMoistureInterface* moisture=0 ) ;

    // Methods called by the two main factory methods
    Sem::SurfaceFireFuelModel* createFuelModel001( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel002( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel003( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel004( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel005( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel006( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel007( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel008( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel009( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel010( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel011( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel012( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel013( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel101( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel102( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel103( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel104( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel105( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel106( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel107( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel108( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel109( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel121( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel122( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel123( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel124( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel141( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel142( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel143( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel144( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel145( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel146( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel147( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel148( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel149( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel161( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel162( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel163( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel164( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel165( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel181( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel182( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel183( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel184( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel185( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel186( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel187( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel188( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel189( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel201( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel202( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel203( void ) ;
    Sem::SurfaceFireFuelModel* createFuelModel204( void ) ;

    // This is the actual factory called by the above methods
    Sem::SurfaceFireFuelModel* createSurfaceFireFuelModel( int id,
        const QString& name, const QString& desc, double mextDead ) ;
}   // End of namespace Sem

#endif  // _SURFACEFIREFUELMODELFACTORY_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelModelFactory.h
//------------------------------------------------------------------------------
