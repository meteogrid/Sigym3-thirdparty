//------------------------------------------------------------------------------
/*! \file SurfaceFireMoistureTimeLag.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireMoistureInterface for
    accessing and updating fuel particle moisture contents
    at a specific location and time.
 */

// Custom header files
#include "Logger.h"
#include "SurfaceFireMoistureTimeLag.h"

// Standard headers
#include <cmath>
#include <iostream>

// Non-integral static data members must be initialized outside the class
const double Sem::SurfaceFireMoistureTimeLag::moisDeadMin = 0.01;
const double Sem::SurfaceFireMoistureTimeLag::moisDeadMax = 1.00;
const double Sem::SurfaceFireMoistureTimeLag::moisLiveMin = 0.30;
const double Sem::SurfaceFireMoistureTimeLag::moisLiveMax = 5.00;

//------------------------------------------------------------------------------
/*! \brief Default constructor.
 */

Sem::SurfaceFireMoistureTimeLag::SurfaceFireMoistureTimeLag( void ) :
    SurfaceFireMoistureInterface(),
    m_dead1h( 0.10 ),
    m_dead10h( 0.10 ),
    m_dead100h( 0.10 ),
    m_dead1000h( 0.10 ),
    m_liveHerb( 3.0 ),
    m_liveWood( 3.0 )
{
    init();
    m_classVersion = surfaceFireTimeLagVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Custom constructor.

    \param[in] dead1h 1-h dead time lag fuel moisture (fraction oven-dry weight)
    \param[in] dead10h 10-h dead time lag fuel moisture (fraction oven-dry weight)
    \param[in] dead100h 100-h dead time lag fuel moisture (fraction oven-dry weight)
    \param[in] dead1000h 1000-h dead time lag fuel moisture (fraction oven-dry weight)
    \param[in] liveHerb Live herbaceous fuel moisture (fraction oven-dry weight)
    \param[in] liveWood Live woody fuel moisture (fraction oven-dry weight)
 */

Sem::SurfaceFireMoistureTimeLag::SurfaceFireMoistureTimeLag(
        double dead1h, double dead10h, double dead100h, double dead1000h,
        double liveHerb, double liveWood ) :
    SurfaceFireMoistureInterface(),
    m_dead1h( dead1h ),
    m_dead10h( dead10h ),
    m_dead100h( dead100h ),
    m_dead1000h( dead1000h ),
    m_liveHerb( liveHerb ),
    m_liveWood( liveWood )
{
    assert( dead1h > moisDeadMin && dead1h < moisDeadMax );
    assert( dead10h > moisDeadMin && dead10h < moisDeadMax );
    assert( dead100h > moisDeadMin && dead100h < moisDeadMax );
    assert( dead1000h > moisDeadMin && dead1000h < moisDeadMax );
    assert( liveHerb > moisLiveMin && liveHerb < moisLiveMax );
    assert( liveWood > moisLiveMin && liveWood < moisLiveMax );
    init();
    m_classVersion = surfaceFireTimeLagVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
    Because this is a QObject, the destroyed() signal always gets sent out.
 */

Sem::SurfaceFireMoistureTimeLag::~SurfaceFireMoistureTimeLag()
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireMoistureTimeLag copy constructor.

    \param[in] right Reference to the SurfaceFireMoistureTimeLag
    from which to copy.

    \return Reference to the newly allocated SurfaceFireMoistureTimeLag.
 */

Sem::SurfaceFireMoistureTimeLag::SurfaceFireMoistureTimeLag(
        const SurfaceFireMoistureTimeLag &right ) :
    SurfaceFireMoistureInterface()
{
    init();
    m_classVersion = right.m_classVersion;
    m_dead1h       = right.m_dead1h;
    m_dead10h      = right.m_dead10h;
    m_dead100h     = right.m_dead100h;
    m_dead1000h    = right.m_dead1000h;
    m_liveHerb     = right.m_liveHerb;
    m_liveWood     = right.m_liveWood;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireMoistureTimeLag assignment operator.

    \param[in] right Reference to the SurfaceFireMoistureTimeLag
    from which to assign.

    \return Reference to the newly assigned SurfaceFireMoistureTimeLag.
 */

const Sem::SurfaceFireMoistureTimeLag&
    Sem::SurfaceFireMoistureTimeLag::operator=(
        const SurfaceFireMoistureTimeLag &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion = right.m_classVersion;
        m_dead1h       = right.m_dead1h;
        m_dead10h      = right.m_dead10h;
        m_dead100h     = right.m_dead100h;
        m_dead1000h    = right.m_dead1000h;
        m_liveHerb     = right.m_liveHerb;
        m_liveWood     = right.m_liveWood;
        setDirty();
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.

    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireMoistureTimeLag::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.

    \return Current class version.
 */

int Sem::SurfaceFireMoistureTimeLag::classVersion( void ) const
{
    return( surfaceFireTimeLagVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the 1-h dead fuel moisture content.

    \return Dead 1-h time lag fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::dead1h( void ) const
{
    checkUpdate();
    return( m_dead1h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the 10-h dead fuel moisture content.

    \return Dead 10-h time lag fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::dead10h( void ) const
{
    checkUpdate();
    return( m_dead10h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the 100-h dead fuel moisture content.

    \return Dead 100-h time lag fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::dead100h( void ) const
{
    checkUpdate();
    return( m_dead100h );
}

//------------------------------------------------------------------------------
/*! \brief Access to the 1000-h dead fuel moisture content.

    \return Dead 1000-h time lag fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::dead1000h( void ) const
{
    checkUpdate();
    return( m_dead1000h );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SurfaceFireMoistureTimeLag::init( void ) const
{
    // There are no intermediates to initialize for this class
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the live herbaceous fuel moisture content.

    \return Live herbaceous fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::liveHerb( void ) const
{
    checkUpdate();
    return( m_liveHerb );
}

//------------------------------------------------------------------------------
/*! \brief Access to the live woody fuel moisture content.

    \return Live woody fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::liveWood( void ) const
{
    checkUpdate();
    return( m_liveWood );
}

//------------------------------------------------------------------------------
/*! \brief Access to one of the moisture properties.

    \param[in] type One of the Sem::SurfaceFireMoistureClass enum values.

    \return Requested fuel moisture content (fraction oven-dry weight).
 */

double Sem::SurfaceFireMoistureTimeLag::moisture(
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass type ) const
{
    checkUpdate();
    if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureDead1h )
    {
        return( dead1h() );
    }
    else if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureDead10h )
    {
        return( dead10h() );
    }
    else if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureDead100h )
    {
        return( dead100h() );
    }
    else if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureDead1000h )
    {
        return( dead1000h() );
    }
    else if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb )
    {
        return( liveHerb() );
    }
    else if ( type == Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood )
    {
        return( liveWood() );
    }
    return( dead1h() );
}

//------------------------------------------------------------------------------
/*! \brief Updates the 1-h dead fuel moisture content.

    \param[in] fractionOdw Dead 1-h time lag fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setDead1h( double fractionOdw )
{
    assert( fractionOdw > moisDeadMin && fractionOdw < moisDeadMax );
    if ( fractionOdw != m_dead1h )
    {
        m_dead1h = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the 10-h dead fuel moisture content.

    \param[in] fractionOdw Dead 10-h time lag fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setDead10h( double fractionOdw )
{
    assert( fractionOdw > moisDeadMin && fractionOdw < moisDeadMax );
    if ( fractionOdw != m_dead10h )
    {
        m_dead10h = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the 100-h dead fuel moisture content.

    \param[in] fractionOdw Dead 100-h time lag fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setDead100h( double fractionOdw )
{
    assert( fractionOdw > moisDeadMin && fractionOdw < moisDeadMax );
    if ( fractionOdw != m_dead100h )
    {
        m_dead100h = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the 1000-h dead fuel moisture content.

    \param[in] fractionOdw Dead 1000-h time lag fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setDead1000h( double fractionOdw )
{
    assert( fractionOdw > moisDeadMin && fractionOdw < moisDeadMax );
    if ( fractionOdw != m_dead1000h )
    {
        m_dead1000h = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the live herbaceous fuel moisture content.

    \param[in] fractionOdw Live herbaceous fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setLiveHerb( double fractionOdw )
{
    assert( fractionOdw > moisLiveMin && fractionOdw < moisLiveMax );
    if ( fractionOdw != m_liveHerb )
    {
        m_liveHerb = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the live woody fuel moisture content.

    \param[in] fractionOdw Live woody fuel moisture content (fraction oven-dry weight).
 */

void Sem::SurfaceFireMoistureTimeLag::setLiveWood( double fractionOdw )
{
    assert( fractionOdw > moisLiveMin && fractionOdw < moisLiveMax );
    if ( fractionOdw != m_liveWood )
    {
        m_liveWood = fractionOdw;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access methods to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SurfaceFireMoistureTimeLag::update( void ) const
{
    // Do whatever here to bring object properties current
    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireMoistureTimeLag objects.

    \param[in] lhs Left-hand-side SurfaceFireMoistureTimeLag object.
    \param[in] rhs Right-hand-side SurfaceFireMoistureTimeLag object.
 */
bool Sem::operator ==( const Sem::SurfaceFireMoistureTimeLag &lhs,
                       const Sem::SurfaceFireMoistureTimeLag &rhs )
{ 
  return( ( fabs( lhs.dead1h()    - rhs.dead1h() )    < 0.00001 )
       && ( fabs( lhs.dead10h()   - rhs.dead10h() )   < 0.00001 )
       && ( fabs( lhs.dead100h()  - rhs.dead100h() )  < 0.00001 )
       && ( fabs( lhs.dead1000h() - rhs.dead1000h() ) < 0.00001 )
       && ( fabs( lhs.liveHerb()  - rhs.liveHerb() )  < 0.00001 )
       && ( fabs( lhs.liveWood()  - rhs.liveWood() )  < 0.00001 )
    );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireMoistureTimeLag objects.

    \param[in] lhs Left-hand-side SurfaceFireMoistureTimeLag object.
    \param[in] rhs Right-hand-side SurfaceFireMoistureTimeLag object.
 */
bool Sem::operator !=( const Sem::SurfaceFireMoistureTimeLag &lhs,
                       const Sem::SurfaceFireMoistureTimeLag &rhs )
{ 
  return( ! ( lhs == rhs ) );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireMoistureTimeLag.cpp
//------------------------------------------------------------------------------

