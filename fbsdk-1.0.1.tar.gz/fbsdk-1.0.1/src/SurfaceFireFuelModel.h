//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelModel.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A derivation of SurfaceFireFuel with added support for model
    name, id, and description.
 */

#ifndef _SURFACEFIREFUELMODEL_H_INCLUDED_
#define _SURFACEFIREFUELMODEL_H_INCLUDED_

// Custom headers
#include "config.h"
#include "SurfaceFireFuel.h"
#include "SurfaceFireFuelAlgorithm.h"
#include "SurfaceFireMoistureInterface.h"

// Qt include files
#include <QString>
#include <QVector>

namespace Sem
{

// Forward class references
class SurfaceFireParticle;

//------------------------------------------------------------------------------
/*! \class SurfaceFireFuelModel SurfaceFireFuelModel.h
    \brief A derivation of SurfaceFireFuel with added support for model
    name, id, and description.
 */

class SurfaceFireFuelModel : public SurfaceFireFuel
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireFuelModelVersion = 1;   //!< Class version

// Public interface
public:
    // Default constructor
    SurfaceFireFuelModel( void ) ;
    // Custom constructors
    SurfaceFireFuelModel( int id, const QString& name, const QString& desc,
        double mextDead ) ;
    // Virtual destructor
    virtual ~SurfaceFireFuelModel( void ) ;
    // Copy constructor
    SurfaceFireFuelModel( const SurfaceFireFuelModel & ) ;
    // Assignment operator
    const SurfaceFireFuelModel &operator=( const SurfaceFireFuelModel &rhs ) ;

    // Property access methods
    virtual const char *className( void ) const ;
    virtual int classVersion( void ) const ;
    QString description( void ) const;
    int     id( void ) const;
    QString name( void ) const;

    // Property update methods
    void addParticleNew(
        double surfaceAreaToVolumeRatio,
        Sem::SurfaceFireFuelAlgorithm::SurfaceFireMoistureClass moistureClass,
        Sem::SurfaceFireFuelAlgorithm::ParticleCureAlgorithm cureAlgorithm=Sem::SurfaceFireFuelAlgorithm::CureNone,
        double height=1.0,
        double load=0.0,
        double moisDead=0.10,
        double moisLive=3.00,
        double heat=8000.,
        double density=32.0,
        double totalSi=0.0555,
        double effectiveSi=0.01 ) ;

// Private properties
protected:
    QString m_desc; //!< Fuel model description
    int     m_id;   //!< Fuel model id number (used by FARSITE).
    QString m_name; //!< Fuel model short name
};

// Non-member equality operators
bool operator ==( const SurfaceFireFuelModel & a, const SurfaceFireFuelModel & b ) ;
bool operator !=( const SurfaceFireFuelModel & a, const SurfaceFireFuelModel & b ) ;

}   // End of namespace Sem

#endif  // _SURFACEFIREFUELMODEL_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFuelModel.h
//------------------------------------------------------------------------------

