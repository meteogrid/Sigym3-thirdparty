//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelInterface.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief An abstract base class defining an interface to provide fuel bed
    information required by the classic Rothermel/Albini (BEHAVE/BehavePlus)
    algorithms.
 */

#ifndef _SURFACEFIREFUELINTERFACE_H_INCLUDED_
#define _SURFACEFIREFUELINTERFACE_H_INCLUDED_

// Custom include files
#include "Signal.h"

namespace Sem
{

//------------------------------------------------------------------------------
/*! \class SurfaceFireFuelInterface SurfaceFireFuelInterface.h
    \brief An abstract base class defining an interface to provide fuel bed
    information required by the classic Rothermel/Albini (BEHAVE/BehavePlus)
    algorithms.

    The SurfaceFireSpread class implements the elliptical fire spread
    algorithms of BEHAVE/BehavePlus.
    While these algorithms have historically been tied to the entire
    "Rothermel spread model", in fact the elliptical spread algorithms only
    require the following information about the fuel bed in which it spreads:
    - characteristic surface area-to-volume ratio, aka 'sigma' (ft2/ft3),
    - fuel bed packing ratio, aka 'beta' (ft3 fuel per ft3 fuel bed),
    - optimum fuel bed packing ratio, aka 'betaOpt' (ft3 fuel / ft3 fue bed),
    - no-wind, no-slope fire spread rate (ft/min),
    - fire reaction intensity (Btu/ft2/min), and
    - fire residence time (min).

    Additional site information required by SurfaceFireSpread is:
    - slope steepness (rise/reach),
    - aspect (downslope direction, degrees clockwise from north),
    - wind speed at midflame height (ft/min), and
    - wind direction (wind source, degrees clockwise from north).

    The SurfaceFireFuel class included in the FBSDK package is an implementation
    of the SurfaceFireFuelInterface using the traditional Rothermel fire model
    algorithms with additional methods for accessing intermediate variables
    and debugging.
    Other implementations, however, could also be derived from
    SurfaceFireFuelInterface and plugged into SurfaceFireFuel instead.
    Such alternate implementations may provide better optimization or
    alternative algorithms, for example.

    The SurfaceFireFuel class is derived from SurfaceFireFuelInterface and
    implements the classic BEHAVE/BehavePlus algorithms.
 */

class SurfaceFireFuelInterface : public Signal
{
// Enable signal, slots, introspection
    Q_OBJECT
// Class version
    static const int surfaceFireFuelInterfaceVersion = 1;   //!< Class version

// Public interface
public:
    /*! \brief Virtual destructor implemented here
     */
    virtual ~SurfaceFireFuelInterface( void ) {}

    // Property access methods
    const char* className( void ) const { return( metaObject()->className() ); }
    int classVersion( void ) const { return ( surfaceFireFuelInterfaceVersion ); }

    /*! \fn virtual double optimumPackingRatio( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed optimum packing ratio (dl).
    */
    virtual double optimumPackingRatio( void ) const = 0 ;

    /*! \fn virtual double packingRatio( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed packing ratio (dl).
    */
    virtual double packingRatio( void ) const = 0 ;

    /*! \fn virtual double reactionIntensity( void ) const = 0;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed reaction intensity (Btu/ft<sup>2</sup>/min).
    */
    virtual double reactionIntensity( void ) const = 0;

    /*! \fn virtual double residenceTime( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed fire residence time (min).
    */
    virtual double residenceTime( void ) const = 0 ;

    /*! \fn virtual double sigma( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed characteristic surface area to volume ratio
        (ft<sup>2</sup>/ft<sup>3</sup>).
    */
    virtual double sigma( void ) const = 0 ;

    /*! \fn virtual double spreadRate( void ) const = 0 ;
        \brief Abstract virtual function that must be re-implemented by
        derived classes.
        \return Surface fuel bed no-wind, no-slope fire spread rate (ft/min).
    */
    virtual double spreadRate( void ) const = 0 ;
};

}   // End of namespace Sem

#endif  // _SURFACEFIREFUELINTERFACE_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelInterface.h
//------------------------------------------------------------------------------

