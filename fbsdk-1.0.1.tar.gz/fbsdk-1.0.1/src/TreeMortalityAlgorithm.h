//------------------------------------------------------------------------------
/*! \file TreeMortalityAlgorithm.h
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This code is released under the GNU Public License 2.
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.
 */

#ifndef _TREEMORTALITYALGORITHM_H_INCLUDED_
#define _TREEMORTALITYALGORITHM_H_INCLUDED_

// Configuration
#include "config.h"
#include "FofemTreeSpecies.h"
namespace Sem
{

//------------------------------------------------------------------------------
/*! \class TreeMortalityAlgorithm TreeMortalityAlgorithm.h
    \brief All fire ignition algorithms are encapsulated
    in this static class of <i>pure functions</i>.

    ANSI standard C89 implementation of all fire ignition equations and
    algorithms.  These can be used to estimate ignition probabilities from
    scratch without linking to additional libraries, but you have to provide
    your own state structures/classes.
 */

class TreeMortalityAlgorithm
{
// Public enums
public:

//------------------------------------------------------------------------------
/*! \enum BehaveBarkSpecies
    \brief Indicates the type of tree species for BEHAVE-style bark thickness
    estimation.
 */

enum BehaveBarkSpecies
{
    BehaveBarkDouglasFir      = 0,  // 0 Douglas-fir (BEHAVE code 1)
    BehaveBarkWesternLarch    = 1,  // 1 western larch (BEHAVE code 1)
    BehaveBarkWesternHemlock  = 2,  // 2 western hemlock (BEHAVE code 2)
    BehaveBarkEngelmannSpruce = 3,  // 3 Engelmann spruce (BEHAVE code 3)
    BehaveBarkWesternRedCedar = 4,  // 4 western red cedar (BEHAVE code 3)
    BehaveBarkSubalpineFir    = 5,  // 5 subalpine fir (BEHAVE code 4)
    BehaveBarkLodgepolePine   = 6   // 6 lodgepole pine (BEHAVE code 4)
};
const static int BehaveBarkSpeciesEnums = 7;    //!< Number of BehaveBarkSpecies enums

// Public interface
public:

    static double treeBarkThicknessBehave(
        BehaveBarkSpecies behaveBarkSpecies,
        double treeDbh ) ;

    static double treeBarkThicknessFofem(
        Sem::FofemTreeSpecies::FofemSpecies species,
        double dbh ) ;

    static double treeCrownBaseHeight(
        double crownRatio,
        double treeHt ) ;

    static double treeCrownScorch(
        double treeHt,
        double crownRatio,
        double scorchHt,
        double *crownLengthScorched,
        double *crownLengthFractionScorched ) ;

    static double treeMortalityBehave(
        double barkThickness,
        double crownVolScorched ) ;

    static double treeMortalityFofem(
        double barkThickness,
        double crownVolScorched,
        bool   isPicea=false ) ;
};

}   // End of namespace Sem

#endif  // _TREEMORTALITYALGORITHM_H_INCLUDED_

//------------------------------------------------------------------------------
//  End of TreeMortalityAlgorithm.h
//------------------------------------------------------------------------------

