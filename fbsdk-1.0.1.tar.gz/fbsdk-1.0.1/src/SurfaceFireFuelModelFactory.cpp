//------------------------------------------------------------------------------
/*! \file SurfaceFireFuelModelFactory.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \brief Factory for the 13 original standard fire behavior fuel models
    as defined by Albini (1976) and 40 extended fuel models defined by
    Scott and Burgan (2005).
    \license This code is released under the GNU Public License 2.
 */

// Custom header files
#include "Logger.h"
#include "SurfaceFireFuelModel.h"
#include "SurfaceFireFuelModelFactory.h"
#include "SurfaceFireMoistureInterface.h"

//------------------------------------------------------------------------------
/*! \brief Creates a SurfaceFireFuelModel for the 13 original standard fire
    behavior fuel models as defined by Albini (1976) and 40 extended fuel
    models defined by Scott and Burgan (2005).

    \param[in] id One of the standard fire behavior fuel model numbers:
    <table>
    <tr><td>I d</td><td>Name</td><td>Description</td></tr>
    <tr><td>  1</td><td>  1</td><td>Short grass (2 ft)</td></tr>
    <tr><td>  2</td><td>  2</td><td>Timber (grass and understory)</td></tr>
    <tr><td>  3</td><td>  3</td><td>Tall grass (2.5 ft)</td></tr>
    <tr><td>  4</td><td>  4</td><td>Chaparral (6 ft)</td></tr>
    <tr><td>  5</td><td>  5</td><td>Brush (2 ft)</td></tr>
    <tr><td>  6</td><td>  6</td><td>Dormant brush, hardwood slash</td></tr>
    <tr><td>  7</td><td>  7</td><td>Southern rough</td></tr>
    <tr><td>  8</td><td>  8</td><td>Closed timber litter</td></tr>
    <tr><td>  9</td><td>  9</td><td>Hardwood litter</td></tr>
    <tr><td> 10</td><td> 10</td><td>Timber (litter and understory)</td></tr>
    <tr><td> 11</td><td> 11</td><td>Light logging slash</td></tr>
    <tr><td> 12</td><td> 12</td><td>Medium logging slash</td></tr>
    <tr><td> 13</td><td> 13</td><td>Heavy logging slash</td></tr>
    <tr><td>101</td><td>gr1</td><td>Short, sparse, dry climate grass</td></tr>
    <tr><td>102</td><td>gr2</td><td>Low load, dry climate grass</td></tr>
    <tr><td>103</td><td>gr3</td><td>Low load, very coarse, dry climate grass</td></tr>
    <tr><td>104</td><td>gr4</td><td>Moderate load, dry climate grass</td></tr>
    <tr><td>105</td><td>gr5</td><td>Low load, humid climate grass</td></tr>
    <tr><td>106</td><td>gr6</td><td>Moderate load, humid climate grass</td></tr>
    <tr><td>107</td><td>gr7</td><td>High load, dry climate grass</td></tr>
    <tr><td>108</td><td>gr8</td><td>High load, very coarse, humid climate grass</td></tr>
    <tr><td>108</td><td>gr9</td><td>Very high load, humid climate grass</td></tr>
    <tr><td>121</td><td>gs1</td><td>Low load, dry climate grass-shrub</td></tr>
    <tr><td>122</td><td>gs2</td><td>Moderate load, dry climate grass-shrub</td></tr>
    <tr><td>123</td><td>gs3</td><td>Moderate load, humid climate grass-shrub</td></tr>
    <tr><td>124</td><td>gs4</td><td>High load, humid climate grass-shrub</td></tr>
    <tr><td>141</td><td>sh1</td><td>Low load, dry climate shrub</td></tr>
    <tr><td>142</td><td>sh2</td><td>Moderate load, dry climate shrub</td></tr>
    <tr><td>143</td><td>sh3</td><td>Moderate load, humid climate shrub</td></tr>
    <tr><td>144</td><td>sh4</td><td>Low load, humid climate timber-shrub</td></tr>
    <tr><td>145</td><td>sh5</td><td>High load, dry climate shrub</td></tr>
    <tr><td>146</td><td>sh6</td><td>Low load, humid climate shrub</td></tr>
    <tr><td>147</td><td>sh7</td><td>Very high load, dry climate shrub</td></tr>
    <tr><td>148</td><td>sh8</td><td>High load, humid climate shrub</td></tr>
    <tr><td>149</td><td>sh9</td><td>Very high load, humid climate shrub</td></tr>
    <tr><td>161</td><td>tu1</td><td>Low load, dry climate timber-grass-shrub</td></tr>
    <tr><td>162</td><td>tu2</td><td>Moderate load, humid climate timber-shrub</td></tr>
    <tr><td>163</td><td>tu3</td><td>Moderate load, humid climate timber-grass-shrub</td></tr>
    <tr><td>164</td><td>tu4</td><td>Dwarf conifer with understory</td></tr>
    <tr><td>165</td><td>tu5</td><td>Very high load, dry climate timber-shrub</td></tr>
    <tr><td>181</td><td>tl1</td><td>Low load compact conifer litter</td></tr>
    <tr><td>182</td><td>tl2</td><td>Low load broadleaf litter</td></tr>
    <tr><td>183</td><td>tl3</td><td>Moderate load conifer litter</td></tr>
    <tr><td>184</td><td>tl4</td><td>Small downed logs</td></tr>
    <tr><td>185</td><td>tl5</td><td>High load conifer litter</td></tr>
    <tr><td>186</td><td>tl6</td><td>Moderate load broadleaf litter</td></tr>
    <tr><td>187</td><td>tl7</td><td>Large downed logs</td></tr>
    <tr><td>188</td><td>tl8</td><td>Long-needle litter</td></tr>
    <tr><td>189</td><td>tl9</td><td>Very high load broadleaf litter</td></tr>
    <tr><td>201</td><td>sb1</td><td>Low activity fuel</td></tr>
    <tr><td>202</td><td>sb2</td><td>Moderate load activity or low load blowdown</td></tr>
    <tr><td>203</td><td>sb3</td><td>High load activity or moderate load blowdown</td></tr>
    <tr><td>204</td><td>sb4</td><td>High load blowndown</td></tr>
    </table>

    \param[in] moisture Pointer to a SurfaceFireMoistureInterface-derived
    instance that provides fuel moisture contents for the fuel model.

    \return Pointer to the newly created instance of the requested
    standard fie behavior fuel model, or 0 if id is invalid.
*/

Sem::SurfaceFireFuelModel* Sem::createFuelModel( int id,
        SurfaceFireMoistureInterface* moisture )
{
    SurfaceFireFuelModel* p;
    if ( id == 1 )        p = Sem::createFuelModel001();
    else if ( id ==   2 ) p = Sem::createFuelModel002();
    else if ( id ==   3 ) p = Sem::createFuelModel003();
    else if ( id ==   4 ) p = Sem::createFuelModel004();
    else if ( id ==   5 ) p = Sem::createFuelModel005();
    else if ( id ==   6 ) p = Sem::createFuelModel006();
    else if ( id ==   7 ) p = Sem::createFuelModel007();
    else if ( id ==   8 ) p = Sem::createFuelModel008();
    else if ( id ==   9 ) p = Sem::createFuelModel009();
    else if ( id ==  10 ) p = Sem::createFuelModel010();
    else if ( id ==  11 ) p = Sem::createFuelModel011();
    else if ( id ==  12 ) p = Sem::createFuelModel012();
    else if ( id ==  13 ) p = Sem::createFuelModel013();
    else if ( id == 101 ) p = Sem::createFuelModel101();
    else if ( id == 102 ) p = Sem::createFuelModel102();
    else if ( id == 103 ) p = Sem::createFuelModel103();
    else if ( id == 104 ) p = Sem::createFuelModel104();
    else if ( id == 105 ) p = Sem::createFuelModel105();
    else if ( id == 106 ) p = Sem::createFuelModel106();
    else if ( id == 107 ) p = Sem::createFuelModel107();
    else if ( id == 108 ) p = Sem::createFuelModel108();
    else if ( id == 109 ) p = Sem::createFuelModel109();
    else if ( id == 121 ) p = Sem::createFuelModel121();
    else if ( id == 122 ) p = Sem::createFuelModel122();
    else if ( id == 123 ) p = Sem::createFuelModel123();
    else if ( id == 124 ) p = Sem::createFuelModel124();
    else if ( id == 141 ) p = Sem::createFuelModel141();
    else if ( id == 142 ) p = Sem::createFuelModel142();
    else if ( id == 143 ) p = Sem::createFuelModel143();
    else if ( id == 144 ) p = Sem::createFuelModel144();
    else if ( id == 145 ) p = Sem::createFuelModel145();
    else if ( id == 146 ) p = Sem::createFuelModel146();
    else if ( id == 147 ) p = Sem::createFuelModel147();
    else if ( id == 148 ) p = Sem::createFuelModel148();
    else if ( id == 149 ) p = Sem::createFuelModel149();
    else if ( id == 161 ) p = Sem::createFuelModel161();
    else if ( id == 162 ) p = Sem::createFuelModel162();
    else if ( id == 163 ) p = Sem::createFuelModel163();
    else if ( id == 164 ) p = Sem::createFuelModel164();
    else if ( id == 165 ) p = Sem::createFuelModel165();
    else if ( id == 181 ) p = Sem::createFuelModel181();
    else if ( id == 182 ) p = Sem::createFuelModel182();
    else if ( id == 183 ) p = Sem::createFuelModel183();
    else if ( id == 184 ) p = Sem::createFuelModel184();
    else if ( id == 185 ) p = Sem::createFuelModel185();
    else if ( id == 186 ) p = Sem::createFuelModel186();
    else if ( id == 187 ) p = Sem::createFuelModel187();
    else if ( id == 188 ) p = Sem::createFuelModel188();
    else if ( id == 189 ) p = Sem::createFuelModel189();
    else if ( id == 201 ) p = Sem::createFuelModel201();
    else if ( id == 202 ) p = Sem::createFuelModel202();
    else if ( id == 203 ) p = Sem::createFuelModel203();
    else if ( id == 204 ) p = Sem::createFuelModel204();
    else
    {
        Sem::Logger::Instance().send( 3,
            QString( "Sem::createFuelModel( id=%1 ) is an invalid fuel model id." )
                .arg( id ) );
        return( 0 );
    }
    p->connectMoisture( moisture );
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates a SurfaceFireFuelModel for the 13 original standard fire
    behavior fuel models as defined by Albini (1976) and 40 extended fuel
    models defined by Scott and Burgan (2005).

    \param[in] standardName One of the standard fire behavior fuel model names:
    <table>
    <tr><td>I d</td><td>Name</td><td>Description</td></tr>
    <tr><td>  1</td><td>  1</td><td>Short grass (2 ft)</td></tr>
    <tr><td>  2</td><td>  2</td><td>Timber (grass and understory)</td></tr>
    <tr><td>  3</td><td>  3</td><td>Tall grass (2.5 ft)</td></tr>
    <tr><td>  4</td><td>  4</td><td>Chaparral (6 ft)</td></tr>
    <tr><td>  5</td><td>  5</td><td>Brush (2 ft)</td></tr>
    <tr><td>  6</td><td>  6</td><td>Dormant brush, hardwood slash</td></tr>
    <tr><td>  7</td><td>  7</td><td>Southern rough</td></tr>
    <tr><td>  8</td><td>  8</td><td>Closed timber litter</td></tr>
    <tr><td>  9</td><td>  9</td><td>Hardwood litter</td></tr>
    <tr><td> 10</td><td> 10</td><td>Timber (litter and understory)</td></tr>
    <tr><td> 11</td><td> 11</td><td>Light logging slash</td></tr>
    <tr><td> 12</td><td> 12</td><td>Medium logging slash</td></tr>
    <tr><td> 13</td><td> 13</td><td>Heavy logging slash</td></tr>
    <tr><td>101</td><td>gr1</td><td>Short, sparse, dry climate grass</td></tr>
    <tr><td>102</td><td>gr2</td><td>Low load, dry climate grass</td></tr>
    <tr><td>103</td><td>gr3</td><td>Low load, very coarse, dry climate grass</td></tr>
    <tr><td>104</td><td>gr4</td><td>Moderate load, dry climate grass</td></tr>
    <tr><td>105</td><td>gr5</td><td>Low load, humid climate grass</td></tr>
    <tr><td>106</td><td>gr6</td><td>Moderate load, humid climate grass</td></tr>
    <tr><td>107</td><td>gr7</td><td>High load, dry climate grass</td></tr>
    <tr><td>108</td><td>gr8</td><td>High load, very coarse, humid climate grass</td></tr>
    <tr><td>108</td><td>gr9</td><td>Very high load, humid climate grass</td></tr>
    <tr><td>121</td><td>gs1</td><td>Low load, dry climate grass-shrub</td></tr>
    <tr><td>122</td><td>gs2</td><td>Moderate load, dry climate grass-shrub</td></tr>
    <tr><td>123</td><td>gs3</td><td>Moderate load, humid climate grass-shrub</td></tr>
    <tr><td>124</td><td>gs4</td><td>High load, humid climate grass-shrub</td></tr>
    <tr><td>141</td><td>sh1</td><td>Low load, dry climate shrub</td></tr>
    <tr><td>142</td><td>sh2</td><td>Moderate load, dry climate shrub</td></tr>
    <tr><td>143</td><td>sh3</td><td>Moderate load, humid climate shrub</td></tr>
    <tr><td>144</td><td>sh4</td><td>Low load, humid climate timber-shrub</td></tr>
    <tr><td>145</td><td>sh5</td><td>High load, dry climate shrub</td></tr>
    <tr><td>146</td><td>sh6</td><td>Low load, humid climate shrub</td></tr>
    <tr><td>147</td><td>sh7</td><td>Very high load, dry climate shrub</td></tr>
    <tr><td>148</td><td>sh8</td><td>High load, humid climate shrub</td></tr>
    <tr><td>149</td><td>sh9</td><td>Very high load, humid climate shrub</td></tr>
    <tr><td>161</td><td>tu1</td><td>Low load, dry climate timber-grass-shrub</td></tr>
    <tr><td>162</td><td>tu2</td><td>Moderate load, humid climate timber-shrub</td></tr>
    <tr><td>163</td><td>tu3</td><td>Moderate load, humid climate timber-grass-shrub</td></tr>
    <tr><td>164</td><td>tu4</td><td>Dwarf conifer with understory</td></tr>
    <tr><td>165</td><td>tu5</td><td>Very high load, dry climate timber-shrub</td></tr>
    <tr><td>181</td><td>tl1</td><td>Low load compact conifer litter</td></tr>
    <tr><td>182</td><td>tl2</td><td>Low load broadleaf litter</td></tr>
    <tr><td>183</td><td>tl3</td><td>Moderate load conifer litter</td></tr>
    <tr><td>184</td><td>tl4</td><td>Small downed logs</td></tr>
    <tr><td>185</td><td>tl5</td><td>High load conifer litter</td></tr>
    <tr><td>186</td><td>tl6</td><td>Moderate load broadleaf litter</td></tr>
    <tr><td>187</td><td>tl7</td><td>Large downed logs</td></tr>
    <tr><td>188</td><td>tl8</td><td>Long-needle litter</td></tr>
    <tr><td>189</td><td>tl9</td><td>Very high load broadleaf litter</td></tr>
    <tr><td>201</td><td>sb1</td><td>Low activity fuel</td></tr>
    <tr><td>202</td><td>sb2</td><td>Moderate load activity or low load blowdown</td></tr>
    <tr><td>203</td><td>sb3</td><td>High load activity or moderate load blowdown</td></tr>
    <tr><td>204</td><td>sb4</td><td>High load blowndown</td></tr>
    </table>

    \param[in] moisture Pointer to a SurfaceFireMoistureInterface-derived
    instance that provides fuel moisture contents for the fuel model.

    \return Pointer to the newly created instance of the requested
    standard fie behavior fuel model, or 0 if id is invalid.
*/

Sem::SurfaceFireFuelModel* Sem::createFuelModel( const QString& standardName,
        SurfaceFireMoistureInterface* moisture )
{
    SurfaceFireFuelModel* p;
    QString name = standardName.toLower();
    if ( name == "1" )        p = Sem::createFuelModel001();
    else if ( name ==   "2" ) p = Sem::createFuelModel002();
    else if ( name ==   "3" ) p = Sem::createFuelModel003();
    else if ( name ==   "4" ) p = Sem::createFuelModel004();
    else if ( name ==   "5" ) p = Sem::createFuelModel005();
    else if ( name ==   "6" ) p = Sem::createFuelModel006();
    else if ( name ==   "7" ) p = Sem::createFuelModel007();
    else if ( name ==   "8" ) p = Sem::createFuelModel008();
    else if ( name ==   "9" ) p = Sem::createFuelModel009();
    else if ( name ==  "10" ) p = Sem::createFuelModel010();
    else if ( name ==  "11" ) p = Sem::createFuelModel011();
    else if ( name ==  "12" ) p = Sem::createFuelModel012();
    else if ( name ==  "13" ) p = Sem::createFuelModel013();
    else if ( name == "gr1" ) p = Sem::createFuelModel101();
    else if ( name == "gr2" ) p = Sem::createFuelModel102();
    else if ( name == "gr3" ) p = Sem::createFuelModel103();
    else if ( name == "gr4" ) p = Sem::createFuelModel104();
    else if ( name == "gr5" ) p = Sem::createFuelModel105();
    else if ( name == "gr6" ) p = Sem::createFuelModel106();
    else if ( name == "gr7" ) p = Sem::createFuelModel107();
    else if ( name == "gr8" ) p = Sem::createFuelModel108();
    else if ( name == "gr9" ) p = Sem::createFuelModel109();
    else if ( name == "gs1" ) p = Sem::createFuelModel121();
    else if ( name == "gs2" ) p = Sem::createFuelModel122();
    else if ( name == "gs3" ) p = Sem::createFuelModel123();
    else if ( name == "gs4" ) p = Sem::createFuelModel124();
    else if ( name == "sh1" ) p = Sem::createFuelModel141();
    else if ( name == "sh2" ) p = Sem::createFuelModel142();
    else if ( name == "sh3" ) p = Sem::createFuelModel143();
    else if ( name == "sh4" ) p = Sem::createFuelModel144();
    else if ( name == "sh5" ) p = Sem::createFuelModel145();
    else if ( name == "sh6" ) p = Sem::createFuelModel146();
    else if ( name == "sh7" ) p = Sem::createFuelModel147();
    else if ( name == "sh8" ) p = Sem::createFuelModel148();
    else if ( name == "sh9" ) p = Sem::createFuelModel149();
    else if ( name == "tu1" ) p = Sem::createFuelModel161();
    else if ( name == "tu2" ) p = Sem::createFuelModel162();
    else if ( name == "tu3" ) p = Sem::createFuelModel163();
    else if ( name == "tu4" ) p = Sem::createFuelModel164();
    else if ( name == "tu5" ) p = Sem::createFuelModel165();
    else if ( name == "tl1" ) p = Sem::createFuelModel181();
    else if ( name == "tl2" ) p = Sem::createFuelModel182();
    else if ( name == "tl3" ) p = Sem::createFuelModel183();
    else if ( name == "tl4" ) p = Sem::createFuelModel184();
    else if ( name == "tl5" ) p = Sem::createFuelModel185();
    else if ( name == "tl6" ) p = Sem::createFuelModel186();
    else if ( name == "tl7" ) p = Sem::createFuelModel187();
    else if ( name == "tl8" ) p = Sem::createFuelModel188();
    else if ( name == "tl9" ) p = Sem::createFuelModel189();
    else if ( name == "sb1" ) p = Sem::createFuelModel201();
    else if ( name == "sb2" ) p = Sem::createFuelModel202();
    else if ( name == "sb3" ) p = Sem::createFuelModel203();
    else if ( name == "sb4" ) p = Sem::createFuelModel204();
    else
    {
        Sem::Logger::Instance().send( 3,
            QString( "Sem::createFuelModel( name=%1 ) is an invalid fuel model name." )
                .arg( name ) );
        return( 0 );
    }
    p->connectMoisture( moisture );
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 1,
    short grass (1 ft), as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel001( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        1, "1", "Short Grass (1 ft)", 0.12 );
    p->addParticleNew(
        3500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0340 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 2,
    timber (grass and understory) as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel002( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        2, "2", "Timber (grass and understory)", 0.15 );
    p->addParticleNew(
        3000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0920 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0460 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0230 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0230 );                   // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 3,
    tall grass (2.5 ft) as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel003( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        3, "3", "Tall grass (2.5 ft)", 0.25 );
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.1380 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 4,
    chaparral (6 ft) as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel004( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        4, "4", "Chaparral (6 ft)", 0.20 );
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        0.2300 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        0.1840 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        0.0920 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        0.2300 );                   // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 5,
    brush (2 ft) as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel005( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        5, "5", "Brush (2 ft)", 0.20 );
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.0460 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.0230 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.0920 );                   // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 6,
    dormant brush, hardwood slash as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel006( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        6, "6", "Dormant brush, hardwood slash", 0.25 );
    p->addParticleNew(
        1750.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0690 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.1150 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0920 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 7,
    southern rough as defined by Albini (1976).

    \note While Albini specified a live fuel surface area-to-volume ratio of
    1550 ft2/ft3, the original BEHAVE (mistakenly?) used 1500.  This 'bug' was
    purposefully perpetuated in BehavePlus  in the interest of consistency,
    and we therefore also do so here.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel007( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        7, "7", "Southern rough", 0.40 );
    p->addParticleNew(
        1750.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0520 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0860 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0690 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.5,                        // maximum height (ft)
        0.0170 );                   // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 8,
    closed timber litter as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel008( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        8, "8", "Closed timber litter", 0.30 );
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.0690 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.0460 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.1150 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 9,
    hardwood litter as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel009( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        9, "9", "Hardwood litter", 0.25 );
    p->addParticleNew(
        2500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.1340 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.0190 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        0.0070 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 10,
    timber (litter and understory) as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel010( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
       10, "10", "Timber (litter and understory)", 0.25 );
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.1380 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0920 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.2300 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0920 );                   // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 11,
    light logging slash as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel011( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
       11, "11", "Light logging slash", 0.15 );
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.0690 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.2070 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.2530 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 11,
    medium logging slash as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel012( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
       12, "12", "Medium logging slash", 0.20 );
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.3,                        // maximum height (ft)
        0.1840 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.3,                        // maximum height (ft)
        0.6440 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.3,                        // maximum height (ft)
        0.7590 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the original standard fire behavior fuel model 13,
    heavy logging slash as defined by Albini (1976).
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel013( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
       13, "13", "Heavy logging slash", 0.25 );
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        0.3220 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        1.0580 );                   // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        1.2880 );                   // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 101 (gr1),
    short, sparse, dry climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel101( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        101, "gr1", "Short, sparse, dry climate grass", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2200.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        0.1 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        0.3 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 102 (gr2),
    low load, dry climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel102( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        102, "gr2", "Low load, dry climate grass", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.1 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.0 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 103 (gr3),
    low load, very coarse, humid climate grass
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel103( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        103, "gr3", "Low load, very coarse, humid climate grass", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.10 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.4 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1300.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        1.5 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 104 (gr4),
    moderate load, dry climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel104( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        104, "gr4", "Moderate load, dry climate grass", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        0.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        1.9 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 105 (gr5),
    low load, humid climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel105( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        105, "gr5", "Low load, humid climate grass", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        0.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        2.5 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 106 (gr6),
    moderate load, humid climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel106( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        106, "gr6", "Moderate load, humid climate grass", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2200.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        0.10 * f,                   // dead fuel load (lb/ft2)
        0.10,                       // dead fuel moisture (g/g)
        2.00,                       // live fuel moisture (g/g)
        9000. );                    // low heat of combustion (Btu/lb)
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        3.4 * f,                    // live fuel load (lb/ft2)
        0.10,                       // dead fuel moisture (g/g)
        2.00,                       // live fuel moisture (g/g)
        9000. );                    // low heat of combustion (Btu/lb)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 107 (gr7),
    high load, dry climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel107( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        107, "gr7", "High load, dry climate grass", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        1.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        5.4 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 108 (gr8),
    high load, very coarse, humid climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel108( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        108, "gr8", "High load, very coarse, humid climate grass", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        4.0,                        // maximum height (ft)
        0.5 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        4.0,                        // maximum height (ft)
        1.0 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1300.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        4.0,                        // maximum height (ft)
        7.3 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 109 (gr9),
    very high load, humid climate grass.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel109( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        108, "gr8", "Very high load, humid climate grass", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        5.0,                        // maximum height (ft)
        1.0 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        5.0,                        // maximum height (ft)
        1.0 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        5.0,                        // maximum height (ft)
        9.0 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 121 (gs1),
    low load, dry climate grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel121( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        121, "gs1", "Low load, dry climate grass-shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.9,                        // maximum height (ft)
        0.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        0.9,                        // maximum height (ft)
        0.50 * f );                 // live fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.9,                        // maximum height (ft)
        0.65 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 122 (gs2),
    moderate load, humid climate grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel122( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        122, "gs2", "Moderate load, dry climate grass-shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        0.5 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        0.5 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        0.6 * f );                  // live fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.5,                        // maximum height (ft)
        1.0 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 123 (gs3),
    moderate load, humid climate grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel123( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        123, "gs3", "Moderate load, humid climate grass-shrub", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.8,                        // maximum height (ft)
        0.3 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.8,                        // maximum height (ft)
        0.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.8,                        // maximum height (ft)
        1.45 * f );                 // live fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.8,                        // maximum height (ft)
        1.25 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 124 (gs4),
    high load, humid climate grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel124( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        124, "gs4", "High load, humid climate grass-shrub", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.1,                        // maximum height (ft)
        1.9 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.1,                        // maximum height (ft)
        0.3 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.1,                        // maximum height (ft)
        0.1 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        2.1,                        // maximum height (ft)
        3.4 * f );                  // live fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.1,                        // maximum height (ft)
        7.1 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 141 (sh1),
    low load, dry climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel141( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        141, "sh1", "Low load, dry climate shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.15 * f );                 // live fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.30 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 142 (sh2),
    moderate load, dry climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel142( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        142, "sh2", "Moderate load, dry climate shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.35 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        2.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.75 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        3.85 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 143 (sh3),
    moderate load, humid climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel143( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        143, "sh3", "Moderate load, humid climate shrub", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.4,                        // maximum height (ft)
        0.45 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.4,                        // maximum height (ft)
        3.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1400.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.4,                        // maximum height (ft)
        6.20 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 144 (sh4),
    low load, humid climate timber-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel144( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        144, "sh4", "Low load, humid climate timber-shrub", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        0.85 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        1.15 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        0.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        2.55 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 145 (sh5),
    high load, dry climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel145( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        145, "sh5", "High load, dry climate shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        3.60 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        2.10 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        2.90 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 146 (sh6),
    low load, humid climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel146( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        146, "sh6", "Low load, humid climate shrub", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        2.90 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        1.45 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.0,                        // maximum height (ft)
        1.40 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 147 (sh7),
    very high load, dry climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel147( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        147, "sh7", "Very high load, dry climate shrub", 0.15 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        3.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        5.30 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        2.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        6.0,                        // maximum height (ft)
        3.40 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 148 (sh8),
    high load, humid climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel148( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        148, "sh8", "High load, humid climate shrub", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        2.05 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        3.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        0.85 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        3.0,                        // maximum height (ft)
        4.35 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 149 (sh9),
    very high load, humid climate shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel149( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        149, "sh9", "Ver high load, humid climate shrub", 0.40 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        4.4,                        // maximum height (ft)
        4.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        4.4,                        // maximum height (ft)
        2.45 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        4.4,                        // maximum height (ft)
        1.55 * f );                 // live fuel load (lb/ft2)
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        4.4,                        // maximum height (ft)
        7.00 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 161 (tu1),
    light load, dry climate timber-grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel161( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        161, "tu1", "Light load, dry climate timber-grass-shrub", 0.20 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        0.20* f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        0.9 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        1.5 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        0.2 * f );                  // live fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        0.9 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 162 (tu2),
    moderate load, humid climate timber-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel162( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        162, "tu2", "Moderate load, humid climate timber-shrub", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.95 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.8 * f );                  // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        0.2 * f );                  // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 163 (tu3),
    moderate load, humid climate timber-grass-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel163( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        163, "tu3", "Moderate load, humid climate timber-grass-shrub", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.3,                        // maximum height (ft)
        1.10 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.3,                        // maximum height (ft)
        0.15 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.3,                        // maximum height (ft)
        0.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        1600.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveHerb,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureHerb1,             // Sem::ParticleCureAlgorithm
        1.3,                        // maximum height (ft)
        0.65 * f );                 // live fuel load (lb/ft2)
    p->addParticleNew(
        1400.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.3,                        // maximum height (ft)
        1.10 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 164 (tu4),
    dwarf conifer with understory.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel164( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        164, "tu4", "Dwarf conifer with understory", 0.12 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2300.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.5,                        // maximum height (ft)
        4.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.5,                        // maximum height (ft)
        2.00 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 165 (tu5),
    very high load, dry climate timber-shrub.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel165( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        165, "tu5", "Very high load, dry climate timber-shrub", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1500.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        4.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        4.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        3.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        750.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureLiveWood,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        3.00 * f );                 // live fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 181 (tl1),
    low load compact conifer litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel181( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        181, "tl1", "Low load, compact conifer litter", 0.30 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        1.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        2.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        3.60 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 182 (tl2),
    low load broadleaf litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel182( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        182, "tl2", "Low load broadleaf litter", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        1.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        2.30 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.2,                        // maximum height (ft)
        2.20 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 183 (tl3),
    moderate load conifer litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel183( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        183, "tl3", "Moderate load conifer litter", 0.20 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        0.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        2.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        2.80 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 184 (tl4),
    small downed logs.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel184( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        184, "tl4", "Small downed logs", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        0.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        1.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        4.20 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 185 (tl5),
    high load conifer litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel185( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        185, "tl5", "High load conifer litter", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        1.15 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        2.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        4.40 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 186 (tl6),
    moderate load broadleaf litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel186( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        186, "tl6", "Moderate load broadleaf litter", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        2.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        1.20 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        1.20 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 187 (tl7),
    large downed logs.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel187( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        187, "tl7", "Large downed logs", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        0.30 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        1.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.4,                        // maximum height (ft)
        8.10 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 188 (tl8),
    long-needle litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel188( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        188, "tl8", "Long-needle litter", 0.35 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        5.80 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        1.40 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.3,                        // maximum height (ft)
        1.10 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 189 (tl9),
    very high load broadleaf litter.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel189( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        189, "tl9", "Very high load broadleaf litter", 0.35 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        1800.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        6.65 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        3.30 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        0.6,                        // maximum height (ft)
        4.15 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 201 (sb1),
    low load activity fuel.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel201( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        201, "sb1", "Low load activity fuel", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        1.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        3.00 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        11.0 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 202 (sb2),
    moderate load activity or low load blowdown.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel202( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        202, "sb2", "Moderate load activity or low load blowdown", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        4.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        4.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.0,                        // maximum height (ft)
        4.00 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 203 (sb3),
    high load activity or moderate load blowdown.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel203( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        203, "sb3", "High load activity or moderate load blowdown", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.2,                        // maximum height (ft)
        5.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.2,                        // maximum height (ft)
        2.75 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        1.2,                        // maximum height (ft)
        3.00 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Creates the extended standard fire behavior fuel model 204 (sb4),
    high load blowdown.
*/
Sem::SurfaceFireFuelModel* Sem::createFuelModel204( void )
{
    Sem::SurfaceFireFuelModel* p = Sem::createSurfaceFireFuelModel(
        204, "sb4", "High load blowdown", 0.25 );
    double f = 2000. / 43560.;      // Convert tons per acre to lb/ft2
    p->addParticleNew(
        2000.,                      // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead1h,        // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.7,                        // maximum height (ft)
        5.25 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        109.,                       // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead10h,       // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.7,                        // maximum height (ft)
        3.50 * f );                 // dead fuel load (lb/ft2)
    p->addParticleNew(
        30.,                        // surface area-to-volume ratio (ft2/ft3)
        Sem::SurfaceFireFuelAlgorithm::MoistureDead100h,      // Sem::SurfaceFuelMoistureClass
        Sem::SurfaceFireFuelAlgorithm::CureNone,              // Sem::ParticleCureAlgorithm
        2.7,                        // maximum height (ft)
        5.25 * f );                 // dead fuel load (lb/ft2)
    return( p );
}

//------------------------------------------------------------------------------
/*! \brief Factory convenience method to create and test the
    SurfaceFireFuelModel portion of the fuel model.

    \param[in] id Surface fire fuel model id.
    \param[in] name Surface fire fuel model name.
    \param[in] desc Surface fire fuel model description
    \param[in] mextDead Surface fuel dead fuel extinction moisture content.

    \return Pointer to the newly created SurfaceFireFuelModel.
*/

Sem::SurfaceFireFuelModel* Sem::createSurfaceFireFuelModel( int id,
        const QString& name, const QString& desc, double mextDead )
{
    Sem::SurfaceFireFuelModel* p =
        new Sem::SurfaceFireFuelModel( id, name, desc, mextDead );
    Q_ASSERT_X( (p != 0 ),
        QString( "Sem::SurfaceFuelModelFactory::createFuelModel%1()" )
            .arg( name ).toLatin1().constData(),
        "SurfaceFireFuelModel allocation failure." );
    return( p );
}

//------------------------------------------------------------------------------
//  End of SurfaceFireFuelModelFactory.cpp
//------------------------------------------------------------------------------

