//------------------------------------------------------------------------------
/*! \file SurfaceFireWind.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief A simple implementation of the SurfaceFireWindInterface for
    accessing and updating surface fire <i>midflame</i> wind speed and direction
    at a specific location and time.
 */

// Custom header files
#include "CompassAlgorithm.h"
#include "Logger.h"
#include "SurfaceFireWind.h"

// Standard headers
#include <cmath>

// Non-integral static data members must be initialized outside the class
const double Sem::SurfaceFireWind::speedMphMin = 0.0;
const double Sem::SurfaceFireWind::speedMphMax = 40.0;

//------------------------------------------------------------------------------
/*! \brief SurfaceFireWind default constructor.
 */

Sem::SurfaceFireWind::SurfaceFireWind( void ) :
    SurfaceFireWindInterface(),
    m_source( 0.0 ),
    m_speed( 0.0 )
{
    init();
    m_classVersion = surfaceFireWindVersion;
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireWind custom constructor.

    \param[in] midflameSpeedMph Midflame wind speed (mi/h).
    \param[in] sourceDegreesClockwiseFromNorth Just what it says.
 */

Sem::SurfaceFireWind::SurfaceFireWind( double midflameSpeedMph,
        double sourceDegreesClockwiseFromNorth ) :
    SurfaceFireWindInterface(),
    m_source( sourceDegreesClockwiseFromNorth ),
    m_speed( midflameSpeedMph )
{
    assert( m_speed >= speedMphMin && m_speed <= speedMphMax );
    init();
    m_classVersion = surfaceFireWindVersion;
    m_source = Sem::CompassAlgorithm::constrain( m_source );
    setDirty();
    return;
}

//------------------------------------------------------------------------------
/*! \brief Virtual destructor.
 */

Sem::SurfaceFireWind::~SurfaceFireWind( void )
{
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireWind copy constructor.
    \param[in] right Reference to the SurfaceFireWind from which to copy.
    \return Reference to the newly allocated SurfaceFireWind.
 */

Sem::SurfaceFireWind::SurfaceFireWind( const SurfaceFireWind &right ) :
    SurfaceFireWindInterface()
{
    init();
    m_classVersion = right.m_classVersion;
    m_source       = right.m_source;
    m_speed        = right.m_speed;
    setDirty();     // emits valueChanged()
    return;
}

//------------------------------------------------------------------------------
/*! \brief SurfaceFireWind assignment operator.
    \param[in] right Reference to the SurfaceFireWind from which to assign.
    \return Reference to the newly assigned SurfaceFireWind.
 */

const Sem::SurfaceFireWind& Sem::SurfaceFireWind::operator=(
        const SurfaceFireWind &right )
{
    if ( this != &right )
    {
        init();
        m_classVersion = right.m_classVersion;
        m_source       = right.m_source;
        m_speed        = right.m_speed;
        setDirty();     // emits valueChanged()
    }
    return( *this );
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind bearing direction.

    \return Wind bearing (degrees clockwise from north).
 */

double Sem::SurfaceFireWind::bearing( void ) const
{
    return( Sem::CompassAlgorithm::opposite( m_source ) );
}

//------------------------------------------------------------------------------
/*! \brief Access to the class name.
    \return Static pointer to the class name.
 */

const char *Sem::SurfaceFireWind::className( void ) const
{
    return( metaObject()->className() );
}

//------------------------------------------------------------------------------
/*! \brief Access to the current class version.
    \return Current class version.
 */

int Sem::SurfaceFireWind::classVersion( void ) const
{
    return( surfaceFireWindVersion );
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at midflame height.

    \return Wind speed at midflame height (ft/min).
 */

double Sem::SurfaceFireWind::fpm( void ) const
{
    return( m_speed * 88. );
}

//------------------------------------------------------------------------------
/*! \brief Initializes all intermediate properties to default values.
 */

void Sem::SurfaceFireWind::init( void ) const
{
    // There are no intermediates to initialize for this class
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind speed at midflame height.

    \return Wind speed at midflame height (mi/h).
 */

double Sem::SurfaceFireWind::mph( void ) const
{
    return( m_speed );
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind bearing direction.

    \param[in] bearingDegreesClockwiseFromNorth Just what it says.
 */

void Sem::SurfaceFireWind::setBearing( double bearingDegreesClockwiseFromNorth )
{
    double bearing = Sem::CompassAlgorithm::constrain( bearingDegreesClockwiseFromNorth );
    double source = Sem::CompassAlgorithm::opposite( bearing );
    if ( source != m_source )
    {
        m_source = source;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the midflame wind speed.

    \param[in] midflameFpm Midflame wind speed (ft/min).
 */

void Sem::SurfaceFireWind::setFpm( double midflameFpm )
{
    setMph( midflameFpm / 88. );
    return;
}


//------------------------------------------------------------------------------
/*! \brief Updates the midflame wind speed.

    \param[in] midflameMph Midflame wind speed (mi/h).
 */

void Sem::SurfaceFireWind::setMph( double midflameMph )
{
    assert( midflameMph >= speedMphMin && midflameMph <= speedMphMax );
    if ( midflameMph != m_speed )
    {
        m_speed = midflameMph;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Updates the wind source direction.

    \param[in] sourceDegreesClockwiseFromNorth Just what it says.
 */

void Sem::SurfaceFireWind::setSource( double sourceDegreesClockwiseFromNorth )
{
    double source = Sem::CompassAlgorithm::constrain( sourceDegreesClockwiseFromNorth );
    if ( source != m_source )
    {
        m_source = source;
        setDirty(); // Notify Observers that we're now dirty
    }
    return;
}

//------------------------------------------------------------------------------
/*! \brief Access to the wind source direction.

    \return Wind source (degrees clockwise from north).
 */

double Sem::SurfaceFireWind::source( void ) const
{
    return( m_source );
}

//------------------------------------------------------------------------------
/*! \brief Does whatever is necessary to bring the object's intermediate
    (non-mutable) properties up to date.

    \note Make sure NOT to call any member access methods to reference
    properties, such as "<property>()", as these then call checkUpdate(),
    resulting in an infinite loop!
    Reference member properties directly, as in "m_property".
 */

void Sem::SurfaceFireWind::update( void ) const
{
    // Do whatever here to bring object properties current
    return;
}

//------------------------------------------------------------------------------
/*! \brief Non-member equality operator between two SurfaceFireWind objects.

    \param[in] lhs Left-hand-side SurfaceFireWind object.
    \param[in] rhs Right-hand-side SurfaceFireWind object.
 */
bool Sem::operator ==( const Sem::SurfaceFireWind &lhs,
                       const Sem::SurfaceFireWind &rhs )
{ 
  return( ( fabs( lhs.mph()    - rhs.mph() )    < Smidgen )
       && ( fabs( lhs.source() - rhs.source() ) < Smidgen )
    );
}

//------------------------------------------------------------------------------
/*! \brief Non-member inequality operator between two SurfaceFireWind objects.

    \param[in] lhs Left-hand-side SurfaceFireWind object.
    \param[in] rhs Right-hand-side SurfaceFireWind object.
 */
bool Sem::operator !=( const Sem::SurfaceFireWind &lhs,
                       const Sem::SurfaceFireWind &rhs )
{ 
  return( ! ( lhs == rhs ) );
}


//------------------------------------------------------------------------------
//  End of SurfaceFireWind.cpp
//------------------------------------------------------------------------------

