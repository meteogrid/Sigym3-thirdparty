//------------------------------------------------------------------------------
/*! \file demo01.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Demonstrates (1) how to use the FBSDK to create a simple fire
    simulation and (2) how changes in the underlying fuel, moisture, terrain,
    or wind are automatically propagated to the fire behavior.
 */

#include "fbsdk.h"

void showInfo( Sem::SurfaceFireSpread* fire, const char* title );

int main()
{
    // Step 1: create a simple fuel moisture observation station 
    // and initialize it with dead 1-h = 4%, dead 10-h = 6%, dead 100-h = 8%,
    // dead 1000-h = 10%, live herb = 100%, and live wood = 150% moisture content.
    Sem::SurfaceFireMoistureTimeLag* moisture = 
        new Sem::SurfaceFireMoistureTimeLag( 0.04, 0.06, 0.08, 0.10, 1.0, 1.5 );

    // Step 2: create a standard fire behavior 'Fuel Model 1'
    // and have it get its fuel moisture from moisture station 'mosture'
    Sem::SurfaceFireFuelModel* fuel = Sem::createFuelModel( 1, moisture );

    // Step 3: create a terrain instance with 100% slope and south aspect
    Sem::SurfaceFireTerrain* terrain = new Sem::SurfaceFireTerrain( 100., 180. );

    // Step 4: create a wind observation station
    // and initialize it to 5 mph wind blowing from the south.
    Sem::SurfaceFireWind* wind = new Sem::SurfaceFireWind( 5., 180. );

    // Step 5: create a surface fire that uses these fuel (and associated
    // moisture), terrain, and wind instances
    Sem::SurfaceFireSpread* fire = new Sem::SurfaceFireSpread( fuel, terrain, wind );

    // Step 6: print out some information about this fire
    showInfo( fire, "FM1, 5 mph north (upslope) wind" );

    // Step 7: change the 'wind' direction and see that its effects are
    // automatically propagated to 'fire' (and, indeed, is propagated to all
    // fires that reference 'wind')
    wind->setBearing( 90. );
    showInfo( fire, "FM1, 5 mph east (cross-slope) wind" );
    return( 0 );
}

void showInfo( Sem::SurfaceFireSpread* fire, const char* title )
{
    const char *fmt = "%36s : %10.2f %s\n";
    fprintf( stdout, "\n\n%36s : %s\n", "Description", title );
    fprintf( stdout, fmt, "Heading Direction",
        fire->spreadDirectionAtHead(), "degrees" );
    fprintf( stdout, fmt, "Backing Direction",
        fire->spreadDirectionAtBack(), "degrees" );
    fprintf( stdout, fmt, "Spread Rate at Head",
        fire->spreadRateAtHead(), "ft/min" );
    fprintf( stdout, fmt, "Spread Rate at Back",
        fire->spreadRateAtBack(), "ft/min" );
    fprintf( stdout, fmt, "Spread Rate at 45o",
        fire->spreadRateAtCompass( 45. ), "ft/min" );
    fprintf( stdout, fmt, "Fireline Intensity at Head",
        fire->firelineIntAtHead(), "Btu/ft/s" );
    fprintf( stdout, fmt, "Fireline Intensity at Back",
        fire->firelineIntAtBack(), "Btu/ft/s" );
    fprintf( stdout, fmt, "Fireline Intensity at 45o",
        fire->firelineIntAtCompass(), "Btu/ft/s" );
    fprintf( stdout, fmt, "Flame Length at Head",
        fire->flameLengthAtHead(), "ft" );
    fprintf( stdout, fmt, "Flame Length at Back",
        fire->flameLengthAtBack(), "ft" );
    fprintf( stdout, fmt, "Flame Length at 45o",
        fire->flameLengthAtCompass(), "ft" );
    fprintf( stdout, fmt, "Scorch Height at Head",
        fire->scorchHeightAtHead(), "ft" );
    fprintf( stdout, fmt, "Scorch Height at Back",
        fire->scorchHeightAtBack(), "ft" );
    fprintf( stdout, fmt, "Scorch Height at 45o",
        fire->scorchHeightAtCompass(), "ft" );
    fprintf( stdout, fmt, "Length-to-Width Ratio",
        fire->lengthToWidthRatio(), "ft/ft" );
    fprintf( stdout, fmt, "Forward Spread Distance at 1 Hour",
        fire->distanceAtHead( 60. ), "ft" );
    fprintf( stdout, fmt, "Backing Spread Distance at 1 Hour",
        fire->distanceAtBack(), "ft" );
    fprintf( stdout, fmt, "Spread Distance at 45o at 1 Hour",
        fire->distanceAtCompass(), "ft" );
    fprintf( stdout, fmt, "Fire Length at 1 Hour",
        fire->fireLength(), "ft" );
    fprintf( stdout, fmt, "Fire Width at 1 Hour",
        fire->fireWidth(), "ft" );
    fprintf( stdout, fmt, "Fire Perimeter at 1 Hour",
        fire->firePerimeter(), "ft" );
    fprintf( stdout, fmt, "Fire Area at 1 Hour",
        fire->fireAcres(), "ac" );

    // Print out some info about the fuel
    Sem::SurfaceFireFuelInterface* fuel = fire->connectedFuel();
    fprintf( stdout, fmt, "Reaction Intensity",
        fuel->reactionIntensity(), "Btu/ft2/min" );
    fprintf( stdout, fmt, "Residence Time",
        fuel->residenceTime(), "min" );
    return;
}
