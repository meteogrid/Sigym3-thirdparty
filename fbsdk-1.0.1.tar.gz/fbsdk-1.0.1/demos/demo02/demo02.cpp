//------------------------------------------------------------------------------
/*! \file demo02.cpp
    \author Copyright (C) 2006 by Collin D. Bevins.
    \license This is released under the GNU Public License 2.
    \brief Demonstrates how diurnal changes detected by a fuel moisture
    monitoring station can be applied to several fuel types.  Again,
    changes to the moisture station are automatically propagated to all the
    fires that are 'connected' to the moisture station.

    Note that the shared weather station could also be updated by an hourly
    forecast feed; this is left as an exercise for the user.
 */

#include "fbsdk.h"

// A structure to hold our dummy moisture stream
typedef struct {
    int    hour;
    double dead1;
    double dead10;
    double dead100;
    double dead1000;
    double liveHerb;
    double liveWood;
} MoistureObservationData;

// Fake a 'live' hourly moisture data stream from 0000 hours through 2300 hours
static MoistureObservationData Forecast[] =
{
    {  0, 0.20, 0.22, 0.16, 0.20, 1.00, 1.50 },
    {  1, 0.20, 0.22, 0.16, 0.20, 1.00, 1.50 },
    {  2, 0.20, 0.20, 0.16, 0.20, 1.00, 1.50 },
    {  3, 0.20, 0.20, 0.16, 0.20, 1.00, 1.50 },
    {  4, 0.20, 0.18, 0.16, 0.20, 1.00, 1.50 },
    {  5, 0.20, 0.18, 0.16, 0.20, 1.00, 1.50 },
    {  6, 0.20, 0.16, 0.16, 0.20, 1.00, 1.50 },
    {  7, 0.20, 0.16, 0.14, 0.20, 1.00, 1.50 },
    {  8, 0.18, 0.14, 0.14, 0.20, 1.00, 1.50 },
    {  9, 0.16, 0.14, 0.12, 0.20, 1.00, 1.50 },
    { 10, 0.14, 0.12, 0.12, 0.20, 1.00, 1.50 },
    { 11, 0.12, 0.12, 0.12, 0.20, 1.00, 1.50 },
    { 12, 0.10, 0.10, 0.12, 0.20, 1.00, 1.50 },
    { 13, 0.08, 0.10, 0.10, 0.20, 1.00, 1.50 },
    { 14, 0.06, 0.08, 0.10, 0.20, 1.00, 1.50 },
    { 15, 0.04, 0.08, 0.10, 0.20, 1.00, 1.50 },
    { 16, 0.06, 0.10, 0.10, 0.20, 1.00, 1.50 },
    { 17, 0.08, 0.10, 0.10, 0.20, 1.00, 1.50 },
    { 18, 0.10, 0.12, 0.12, 0.20, 1.00, 1.50 },
    { 19, 0.12, 0.12, 0.12, 0.20, 1.00, 1.50 },
    { 20, 0.14, 0.14, 0.12, 0.20, 1.00, 1.50 },
    { 21, 0.16, 0.14, 0.12, 0.20, 1.00, 1.50 },
    { 22, 0.18, 0.16, 0.14, 0.20, 1.00, 1.50 },
    { 23, 0.20, 0.16, 0.14, 0.20, 1.00, 1.50 }
};

int main()
{
    // Step 1: create a fuel moisture observation station 
    Sem::SurfaceFireMoistureTimeLag* moisture =
        new Sem::SurfaceFireMoistureTimeLag();

    // Step 2: create standard fire behavior fuel models 1 (short grass)
    // and 4 (chaparral) and have them get their fuel moisture
    // from the same moisture station 'mosture'
    Sem::SurfaceFireFuelModel* fuel01 = Sem::createFuelModel( 1, moisture );
    Sem::SurfaceFireFuelModel* fuel04 = Sem::createFuelModel( 4, moisture );

    // Step 3: create a terrain instance with 100% slope and south aspect
    Sem::SurfaceFireTerrain* terrain = new Sem::SurfaceFireTerrain( 100., 180. );

    // Step 4: create a wind observation station
    // and initialize it to 5 mph wind blowing from the south.
    Sem::SurfaceFireWind* wind = new Sem::SurfaceFireWind( 5., 180. );

    // Step 5: create a surface fire for each of the two fuel models
    // that uses the terrain and wind instances
    Sem::SurfaceFireSpread* fire01 =
        new Sem::SurfaceFireSpread( fuel01, terrain, wind );
    Sem::SurfaceFireSpread* fire04 =
        new Sem::SurfaceFireSpread( fuel04, terrain, wind );

    // Step 6: update the 'moisture' station for each hour of data
    // and print its effects on the fire behavior in the two fuel types
    fprintf( stdout, "      1: Short Grass     4: Chaparral\n" );
    fprintf( stdout, "Obs    Spread  Flame    Spread  Flame\n" );
    fprintf( stdout, "Time   ft/min     ft    ft/min     ft\n" );
    for ( int i=0; i<24; i++ )
    {
        moisture->setDead1h( Forecast[i].dead1 );
        moisture->setDead10h( Forecast[i].dead10 );
        moisture->setDead100h( Forecast[i].dead100 );
        moisture->setDead1000h( Forecast[i].dead1000 );
        moisture->setLiveHerb( Forecast[i].liveHerb );
        moisture->setLiveWood( Forecast[i].liveWood );

        fprintf( stdout, "%04d:  %6.1f %6.1f    %6.1f %6.1f\n",
            100*i,
            fire01->spreadRateAtHead(),
            fire01->flameLengthAtHead(),
            fire04->spreadRateAtHead(),
            fire04->flameLengthAtHead()
        );
    }
    return( 0 );
}

