from mypackage.math.basic import *
