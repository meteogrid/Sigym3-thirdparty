Doctests: run doctests with nose
================================

.. autoplugin :: nose.plugins.doctests
