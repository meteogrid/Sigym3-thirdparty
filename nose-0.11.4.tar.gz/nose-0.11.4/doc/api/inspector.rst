Traceback inspector
===================

.. automodule :: nose.inspector
   :members: