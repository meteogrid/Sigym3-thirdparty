from fanstatic import Library

library = Library('extjs', 'resources')
