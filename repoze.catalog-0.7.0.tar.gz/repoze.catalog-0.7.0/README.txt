================
 repoze.catalog
================

An indexing and searching system based on ``zope.index
<http://pypi.python.org/pypi/zope.index>`_.

See the ``docs`` subdirectory for documentation.

